(function() {
  var AutoLaunch, URL, autoLaunchPath, autoLauncher, clipboard, convertEmoji, drawAvatar, escapeRegExp, fixlink, getImageUrl, getProxiedName, initialsof, insertTextAtCursor, isAboutLink, isContentPasteable, isImg, later, linkto, nameof, nameofconv, notificationCenterSupportsSound, notifier, throttle, toggleVisibility, topof, tryparse, uniqfn, vesrions;

  URL = require('url');

  notifier = require('node-notifier');

  AutoLaunch = require('auto-launch');

  clipboard = require('electron').clipboard;

  
  // Checks if the clipboard has pasteable content.

  // Currently only text and images are supported

  isContentPasteable = function() {
    var content, formats, j, len, pasteableContent;
    formats = clipboard.availableFormats();
    // as more content is supported in clipboard it should be placed here
    pasteableContent = ['text/plain', 'image/png'];
    isContentPasteable = 0;
    for (j = 0, len = formats.length; j < len; j++) {
      content = formats[j];
      isContentPasteable += pasteableContent.includes(content);
    }
    return isContentPasteable > 0;
  };

  notificationCenterSupportsSound = function() {
    var notifierSupportsSound, playSoundIn;
    // check if sound should be played via notification
    //  documentation says that only WindowsToaster and
    //  NotificationCenter supports sound
    playSoundIn = ['WindowsToaster', 'NotificationCenter'];
    // check if currect notifier supports sound
    return notifierSupportsSound = playSoundIn.find(function(str) {
      return str === notifier.constructor.name;
    }) != null;
  };

  nameof = function(e) {
    var ref, ref1, ref2;
    return (ref = (ref1 = (ref2 = e != null ? e.display_name : void 0) != null ? ref2 : e != null ? e.fallback_name : void 0) != null ? ref1 : e != null ? e.first_name : void 0) != null ? ref : 'Unknown';
  };

  initialsof = function(e) {
    var firstname, lastname, name, name_splitted, name_to_split, ref;
    if (e != null ? e.first_name : void 0) {
      name = nameof(e);
      firstname = e != null ? e.first_name : void 0;
      return firstname.charAt(0) + name.replace(firstname, "").charAt(1);
    } else if ((e != null ? e.display_name : void 0) || (e != null ? e.fallback_name : void 0)) {
      name_to_split = (ref = e != null ? e.display_name : void 0) != null ? ref : e != null ? e.fallback_name : void 0;
      name_splitted = name_to_split.split(' ');
      firstname = name_splitted[0].charAt(0);
      if (name_splitted.length === 1) {
        return firstname.charAt(0);
      // just in case something strange
      } else if ((name_splitted != null ? name_splitted.length : void 0) === 0) {
        return '?';
      } else {
        lastname = name_splitted[name_splitted.length - 1];
        return firstname.charAt(0) + lastname.charAt(0);
      }
    } else {
      return '?';
    }
  };

  drawAvatar = function(user_id, viewstate, entity, image = null, email = null, initials = null) {
    var initialsCode, ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7;
    if (entity[user_id] == null) {
      
      entity.needEntity(user_id);
    }
    if (entity[user_id] != null) {
      
      // overwrites if entity is cached
      initials = initialsof(entity[user_id]).toUpperCase();
    }
    if (((ref = entity[user_id]) != null ? (ref1 = ref.emails) != null ? ref1[0] : void 0 : void 0) == null) {
      email = (ref2 = entity[user_id]) != null ? (ref3 = ref2.emails) != null ? ref3[0] : void 0 : void 0;
    }
    if (((ref4 = entity[user_id]) != null ? ref4.photo_url : void 0) != null) {
      image = (ref5 = entity[user_id]) != null ? ref5.photo_url : void 0;
    }
    
    // Reproducible color code for initials
    //  see global.less for the color mapping [-1-25]
    //     -1: ? initials
    //   0-25: should be a uniform distribution of colors per users
    initialsCode = (ref6 = (ref7 = viewstate.cachedInitialsCode) != null ? ref7[user_id] : void 0) != null ? ref6 : (isNaN(user_id) ? initialsCode = -1 : initialsCode = user_id % 26);
    
    return div({
      class: 'avatar',
      'data-id': user_id
    }, function() {
      if (image != null) {
        if (!(viewstate != null ? viewstate.showAnimatedThumbs : void 0)) {
          image += "?sz=50";
        }
        
        img({
          src: fixlink(image),
          "data-initials": initials,
          class: 'fallback-on',
          onerror: function(ev) {
            // in case the image is not available, it
            //  fallbacks to initials
            return ev.target.parentElement.classList.add("fallback-on");
          },
          onload: function(ev) {
            // when loading successfuly, update again all other imgs
            return ev.target.parentElement.classList.remove("fallback-on");
          }
        });
      }
      return div({
        class: `initials ${(image ? 'fallback' : '')}`,
        'data-first-letter': initialsCode
      }, initials);
    });
  };

  nameofconv = function(c) {
    var entity, ents, name, names, one_to_one, p, part, ref, ref1;
    ({entity} = require('./models'));
    part = (ref = c != null ? c.current_participant : void 0) != null ? ref : [];
    ents = (function() {
      var j, len, results;
      results = [];
      for (j = 0, len = part.length; j < len; j++) {
        p = part[j];
        if (!entity.isSelf(p.chat_id)) {
          results.push(entity[p.chat_id]);
        }
      }
      return results;
    })();
    name = "";
    one_to_one = (c != null ? (ref1 = c.type) != null ? ref1.indexOf('ONE_TO_ONE') : void 0 : void 0) >= 0;
    if (((c != null ? c.name : void 0) != null) && !one_to_one) {
      name = c.name;
    } else {
      // all entities in conversation that is not self
      // the names of those entities
      names = ents.map(nameof);
      // joined together in a compelling manner
      name = names.join(', ');
    }
    return name;
  };

  linkto = function(c) {
    return `https://plus.google.com/u/0/${c}/about`;
  };

  later = function(f) {
    return setTimeout(f, 1);
  };

  throttle = function(ms, f) {
    var g, last, tim;
    last = 0;
    tim = null;
    return g = function(...as) {
      var d, ret;
      if (tim) {
        clearTimeout(tim);
      }
      if ((d = Date.now() - last) > ms) {
        ret = f(...as);
        last = Date.now();
        return ret;
      } else {
        // ensure that last event is always fired
        tim = setTimeout((function() {
          return g(...as);
        }), d);
        return void 0;
      }
    };
  };

  isAboutLink = function(s) {
    var ref;
    return ((ref = /https:\/\/plus.google.com\/u\/0\/([0-9]+)\/about/.exec(s)) != null ? ref : [])[1];
  };

  getProxiedName = function(e) {
    var ref, ref1, ref2, ref3, ref4, s;
    s = e != null ? (ref = e.chat_message) != null ? (ref1 = ref.message_content) != null ? (ref2 = ref1.segment) != null ? ref2[0] : void 0 : void 0 : void 0 : void 0;
    if (!s) {
      return;
    }
    return (s != null ? (ref3 = s.formatting) != null ? ref3.bold : void 0 : void 0) && isAboutLink(s != null ? (ref4 = s.link_data) != null ? ref4.link_target : void 0 : void 0);
  };

  tryparse = function(s) {
    var err;
    try {
      return JSON.parse(s);
    } catch (error) {
      err = error;
      return void 0;
    }
  };

  fixlink = function(l) {
    if ((l != null ? l[0] : void 0) === '/') {
      return `https:${l}`;
    } else {
      return l;
    }
  };

  topof = function(el) {
    return (el != null ? el.offsetTop : void 0) + ((el != null ? el.offsetParent : void 0) ? topof(el.offsetParent) : 0);
  };

  uniqfn = function(as, fn) {
    var fned;
    fned = as.map(fn);
    return as.filter(function(v, i) {
      return fned.indexOf(fned[i]) === i;
    });
  };

  isImg = function(url) {
    return url != null ? url.match(/\.(png|jpe?g|gif|svg)$/i) : void 0;
  };

  getImageUrl = function(url = "") {
    var parsed;
    if (isImg(url)) {
      return url;
    }
    parsed = URL.parse(url, true);
    url = parsed.query.q;
    if (isImg(url)) {
      return url;
    }
    return false;
  };

  toggleVisibility = function(element) {
    if (element.style.display === 'block') {
      return element.style.display = 'none';
    } else {
      return element.style.display = 'block';
    }
  };

  escapeRegExp = function(text) {
    return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
  };

  convertEmoji = function(text) {
    var el, emojiCodeRegex, inferedPattern, patterns, unicodeMap;
    unicodeMap = require('./emojishortcode');
    inferedPattern = "(^|[ ])" + "(:\\(:\\)|:\\(\\|\\)|:X\\)|:3|\\(=\\^\\.\\.\\^=\\)|\\(=\\^\\.\\^=\\)|=\\^_\\^=|" + ((function() {
      var j, len, ref, results;
      ref = Object.keys(unicodeMap);
      results = [];
      for (j = 0, len = ref.length; j < len; j++) {
        el = ref[j];
        results.push(escapeRegExp(el));
      }
      return results;
    })()).join('|') + ")([ ]|$)";
    patterns = [inferedPattern];
    emojiCodeRegex = new RegExp(patterns.join('|'), 'g');
    text = text.replace(emojiCodeRegex, function(emoji) {
      var prefix, suffix, unicode;
      suffix = emoji.slice(emoji.trimRight().length);
      prefix = emoji.slice(0, emoji.length - emoji.trimLeft().length);
      unicode = unicodeMap[emoji.trim()];
      if (unicode != null) {
        return prefix + unicode + suffix;
      } else {
        return emoji;
      }
    });
    return text;
  };

  insertTextAtCursor = function(el, text) {
    var doc, endIndex, range, value;
    value = el.value;
    doc = el.ownerDocument;
    if (typeof el.selectionStart === "number" && typeof el.selectionEnd === "number") {
      endIndex = el.selectionEnd;
      el.value = value.slice(0, endIndex) + text + value.slice(endIndex);
      el.selectionStart = el.selectionEnd = endIndex + text.length;
      return el.focus();
    } else if (doc.selection !== "undefined" && doc.selection.createRange) {
      el.focus();
      range = doc.selection.createRange();
      range.collapse(false);
      range.text = text;
      return range.select();
    }
  };

  // AutoLaunch requires a path unless you are running in electron/nw
  vesrions = typeof process !== "undefined" && process !== null ? process.versions : void 0;

  if ((typeof versions !== "undefined" && versions !== null) && ((versions.nw != null) || (versions['node-webkit'] != null) || (versions.electron != null))) {
    autoLaunchPath = void 0;
  } else {
    autoLaunchPath = process.execPath;
  }

  autoLauncher = new AutoLaunch({
    name: 'YakYak',
    path: autoLaunchPath
  });

  module.exports = {nameof, initialsof, nameofconv, linkto, later, throttle, uniqfn, isAboutLink, getProxiedName, tryparse, fixlink, topof, isImg, getImageUrl, toggleVisibility, convertEmoji, drawAvatar, notificationCenterSupportsSound, insertTextAtCursor, isContentPasteable, autoLauncher};

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvdXRpbC5qcyIsInNvdXJjZXMiOlsidWkvdXRpbC5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLFVBQUEsRUFBQSxHQUFBLEVBQUEsY0FBQSxFQUFBLFlBQUEsRUFBQSxTQUFBLEVBQUEsWUFBQSxFQUFBLFVBQUEsRUFBQSxZQUFBLEVBQUEsT0FBQSxFQUFBLFdBQUEsRUFBQSxjQUFBLEVBQUEsVUFBQSxFQUFBLGtCQUFBLEVBQUEsV0FBQSxFQUFBLGtCQUFBLEVBQUEsS0FBQSxFQUFBLEtBQUEsRUFBQSxNQUFBLEVBQUEsTUFBQSxFQUFBLFVBQUEsRUFBQSwrQkFBQSxFQUFBLFFBQUEsRUFBQSxRQUFBLEVBQUEsZ0JBQUEsRUFBQSxLQUFBLEVBQUEsUUFBQSxFQUFBLE1BQUEsRUFBQTs7RUFBQSxHQUFBLEdBQVksT0FBQSxDQUFRLEtBQVI7O0VBQ1osUUFBQSxHQUFZLE9BQUEsQ0FBUSxlQUFSOztFQUNaLFVBQUEsR0FBYSxPQUFBLENBQVEsYUFBUjs7RUFDYixTQUFBLEdBQVksT0FBQSxDQUFRLFVBQVIsQ0FBbUIsQ0FBQyxVQUhoQzs7Ozs7OztFQVdBLGtCQUFBLEdBQXFCLFFBQUEsQ0FBQSxDQUFBO0FBQ2pCLFFBQUEsT0FBQSxFQUFBLE9BQUEsRUFBQSxDQUFBLEVBQUEsR0FBQSxFQUFBO0lBQUEsT0FBQSxHQUFVLFNBQVMsQ0FBQyxnQkFBVixDQUFBLEVBQVY7O0lBRUEsZ0JBQUEsR0FBbUIsQ0FBQyxZQUFELEVBQWUsV0FBZjtJQUNuQixrQkFBQSxHQUFxQjtJQUNyQixLQUFBLHlDQUFBOztNQUNJLGtCQUFBLElBQXNCLGdCQUFnQixDQUFDLFFBQWpCLENBQTBCLE9BQTFCO0lBRDFCO1dBRUEsa0JBQUEsR0FBcUI7RUFQSjs7RUFTckIsK0JBQUEsR0FBa0MsUUFBQSxDQUFBLENBQUE7QUFJOUIsUUFBQSxxQkFBQSxFQUFBLFdBQUE7Ozs7SUFBQSxXQUFBLEdBQWMsQ0FBQyxnQkFBRCxFQUFtQixvQkFBbkIsRUFBZDs7V0FFQSxxQkFBQSxHQUF3Qjs7O0VBTk07O0VBVWxDLE1BQUEsR0FBUyxRQUFBLENBQUMsQ0FBRCxDQUFBO0FBQU8sUUFBQSxHQUFBLEVBQUEsSUFBQSxFQUFBO2tNQUFxRDtFQUE1RDs7RUFFVCxVQUFBLEdBQWEsUUFBQSxDQUFDLENBQUQsQ0FBQTtBQUNULFFBQUEsU0FBQSxFQUFBLFFBQUEsRUFBQSxJQUFBLEVBQUEsYUFBQSxFQUFBLGFBQUEsRUFBQTtJQUFBLGdCQUFHLENBQUMsQ0FBRSxtQkFBTjtNQUNJLElBQUEsR0FBTyxNQUFBLENBQU8sQ0FBUDtNQUNQLFNBQUEsZUFBWSxDQUFDLENBQUU7QUFDZixhQUFRLFNBQVMsQ0FBQyxNQUFWLENBQWlCLENBQWpCLENBQUEsR0FBc0IsSUFBSSxDQUFDLE9BQUwsQ0FBYSxTQUFiLEVBQXdCLEVBQXhCLENBQTJCLENBQUMsTUFBNUIsQ0FBbUMsQ0FBbkMsRUFIbEM7S0FBQSxNQUlLLGlCQUFHLENBQUMsQ0FBRSxzQkFBSCxpQkFBbUIsQ0FBQyxDQUFFLHVCQUF6QjtNQUNELGFBQUEsMkVBQWtDLENBQUMsQ0FBRTtNQUNyQyxhQUFBLEdBQWdCLGFBQWEsQ0FBQyxLQUFkLENBQW9CLEdBQXBCO01BQ2hCLFNBQUEsR0FBWSxhQUFjLENBQUEsQ0FBQSxDQUFFLENBQUMsTUFBakIsQ0FBd0IsQ0FBeEI7TUFDWixJQUFHLGFBQWEsQ0FBQyxNQUFkLEtBQXdCLENBQTNCO0FBQ0ksZUFBTyxTQUFTLENBQUMsTUFBVixDQUFpQixDQUFqQixFQURYOztPQUFBLE1BR0ssNkJBQUcsYUFBYSxDQUFFLGdCQUFmLEtBQXlCLENBQTVCO0FBQ0QsZUFBTyxJQUROO09BQUEsTUFBQTtRQUdELFFBQUEsR0FBVyxhQUFjLENBQUEsYUFBYSxDQUFDLE1BQWQsR0FBdUIsQ0FBdkI7QUFDekIsZUFBTyxTQUFTLENBQUMsTUFBVixDQUFpQixDQUFqQixDQUFBLEdBQXNCLFFBQVEsQ0FBQyxNQUFULENBQWdCLENBQWhCLEVBSjVCO09BUEo7S0FBQSxNQUFBO0FBYUQsYUFBTyxJQWJOOztFQUxJOztFQW9CYixVQUFBLEdBQWEsUUFBQSxDQUFDLE9BQUQsRUFBVSxTQUFWLEVBQXFCLE1BQXJCLEVBQTZCLFFBQVEsSUFBckMsRUFBMkMsUUFBUSxJQUFuRCxFQUF5RCxXQUFXLElBQXBFLENBQUE7QUFFVCxRQUFBLFlBQUEsRUFBQSxHQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUE7SUFBQSxJQUFrQyx1QkFBbEM7O01BQUEsTUFBTSxDQUFDLFVBQVAsQ0FBa0IsT0FBbEIsRUFBQTs7SUFHQSxJQUF3RCx1QkFBeEQ7OztNQUFBLFFBQUEsR0FBVyxVQUFBLENBQVcsTUFBTyxDQUFBLE9BQUEsQ0FBbEIsQ0FBMkIsQ0FBQyxXQUE1QixDQUFBLEVBQVg7O0lBQ0EsSUFBOEMsbUdBQTlDO01BQUEsS0FBQSx5RUFBb0MsQ0FBQSxDQUFBLG9CQUFwQzs7SUFDQSxJQUF5QyxvRUFBekM7TUFBQSxLQUFBLDBDQUEwQixDQUFFLG1CQUE1QjtLQUxBOzs7Ozs7SUFXQSxZQUFBLG9HQUF3RCxDQUFJLEtBQUEsQ0FBTSxPQUFOLENBQUgsR0FDckQsWUFBQSxHQUFlLENBQUMsQ0FEcUMsR0FHckQsWUFBQSxHQUFlLE9BQUEsR0FBVSxFQUgyQjs7V0FNeEQsR0FBQSxDQUFJO01BQUEsS0FBQSxFQUFPLFFBQVA7TUFBaUIsU0FBQSxFQUFXO0lBQTVCLENBQUosRUFBeUMsUUFBQSxDQUFBLENBQUE7TUFDckMsSUFBRyxhQUFIO1FBQ0ksSUFBRyxzQkFBQyxTQUFTLENBQUUsNEJBQWY7VUFDSSxLQUFBLElBQVMsU0FEYjs7O1FBR0EsR0FBQSxDQUFJO1VBQUEsR0FBQSxFQUFJLE9BQUEsQ0FBUSxLQUFSLENBQUo7VUFDRixlQUFBLEVBQWlCLFFBRGY7VUFFRixLQUFBLEVBQU8sYUFGTDtVQUdELE9BQUEsRUFBUyxRQUFBLENBQUMsRUFBRCxDQUFBLEVBQUE7OzttQkFHUixFQUFFLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsR0FBbEMsQ0FBc0MsYUFBdEM7VUFIUSxDQUhSO1VBT0YsTUFBQSxFQUFRLFFBQUEsQ0FBQyxFQUFELENBQUEsRUFBQTs7bUJBRU4sRUFBRSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLE1BQWxDLENBQXlDLGFBQXpDO1VBRk07UUFQTixDQUFKLEVBSko7O2FBY0EsR0FBQSxDQUFJO1FBQUEsS0FBQSxFQUFPLENBQUEsU0FBQSxDQUFBLENBQVcsQ0FBSSxLQUFILEdBQWMsVUFBZCxHQUE4QixFQUEvQixDQUFYLENBQUEsQ0FBUDtRQUNGLG1CQUFBLEVBQXFCO01BRG5CLENBQUosRUFFRSxRQUZGO0lBZnFDLENBQXpDO0VBbkJTOztFQXNDYixVQUFBLEdBQWEsUUFBQSxDQUFDLENBQUQsQ0FBQTtBQUNULFFBQUEsTUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUEsS0FBQSxFQUFBLFVBQUEsRUFBQSxDQUFBLEVBQUEsSUFBQSxFQUFBLEdBQUEsRUFBQTtJQUFBLENBQUEsQ0FBQyxNQUFELENBQUEsR0FBVyxPQUFBLENBQVEsVUFBUixDQUFYO0lBQ0EsSUFBQSxzRUFBZ0M7SUFDaEMsSUFBQTs7QUFBTztNQUFBLEtBQUEsc0NBQUE7O1lBQW1CLENBQUksTUFBTSxDQUFDLE1BQVAsQ0FBYyxDQUFDLENBQUMsT0FBaEI7dUJBQzFCLE1BQU8sQ0FBQSxDQUFDLENBQUMsT0FBRjs7TUFESixDQUFBOzs7SUFFUCxJQUFBLEdBQU87SUFDUCxVQUFBLDhDQUFvQixDQUFFLE9BQVQsQ0FBaUIsWUFBakIsb0JBQUEsSUFBa0M7SUFDL0MsSUFBRyx1Q0FBQSxJQUFhLENBQUksVUFBcEI7TUFDSSxJQUFBLEdBQU8sQ0FBQyxDQUFDLEtBRGI7S0FBQSxNQUFBOzs7TUFLSSxLQUFBLEdBQVEsSUFBSSxDQUFDLEdBQUwsQ0FBUyxNQUFULEVBQVI7O01BRUEsSUFBQSxHQUFPLEtBQUssQ0FBQyxJQUFOLENBQVcsSUFBWCxFQVBYOztBQVFBLFdBQU87RUFmRTs7RUFrQmIsTUFBQSxHQUFTLFFBQUEsQ0FBQyxDQUFELENBQUE7V0FBTyxDQUFBLDRCQUFBLENBQUEsQ0FBK0IsQ0FBL0IsQ0FBaUMsTUFBakM7RUFBUDs7RUFFVCxLQUFBLEdBQVEsUUFBQSxDQUFDLENBQUQsQ0FBQTtXQUFPLFVBQUEsQ0FBVyxDQUFYLEVBQWMsQ0FBZDtFQUFQOztFQUVSLFFBQUEsR0FBVyxRQUFBLENBQUMsRUFBRCxFQUFLLENBQUwsQ0FBQTtBQUNQLFFBQUEsQ0FBQSxFQUFBLElBQUEsRUFBQTtJQUFBLElBQUEsR0FBTztJQUNQLEdBQUEsR0FBTTtXQUNOLENBQUEsR0FBSSxRQUFBLENBQUEsR0FBQyxFQUFELENBQUE7QUFDQSxVQUFBLENBQUEsRUFBQTtNQUFBLElBQW9CLEdBQXBCO1FBQUEsWUFBQSxDQUFhLEdBQWIsRUFBQTs7TUFDQSxJQUFHLENBQUMsQ0FBQSxHQUFLLElBQUksQ0FBQyxHQUFMLENBQUEsQ0FBQSxHQUFhLElBQW5CLENBQUEsR0FBNEIsRUFBL0I7UUFDSSxHQUFBLEdBQU0sQ0FBQSxDQUFFLEdBQUEsRUFBRjtRQUNOLElBQUEsR0FBTyxJQUFJLENBQUMsR0FBTCxDQUFBO2VBQ1AsSUFISjtPQUFBLE1BQUE7O1FBTUksR0FBQSxHQUFNLFVBQUEsQ0FBVyxDQUFDLFFBQUEsQ0FBQSxDQUFBO2lCQUFFLENBQUEsQ0FBRSxHQUFBLEVBQUY7UUFBRixDQUFELENBQVgsRUFBd0IsQ0FBeEI7ZUFDTixPQVBKOztJQUZBO0VBSEc7O0VBY1gsV0FBQSxHQUFjLFFBQUEsQ0FBQyxDQUFELENBQUE7QUFBTyxRQUFBO1dBQUEsb0ZBQThELEVBQTlELENBQWtFLENBQUEsQ0FBQTtFQUF6RTs7RUFFZCxjQUFBLEdBQWlCLFFBQUEsQ0FBQyxDQUFELENBQUE7QUFDYixRQUFBLEdBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUE7SUFBQSxDQUFBLDJIQUErQyxDQUFBLENBQUE7SUFDL0MsSUFBQSxDQUFjLENBQWQ7QUFBQSxhQUFBOztBQUNBLDREQUFvQixDQUFFLHVCQUFmLElBQXdCLFdBQUEsZ0RBQXdCLENBQUUsNkJBQTFCO0VBSGxCOztFQUtqQixRQUFBLEdBQVcsUUFBQSxDQUFDLENBQUQsQ0FBQTtBQUFPLFFBQUE7QUFBQTthQUFJLElBQUksQ0FBQyxLQUFMLENBQVcsQ0FBWCxFQUFKO0tBQUEsYUFBQTtNQUF3QjthQUFTLE9BQWpDOztFQUFQOztFQUVYLE9BQUEsR0FBVSxRQUFBLENBQUMsQ0FBRCxDQUFBO0lBQU8saUJBQUcsQ0FBRyxDQUFBLENBQUEsV0FBSCxLQUFTLEdBQVo7YUFBcUIsQ0FBQSxNQUFBLENBQUEsQ0FBUyxDQUFULENBQUEsRUFBckI7S0FBQSxNQUFBO2FBQXVDLEVBQXZDOztFQUFQOztFQUVWLEtBQUEsR0FBUSxRQUFBLENBQUMsRUFBRCxDQUFBO3lCQUFRLEVBQUUsQ0FBRSxtQkFBSixHQUFnQixlQUFHLEVBQUUsQ0FBRSxzQkFBUCxHQUF5QixLQUFBLENBQU0sRUFBRSxDQUFDLFlBQVQsQ0FBekIsR0FBcUQsQ0FBckQ7RUFBeEI7O0VBRVIsTUFBQSxHQUFTLFFBQUEsQ0FBQyxFQUFELEVBQUssRUFBTCxDQUFBO0FBQ0wsUUFBQTtJQUFBLElBQUEsR0FBTyxFQUFFLENBQUMsR0FBSCxDQUFPLEVBQVA7V0FDUCxFQUFFLENBQUMsTUFBSCxDQUFVLFFBQUEsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUFBO2FBQVUsSUFBSSxDQUFDLE9BQUwsQ0FBYSxJQUFLLENBQUEsQ0FBQSxDQUFsQixDQUFBLEtBQXlCO0lBQW5DLENBQVY7RUFGSzs7RUFJVCxLQUFBLEdBQVEsUUFBQSxDQUFDLEdBQUQsQ0FBQTt5QkFBUyxHQUFHLENBQUUsS0FBTCxDQUFXLHlCQUFYO0VBQVQ7O0VBRVIsV0FBQSxHQUFjLFFBQUEsQ0FBQyxNQUFJLEVBQUwsQ0FBQTtBQUNWLFFBQUE7SUFBQSxJQUFjLEtBQUEsQ0FBTSxHQUFOLENBQWQ7QUFBQSxhQUFPLElBQVA7O0lBQ0EsTUFBQSxHQUFTLEdBQUcsQ0FBQyxLQUFKLENBQVUsR0FBVixFQUFlLElBQWY7SUFDVCxHQUFBLEdBQU0sTUFBTSxDQUFDLEtBQUssQ0FBQztJQUNuQixJQUFjLEtBQUEsQ0FBTSxHQUFOLENBQWQ7QUFBQSxhQUFPLElBQVA7O1dBQ0E7RUFMVTs7RUFPZCxnQkFBQSxHQUFtQixRQUFBLENBQUMsT0FBRCxDQUFBO0lBQ2YsSUFBRyxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQWQsS0FBeUIsT0FBNUI7YUFDSSxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQWQsR0FBd0IsT0FENUI7S0FBQSxNQUFBO2FBR0ksT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFkLEdBQXdCLFFBSDVCOztFQURlOztFQU1uQixZQUFBLEdBQWUsUUFBQSxDQUFDLElBQUQsQ0FBQTtXQUNiLElBQUksQ0FBQyxPQUFMLENBQWEsMEJBQWIsRUFBeUMsTUFBekM7RUFEYTs7RUFHZixZQUFBLEdBQWUsUUFBQSxDQUFDLElBQUQsQ0FBQTtBQUNYLFFBQUEsRUFBQSxFQUFBLGNBQUEsRUFBQSxjQUFBLEVBQUEsUUFBQSxFQUFBO0lBQUEsVUFBQSxHQUFhLE9BQUEsQ0FBUSxrQkFBUjtJQUNiLGNBQUEsR0FBaUIsU0FBQSxHQUNqQixpRkFEaUIsR0FFakI7O0FBQWtCO0FBQUE7TUFBQSxLQUFBLHFDQUFBOztxQkFBakIsWUFBQSxDQUFhLEVBQWI7TUFBaUIsQ0FBQTs7UUFBbEIsQ0FBb0QsQ0FBQyxJQUFyRCxDQUEwRCxHQUExRCxDQUZpQixHQUdqQjtJQUVBLFFBQUEsR0FBVyxDQUFDLGNBQUQ7SUFFWCxjQUFBLEdBQWlCLElBQUksTUFBSixDQUFXLFFBQVEsQ0FBQyxJQUFULENBQWMsR0FBZCxDQUFYLEVBQThCLEdBQTlCO0lBRWpCLElBQUEsR0FBTyxJQUFJLENBQUMsT0FBTCxDQUFhLGNBQWIsRUFBNkIsUUFBQSxDQUFDLEtBQUQsQ0FBQTtBQUNoQyxVQUFBLE1BQUEsRUFBQSxNQUFBLEVBQUE7TUFBQSxNQUFBLEdBQVMsS0FBSyxDQUFDLEtBQU4sQ0FBWSxLQUFLLENBQUMsU0FBTixDQUFBLENBQWlCLENBQUMsTUFBOUI7TUFDVCxNQUFBLEdBQVMsS0FBSyxDQUFDLEtBQU4sQ0FBWSxDQUFaLEVBQWUsS0FBSyxDQUFDLE1BQU4sR0FBZSxLQUFLLENBQUMsUUFBTixDQUFBLENBQWdCLENBQUMsTUFBL0M7TUFDVCxPQUFBLEdBQVUsVUFBVyxDQUFBLEtBQUssQ0FBQyxJQUFOLENBQUEsQ0FBQTtNQUNyQixJQUFHLGVBQUg7ZUFDSSxNQUFBLEdBQVMsT0FBVCxHQUFtQixPQUR2QjtPQUFBLE1BQUE7ZUFHSSxNQUhKOztJQUpnQyxDQUE3QjtBQVNQLFdBQU87RUFwQkk7O0VBc0JmLGtCQUFBLEdBQXFCLFFBQUEsQ0FBQyxFQUFELEVBQUssSUFBTCxDQUFBO0FBQ2pCLFFBQUEsR0FBQSxFQUFBLFFBQUEsRUFBQSxLQUFBLEVBQUE7SUFBQSxLQUFBLEdBQVEsRUFBRSxDQUFDO0lBQ1gsR0FBQSxHQUFNLEVBQUUsQ0FBQztJQUNULElBQUcsT0FBTyxFQUFFLENBQUMsY0FBVixLQUE0QixRQUE1QixJQUF5QyxPQUFPLEVBQUUsQ0FBQyxZQUFWLEtBQTBCLFFBQXRFO01BQ0ksUUFBQSxHQUFXLEVBQUUsQ0FBQztNQUNkLEVBQUUsQ0FBQyxLQUFILEdBQVcsS0FBSyxDQUFDLEtBQU4sQ0FBWSxDQUFaLEVBQWUsUUFBZixDQUFBLEdBQTJCLElBQTNCLEdBQWtDLEtBQUssQ0FBQyxLQUFOLENBQVksUUFBWjtNQUM3QyxFQUFFLENBQUMsY0FBSCxHQUFvQixFQUFFLENBQUMsWUFBSCxHQUFrQixRQUFBLEdBQVcsSUFBSSxDQUFDO2FBQ3RELEVBQUUsQ0FBQyxLQUFILENBQUEsRUFKSjtLQUFBLE1BS0ssSUFBRyxHQUFHLENBQUMsU0FBSixLQUFpQixXQUFqQixJQUFpQyxHQUFHLENBQUMsU0FBUyxDQUFDLFdBQWxEO01BQ0QsRUFBRSxDQUFDLEtBQUgsQ0FBQTtNQUNBLEtBQUEsR0FBUSxHQUFHLENBQUMsU0FBUyxDQUFDLFdBQWQsQ0FBQTtNQUNSLEtBQUssQ0FBQyxRQUFOLENBQWUsS0FBZjtNQUNBLEtBQUssQ0FBQyxJQUFOLEdBQWE7YUFDYixLQUFLLENBQUMsTUFBTixDQUFBLEVBTEM7O0VBUlksRUF2THJCOzs7RUF1TUEsUUFBQSx3REFBVyxPQUFPLENBQUU7O0VBQ3BCLElBQUcsc0RBQUEsSUFBYyxDQUFDLHFCQUFBLElBQWdCLGlDQUFoQixJQUE0QywyQkFBN0MsQ0FBakI7SUFDSSxjQUFBLEdBQWlCLE9BRHJCO0dBQUEsTUFBQTtJQUdJLGNBQUEsR0FBaUIsT0FBTyxDQUFDLFNBSDdCOzs7RUFJQSxZQUFBLEdBQWUsSUFBSSxVQUFKLENBQWU7SUFDMUIsSUFBQSxFQUFNLFFBRG9CO0lBRTFCLElBQUEsRUFBTTtFQUZvQixDQUFmOztFQUtmLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLENBQUMsTUFBRCxFQUFTLFVBQVQsRUFBcUIsVUFBckIsRUFBaUMsTUFBakMsRUFBeUMsS0FBekMsRUFDQyxRQURELEVBQ1csTUFEWCxFQUNtQixXQURuQixFQUNnQyxjQURoQyxFQUNnRCxRQURoRCxFQUVDLE9BRkQsRUFFVSxLQUZWLEVBRWlCLEtBRmpCLEVBRXdCLFdBRnhCLEVBRXFDLGdCQUZyQyxFQUdDLFlBSEQsRUFHZSxVQUhmLEVBRzJCLCtCQUgzQixFQUlDLGtCQUpELEVBSXFCLGtCQUpyQixFQUl5QyxZQUp6QztBQWpOakIiLCJzb3VyY2VzQ29udGVudCI6WyJVUkwgICAgICAgPSByZXF1aXJlICd1cmwnXG5ub3RpZmllciAgPSByZXF1aXJlICdub2RlLW5vdGlmaWVyJ1xuQXV0b0xhdW5jaCA9IHJlcXVpcmUgJ2F1dG8tbGF1bmNoJ1xuY2xpcGJvYXJkID0gcmVxdWlyZSgnZWxlY3Ryb24nKS5jbGlwYm9hcmRcblxuI1xuI1xuIyBDaGVja3MgaWYgdGhlIGNsaXBib2FyZCBoYXMgcGFzdGVhYmxlIGNvbnRlbnQuXG4jXG4jIEN1cnJlbnRseSBvbmx5IHRleHQgYW5kIGltYWdlcyBhcmUgc3VwcG9ydGVkXG4jXG5pc0NvbnRlbnRQYXN0ZWFibGUgPSAoKSAtPlxuICAgIGZvcm1hdHMgPSBjbGlwYm9hcmQuYXZhaWxhYmxlRm9ybWF0cygpXG4gICAgIyBhcyBtb3JlIGNvbnRlbnQgaXMgc3VwcG9ydGVkIGluIGNsaXBib2FyZCBpdCBzaG91bGQgYmUgcGxhY2VkIGhlcmVcbiAgICBwYXN0ZWFibGVDb250ZW50ID0gWyd0ZXh0L3BsYWluJywgJ2ltYWdlL3BuZyddXG4gICAgaXNDb250ZW50UGFzdGVhYmxlID0gMFxuICAgIGZvciBjb250ZW50IGluIGZvcm1hdHNcbiAgICAgICAgaXNDb250ZW50UGFzdGVhYmxlICs9IHBhc3RlYWJsZUNvbnRlbnQuaW5jbHVkZXMoY29udGVudClcbiAgICBpc0NvbnRlbnRQYXN0ZWFibGUgPiAwXG5cbm5vdGlmaWNhdGlvbkNlbnRlclN1cHBvcnRzU291bmQgPSAoKSAtPlxuICAgICMgY2hlY2sgaWYgc291bmQgc2hvdWxkIGJlIHBsYXllZCB2aWEgbm90aWZpY2F0aW9uXG4gICAgIyAgZG9jdW1lbnRhdGlvbiBzYXlzIHRoYXQgb25seSBXaW5kb3dzVG9hc3RlciBhbmRcbiAgICAjICBOb3RpZmljYXRpb25DZW50ZXIgc3VwcG9ydHMgc291bmRcbiAgICBwbGF5U291bmRJbiA9IFsnV2luZG93c1RvYXN0ZXInLCAnTm90aWZpY2F0aW9uQ2VudGVyJ11cbiAgICAjIGNoZWNrIGlmIGN1cnJlY3Qgbm90aWZpZXIgc3VwcG9ydHMgc291bmRcbiAgICBub3RpZmllclN1cHBvcnRzU291bmQgPSBwbGF5U291bmRJbi5maW5kKCAoc3RyKSAtPlxuICAgICAgICBzdHIgPT0gbm90aWZpZXIuY29uc3RydWN0b3IubmFtZVxuICAgICk/XG5cbm5hbWVvZiA9IChlKSAtPiBlPy5kaXNwbGF5X25hbWUgPyBlPy5mYWxsYmFja19uYW1lID8gZT8uZmlyc3RfbmFtZSA/ICdVbmtub3duJ1xuXG5pbml0aWFsc29mID0gKGUpIC0+XG4gICAgaWYgZT8uZmlyc3RfbmFtZVxuICAgICAgICBuYW1lID0gbmFtZW9mIGVcbiAgICAgICAgZmlyc3RuYW1lID0gZT8uZmlyc3RfbmFtZVxuICAgICAgICByZXR1cm4gIGZpcnN0bmFtZS5jaGFyQXQoMCkgKyBuYW1lLnJlcGxhY2UoZmlyc3RuYW1lLCBcIlwiKS5jaGFyQXQoMSlcbiAgICBlbHNlIGlmIGU/LmRpc3BsYXlfbmFtZSB8fCBlPy5mYWxsYmFja19uYW1lXG4gICAgICAgIG5hbWVfdG9fc3BsaXQgPSBlPy5kaXNwbGF5X25hbWUgPyBlPy5mYWxsYmFja19uYW1lXG4gICAgICAgIG5hbWVfc3BsaXR0ZWQgPSBuYW1lX3RvX3NwbGl0LnNwbGl0KCcgJylcbiAgICAgICAgZmlyc3RuYW1lID0gbmFtZV9zcGxpdHRlZFswXS5jaGFyQXQoMClcbiAgICAgICAgaWYgbmFtZV9zcGxpdHRlZC5sZW5ndGggPT0gMVxuICAgICAgICAgICAgcmV0dXJuIGZpcnN0bmFtZS5jaGFyQXQoMClcbiAgICAgICAgIyBqdXN0IGluIGNhc2Ugc29tZXRoaW5nIHN0cmFuZ2VcbiAgICAgICAgZWxzZSBpZiBuYW1lX3NwbGl0dGVkPy5sZW5ndGggPT0gMFxuICAgICAgICAgICAgcmV0dXJuICc/J1xuICAgICAgICBlbHNlXG4gICAgICAgICAgICBsYXN0bmFtZSA9IG5hbWVfc3BsaXR0ZWRbbmFtZV9zcGxpdHRlZC5sZW5ndGggLSAxXVxuICAgICAgICAgICAgcmV0dXJuIGZpcnN0bmFtZS5jaGFyQXQoMCkgKyBsYXN0bmFtZS5jaGFyQXQoMClcbiAgICBlbHNlXG4gICAgICAgIHJldHVybiAnPydcblxuZHJhd0F2YXRhciA9ICh1c2VyX2lkLCB2aWV3c3RhdGUsIGVudGl0eSwgaW1hZ2UgPSBudWxsLCBlbWFpbCA9IG51bGwsIGluaXRpYWxzID0gbnVsbCkgLT5cbiAgICAjXG4gICAgZW50aXR5Lm5lZWRFbnRpdHkodXNlcl9pZCkgdW5sZXNzIGVudGl0eVt1c2VyX2lkXT9cbiAgICAjXG4gICAgIyBvdmVyd3JpdGVzIGlmIGVudGl0eSBpcyBjYWNoZWRcbiAgICBpbml0aWFscyA9IGluaXRpYWxzb2YoZW50aXR5W3VzZXJfaWRdKS50b1VwcGVyQ2FzZSgpIGlmIGVudGl0eVt1c2VyX2lkXT9cbiAgICBlbWFpbCAgICA9IGVudGl0eVt1c2VyX2lkXT8uZW1haWxzP1swXSB1bmxlc3MgZW50aXR5W3VzZXJfaWRdPy5lbWFpbHM/WzBdP1xuICAgIGltYWdlICAgID0gZW50aXR5W3VzZXJfaWRdPy5waG90b191cmwgaWYgZW50aXR5W3VzZXJfaWRdPy5waG90b191cmw/XG4gICAgI1xuICAgICMgUmVwcm9kdWNpYmxlIGNvbG9yIGNvZGUgZm9yIGluaXRpYWxzXG4gICAgIyAgc2VlIGdsb2JhbC5sZXNzIGZvciB0aGUgY29sb3IgbWFwcGluZyBbLTEtMjVdXG4gICAgIyAgICAgLTE6ID8gaW5pdGlhbHNcbiAgICAjICAgMC0yNTogc2hvdWxkIGJlIGEgdW5pZm9ybSBkaXN0cmlidXRpb24gb2YgY29sb3JzIHBlciB1c2Vyc1xuICAgIGluaXRpYWxzQ29kZSA9IHZpZXdzdGF0ZS5jYWNoZWRJbml0aWFsc0NvZGU/W3VzZXJfaWRdID8gKGlmIGlzTmFOKHVzZXJfaWQpXG4gICAgICAgIGluaXRpYWxzQ29kZSA9IC0xXG4gICAgZWxzZVxuICAgICAgICBpbml0aWFsc0NvZGUgPSB1c2VyX2lkICUgMjZcbiAgICApXG4gICAgI1xuICAgIGRpdiBjbGFzczogJ2F2YXRhcicsICdkYXRhLWlkJzogdXNlcl9pZCwgLT5cbiAgICAgICAgaWYgaW1hZ2U/XG4gICAgICAgICAgICBpZiAhdmlld3N0YXRlPy5zaG93QW5pbWF0ZWRUaHVtYnNcbiAgICAgICAgICAgICAgICBpbWFnZSArPSBcIj9zej01MFwiXG4gICAgICAgICAgICAjXG4gICAgICAgICAgICBpbWcgc3JjOmZpeGxpbmsoaW1hZ2UpXG4gICAgICAgICAgICAsIFwiZGF0YS1pbml0aWFsc1wiOiBpbml0aWFsc1xuICAgICAgICAgICAgLCBjbGFzczogJ2ZhbGxiYWNrLW9uJ1xuICAgICAgICAgICAgLCAgb25lcnJvcjogKGV2KSAtPlxuICAgICAgICAgICAgICAgICMgaW4gY2FzZSB0aGUgaW1hZ2UgaXMgbm90IGF2YWlsYWJsZSwgaXRcbiAgICAgICAgICAgICAgICAjICBmYWxsYmFja3MgdG8gaW5pdGlhbHNcbiAgICAgICAgICAgICAgICBldi50YXJnZXQucGFyZW50RWxlbWVudC5jbGFzc0xpc3QuYWRkIFwiZmFsbGJhY2stb25cIlxuICAgICAgICAgICAgLCBvbmxvYWQ6IChldikgLT5cbiAgICAgICAgICAgICAgICAjIHdoZW4gbG9hZGluZyBzdWNjZXNzZnVseSwgdXBkYXRlIGFnYWluIGFsbCBvdGhlciBpbWdzXG4gICAgICAgICAgICAgICAgZXYudGFyZ2V0LnBhcmVudEVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSBcImZhbGxiYWNrLW9uXCJcbiAgICAgICAgZGl2IGNsYXNzOiBcImluaXRpYWxzICN7aWYgaW1hZ2UgdGhlbiAnZmFsbGJhY2snIGVsc2UgJyd9XCJcbiAgICAgICAgLCAnZGF0YS1maXJzdC1sZXR0ZXInOiBpbml0aWFsc0NvZGVcbiAgICAgICAgLCBpbml0aWFsc1xuXG5uYW1lb2Zjb252ID0gKGMpIC0+XG4gICAge2VudGl0eX0gPSByZXF1aXJlICcuL21vZGVscydcbiAgICBwYXJ0ID0gYz8uY3VycmVudF9wYXJ0aWNpcGFudCA/IFtdXG4gICAgZW50cyA9IGZvciBwIGluIHBhcnQgd2hlbiBub3QgZW50aXR5LmlzU2VsZiBwLmNoYXRfaWRcbiAgICAgICAgZW50aXR5W3AuY2hhdF9pZF1cbiAgICBuYW1lID0gXCJcIlxuICAgIG9uZV90b19vbmUgPSBjPy50eXBlPy5pbmRleE9mKCdPTkVfVE9fT05FJykgPj0gMFxuICAgIGlmIGM/Lm5hbWU/IGFuZCBub3Qgb25lX3RvX29uZVxuICAgICAgICBuYW1lID0gYy5uYW1lXG4gICAgZWxzZVxuICAgICAgICAjIGFsbCBlbnRpdGllcyBpbiBjb252ZXJzYXRpb24gdGhhdCBpcyBub3Qgc2VsZlxuICAgICAgICAjIHRoZSBuYW1lcyBvZiB0aG9zZSBlbnRpdGllc1xuICAgICAgICBuYW1lcyA9IGVudHMubWFwIG5hbWVvZlxuICAgICAgICAjIGpvaW5lZCB0b2dldGhlciBpbiBhIGNvbXBlbGxpbmcgbWFubmVyXG4gICAgICAgIG5hbWUgPSBuYW1lcy5qb2luICcsICdcbiAgICByZXR1cm4gbmFtZVxuXG5cbmxpbmt0byA9IChjKSAtPiBcImh0dHBzOi8vcGx1cy5nb29nbGUuY29tL3UvMC8je2N9L2Fib3V0XCJcblxubGF0ZXIgPSAoZikgLT4gc2V0VGltZW91dCBmLCAxXG5cbnRocm90dGxlID0gKG1zLCBmKSAtPlxuICAgIGxhc3QgPSAwXG4gICAgdGltID0gbnVsbFxuICAgIGcgPSAoYXMuLi4pIC0+XG4gICAgICAgIGNsZWFyVGltZW91dCB0aW0gaWYgdGltXG4gICAgICAgIGlmIChkID0gKERhdGUubm93KCkgLSBsYXN0KSkgPiBtc1xuICAgICAgICAgICAgcmV0ID0gZiBhcy4uLlxuICAgICAgICAgICAgbGFzdCA9IERhdGUubm93KClcbiAgICAgICAgICAgIHJldFxuICAgICAgICBlbHNlXG4gICAgICAgICAgICAjIGVuc3VyZSB0aGF0IGxhc3QgZXZlbnQgaXMgYWx3YXlzIGZpcmVkXG4gICAgICAgICAgICB0aW0gPSBzZXRUaW1lb3V0ICgtPmcgYXMuLi4pLCBkXG4gICAgICAgICAgICB1bmRlZmluZWRcblxuaXNBYm91dExpbmsgPSAocykgLT4gKC9odHRwczpcXC9cXC9wbHVzLmdvb2dsZS5jb21cXC91XFwvMFxcLyhbMC05XSspXFwvYWJvdXQvLmV4ZWMocykgPyBbXSlbMV1cblxuZ2V0UHJveGllZE5hbWUgPSAoZSkgLT5cbiAgICBzID0gZT8uY2hhdF9tZXNzYWdlPy5tZXNzYWdlX2NvbnRlbnQ/LnNlZ21lbnQ/WzBdXG4gICAgcmV0dXJuIHVubGVzcyBzXG4gICAgcmV0dXJuIHM/LmZvcm1hdHRpbmc/LmJvbGQgYW5kIGlzQWJvdXRMaW5rKHM/LmxpbmtfZGF0YT8ubGlua190YXJnZXQpXG5cbnRyeXBhcnNlID0gKHMpIC0+IHRyeSBKU09OLnBhcnNlKHMpIGNhdGNoIGVyciB0aGVuIHVuZGVmaW5lZFxuXG5maXhsaW5rID0gKGwpIC0+IGlmIGw/WzBdID09ICcvJyB0aGVuIFwiaHR0cHM6I3tsfVwiIGVsc2UgbFxuXG50b3BvZiA9IChlbCkgLT4gZWw/Lm9mZnNldFRvcCArIGlmIGVsPy5vZmZzZXRQYXJlbnQgdGhlbiB0b3BvZihlbC5vZmZzZXRQYXJlbnQpIGVsc2UgMFxuXG51bmlxZm4gPSAoYXMsIGZuKSAtPlxuICAgIGZuZWQgPSBhcy5tYXAgZm5cbiAgICBhcy5maWx0ZXIgKHYsIGkpIC0+IGZuZWQuaW5kZXhPZihmbmVkW2ldKSA9PSBpXG5cbmlzSW1nID0gKHVybCkgLT4gdXJsPy5tYXRjaCAvXFwuKHBuZ3xqcGU/Z3xnaWZ8c3ZnKSQvaVxuXG5nZXRJbWFnZVVybCA9ICh1cmw9XCJcIikgLT5cbiAgICByZXR1cm4gdXJsIGlmIGlzSW1nIHVybFxuICAgIHBhcnNlZCA9IFVSTC5wYXJzZSB1cmwsIHRydWVcbiAgICB1cmwgPSBwYXJzZWQucXVlcnkucVxuICAgIHJldHVybiB1cmwgaWYgaXNJbWcgdXJsXG4gICAgZmFsc2VcblxudG9nZ2xlVmlzaWJpbGl0eSA9IChlbGVtZW50KSAtPlxuICAgIGlmIGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9PSAnYmxvY2snXG4gICAgICAgIGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9ICdub25lJ1xuICAgIGVsc2VcbiAgICAgICAgZWxlbWVudC5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJ1xuXG5lc2NhcGVSZWdFeHAgPSAodGV4dCkgLT5cbiAgdGV4dC5yZXBsYWNlKC9bLVtcXF17fSgpKis/LixcXFxcXiR8I1xcc10vZywgJ1xcXFwkJicpXG5cbmNvbnZlcnRFbW9qaSA9ICh0ZXh0KSAtPlxuICAgIHVuaWNvZGVNYXAgPSByZXF1aXJlICcuL2Vtb2ppc2hvcnRjb2RlJ1xuICAgIGluZmVyZWRQYXR0ZXJuID0gXCIoXnxbIF0pXCIgK1xuICAgIFwiKDpcXFxcKDpcXFxcKXw6XFxcXChcXFxcfFxcXFwpfDpYXFxcXCl8OjN8XFxcXCg9XFxcXF5cXFxcLlxcXFwuXFxcXF49XFxcXCl8XFxcXCg9XFxcXF5cXFxcLlxcXFxePVxcXFwpfD1cXFxcXl9cXFxcXj18XCIgK1xuICAgIChlc2NhcGVSZWdFeHAoZWwpIGZvciBlbCBpbiBPYmplY3Qua2V5cyh1bmljb2RlTWFwKSkuam9pbignfCcpICtcbiAgICBcIikoWyBdfCQpXCJcblxuICAgIHBhdHRlcm5zID0gW2luZmVyZWRQYXR0ZXJuXVxuXG4gICAgZW1vamlDb2RlUmVnZXggPSBuZXcgUmVnRXhwKHBhdHRlcm5zLmpvaW4oJ3wnKSwnZycpXG5cbiAgICB0ZXh0ID0gdGV4dC5yZXBsYWNlKGVtb2ppQ29kZVJlZ2V4LCAoZW1vamkpIC0+XG4gICAgICAgIHN1ZmZpeCA9IGVtb2ppLnNsaWNlKGVtb2ppLnRyaW1SaWdodCgpLmxlbmd0aClcbiAgICAgICAgcHJlZml4ID0gZW1vamkuc2xpY2UoMCwgZW1vamkubGVuZ3RoIC0gZW1vamkudHJpbUxlZnQoKS5sZW5ndGgpXG4gICAgICAgIHVuaWNvZGUgPSB1bmljb2RlTWFwW2Vtb2ppLnRyaW0oKV1cbiAgICAgICAgaWYgdW5pY29kZT9cbiAgICAgICAgICAgIHByZWZpeCArIHVuaWNvZGUgKyBzdWZmaXhcbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgZW1vamlcbiAgICApXG4gICAgcmV0dXJuIHRleHRcblxuaW5zZXJ0VGV4dEF0Q3Vyc29yID0gKGVsLCB0ZXh0KSAtPlxuICAgIHZhbHVlID0gZWwudmFsdWVcbiAgICBkb2MgPSBlbC5vd25lckRvY3VtZW50XG4gICAgaWYgdHlwZW9mIGVsLnNlbGVjdGlvblN0YXJ0ID09IFwibnVtYmVyXCIgYW5kIHR5cGVvZiBlbC5zZWxlY3Rpb25FbmQgPT0gXCJudW1iZXJcIlxuICAgICAgICBlbmRJbmRleCA9IGVsLnNlbGVjdGlvbkVuZFxuICAgICAgICBlbC52YWx1ZSA9IHZhbHVlLnNsaWNlKDAsIGVuZEluZGV4KSArIHRleHQgKyB2YWx1ZS5zbGljZShlbmRJbmRleClcbiAgICAgICAgZWwuc2VsZWN0aW9uU3RhcnQgPSBlbC5zZWxlY3Rpb25FbmQgPSBlbmRJbmRleCArIHRleHQubGVuZ3RoXG4gICAgICAgIGVsLmZvY3VzKClcbiAgICBlbHNlIGlmIGRvYy5zZWxlY3Rpb24gIT0gXCJ1bmRlZmluZWRcIiBhbmQgZG9jLnNlbGVjdGlvbi5jcmVhdGVSYW5nZVxuICAgICAgICBlbC5mb2N1cygpXG4gICAgICAgIHJhbmdlID0gZG9jLnNlbGVjdGlvbi5jcmVhdGVSYW5nZSgpXG4gICAgICAgIHJhbmdlLmNvbGxhcHNlKGZhbHNlKVxuICAgICAgICByYW5nZS50ZXh0ID0gdGV4dFxuICAgICAgICByYW5nZS5zZWxlY3QoKVxuXG4jIEF1dG9MYXVuY2ggcmVxdWlyZXMgYSBwYXRoIHVubGVzcyB5b3UgYXJlIHJ1bm5pbmcgaW4gZWxlY3Ryb24vbndcbnZlc3Jpb25zID0gcHJvY2Vzcz8udmVyc2lvbnNcbmlmIHZlcnNpb25zPyBhbmQgKHZlcnNpb25zLm53PyBvciB2ZXJzaW9uc1snbm9kZS13ZWJraXQnXT8gb3IgdmVyc2lvbnMuZWxlY3Ryb24/KVxuICAgIGF1dG9MYXVuY2hQYXRoID0gdW5kZWZpbmVkXG5lbHNlXG4gICAgYXV0b0xhdW5jaFBhdGggPSBwcm9jZXNzLmV4ZWNQYXRoXG5hdXRvTGF1bmNoZXIgPSBuZXcgQXV0b0xhdW5jaCh7XG4gICAgbmFtZTogJ1lha1lhaycsXG4gICAgcGF0aDogYXV0b0xhdW5jaFBhdGhcbn0pO1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtuYW1lb2YsIGluaXRpYWxzb2YsIG5hbWVvZmNvbnYsIGxpbmt0bywgbGF0ZXIsXG4gICAgICAgICAgICAgICAgICB0aHJvdHRsZSwgdW5pcWZuLCBpc0Fib3V0TGluaywgZ2V0UHJveGllZE5hbWUsIHRyeXBhcnNlLFxuICAgICAgICAgICAgICAgICAgZml4bGluaywgdG9wb2YsIGlzSW1nLCBnZXRJbWFnZVVybCwgdG9nZ2xlVmlzaWJpbGl0eSxcbiAgICAgICAgICAgICAgICAgIGNvbnZlcnRFbW9qaSwgZHJhd0F2YXRhciwgbm90aWZpY2F0aW9uQ2VudGVyU3VwcG9ydHNTb3VuZCxcbiAgICAgICAgICAgICAgICAgIGluc2VydFRleHRBdEN1cnNvciwgaXNDb250ZW50UGFzdGVhYmxlLCBhdXRvTGF1bmNoZXJ9XG4iXX0=
