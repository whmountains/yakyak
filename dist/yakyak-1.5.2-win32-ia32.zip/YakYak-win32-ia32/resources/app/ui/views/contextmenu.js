(function() {
  var ContextMenu, clipboard, isContentPasteable, remote, templateContext;

  remote = require('electron').remote;

  clipboard = require('electron').clipboard;

  // {download}  = require('electron-dl') # See IMPORTANT below
  ContextMenu = remote.Menu;

  ({isContentPasteable} = require('../util'));

  templateContext = function(params, viewstate) {
    var canShowCopyImgLink, canShowCopyLink, canShowSaveImg;
    
    //          IMPORTANT: currently save images is disabled as there
    //            are exceptions being thrown from the electron-dl module

    canShowSaveImg = params.mediaType === 'image' && false;
    canShowCopyImgLink = params.mediaType === 'image' && params.srcURL !== '';
    canShowCopyLink = params.linkURL !== '' && params.mediaType === 'none';
    return [
      {
        
        label: 'Save Image',
        visible: canShowSaveImg,
        click: function(item,
      win) {
          try {
            return download(win,
      params.srcURL);
          } catch (error) {
            return console.log('Possible problem with saving image. ',
      err);
          }
        }
      },
      canShowSaveImg ? {
        type: 'separator'
      } : void 0,
      {
        label: i18n.__('menu.edit.undo:Undo'),
        role: 'undo',
        enabled: params.editFlags.canUndo,
        visible: true
      },
      {
        label: i18n.__('menu.edit.redo:Redo'),
        role: 'redo',
        enabled: params.editFlags.canRedo,
        visible: true
      },
      {
        type: 'separator'
      },
      {
        label: i18n.__('menu.edit.cut:Cut'),
        role: 'cut',
        enabled: params.editFlags.canCut,
        visible: true
      },
      {
        label: i18n.__('menu.edit.copy:Copy'),
        role: 'copy',
        enabled: params.editFlags.canCopy,
        visible: true
      },
      {
        label: i18n.__('menu.edit.copy_link:Copy Link'),
        visible: canShowCopyLink,
        click: function() {
          if (process.platform === 'darwin') {
            return clipboard.writeBookmark(params.linkText,
      params.linkText);
          } else {
            return clipboard.writeText(params.linkText);
          }
        }
      },
      {
        label: i18n.__('menu.edit.copy_image_link:Copy Image Link'),
        visible: canShowCopyImgLink,
        click: function(item,
      win) {
          if (process.platform === 'darwin') {
            return clipboard.writeBookmark(params.srcURL,
      params.srcURL);
          } else {
            return clipboard.writeText(params.srcURL);
          }
        }
      },
      {
        label: i18n.__('menu.edit.paste:Paste'),
        role: 'paste',
        visible: (isContentPasteable() && viewstate.state === viewstate.STATE_NORMAL) || params.isEditable
      }
    ].filter(function(n) {
      return n !== void 0;
    });
  };

  module.exports = function(e, viewstate) {
    return ContextMenu.buildFromTemplate(templateContext(e, viewstate));
  };

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvdmlld3MvY29udGV4dG1lbnUuanMiLCJzb3VyY2VzIjpbInVpL3ZpZXdzL2NvbnRleHRtZW51LmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUEsV0FBQSxFQUFBLFNBQUEsRUFBQSxrQkFBQSxFQUFBLE1BQUEsRUFBQTs7RUFBQSxNQUFBLEdBQWMsT0FBQSxDQUFRLFVBQVIsQ0FBbUIsQ0FBQzs7RUFDbEMsU0FBQSxHQUFjLE9BQUEsQ0FBUSxVQUFSLENBQW1CLENBQUMsVUFEbEM7OztFQUdBLFdBQUEsR0FBYyxNQUFNLENBQUM7O0VBRXJCLENBQUEsQ0FBQyxrQkFBRCxDQUFBLEdBQXVCLE9BQUEsQ0FBUSxTQUFSLENBQXZCOztFQUVBLGVBQUEsR0FBa0IsUUFBQSxDQUFDLE1BQUQsRUFBUyxTQUFULENBQUE7QUFLZCxRQUFBLGtCQUFBLEVBQUEsZUFBQSxFQUFBLGNBQUE7Ozs7O0lBQUEsY0FBQSxHQUFpQixNQUFNLENBQUMsU0FBUCxLQUFvQixPQUFwQixJQUErQjtJQUNoRCxrQkFBQSxHQUFxQixNQUFNLENBQUMsU0FBUCxLQUFvQixPQUFwQixJQUErQixNQUFNLENBQUMsTUFBUCxLQUFpQjtJQUNyRSxlQUFBLEdBQWtCLE1BQU0sQ0FBQyxPQUFQLEtBQWtCLEVBQWxCLElBQXdCLE1BQU0sQ0FBQyxTQUFQLEtBQW9CO1dBRTlEO01BQUM7O1FBQ0csS0FBQSxFQUFPLFlBRFY7UUFFRyxPQUFBLEVBQVMsY0FGWjtRQUdHLEtBQUEsRUFBTyxRQUFBLENBQUMsSUFBRDtNQUFPLEdBQVAsQ0FBQTtBQUNIO21CQUNJLFFBQUEsQ0FBUyxHQUFUO01BQWMsTUFBTSxDQUFDLE1BQXJCLEVBREo7V0FBQSxhQUFBO21CQUdJLE9BQU8sQ0FBQyxHQUFSLENBQVksc0NBQVo7TUFBb0QsR0FBcEQsRUFISjs7UUFERztNQUhWLENBQUQ7TUFTeUIsY0FBekIsR0FBQTtRQUFFLElBQUEsRUFBTTtNQUFSLENBQUEsR0FBQSxNQVRBO01BVUE7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxxQkFBUixDQURYO1FBRUksSUFBQSxFQUFNLE1BRlY7UUFHSSxPQUFBLEVBQVMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxPQUg5QjtRQUlJLE9BQUEsRUFBUztNQUpiLENBVkE7TUFnQkE7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxxQkFBUixDQURYO1FBRUksSUFBQSxFQUFNLE1BRlY7UUFHSSxPQUFBLEVBQVMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxPQUg5QjtRQUlJLE9BQUEsRUFBUztNQUpiLENBaEJBO01Bc0JBO1FBQUUsSUFBQSxFQUFNO01BQVIsQ0F0QkE7TUF1QkE7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxtQkFBUixDQURYO1FBRUksSUFBQSxFQUFNLEtBRlY7UUFHSSxPQUFBLEVBQVMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxNQUg5QjtRQUlJLE9BQUEsRUFBUztNQUpiLENBdkJBO01BNkJBO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEscUJBQVIsQ0FEWDtRQUVJLElBQUEsRUFBTSxNQUZWO1FBR0ksT0FBQSxFQUFTLE1BQU0sQ0FBQyxTQUFTLENBQUMsT0FIOUI7UUFJSSxPQUFBLEVBQVM7TUFKYixDQTdCQTtNQW1DQTtRQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLCtCQUFSLENBRFg7UUFFSSxPQUFBLEVBQVMsZUFGYjtRQUdJLEtBQUEsRUFBTyxRQUFBLENBQUEsQ0FBQTtVQUNILElBQUcsT0FBTyxDQUFDLFFBQVIsS0FBb0IsUUFBdkI7bUJBQ0ksU0FBUyxDQUFDLGFBQVYsQ0FBd0IsTUFBTSxDQUFDLFFBQS9CO01BQXlDLE1BQU0sQ0FBQyxRQUFoRCxFQURKO1dBQUEsTUFBQTttQkFHSSxTQUFTLENBQUMsU0FBVixDQUFvQixNQUFNLENBQUMsUUFBM0IsRUFISjs7UUFERztNQUhYLENBbkNBO01BNENBO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsMkNBQVIsQ0FEWDtRQUVJLE9BQUEsRUFBUyxrQkFGYjtRQUdJLEtBQUEsRUFBTyxRQUFBLENBQUMsSUFBRDtNQUFPLEdBQVAsQ0FBQTtVQUNILElBQUcsT0FBTyxDQUFDLFFBQVIsS0FBb0IsUUFBdkI7bUJBQ0ksU0FBUyxDQUFDLGFBQVYsQ0FBd0IsTUFBTSxDQUFDLE1BQS9CO01BQXVDLE1BQU0sQ0FBQyxNQUE5QyxFQURKO1dBQUEsTUFBQTttQkFHSSxTQUFTLENBQUMsU0FBVixDQUFvQixNQUFNLENBQUMsTUFBM0IsRUFISjs7UUFERztNQUhYLENBNUNBO01BcURBO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsdUJBQVIsQ0FEWDtRQUVJLElBQUEsRUFBTSxPQUZWO1FBR0ksT0FBQSxFQUFTLENBQUMsa0JBQUEsQ0FBQSxDQUFBLElBQ04sU0FBUyxDQUFDLEtBQVYsS0FBbUIsU0FBUyxDQUFDLFlBRHhCLENBQUEsSUFDeUMsTUFBTSxDQUFDO01BSjdELENBckRBO0tBMERFLENBQUMsTUExREgsQ0EwRFUsUUFBQSxDQUFDLENBQUQsQ0FBQTthQUFPLENBQUEsS0FBSztJQUFaLENBMURWO0VBVGM7O0VBcUVsQixNQUFNLENBQUMsT0FBUCxHQUFpQixRQUFBLENBQUMsQ0FBRCxFQUFJLFNBQUosQ0FBQTtXQUNiLFdBQVcsQ0FBQyxpQkFBWixDQUE4QixlQUFBLENBQWdCLENBQWhCLEVBQW1CLFNBQW5CLENBQTlCO0VBRGE7QUE1RWpCIiwic291cmNlc0NvbnRlbnQiOlsicmVtb3RlICAgICAgPSByZXF1aXJlKCdlbGVjdHJvbicpLnJlbW90ZVxuY2xpcGJvYXJkICAgPSByZXF1aXJlKCdlbGVjdHJvbicpLmNsaXBib2FyZFxuIyB7ZG93bmxvYWR9ICA9IHJlcXVpcmUoJ2VsZWN0cm9uLWRsJykgIyBTZWUgSU1QT1JUQU5UIGJlbG93XG5Db250ZXh0TWVudSA9IHJlbW90ZS5NZW51XG5cbntpc0NvbnRlbnRQYXN0ZWFibGV9ID0gcmVxdWlyZSAnLi4vdXRpbCdcblxudGVtcGxhdGVDb250ZXh0ID0gKHBhcmFtcywgdmlld3N0YXRlKSAtPlxuICAgICNcbiAgICAjICAgICAgICAgIElNUE9SVEFOVDogY3VycmVudGx5IHNhdmUgaW1hZ2VzIGlzIGRpc2FibGVkIGFzIHRoZXJlXG4gICAgIyAgICAgICAgICAgIGFyZSBleGNlcHRpb25zIGJlaW5nIHRocm93biBmcm9tIHRoZSBlbGVjdHJvbi1kbCBtb2R1bGVcbiAgICAjXG4gICAgY2FuU2hvd1NhdmVJbWcgPSBwYXJhbXMubWVkaWFUeXBlID09ICdpbWFnZScgJiYgZmFsc2VcbiAgICBjYW5TaG93Q29weUltZ0xpbmsgPSBwYXJhbXMubWVkaWFUeXBlID09ICdpbWFnZScgJiYgcGFyYW1zLnNyY1VSTCAhPSAnJ1xuICAgIGNhblNob3dDb3B5TGluayA9IHBhcmFtcy5saW5rVVJMICE9ICcnICYmIHBhcmFtcy5tZWRpYVR5cGUgPT0gJ25vbmUnXG4gICAgI1xuICAgIFt7XG4gICAgICAgIGxhYmVsOiAnU2F2ZSBJbWFnZSdcbiAgICAgICAgdmlzaWJsZTogY2FuU2hvd1NhdmVJbWdcbiAgICAgICAgY2xpY2s6IChpdGVtLCB3aW4pIC0+XG4gICAgICAgICAgICB0cnlcbiAgICAgICAgICAgICAgICBkb3dubG9hZCB3aW4sIHBhcmFtcy5zcmNVUkxcbiAgICAgICAgICAgIGNhdGNoXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2cgJ1Bvc3NpYmxlIHByb2JsZW0gd2l0aCBzYXZpbmcgaW1hZ2UuICcsIGVyclxuICAgIH1cbiAgICB7IHR5cGU6ICdzZXBhcmF0b3InIH0gaWYgY2FuU2hvd1NhdmVJbWdcbiAgICB7XG4gICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LmVkaXQudW5kbzpVbmRvJylcbiAgICAgICAgcm9sZTogJ3VuZG8nXG4gICAgICAgIGVuYWJsZWQ6IHBhcmFtcy5lZGl0RmxhZ3MuY2FuVW5kb1xuICAgICAgICB2aXNpYmxlOiB0cnVlXG4gICAgfVxuICAgIHtcbiAgICAgICAgbGFiZWw6IGkxOG4uX18oJ21lbnUuZWRpdC5yZWRvOlJlZG8nKVxuICAgICAgICByb2xlOiAncmVkbydcbiAgICAgICAgZW5hYmxlZDogcGFyYW1zLmVkaXRGbGFncy5jYW5SZWRvXG4gICAgICAgIHZpc2libGU6IHRydWVcbiAgICB9XG4gICAgeyB0eXBlOiAnc2VwYXJhdG9yJyB9XG4gICAge1xuICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS5lZGl0LmN1dDpDdXQnKVxuICAgICAgICByb2xlOiAnY3V0J1xuICAgICAgICBlbmFibGVkOiBwYXJhbXMuZWRpdEZsYWdzLmNhbkN1dFxuICAgICAgICB2aXNpYmxlOiB0cnVlXG4gICAgfVxuICAgIHtcbiAgICAgICAgbGFiZWw6IGkxOG4uX18oJ21lbnUuZWRpdC5jb3B5OkNvcHknKVxuICAgICAgICByb2xlOiAnY29weSdcbiAgICAgICAgZW5hYmxlZDogcGFyYW1zLmVkaXRGbGFncy5jYW5Db3B5XG4gICAgICAgIHZpc2libGU6IHRydWVcbiAgICB9XG4gICAge1xuICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS5lZGl0LmNvcHlfbGluazpDb3B5IExpbmsnKVxuICAgICAgICB2aXNpYmxlOiBjYW5TaG93Q29weUxpbmtcbiAgICAgICAgY2xpY2s6ICgpIC0+XG4gICAgICAgICAgICBpZiBwcm9jZXNzLnBsYXRmb3JtID09ICdkYXJ3aW4nXG4gICAgICAgICAgICAgICAgY2xpcGJvYXJkLndyaXRlQm9va21hcmsgcGFyYW1zLmxpbmtUZXh0LCBwYXJhbXMubGlua1RleHRcbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICBjbGlwYm9hcmQud3JpdGVUZXh0IHBhcmFtcy5saW5rVGV4dFxuICAgIH1cbiAgICB7XG4gICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LmVkaXQuY29weV9pbWFnZV9saW5rOkNvcHkgSW1hZ2UgTGluaycpXG4gICAgICAgIHZpc2libGU6IGNhblNob3dDb3B5SW1nTGlua1xuICAgICAgICBjbGljazogKGl0ZW0sIHdpbikgLT5cbiAgICAgICAgICAgIGlmIHByb2Nlc3MucGxhdGZvcm0gPT0gJ2RhcndpbidcbiAgICAgICAgICAgICAgICBjbGlwYm9hcmQud3JpdGVCb29rbWFyayBwYXJhbXMuc3JjVVJMLCBwYXJhbXMuc3JjVVJMXG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgY2xpcGJvYXJkLndyaXRlVGV4dCBwYXJhbXMuc3JjVVJMXG4gICAgfVxuICAgIHtcbiAgICAgICAgbGFiZWw6IGkxOG4uX18oJ21lbnUuZWRpdC5wYXN0ZTpQYXN0ZScpXG4gICAgICAgIHJvbGU6ICdwYXN0ZSdcbiAgICAgICAgdmlzaWJsZTogKGlzQ29udGVudFBhc3RlYWJsZSgpICYmXG4gICAgICAgICAgICB2aWV3c3RhdGUuc3RhdGUgPT0gdmlld3N0YXRlLlNUQVRFX05PUk1BTCkgfHwgcGFyYW1zLmlzRWRpdGFibGVcbiAgICB9XS5maWx0ZXIgKG4pIC0+IG4gIT0gdW5kZWZpbmVkXG5cbm1vZHVsZS5leHBvcnRzID0gKGUsIHZpZXdzdGF0ZSkgLT5cbiAgICBDb250ZXh0TWVudS5idWlsZEZyb21UZW1wbGF0ZSB0ZW1wbGF0ZUNvbnRleHQoZSwgdmlld3N0YXRlKVxuIl19
