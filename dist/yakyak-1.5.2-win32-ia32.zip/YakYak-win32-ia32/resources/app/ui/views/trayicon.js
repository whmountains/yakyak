(function() {
  var Menu, Tray, compact, create, destroy, i18n, nativeImage, os, path, quit, tray, trayIcons, update;

  path = require('path');

  os = require('os');

  i18n = require('i18n');

  ({Menu, Tray, nativeImage} = require('electron').remote);

  trayIcons = null;

  if (os.platform() === 'darwin') {
    trayIcons = {
      "read": path.join(__dirname, '..', '..', 'icons', 'osx-icon-read-Template.png'),
      "unread": path.join(__dirname, '..', '..', 'icons', 'osx-icon-unread-Template.png')
    };
  } else {
    trayIcons = {
      "read": path.join(__dirname, '..', '..', 'icons', 'icon-read@8x.png'),
      "unread": path.join(__dirname, '..', '..', 'icons', 'icon-unread@8x.png')
    };
  }

  tray = null;

  // TODO: this is all WIP
  quit = function() {};

  compact = function(array) {
    var i, item, len, results;
    results = [];
    for (i = 0, len = array.length; i < len; i++) {
      item = array[i];
      if (item) {
        results.push(item);
      }
    }
    return results;
  };

  create = function() {
    tray = new Tray(trayIcons["read"]);
    tray.setToolTip(i18n.__('title:YakYak - Hangouts Client'));
    // Emitted when the tray icon is clicked
    return tray.on('click', function() {
      return action('togglewindow');
    });
  };

  destroy = function() {
    if (tray) {
      tray.destroy();
    }
    return tray = null;
  };

  update = function(unreadCount, viewstate) {
    var contextMenu, e, templateContextMenu;
    // update menu
    templateContextMenu = compact([
      {
        label: i18n.__('menu.view.tray.toggle_minimize:Toggle window show/hide'),
        click: function() {
          return action('togglewindow');
        }
      },
      {
        label: i18n.__("menu.view.tray.start_minimize:Start minimized to tray"),
        type: "checkbox",
        checked: viewstate.startminimizedtotray,
        click: function() {
          return action('togglestartminimizedtotray');
        }
      },
      {
        label: i18n.__('menu.view.notification.show:Show notifications'),
        type: "checkbox",
        checked: viewstate.showPopUpNotifications,
        // usage of already existing method and implements same logic
        //  as other toggle... methods
        click: function() {
          return action('showpopupnotifications',
      !viewstate.showPopUpNotifications);
        }
      },
      {
        label: i18n.__("menu.view.tray.close:Close to tray"),
        type: "checkbox",
        checked: viewstate.closetotray,
        click: function() {
          return action('toggleclosetotray');
        }
      },
      os.platform() === 'darwin' ? {
        label: i18n.__('menu.view.hide_dock:Hide Dock icon'),
        type: 'checkbox',
        checked: viewstate.hidedockicon,
        click: function() {
          return action('togglehidedockicon');
        }
      } : void 0,
      {
        label: i18n.__('menu.file.quit:Quit'),
        click: function() {
          return action('quit');
        }
      }
    ]);
    contextMenu = Menu.buildFromTemplate(templateContextMenu);
    tray.setContextMenu(contextMenu);
    try {
      // update icon
      if (unreadCount > 0) {
        if (tray.currentImage !== 'unread') {
          tray.setImage(trayIcons["unread"]);
        }
        return tray.currentImage = 'unread';
      } else {
        if (tray.currentImage !== 'read') {
          tray.setImage(trayIcons["read"]);
        }
        return tray.currentImage = 'read';
      }
    } catch (error) {
      e = error;
      return console.log('missing icons', e);
    }
  };

  module.exports = function({viewstate, conv}) {
    if (viewstate.showtray) {
      if (tray == null) {
        create();
      }
      return update(conv.unreadTotal(), viewstate);
    } else {
      if (tray) {
        return destroy();
      }
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvdmlld3MvdHJheWljb24uanMiLCJzb3VyY2VzIjpbInVpL3ZpZXdzL3RyYXlpY29uLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxPQUFBLEVBQUEsTUFBQSxFQUFBLE9BQUEsRUFBQSxJQUFBLEVBQUEsV0FBQSxFQUFBLEVBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxTQUFBLEVBQUE7O0VBQUEsSUFBQSxHQUFPLE9BQUEsQ0FBUSxNQUFSOztFQUNQLEVBQUEsR0FBTyxPQUFBLENBQVEsSUFBUjs7RUFDUCxJQUFBLEdBQU8sT0FBQSxDQUFRLE1BQVI7O0VBRVAsQ0FBQSxDQUFDLElBQUQsRUFBTyxJQUFQLEVBQWEsV0FBYixDQUFBLEdBQTRCLE9BQUEsQ0FBUSxVQUFSLENBQW1CLENBQUMsTUFBaEQ7O0VBRUEsU0FBQSxHQUFZOztFQUVaLElBQUcsRUFBRSxDQUFDLFFBQUgsQ0FBQSxDQUFBLEtBQWlCLFFBQXBCO0lBQ0ksU0FBQSxHQUNJO01BQUEsTUFBQSxFQUFRLElBQUksQ0FBQyxJQUFMLENBQVUsU0FBVixFQUFxQixJQUFyQixFQUEyQixJQUEzQixFQUFpQyxPQUFqQyxFQUEwQyw0QkFBMUMsQ0FBUjtNQUNBLFFBQUEsRUFBVSxJQUFJLENBQUMsSUFBTCxDQUFVLFNBQVYsRUFBcUIsSUFBckIsRUFBMkIsSUFBM0IsRUFBaUMsT0FBakMsRUFBMEMsOEJBQTFDO0lBRFYsRUFGUjtHQUFBLE1BQUE7SUFLSSxTQUFBLEdBQ0k7TUFBQSxNQUFBLEVBQVEsSUFBSSxDQUFDLElBQUwsQ0FBVSxTQUFWLEVBQXFCLElBQXJCLEVBQTJCLElBQTNCLEVBQWlDLE9BQWpDLEVBQTBDLGtCQUExQyxDQUFSO01BQ0EsUUFBQSxFQUFVLElBQUksQ0FBQyxJQUFMLENBQVUsU0FBVixFQUFxQixJQUFyQixFQUEyQixJQUEzQixFQUFpQyxPQUFqQyxFQUEwQyxvQkFBMUM7SUFEVixFQU5SOzs7RUFTQSxJQUFBLEdBQU8sS0FqQlA7OztFQW9CQSxJQUFBLEdBQU8sUUFBQSxDQUFBLENBQUEsRUFBQTs7RUFFUCxPQUFBLEdBQVUsUUFBQSxDQUFDLEtBQUQsQ0FBQTtBQUFXLFFBQUEsQ0FBQSxFQUFBLElBQUEsRUFBQSxHQUFBLEVBQUE7QUFBSztJQUFBLEtBQUEsdUNBQUE7O1VBQXVCO3FCQUE1Qjs7SUFBSyxDQUFBOztFQUFoQjs7RUFFVixNQUFBLEdBQVMsUUFBQSxDQUFBLENBQUE7SUFDTCxJQUFBLEdBQU8sSUFBSSxJQUFKLENBQVMsU0FBVSxDQUFBLE1BQUEsQ0FBbkI7SUFDUCxJQUFJLENBQUMsVUFBTCxDQUFnQixJQUFJLENBQUMsRUFBTCxDQUFRLGdDQUFSLENBQWhCLEVBREE7O1dBR0EsSUFBSSxDQUFDLEVBQUwsQ0FBUSxPQUFSLEVBQWlCLFFBQUEsQ0FBQSxDQUFBO2FBQUcsTUFBQSxDQUFPLGNBQVA7SUFBSCxDQUFqQjtFQUpLOztFQU1ULE9BQUEsR0FBVSxRQUFBLENBQUEsQ0FBQTtJQUNOLElBQWtCLElBQWxCO01BQUEsSUFBSSxDQUFDLE9BQUwsQ0FBQSxFQUFBOztXQUNBLElBQUEsR0FBTztFQUZEOztFQUlWLE1BQUEsR0FBUyxRQUFBLENBQUMsV0FBRCxFQUFjLFNBQWQsQ0FBQTtBQUVMLFFBQUEsV0FBQSxFQUFBLENBQUEsRUFBQSxtQkFBQTs7SUFBQSxtQkFBQSxHQUFzQixPQUFBLENBQVE7TUFDMUI7UUFDRSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx3REFBUixDQURUO1FBRUUsS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO2lCQUFHLE1BQUEsQ0FBTyxjQUFQO1FBQUg7TUFGVCxDQUQwQjtNQU0xQjtRQUNFLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLHVEQUFSLENBRFQ7UUFFRSxJQUFBLEVBQU0sVUFGUjtRQUdFLE9BQUEsRUFBUyxTQUFTLENBQUMsb0JBSHJCO1FBSUUsS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO2lCQUFHLE1BQUEsQ0FBTyw0QkFBUDtRQUFIO01BSlQsQ0FOMEI7TUFhMUI7UUFDRSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxnREFBUixDQURUO1FBRUUsSUFBQSxFQUFNLFVBRlI7UUFHRSxPQUFBLEVBQVMsU0FBUyxDQUFDLHNCQUhyQjs7O1FBTUUsS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO2lCQUFHLE1BQUEsQ0FBTyx3QkFBUDtNQUNOLENBQUMsU0FBUyxDQUFDLHNCQURMO1FBQUg7TUFOVCxDQWIwQjtNQXVCMUI7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxvQ0FBUixDQURYO1FBRUksSUFBQSxFQUFNLFVBRlY7UUFHSSxPQUFBLEVBQVMsU0FBUyxDQUFDLFdBSHZCO1FBSUksS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO2lCQUFHLE1BQUEsQ0FBTyxtQkFBUDtRQUFIO01BSlgsQ0F2QjBCO01BbUNyQixFQUFFLENBQUMsUUFBSCxDQUFBLENBQUEsS0FBaUIsUUFMdEIsR0FBQTtRQUNFLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLG9DQUFSLENBRFQ7UUFFRSxJQUFBLEVBQU0sVUFGUjtRQUdFLE9BQUEsRUFBUyxTQUFTLENBQUMsWUFIckI7UUFJRSxLQUFBLEVBQU8sUUFBQSxDQUFBLENBQUE7aUJBQUcsTUFBQSxDQUFPLG9CQUFQO1FBQUg7TUFKVCxDQUFBLEdBQUEsTUE5QjBCO01BcUMxQjtRQUNFLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLHFCQUFSLENBRFQ7UUFFRSxLQUFBLEVBQU8sUUFBQSxDQUFBLENBQUE7aUJBQUcsTUFBQSxDQUFPLE1BQVA7UUFBSDtNQUZULENBckMwQjtLQUFSO0lBMkN0QixXQUFBLEdBQWMsSUFBSSxDQUFDLGlCQUFMLENBQXVCLG1CQUF2QjtJQUNkLElBQUksQ0FBQyxjQUFMLENBQW9CLFdBQXBCO0FBR0E7O01BQ0ksSUFBRyxXQUFBLEdBQWMsQ0FBakI7UUFDSSxJQUF5QyxJQUFJLENBQUMsWUFBTCxLQUFxQixRQUE5RDtVQUFBLElBQUksQ0FBQyxRQUFMLENBQWMsU0FBVSxDQUFBLFFBQUEsQ0FBeEIsRUFBQTs7ZUFDQSxJQUFJLENBQUMsWUFBTCxHQUFvQixTQUZ4QjtPQUFBLE1BQUE7UUFJSSxJQUF1QyxJQUFJLENBQUMsWUFBTCxLQUFxQixNQUE1RDtVQUFBLElBQUksQ0FBQyxRQUFMLENBQWMsU0FBVSxDQUFBLE1BQUEsQ0FBeEIsRUFBQTs7ZUFDQSxJQUFJLENBQUMsWUFBTCxHQUFvQixPQUx4QjtPQURKO0tBQUEsYUFBQTtNQU9NO2FBQ0YsT0FBTyxDQUFDLEdBQVIsQ0FBWSxlQUFaLEVBQTZCLENBQTdCLEVBUko7O0VBakRLOztFQTREVCxNQUFNLENBQUMsT0FBUCxHQUFpQixRQUFBLENBQUMsQ0FBQyxTQUFELEVBQVksSUFBWixDQUFELENBQUE7SUFDYixJQUFHLFNBQVMsQ0FBQyxRQUFiO01BQ0ksSUFBZ0IsWUFBaEI7UUFBQSxNQUFBLENBQUEsRUFBQTs7YUFDQSxNQUFBLENBQU8sSUFBSSxDQUFDLFdBQUwsQ0FBQSxDQUFQLEVBQTJCLFNBQTNCLEVBRko7S0FBQSxNQUFBO01BSUksSUFBYSxJQUFiO2VBQUEsT0FBQSxDQUFBLEVBQUE7T0FKSjs7RUFEYTtBQTlGakIiLCJzb3VyY2VzQ29udGVudCI6WyJwYXRoID0gcmVxdWlyZSAncGF0aCdcbm9zICAgPSByZXF1aXJlICdvcydcbmkxOG4gPSByZXF1aXJlICdpMThuJ1xuXG57TWVudSwgVHJheSwgbmF0aXZlSW1hZ2V9ID0gcmVxdWlyZSgnZWxlY3Ryb24nKS5yZW1vdGVcblxudHJheUljb25zID0gbnVsbFxuXG5pZiBvcy5wbGF0Zm9ybSgpID09ICdkYXJ3aW4nXG4gICAgdHJheUljb25zID1cbiAgICAgICAgXCJyZWFkXCI6IHBhdGguam9pbiBfX2Rpcm5hbWUsICcuLicsICcuLicsICdpY29ucycsICdvc3gtaWNvbi1yZWFkLVRlbXBsYXRlLnBuZydcbiAgICAgICAgXCJ1bnJlYWRcIjogcGF0aC5qb2luIF9fZGlybmFtZSwgJy4uJywgJy4uJywgJ2ljb25zJywgJ29zeC1pY29uLXVucmVhZC1UZW1wbGF0ZS5wbmcnXG5lbHNlXG4gICAgdHJheUljb25zID1cbiAgICAgICAgXCJyZWFkXCI6IHBhdGguam9pbiBfX2Rpcm5hbWUsICcuLicsICcuLicsICdpY29ucycsICdpY29uLXJlYWRAOHgucG5nJ1xuICAgICAgICBcInVucmVhZFwiOiBwYXRoLmpvaW4gX19kaXJuYW1lLCAnLi4nLCAnLi4nLCAnaWNvbnMnLCAnaWNvbi11bnJlYWRAOHgucG5nJ1xuXG50cmF5ID0gbnVsbFxuXG4jIFRPRE86IHRoaXMgaXMgYWxsIFdJUFxucXVpdCA9IC0+XG5cbmNvbXBhY3QgPSAoYXJyYXkpIC0+IGl0ZW0gZm9yIGl0ZW0gaW4gYXJyYXkgd2hlbiBpdGVtXG5cbmNyZWF0ZSA9ICgpIC0+XG4gICAgdHJheSA9IG5ldyBUcmF5IHRyYXlJY29uc1tcInJlYWRcIl1cbiAgICB0cmF5LnNldFRvb2xUaXAgaTE4bi5fXygndGl0bGU6WWFrWWFrIC0gSGFuZ291dHMgQ2xpZW50JylcbiAgICAjIEVtaXR0ZWQgd2hlbiB0aGUgdHJheSBpY29uIGlzIGNsaWNrZWRcbiAgICB0cmF5Lm9uICdjbGljaycsIC0+IGFjdGlvbiAndG9nZ2xld2luZG93J1xuXG5kZXN0cm95ID0gLT5cbiAgICB0cmF5LmRlc3Ryb3koKSBpZiB0cmF5XG4gICAgdHJheSA9IG51bGxcblxudXBkYXRlID0gKHVucmVhZENvdW50LCB2aWV3c3RhdGUpIC0+XG4gICAgIyB1cGRhdGUgbWVudVxuICAgIHRlbXBsYXRlQ29udGV4dE1lbnUgPSBjb21wYWN0KFtcbiAgICAgICAge1xuICAgICAgICAgIGxhYmVsOiBpMThuLl9fICdtZW51LnZpZXcudHJheS50b2dnbGVfbWluaW1pemU6VG9nZ2xlIHdpbmRvdyBzaG93L2hpZGUnXG4gICAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAndG9nZ2xld2luZG93J1xuICAgICAgICB9XG5cbiAgICAgICAge1xuICAgICAgICAgIGxhYmVsOiBpMThuLl9fIFwibWVudS52aWV3LnRyYXkuc3RhcnRfbWluaW1pemU6U3RhcnQgbWluaW1pemVkIHRvIHRyYXlcIlxuICAgICAgICAgIHR5cGU6IFwiY2hlY2tib3hcIlxuICAgICAgICAgIGNoZWNrZWQ6IHZpZXdzdGF0ZS5zdGFydG1pbmltaXplZHRvdHJheVxuICAgICAgICAgIGNsaWNrOiAtPiBhY3Rpb24gJ3RvZ2dsZXN0YXJ0bWluaW1pemVkdG90cmF5J1xuICAgICAgICB9XG5cbiAgICAgICAge1xuICAgICAgICAgIGxhYmVsOiBpMThuLl9fICdtZW51LnZpZXcubm90aWZpY2F0aW9uLnNob3c6U2hvdyBub3RpZmljYXRpb25zJ1xuICAgICAgICAgIHR5cGU6IFwiY2hlY2tib3hcIlxuICAgICAgICAgIGNoZWNrZWQ6IHZpZXdzdGF0ZS5zaG93UG9wVXBOb3RpZmljYXRpb25zXG4gICAgICAgICAgIyB1c2FnZSBvZiBhbHJlYWR5IGV4aXN0aW5nIG1ldGhvZCBhbmQgaW1wbGVtZW50cyBzYW1lIGxvZ2ljXG4gICAgICAgICAgIyAgYXMgb3RoZXIgdG9nZ2xlLi4uIG1ldGhvZHNcbiAgICAgICAgICBjbGljazogLT4gYWN0aW9uICdzaG93cG9wdXBub3RpZmljYXRpb25zJyxcbiAgICAgICAgICAgICAgIXZpZXdzdGF0ZS5zaG93UG9wVXBOb3RpZmljYXRpb25zXG4gICAgICAgIH1cblxuICAgICAgICB7XG4gICAgICAgICAgICBsYWJlbDogaTE4bi5fXyBcIm1lbnUudmlldy50cmF5LmNsb3NlOkNsb3NlIHRvIHRyYXlcIlxuICAgICAgICAgICAgdHlwZTogXCJjaGVja2JveFwiXG4gICAgICAgICAgICBjaGVja2VkOiB2aWV3c3RhdGUuY2xvc2V0b3RyYXlcbiAgICAgICAgICAgIGNsaWNrOiAtPiBhY3Rpb24gJ3RvZ2dsZWNsb3NldG90cmF5J1xuICAgICAgICB9XG5cbiAgICAgICAge1xuICAgICAgICAgIGxhYmVsOiBpMThuLl9fICdtZW51LnZpZXcuaGlkZV9kb2NrOkhpZGUgRG9jayBpY29uJ1xuICAgICAgICAgIHR5cGU6ICdjaGVja2JveCdcbiAgICAgICAgICBjaGVja2VkOiB2aWV3c3RhdGUuaGlkZWRvY2tpY29uXG4gICAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAndG9nZ2xlaGlkZWRvY2tpY29uJ1xuICAgICAgICB9IGlmIG9zLnBsYXRmb3JtKCkgPT0gJ2RhcndpbidcblxuICAgICAgICB7XG4gICAgICAgICAgbGFiZWw6IGkxOG4uX18oJ21lbnUuZmlsZS5xdWl0OlF1aXQnKSxcbiAgICAgICAgICBjbGljazogLT4gYWN0aW9uICdxdWl0J1xuICAgICAgICB9XG4gICAgXSlcblxuICAgIGNvbnRleHRNZW51ID0gTWVudS5idWlsZEZyb21UZW1wbGF0ZSB0ZW1wbGF0ZUNvbnRleHRNZW51XG4gICAgdHJheS5zZXRDb250ZXh0TWVudSBjb250ZXh0TWVudVxuXG4gICAgIyB1cGRhdGUgaWNvblxuICAgIHRyeVxuICAgICAgICBpZiB1bnJlYWRDb3VudCA+IDBcbiAgICAgICAgICAgIHRyYXkuc2V0SW1hZ2UgdHJheUljb25zW1widW5yZWFkXCJdIHVubGVzcyB0cmF5LmN1cnJlbnRJbWFnZSA9PSAndW5yZWFkJ1xuICAgICAgICAgICAgdHJheS5jdXJyZW50SW1hZ2UgPSAndW5yZWFkJ1xuICAgICAgICBlbHNlXG4gICAgICAgICAgICB0cmF5LnNldEltYWdlIHRyYXlJY29uc1tcInJlYWRcIl0gdW5sZXNzIHRyYXkuY3VycmVudEltYWdlID09ICdyZWFkJ1xuICAgICAgICAgICAgdHJheS5jdXJyZW50SW1hZ2UgPSAncmVhZCdcbiAgICBjYXRjaCBlXG4gICAgICAgIGNvbnNvbGUubG9nICdtaXNzaW5nIGljb25zJywgZVxuXG5cbm1vZHVsZS5leHBvcnRzID0gKHt2aWV3c3RhdGUsIGNvbnZ9KSAtPlxuICAgIGlmIHZpZXdzdGF0ZS5zaG93dHJheVxuICAgICAgICBjcmVhdGUoKSBpZiBub3QgdHJheT9cbiAgICAgICAgdXBkYXRlKGNvbnYudW5yZWFkVG90YWwoKSwgdmlld3N0YXRlKVxuICAgIGVsc2VcbiAgICAgICAgZGVzdHJveSgpIGlmIHRyYXlcbiJdfQ==
