(function() {
  var audioEl, audioFile, callNeedAnswer, fixlink, getProxiedName, i18n, nameof, notificationCenterSupportsSound, notifier, notifierSupportsSound, openHangout, path, remote, shell, textMessage;

  notifier = require('node-notifier');

  shell = require('electron').shell;

  path = require('path');

  remote = require('electron').remote;

  i18n = require('i18n');

  ({nameof, getProxiedName, fixlink, notificationCenterSupportsSound} = require('../util'));

  // conv_id markers for call notifications
  callNeedAnswer = {};

  notifierSupportsSound = notificationCenterSupportsSound();

  // Custom sound for new message notifications
  audioFile = path.join(YAKYAK_ROOT_DIR, '..', 'media', 'new_message.ogg');

  audioEl = new Audio(audioFile);

  audioEl.volume = .4;

  module.exports = function(models) {
    var conv, entity, notify, quietIf, tonot, viewstate;
    ({conv, notify, entity, viewstate} = models);
    tonot = notify.popToNotify();
    quietIf = function(c, chat_id) {
      return (typeof document !== "undefined" && document !== null ? document.hasFocus() : void 0) || conv.isQuiet(c) || entity.isSelf(chat_id);
    };
    return tonot.forEach(function(msg) {
      var c, chat_id, cid, contentImage, conv_id, icon, isNotificationCenter, mainWindow, proxied, ref, ref1, ref2, ref3, ref4, ref5, ref6, sender, text;
      conv_id = msg != null ? (ref = msg.conversation_id) != null ? ref.id : void 0 : void 0;
      c = conv[conv_id];
      chat_id = msg != null ? (ref1 = msg.sender_id) != null ? ref1.chat_id : void 0 : void 0;
      proxied = getProxiedName(msg);
      cid = proxied ? proxied : msg != null ? (ref2 = msg.sender_id) != null ? ref2.chat_id : void 0 : void 0;
      sender = nameof(entity[cid]);
      text = null;
      if (msg.chat_message != null) {
        if (((ref3 = msg.chat_message) != null ? ref3.message_content : void 0) == null) {
          return;
        }
        text = textMessage(msg.chat_message.message_content, proxied, viewstate.showMessageInNotification);
      } else if (((ref4 = msg.hangout_event) != null ? ref4.event_type : void 0) === 'START_HANGOUT') {
        text = i18n.__("call.incoming:Incoming call");
        callNeedAnswer[conv_id] = true;
        notr({
          html: `${i18n.__('call.incoming_from:Incoming call from %s', sender)}. ` + `<a href="#" class="accept">${i18n.__('call.accept:Accept')}</a> / ` + `<a href="#" class="reject">${i18n.__('call.reject:Reject')}</a>`,
          stay: 0,
          id: `hang${conv_id}`,
          onclick: function(e) {
            var ref5;
            delete callNeedAnswer[conv_id];
            if ((e != null ? (ref5 = e.target) != null ? ref5.className : void 0 : void 0) === 'accept') {
              notr({
                html: i18n.__('calls.accepted:Accepted'),
                stay: 1000,
                id: `hang${conv_id}`
              });
              return openHangout(conv_id);
            } else {
              return notr({
                html: i18n.__('calls.rejected:Rejected'),
                stay: 1000,
                id: `hang${conv_id}`
              });
            }
          }
        });
      } else if (((ref5 = msg.hangout_event) != null ? ref5.event_type : void 0) === 'END_HANGOUT') {
        if (callNeedAnswer[conv_id]) {
          delete callNeedAnswer[conv_id];
          notr({
            html: `${i18n.__('calls.missed:Missed call from %s', sender)}. ` + `<a href="#">${i18n.__('actions.ok: Ok')}</a>`,
            id: `hang${conv_id}`,
            stay: 0
          });
        }
      } else {
        return;
      }
      if (!text || quietIf(c, chat_id)) {
        return;
      }
      if (viewstate.showPopUpNotifications) {
        isNotificationCenter = notifier.constructor.name === 'NotificationCenter';
        
        icon = path.join(__dirname, '..', '..', 'icons', 'icon@8.png');
        // Only for NotificationCenter (darwin)
        if (isNotificationCenter && viewstate.showIconNotification) {
          contentImage = fixlink((ref6 = entity[cid]) != null ? ref6.photo_url : void 0);
        } else {
          contentImage = void 0;
        }
        
        notifier.notify({
          title: viewstate.showUsernameInNotification ? !isNotificationCenter && !viewstate.showIconNotification ? `${sender} (YakYak)` : sender : 'YakYak',
          message: text,
          wait: true,
          hint: "int:transient:1",
          category: 'im.received',
          sender: 'com.github.yakyak',
          sound: !viewstate.muteSoundNotification && (notifierSupportsSound && !viewstate.forceCustomSound),
          icon: !isNotificationCenter && viewstate.showIconNotification ? icon : void 0,
          contentImage: contentImage
        }, function(err, res) {
          if (res != null ? res.trim().match(/Activate/i) : void 0) {
            action('appfocus');
            return action('selectConv', c);
          }
        });
        if ((!notifierSupportsSound || viewstate.forceCustomSound) && !viewstate.muteSoundNotification && audioEl.paused) {
          audioEl.play();
        }
      }
      // And we hope we don't get another 'currentWindow' ;)
      mainWindow = remote.getCurrentWindow();
      return mainWindow.flashFrame(true);
    });
  };

  textMessage = function(cont, proxied, showMessage = true) {
    var i, seg, segs;
    if ((cont != null ? cont.segment : void 0) != null) {
      if (!showMessage) {
        return i18n.__('conversation.new_message:New message received');
      } else {
        segs = (function() {
          var j, len, ref, ref1, results;
          ref1 = (ref = cont != null ? cont.segment : void 0) != null ? ref : [];
          results = [];
          for (i = j = 0, len = ref1.length; j < len; i = ++j) {
            seg = ref1[i];
            if (proxied && i < 2) {
              continue;
            }
            if (!seg.text) {
              continue;
            }
            results.push(seg.text);
          }
          return results;
        })();
        return segs.join('');
      }
    } else if ((cont != null ? cont.attachment : void 0) != null) {
      return i18n.__('conversation.new_attachment:New message received (image or video)');
    }
  };

  openHangout = function(conv_id) {
    return shell.openExternal(`https://plus.google.com/hangouts/_/CONVERSATION/${conv_id}`);
  };

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvdmlld3Mvbm90aWZpY2F0aW9ucy5qcyIsInNvdXJjZXMiOlsidWkvdmlld3Mvbm90aWZpY2F0aW9ucy5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLE9BQUEsRUFBQSxTQUFBLEVBQUEsY0FBQSxFQUFBLE9BQUEsRUFBQSxjQUFBLEVBQUEsSUFBQSxFQUFBLE1BQUEsRUFBQSwrQkFBQSxFQUFBLFFBQUEsRUFBQSxxQkFBQSxFQUFBLFdBQUEsRUFBQSxJQUFBLEVBQUEsTUFBQSxFQUFBLEtBQUEsRUFBQTs7RUFBQSxRQUFBLEdBQVcsT0FBQSxDQUFRLGVBQVI7O0VBQ1gsS0FBQSxHQUFXLE9BQUEsQ0FBUSxVQUFSLENBQW1CLENBQUM7O0VBQy9CLElBQUEsR0FBVyxPQUFBLENBQVEsTUFBUjs7RUFDWCxNQUFBLEdBQVcsT0FBQSxDQUFRLFVBQVIsQ0FBbUIsQ0FBQzs7RUFDL0IsSUFBQSxHQUFXLE9BQUEsQ0FBUSxNQUFSOztFQUVYLENBQUEsQ0FBQyxNQUFELEVBQVMsY0FBVCxFQUF5QixPQUF6QixFQUFrQywrQkFBbEMsQ0FBQSxHQUFxRSxPQUFBLENBQVEsU0FBUixDQUFyRSxFQU5BOzs7RUFTQSxjQUFBLEdBQWlCLENBQUE7O0VBRWpCLHFCQUFBLEdBQXdCLCtCQUFBLENBQUEsRUFYeEI7OztFQWNBLFNBQUEsR0FBWSxJQUFJLENBQUMsSUFBTCxDQUFVLGVBQVYsRUFBMkIsSUFBM0IsRUFBaUMsT0FBakMsRUFDWixpQkFEWTs7RUFFWixPQUFBLEdBQVUsSUFBSSxLQUFKLENBQVUsU0FBVjs7RUFDVixPQUFPLENBQUMsTUFBUixHQUFpQjs7RUFHakIsTUFBTSxDQUFDLE9BQVAsR0FBaUIsUUFBQSxDQUFDLE1BQUQsQ0FBQTtBQUNiLFFBQUEsSUFBQSxFQUFBLE1BQUEsRUFBQSxNQUFBLEVBQUEsT0FBQSxFQUFBLEtBQUEsRUFBQTtJQUFBLENBQUEsQ0FBQyxJQUFELEVBQU8sTUFBUCxFQUFlLE1BQWYsRUFBdUIsU0FBdkIsQ0FBQSxHQUFvQyxNQUFwQztJQUNBLEtBQUEsR0FBUSxNQUFNLENBQUMsV0FBUCxDQUFBO0lBRVIsT0FBQSxHQUFVLFFBQUEsQ0FBQyxDQUFELEVBQUksT0FBSixDQUFBO3FFQUFnQixRQUFRLENBQUUsUUFBVixDQUFBLFdBQUEsSUFBd0IsSUFBSSxDQUFDLE9BQUwsQ0FBYSxDQUFiLENBQXhCLElBQTJDLE1BQU0sQ0FBQyxNQUFQLENBQWMsT0FBZDtJQUEzRDtXQUVWLEtBQUssQ0FBQyxPQUFOLENBQWMsUUFBQSxDQUFDLEdBQUQsQ0FBQTtBQUNWLFVBQUEsQ0FBQSxFQUFBLE9BQUEsRUFBQSxHQUFBLEVBQUEsWUFBQSxFQUFBLE9BQUEsRUFBQSxJQUFBLEVBQUEsb0JBQUEsRUFBQSxVQUFBLEVBQUEsT0FBQSxFQUFBLEdBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxNQUFBLEVBQUE7TUFBQSxPQUFBLDBEQUE4QixDQUFFO01BQ2hDLENBQUEsR0FBSSxJQUFLLENBQUEsT0FBQTtNQUNULE9BQUEsc0RBQXdCLENBQUU7TUFFMUIsT0FBQSxHQUFVLGNBQUEsQ0FBZSxHQUFmO01BQ1YsR0FBQSxHQUFTLE9BQUgsR0FBZ0IsT0FBaEIsc0RBQTJDLENBQUU7TUFDbkQsTUFBQSxHQUFTLE1BQUEsQ0FBTyxNQUFPLENBQUEsR0FBQSxDQUFkO01BQ1QsSUFBQSxHQUFPO01BRVAsSUFBRyx3QkFBSDtRQUNJLElBQWMsMkVBQWQ7QUFBQSxpQkFBQTs7UUFDQSxJQUFBLEdBQU8sV0FBQSxDQUFZLEdBQUcsQ0FBQyxZQUFZLENBQUMsZUFBN0IsRUFBOEMsT0FBOUMsRUFBdUQsU0FBUyxDQUFDLHlCQUFqRSxFQUZYO09BQUEsTUFHSyw4Q0FBb0IsQ0FBRSxvQkFBbkIsS0FBaUMsZUFBcEM7UUFDRCxJQUFBLEdBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSw2QkFBUjtRQUNQLGNBQWUsQ0FBQSxPQUFBLENBQWYsR0FBMEI7UUFDMUIsSUFBQSxDQUNJO1VBQUEsSUFBQSxFQUFNLENBQUEsQ0FBQSxDQUFHLElBQUksQ0FBQyxFQUFMLENBQVEsMENBQVIsRUFBb0QsTUFBcEQsQ0FBSCxDQUErRCxFQUEvRCxDQUFBLEdBQ04sQ0FBQSwyQkFBQSxDQUFBLENBQWtDLElBQUksQ0FBQyxFQUFMLENBQVEsb0JBQVIsQ0FBbEMsQ0FBK0QsT0FBL0QsQ0FETSxHQUVOLENBQUEsMkJBQUEsQ0FBQSxDQUFrQyxJQUFJLENBQUMsRUFBTCxDQUFRLG9CQUFSLENBQWxDLENBQStELElBQS9ELENBRkE7VUFHQSxJQUFBLEVBQU0sQ0FITjtVQUlBLEVBQUEsRUFBSSxDQUFBLElBQUEsQ0FBQSxDQUFPLE9BQVAsQ0FBQSxDQUpKO1VBS0EsT0FBQSxFQUFTLFFBQUEsQ0FBQyxDQUFELENBQUE7QUFDTCxnQkFBQTtZQUFBLE9BQU8sY0FBZSxDQUFBLE9BQUE7WUFDdEIsaURBQVksQ0FBRSw0QkFBWCxLQUF3QixRQUEzQjtjQUNJLElBQUEsQ0FBSztnQkFBQyxJQUFBLEVBQUssSUFBSSxDQUFDLEVBQUwsQ0FBUSx5QkFBUixDQUFOO2dCQUEwQyxJQUFBLEVBQUssSUFBL0M7Z0JBQXFELEVBQUEsRUFBRyxDQUFBLElBQUEsQ0FBQSxDQUFPLE9BQVAsQ0FBQTtjQUF4RCxDQUFMO3FCQUNBLFdBQUEsQ0FBWSxPQUFaLEVBRko7YUFBQSxNQUFBO3FCQUlJLElBQUEsQ0FBSztnQkFBQyxJQUFBLEVBQU0sSUFBSSxDQUFDLEVBQUwsQ0FBUSx5QkFBUixDQUFQO2dCQUEyQyxJQUFBLEVBQUssSUFBaEQ7Z0JBQXNELEVBQUEsRUFBRyxDQUFBLElBQUEsQ0FBQSxDQUFPLE9BQVAsQ0FBQTtjQUF6RCxDQUFMLEVBSko7O1VBRks7UUFMVCxDQURKLEVBSEM7T0FBQSxNQWdCQSw4Q0FBb0IsQ0FBRSxvQkFBbkIsS0FBaUMsYUFBcEM7UUFDRCxJQUFHLGNBQWUsQ0FBQSxPQUFBLENBQWxCO1VBQ0ksT0FBTyxjQUFlLENBQUEsT0FBQTtVQUN0QixJQUFBLENBQ0k7WUFBQSxJQUFBLEVBQU0sQ0FBQSxDQUFBLENBQUcsSUFBSSxDQUFDLEVBQUwsQ0FBUSxrQ0FBUixFQUE0QyxNQUE1QyxDQUFILENBQXVELEVBQXZELENBQUEsR0FDRixDQUFBLFlBQUEsQ0FBQSxDQUFpQixJQUFJLENBQUMsRUFBTCxDQUFRLGdCQUFSLENBQWpCLENBQTJDLElBQTNDLENBREo7WUFFQSxFQUFBLEVBQUksQ0FBQSxJQUFBLENBQUEsQ0FBTyxPQUFQLENBQUEsQ0FGSjtZQUdBLElBQUEsRUFBTTtVQUhOLENBREosRUFGSjtTQURDO09BQUEsTUFBQTtBQVNELGVBVEM7O01BWUwsSUFBVSxDQUFDLElBQUQsSUFBUyxPQUFBLENBQVEsQ0FBUixFQUFXLE9BQVgsQ0FBbkI7QUFBQSxlQUFBOztNQUVBLElBQUcsU0FBUyxDQUFDLHNCQUFiO1FBQ0ksb0JBQUEsR0FBdUIsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFyQixLQUE2Qjs7UUFFcEQsSUFBQSxHQUFPLElBQUksQ0FBQyxJQUFMLENBQVUsU0FBVixFQUFxQixJQUFyQixFQUEyQixJQUEzQixFQUFpQyxPQUFqQyxFQUEwQyxZQUExQyxFQUZQOztRQUlBLElBQUcsb0JBQUEsSUFBd0IsU0FBUyxDQUFDLG9CQUFyQztVQUNJLFlBQUEsR0FBZSxPQUFBLG9DQUFtQixDQUFFLGtCQUFyQixFQURuQjtTQUFBLE1BQUE7VUFHSSxZQUFBLEdBQWUsT0FIbkI7OztRQUtBLFFBQVEsQ0FBQyxNQUFULENBQ0k7VUFBQSxLQUFBLEVBQVUsU0FBUyxDQUFDLDBCQUFiLEdBQ08sQ0FBQyxvQkFBRCxJQUF5QixDQUFDLFNBQVMsQ0FBQyxvQkFBdkMsR0FDSSxDQUFBLENBQUEsQ0FBRyxNQUFILENBQVUsU0FBVixDQURKLEdBR0ksTUFKUixHQU1JLFFBTlg7VUFPQSxPQUFBLEVBQVMsSUFQVDtVQVFBLElBQUEsRUFBTSxJQVJOO1VBU0EsSUFBQSxFQUFNLGlCQVROO1VBVUEsUUFBQSxFQUFVLGFBVlY7VUFXQSxNQUFBLEVBQVEsbUJBWFI7VUFZQSxLQUFBLEVBQU8sQ0FBQyxTQUFTLENBQUMscUJBQVgsSUFBb0MsQ0FBQyxxQkFBQSxJQUF5QixDQUFDLFNBQVMsQ0FBQyxnQkFBckMsQ0FaM0M7VUFhQSxJQUFBLEVBQWMsQ0FBQyxvQkFBRCxJQUF5QixTQUFTLENBQUMsb0JBQTNDLEdBQUEsSUFBQSxHQUFBLE1BYk47VUFjQSxZQUFBLEVBQWM7UUFkZCxDQURKLEVBZ0JFLFFBQUEsQ0FBQyxHQUFELEVBQU0sR0FBTixDQUFBO1VBQ0Esa0JBQUcsR0FBRyxDQUFFLElBQUwsQ0FBQSxDQUFXLENBQUMsS0FBWixDQUFrQixXQUFsQixVQUFIO1lBQ0UsTUFBQSxDQUFPLFVBQVA7bUJBQ0EsTUFBQSxDQUFPLFlBQVAsRUFBcUIsQ0FBckIsRUFGRjs7UUFEQSxDQWhCRjtRQXdCQSxJQUFHLENBQUMsQ0FBQyxxQkFBRCxJQUEwQixTQUFTLENBQUMsZ0JBQXJDLENBQUEsSUFBMEQsQ0FBQyxTQUFTLENBQUMscUJBQXJFLElBQThGLE9BQU8sQ0FBQyxNQUF6RztVQUNJLE9BQU8sQ0FBQyxJQUFSLENBQUEsRUFESjtTQWxDSjtPQTFDQTs7TUErRUEsVUFBQSxHQUFhLE1BQU0sQ0FBQyxnQkFBUCxDQUFBO2FBQ2IsVUFBVSxDQUFDLFVBQVgsQ0FBc0IsSUFBdEI7SUFqRlUsQ0FBZDtFQU5hOztFQXlGakIsV0FBQSxHQUFjLFFBQUEsQ0FBQyxJQUFELEVBQU8sT0FBUCxFQUFnQixjQUFjLElBQTlCLENBQUE7QUFDVixRQUFBLENBQUEsRUFBQSxHQUFBLEVBQUE7SUFBQSxJQUFHLDhDQUFIO01BQ0UsSUFBQSxDQUFPLFdBQVA7ZUFDSSxJQUFJLENBQUMsRUFBTCxDQUFRLCtDQUFSLEVBREo7T0FBQSxNQUFBO1FBR0ksSUFBQTs7QUFBTztBQUFBO1VBQUEsS0FBQSw4Q0FBQTs7WUFDSCxJQUFZLE9BQUEsSUFBWSxDQUFBLEdBQUksQ0FBNUI7QUFBQSx1QkFBQTs7WUFDQSxJQUFBLENBQWdCLEdBQUcsQ0FBQyxJQUFwQjtBQUFBLHVCQUFBOzt5QkFDQSxHQUFHLENBQUM7VUFIRCxDQUFBOzs7ZUFJUCxJQUFJLENBQUMsSUFBTCxDQUFVLEVBQVYsRUFQSjtPQURGO0tBQUEsTUFTSyxJQUFHLGlEQUFIO2FBQ0gsSUFBSSxDQUFDLEVBQUwsQ0FBUSxtRUFBUixFQURHOztFQVZLOztFQWFkLFdBQUEsR0FBYyxRQUFBLENBQUMsT0FBRCxDQUFBO1dBQ1YsS0FBSyxDQUFDLFlBQU4sQ0FBbUIsQ0FBQSxnREFBQSxDQUFBLENBQW1ELE9BQW5ELENBQUEsQ0FBbkI7RUFEVTtBQTFIZCIsInNvdXJjZXNDb250ZW50IjpbIm5vdGlmaWVyID0gcmVxdWlyZSAnbm9kZS1ub3RpZmllcidcbnNoZWxsICAgID0gcmVxdWlyZSgnZWxlY3Ryb24nKS5zaGVsbFxucGF0aCAgICAgPSByZXF1aXJlICdwYXRoJ1xucmVtb3RlICAgPSByZXF1aXJlKCdlbGVjdHJvbicpLnJlbW90ZVxuaTE4biAgICAgPSByZXF1aXJlICdpMThuJ1xuXG57bmFtZW9mLCBnZXRQcm94aWVkTmFtZSwgZml4bGluaywgbm90aWZpY2F0aW9uQ2VudGVyU3VwcG9ydHNTb3VuZH0gPSByZXF1aXJlICcuLi91dGlsJ1xuXG4jIGNvbnZfaWQgbWFya2VycyBmb3IgY2FsbCBub3RpZmljYXRpb25zXG5jYWxsTmVlZEFuc3dlciA9IHt9XG5cbm5vdGlmaWVyU3VwcG9ydHNTb3VuZCA9IG5vdGlmaWNhdGlvbkNlbnRlclN1cHBvcnRzU291bmQoKVxuXG4jIEN1c3RvbSBzb3VuZCBmb3IgbmV3IG1lc3NhZ2Ugbm90aWZpY2F0aW9uc1xuYXVkaW9GaWxlID0gcGF0aC5qb2luIFlBS1lBS19ST09UX0RJUiwgJy4uJywgJ21lZGlhJyxcbiduZXdfbWVzc2FnZS5vZ2cnXG5hdWRpb0VsID0gbmV3IEF1ZGlvKGF1ZGlvRmlsZSlcbmF1ZGlvRWwudm9sdW1lID0gLjRcblxuXG5tb2R1bGUuZXhwb3J0cyA9IChtb2RlbHMpIC0+XG4gICAge2NvbnYsIG5vdGlmeSwgZW50aXR5LCB2aWV3c3RhdGV9ID0gbW9kZWxzXG4gICAgdG9ub3QgPSBub3RpZnkucG9wVG9Ob3RpZnkoKVxuXG4gICAgcXVpZXRJZiA9IChjLCBjaGF0X2lkKSAtPiBkb2N1bWVudD8uaGFzRm9jdXMoKSBvciBjb252LmlzUXVpZXQoYykgb3IgZW50aXR5LmlzU2VsZihjaGF0X2lkKVxuXG4gICAgdG9ub3QuZm9yRWFjaCAobXNnKSAtPlxuICAgICAgICBjb252X2lkID0gbXNnPy5jb252ZXJzYXRpb25faWQ/LmlkXG4gICAgICAgIGMgPSBjb252W2NvbnZfaWRdXG4gICAgICAgIGNoYXRfaWQgPSBtc2c/LnNlbmRlcl9pZD8uY2hhdF9pZFxuXG4gICAgICAgIHByb3hpZWQgPSBnZXRQcm94aWVkTmFtZShtc2cpXG4gICAgICAgIGNpZCA9IGlmIHByb3hpZWQgdGhlbiBwcm94aWVkIGVsc2UgbXNnPy5zZW5kZXJfaWQ/LmNoYXRfaWRcbiAgICAgICAgc2VuZGVyID0gbmFtZW9mIGVudGl0eVtjaWRdXG4gICAgICAgIHRleHQgPSBudWxsXG5cbiAgICAgICAgaWYgbXNnLmNoYXRfbWVzc2FnZT9cbiAgICAgICAgICAgIHJldHVybiB1bmxlc3MgbXNnLmNoYXRfbWVzc2FnZT8ubWVzc2FnZV9jb250ZW50P1xuICAgICAgICAgICAgdGV4dCA9IHRleHRNZXNzYWdlIG1zZy5jaGF0X21lc3NhZ2UubWVzc2FnZV9jb250ZW50LCBwcm94aWVkLCB2aWV3c3RhdGUuc2hvd01lc3NhZ2VJbk5vdGlmaWNhdGlvblxuICAgICAgICBlbHNlIGlmIG1zZy5oYW5nb3V0X2V2ZW50Py5ldmVudF90eXBlID09ICdTVEFSVF9IQU5HT1VUJ1xuICAgICAgICAgICAgdGV4dCA9IGkxOG4uX18gXCJjYWxsLmluY29taW5nOkluY29taW5nIGNhbGxcIlxuICAgICAgICAgICAgY2FsbE5lZWRBbnN3ZXJbY29udl9pZF0gPSB0cnVlXG4gICAgICAgICAgICBub3RyXG4gICAgICAgICAgICAgICAgaHRtbDogXCIje2kxOG4uX18oJ2NhbGwuaW5jb21pbmdfZnJvbTpJbmNvbWluZyBjYWxsIGZyb20gJXMnLCBzZW5kZXIpfS4gXCIgK1xuICAgICAgICAgICAgICAgIFwiPGEgaHJlZj1cXFwiI1xcXCIgY2xhc3M9XFxcImFjY2VwdFxcXCI+I3tpMThuLl9fICdjYWxsLmFjY2VwdDpBY2NlcHQnfTwvYT4gLyBcIiArXG4gICAgICAgICAgICAgICAgXCI8YSBocmVmPVxcXCIjXFxcIiBjbGFzcz1cXFwicmVqZWN0XFxcIj4je2kxOG4uX18gJ2NhbGwucmVqZWN0OlJlamVjdCd9PC9hPlwiXG4gICAgICAgICAgICAgICAgc3RheTogMFxuICAgICAgICAgICAgICAgIGlkOiBcImhhbmcje2NvbnZfaWR9XCJcbiAgICAgICAgICAgICAgICBvbmNsaWNrOiAoZSkgLT5cbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlIGNhbGxOZWVkQW5zd2VyW2NvbnZfaWRdXG4gICAgICAgICAgICAgICAgICAgIGlmIGU/LnRhcmdldD8uY2xhc3NOYW1lID09ICdhY2NlcHQnXG4gICAgICAgICAgICAgICAgICAgICAgICBub3RyKHtodG1sOmkxOG4uX18oJ2NhbGxzLmFjY2VwdGVkOkFjY2VwdGVkJyksIHN0YXk6MTAwMCwgaWQ6XCJoYW5nI3tjb252X2lkfVwifSlcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wZW5IYW5nb3V0IGNvbnZfaWRcbiAgICAgICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgbm90cih7aHRtbDogaTE4bi5fXygnY2FsbHMucmVqZWN0ZWQ6UmVqZWN0ZWQnKSwgc3RheToxMDAwLCBpZDpcImhhbmcje2NvbnZfaWR9XCJ9KVxuICAgICAgICBlbHNlIGlmIG1zZy5oYW5nb3V0X2V2ZW50Py5ldmVudF90eXBlID09ICdFTkRfSEFOR09VVCdcbiAgICAgICAgICAgIGlmIGNhbGxOZWVkQW5zd2VyW2NvbnZfaWRdXG4gICAgICAgICAgICAgICAgZGVsZXRlIGNhbGxOZWVkQW5zd2VyW2NvbnZfaWRdXG4gICAgICAgICAgICAgICAgbm90clxuICAgICAgICAgICAgICAgICAgICBodG1sOiBcIiN7aTE4bi5fXygnY2FsbHMubWlzc2VkOk1pc3NlZCBjYWxsIGZyb20gJXMnLCBzZW5kZXIpfS4gXCIgK1xuICAgICAgICAgICAgICAgICAgICAgICAgXCI8YSBocmVmPVxcXCIjXFxcIj4je2kxOG4uX18oJ2FjdGlvbnMub2s6IE9rJyl9PC9hPlwiXG4gICAgICAgICAgICAgICAgICAgIGlkOiBcImhhbmcje2NvbnZfaWR9XCJcbiAgICAgICAgICAgICAgICAgICAgc3RheTogMFxuICAgICAgICBlbHNlXG4gICAgICAgICAgICByZXR1cm5cblxuICAgICAgICAjIG1heWJlIHRyaWdnZXIgT1Mgbm90aWZpY2F0aW9uXG4gICAgICAgIHJldHVybiBpZiAhdGV4dCBvciBxdWlldElmKGMsIGNoYXRfaWQpXG5cbiAgICAgICAgaWYgdmlld3N0YXRlLnNob3dQb3BVcE5vdGlmaWNhdGlvbnNcbiAgICAgICAgICAgIGlzTm90aWZpY2F0aW9uQ2VudGVyID0gbm90aWZpZXIuY29uc3RydWN0b3IubmFtZSA9PSAnTm90aWZpY2F0aW9uQ2VudGVyJ1xuICAgICAgICAgICAgI1xuICAgICAgICAgICAgaWNvbiA9IHBhdGguam9pbiBfX2Rpcm5hbWUsICcuLicsICcuLicsICdpY29ucycsICdpY29uQDgucG5nJ1xuICAgICAgICAgICAgIyBPbmx5IGZvciBOb3RpZmljYXRpb25DZW50ZXIgKGRhcndpbilcbiAgICAgICAgICAgIGlmIGlzTm90aWZpY2F0aW9uQ2VudGVyICYmIHZpZXdzdGF0ZS5zaG93SWNvbk5vdGlmaWNhdGlvblxuICAgICAgICAgICAgICAgIGNvbnRlbnRJbWFnZSA9IGZpeGxpbmsgZW50aXR5W2NpZF0/LnBob3RvX3VybFxuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgIGNvbnRlbnRJbWFnZSA9IHVuZGVmaW5lZFxuICAgICAgICAgICAgI1xuICAgICAgICAgICAgbm90aWZpZXIubm90aWZ5XG4gICAgICAgICAgICAgICAgdGl0bGU6IGlmIHZpZXdzdGF0ZS5zaG93VXNlcm5hbWVJbk5vdGlmaWNhdGlvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgIWlzTm90aWZpY2F0aW9uQ2VudGVyICYmICF2aWV3c3RhdGUuc2hvd0ljb25Ob3RpZmljYXRpb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIiN7c2VuZGVyfSAoWWFrWWFrKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VuZGVyXG4gICAgICAgICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICdZYWtZYWsnXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogdGV4dFxuICAgICAgICAgICAgICAgIHdhaXQ6IHRydWVcbiAgICAgICAgICAgICAgICBoaW50OiBcImludDp0cmFuc2llbnQ6MVwiXG4gICAgICAgICAgICAgICAgY2F0ZWdvcnk6ICdpbS5yZWNlaXZlZCdcbiAgICAgICAgICAgICAgICBzZW5kZXI6ICdjb20uZ2l0aHViLnlha3lhaydcbiAgICAgICAgICAgICAgICBzb3VuZDogIXZpZXdzdGF0ZS5tdXRlU291bmROb3RpZmljYXRpb24gJiYgKG5vdGlmaWVyU3VwcG9ydHNTb3VuZCAmJiAhdmlld3N0YXRlLmZvcmNlQ3VzdG9tU291bmQpXG4gICAgICAgICAgICAgICAgaWNvbjogaWNvbiBpZiAhaXNOb3RpZmljYXRpb25DZW50ZXIgJiYgdmlld3N0YXRlLnNob3dJY29uTm90aWZpY2F0aW9uXG4gICAgICAgICAgICAgICAgY29udGVudEltYWdlOiBjb250ZW50SW1hZ2VcbiAgICAgICAgICAgICwgKGVyciwgcmVzKSAtPlxuICAgICAgICAgICAgICBpZiByZXM/LnRyaW0oKS5tYXRjaCgvQWN0aXZhdGUvaSlcbiAgICAgICAgICAgICAgICBhY3Rpb24gJ2FwcGZvY3VzJ1xuICAgICAgICAgICAgICAgIGFjdGlvbiAnc2VsZWN0Q29udicsIGNcblxuICAgICAgICAgICAgIyBvbmx5IHBsYXkgaWYgaXQgaXMgbm90IHBsYXlpbmcgYWxyZWFkeVxuICAgICAgICAgICAgIyAgYW5kIG5vdGlmaWVyIGRvZXMgbm90IHN1cHBvcnQgc291bmQgb3IgZm9yY2UgY3VzdG9tIHNvdW5kIGlzIHNldFxuICAgICAgICAgICAgIyAgYW5kIG11dGUgb3B0aW9uIGlzIG5vdCBzZXRcbiAgICAgICAgICAgIGlmICghbm90aWZpZXJTdXBwb3J0c1NvdW5kIHx8IHZpZXdzdGF0ZS5mb3JjZUN1c3RvbVNvdW5kKSAmJiAhdmlld3N0YXRlLm11dGVTb3VuZE5vdGlmaWNhdGlvbiAmJiBhdWRpb0VsLnBhdXNlZFxuICAgICAgICAgICAgICAgIGF1ZGlvRWwucGxheSgpXG4gICAgICAgICMgQW5kIHdlIGhvcGUgd2UgZG9uJ3QgZ2V0IGFub3RoZXIgJ2N1cnJlbnRXaW5kb3cnIDspXG4gICAgICAgIG1haW5XaW5kb3cgPSByZW1vdGUuZ2V0Q3VycmVudFdpbmRvdygpXG4gICAgICAgIG1haW5XaW5kb3cuZmxhc2hGcmFtZSh0cnVlKVxuXG50ZXh0TWVzc2FnZSA9IChjb250LCBwcm94aWVkLCBzaG93TWVzc2FnZSA9IHRydWUpIC0+XG4gICAgaWYgY29udD8uc2VnbWVudD9cbiAgICAgIHVubGVzcyBzaG93TWVzc2FnZVxuICAgICAgICAgIGkxOG4uX18oJ2NvbnZlcnNhdGlvbi5uZXdfbWVzc2FnZTpOZXcgbWVzc2FnZSByZWNlaXZlZCcpXG4gICAgICBlbHNlXG4gICAgICAgICAgc2VncyA9IGZvciBzZWcsIGkgaW4gY29udD8uc2VnbWVudCA/IFtdXG4gICAgICAgICAgICAgIGNvbnRpbnVlIGlmIHByb3hpZWQgYW5kIGkgPCAyXG4gICAgICAgICAgICAgIGNvbnRpbnVlIHVubGVzcyBzZWcudGV4dFxuICAgICAgICAgICAgICBzZWcudGV4dFxuICAgICAgICAgIHNlZ3Muam9pbignJylcbiAgICBlbHNlIGlmIGNvbnQ/LmF0dGFjaG1lbnQ/XG4gICAgICBpMThuLl9fKCdjb252ZXJzYXRpb24ubmV3X2F0dGFjaG1lbnQ6TmV3IG1lc3NhZ2UgcmVjZWl2ZWQgKGltYWdlIG9yIHZpZGVvKScpXG5cbm9wZW5IYW5nb3V0ID0gKGNvbnZfaWQpIC0+XG4gICAgc2hlbGwub3BlbkV4dGVybmFsIFwiaHR0cHM6Ly9wbHVzLmdvb2dsZS5jb20vaGFuZ291dHMvXy9DT05WRVJTQVRJT04vI3tjb252X2lkfVwiXG4iXX0=
