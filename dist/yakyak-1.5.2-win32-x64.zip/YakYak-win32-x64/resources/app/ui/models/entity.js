(function() {
  var add, domerge, funcs, list, lookup, merge, needEntity, shallowif;

  merge = function(t, ...os) {
    var i, k, len, o, v;
    for (i = 0, len = os.length; i < len; i++) {
      o = os[i];
      for (k in o) {
        v = o[k];
        if (v !== null && v !== (void 0)) {
          t[k] = v;
        }
      }
    }
    return t;
  };

  shallowif = function(o, f) {
    var k, r, v;
    r = {};
    for (k in o) {
      v = o[k];
      if (f(k, v)) {
        r[k] = v;
      }
    }
    return r;
  };

  lookup = {};

  domerge = function(id, props) {
    var ref;
    return lookup[id] = merge((ref = lookup[id]) != null ? ref : {}, props);
  };

  add = function(entity, opts = {
      silent: false
    }) {
    var chat_id, clone, gaia_id, ref;
    ({gaia_id, chat_id} = (ref = entity != null ? entity.id : void 0) != null ? ref : {});
    if (!(gaia_id || chat_id)) {
      return null;
    }
    if (!lookup[chat_id]) {
      // ensure there is at least something
      lookup[chat_id] = {};
    }
    // dereference .properties to be on main obj
    if (entity.properties) {
      domerge(chat_id, entity.properties);
    }
    // merge rest of props
    clone = shallowif(entity, function(k) {
      return k !== 'id' && k !== 'properties';
    });
    domerge(chat_id, clone);
    lookup[chat_id].id = chat_id;
    if (chat_id !== gaia_id) {
      // handle different chat_id to gaia_id
      lookup[gaia_id] = lookup[chat_id];
    }
    if (!opts.silent) {
      updated('entity');
    }
    // return the result
    return lookup[chat_id];
  };

  needEntity = (function() {
    var fetch, gather, tim;
    tim = null;
    gather = [];
    fetch = function() {
      tim = null;
      action('getentity', gather);
      return gather = [];
    };
    return function(id, wait = 1000) {
      var ref;
      if ((ref = lookup[id]) != null ? ref.fetching : void 0) {
        return;
      }
      if (lookup[id]) {
        lookup[id].fetching = true;
      } else {
        lookup[id] = {
          id: id,
          fetching: true
        };
      }
      if (tim) {
        clearTimeout(tim);
      }
      tim = setTimeout(fetch, wait);
      return gather.push(id);
    };
  })();

  list = function() {
    var k, results, v;
    results = [];
    for (k in lookup) {
      v = lookup[k];
      if (typeof v === 'object') {
        results.push(v);
      }
    }
    return results;
  };

  funcs = {
    count: function() {
      var c, k, v;
      c = 0;
      (function() {
        var results;
        results = [];
        for (k in lookup) {
          v = lookup[k];
          if (typeof v === 'object') {
            results.push(c++);
          }
        }
        return results;
      })();
      return c;
    },
    list: list,
    setPresence: function(id, p) {
      if (!lookup[id]) {
        return needEntity(id);
      }
      lookup[id].presence = p;
      return updated('entity');
    },
    isSelf: function(chat_id) {
      return !!lookup.self && lookup[chat_id] === lookup.self;
    },
    _reset: function() {
      var k, v;
      for (k in lookup) {
        v = lookup[k];
        if (typeof v === 'object') {
          delete lookup[k];
        }
      }
      updated('entity');
      return null;
    },
    _initFromSelfEntity: function(self) {
      updated('entity');
      return lookup.self = add(self);
    },
    _initFromEntities: function(entities) {
      var c, countIf, entity, i, len;
      c = 0;
      countIf = function(a) {
        if (a) {
          return c++;
        }
      };
      for (i = 0, len = entities.length; i < len; i++) {
        entity = entities[i];
        countIf(add(entity));
      }
      updated('entity');
      return c;
    },
    add: add,
    needEntity: needEntity
  };

  module.exports = merge(lookup, funcs);

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvbW9kZWxzL2VudGl0eS5qcyIsInNvdXJjZXMiOlsidWkvbW9kZWxzL2VudGl0eS5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7QUFBQSxNQUFBLEdBQUEsRUFBQSxPQUFBLEVBQUEsS0FBQSxFQUFBLElBQUEsRUFBQSxNQUFBLEVBQUEsS0FBQSxFQUFBLFVBQUEsRUFBQTs7RUFBQSxLQUFBLEdBQVUsUUFBQSxDQUFDLENBQUQsRUFBQSxHQUFJLEVBQUosQ0FBQTtBQUFjLFFBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxHQUFBLEVBQUEsQ0FBQSxFQUFBO0lBQXNELEtBQUEsb0NBQUE7O01BQTdDLEtBQUEsTUFBQTs7WUFBa0IsQ0FBQSxLQUFVLElBQVYsSUFBQSxDQUFBLEtBQWdCO1VBQTNDLENBQUUsQ0FBQSxDQUFBLENBQUYsR0FBTzs7TUFBRTtJQUE2QztXQUFhO0VBQWpGOztFQUNWLFNBQUEsR0FBWSxRQUFBLENBQUMsQ0FBRCxFQUFJLENBQUosQ0FBQTtBQUFVLFFBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQTtJQUFBLENBQUEsR0FBSSxDQUFBO0lBQWEsS0FBQSxNQUFBOztVQUFtQixDQUFBLENBQUUsQ0FBRixFQUFJLENBQUo7UUFBNUIsQ0FBRSxDQUFBLENBQUEsQ0FBRixHQUFPOztJQUFFO1dBQTJCO0VBQXREOztFQUVaLE1BQUEsR0FBUyxDQUFBOztFQUVULE9BQUEsR0FBVSxRQUFBLENBQUMsRUFBRCxFQUFLLEtBQUwsQ0FBQTtBQUFlLFFBQUE7V0FBQSxNQUFPLENBQUEsRUFBQSxDQUFQLEdBQWEsS0FBQSxvQ0FBb0IsQ0FBQSxDQUFwQixFQUF5QixLQUF6QjtFQUE1Qjs7RUFFVixHQUFBLEdBQU0sUUFBQSxDQUFDLE1BQUQsRUFBUyxPQUFPO01BQUEsTUFBQSxFQUFPO0lBQVAsQ0FBaEIsQ0FBQTtBQUNGLFFBQUEsT0FBQSxFQUFBLEtBQUEsRUFBQSxPQUFBLEVBQUE7SUFBQSxDQUFBLENBQUMsT0FBRCxFQUFVLE9BQVYsQ0FBQSwrREFBa0MsQ0FBQSxDQUFsQztJQUNBLElBQUEsQ0FBQSxDQUFtQixPQUFBLElBQVcsT0FBOUIsQ0FBQTtBQUFBLGFBQU8sS0FBUDs7SUFHQSxJQUFBLENBQTRCLE1BQU8sQ0FBQSxPQUFBLENBQW5DOztNQUFBLE1BQU8sQ0FBQSxPQUFBLENBQVAsR0FBa0IsQ0FBQSxFQUFsQjtLQUpBOztJQU9BLElBQUcsTUFBTSxDQUFDLFVBQVY7TUFDSSxPQUFBLENBQVEsT0FBUixFQUFpQixNQUFNLENBQUMsVUFBeEIsRUFESjtLQVBBOztJQVdBLEtBQUEsR0FBUSxTQUFBLENBQVUsTUFBVixFQUFrQixRQUFBLENBQUMsQ0FBRCxDQUFBO2FBQU8sQ0FBQSxLQUFVLElBQVYsSUFBQSxDQUFBLEtBQWdCO0lBQXZCLENBQWxCO0lBQ1IsT0FBQSxDQUFRLE9BQVIsRUFBaUIsS0FBakI7SUFFQSxNQUFPLENBQUEsT0FBQSxDQUFRLENBQUMsRUFBaEIsR0FBcUI7SUFHckIsSUFBcUMsT0FBQSxLQUFXLE9BQWhEOztNQUFBLE1BQU8sQ0FBQSxPQUFBLENBQVAsR0FBa0IsTUFBTyxDQUFBLE9BQUEsRUFBekI7O0lBRUEsSUFBQSxDQUF3QixJQUFJLENBQUMsTUFBN0I7TUFBQSxPQUFBLENBQVEsUUFBUixFQUFBO0tBbkJBOztXQXNCQSxNQUFPLENBQUEsT0FBQTtFQXZCTDs7RUEwQk4sVUFBQSxHQUFnQixDQUFBLFFBQUEsQ0FBQSxDQUFBO0FBQ1osUUFBQSxLQUFBLEVBQUEsTUFBQSxFQUFBO0lBQUEsR0FBQSxHQUFNO0lBQ04sTUFBQSxHQUFTO0lBQ1QsS0FBQSxHQUFRLFFBQUEsQ0FBQSxDQUFBO01BQ0osR0FBQSxHQUFNO01BQ04sTUFBQSxDQUFPLFdBQVAsRUFBb0IsTUFBcEI7YUFDQSxNQUFBLEdBQVM7SUFITDtXQUlSLFFBQUEsQ0FBQyxFQUFELEVBQUssT0FBSyxJQUFWLENBQUE7QUFDSSxVQUFBO01BQUEsb0NBQW9CLENBQUUsaUJBQXRCO0FBQUEsZUFBQTs7TUFDQSxJQUFHLE1BQU8sQ0FBQSxFQUFBLENBQVY7UUFDSSxNQUFPLENBQUEsRUFBQSxDQUFHLENBQUMsUUFBWCxHQUFzQixLQUQxQjtPQUFBLE1BQUE7UUFHSSxNQUFPLENBQUEsRUFBQSxDQUFQLEdBQWE7VUFDVCxFQUFBLEVBQUksRUFESztVQUVULFFBQUEsRUFBVTtRQUZELEVBSGpCOztNQU9BLElBQW9CLEdBQXBCO1FBQUEsWUFBQSxDQUFhLEdBQWIsRUFBQTs7TUFDQSxHQUFBLEdBQU0sVUFBQSxDQUFXLEtBQVgsRUFBa0IsSUFBbEI7YUFDTixNQUFNLENBQUMsSUFBUCxDQUFZLEVBQVo7SUFYSjtFQVBZLENBQUEsQ0FBSCxDQUFBOztFQW9CYixJQUFBLEdBQU8sUUFBQSxDQUFBLENBQUE7QUFDSCxRQUFBLENBQUEsRUFBQSxPQUFBLEVBQUE7QUFBRTtJQUFBLEtBQUEsV0FBQTs7VUFBd0IsT0FBTyxDQUFQLEtBQVk7cUJBQXRDOztJQUFFLENBQUE7O0VBREM7O0VBS1AsS0FBQSxHQUNJO0lBQUEsS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO0FBQ0gsVUFBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBO01BQUEsQ0FBQSxHQUFJOzs7QUFBUTtRQUFBLEtBQUEsV0FBQTs7Y0FBd0IsT0FBTyxDQUFQLEtBQVk7eUJBQXhDLENBQUE7O1FBQUksQ0FBQTs7O2FBQStDO0lBRHhELENBQVA7SUFHQSxJQUFBLEVBQU0sSUFITjtJQUtBLFdBQUEsRUFBYSxRQUFBLENBQUMsRUFBRCxFQUFLLENBQUwsQ0FBQTtNQUNULElBQXlCLENBQUksTUFBTyxDQUFBLEVBQUEsQ0FBcEM7QUFBQSxlQUFPLFVBQUEsQ0FBVyxFQUFYLEVBQVA7O01BQ0EsTUFBTyxDQUFBLEVBQUEsQ0FBRyxDQUFDLFFBQVgsR0FBc0I7YUFDdEIsT0FBQSxDQUFRLFFBQVI7SUFIUyxDQUxiO0lBVUEsTUFBQSxFQUFRLFFBQUEsQ0FBQyxPQUFELENBQUE7QUFBYSxhQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBVCxJQUFrQixNQUFPLENBQUEsT0FBQSxDQUFQLEtBQW1CLE1BQU0sQ0FBQztJQUFoRSxDQVZSO0lBWUEsTUFBQSxFQUFRLFFBQUEsQ0FBQSxDQUFBO0FBQ0osVUFBQSxDQUFBLEVBQUE7TUFBaUIsS0FBQSxXQUFBOztZQUF3QixPQUFPLENBQVAsS0FBWTtVQUFyRCxPQUFPLE1BQU8sQ0FBQSxDQUFBOztNQUFHO01BQ2pCLE9BQUEsQ0FBUSxRQUFSO2FBQ0E7SUFISSxDQVpSO0lBaUJBLG1CQUFBLEVBQXFCLFFBQUEsQ0FBQyxJQUFELENBQUE7TUFDakIsT0FBQSxDQUFRLFFBQVI7YUFDQSxNQUFNLENBQUMsSUFBUCxHQUFjLEdBQUEsQ0FBSSxJQUFKO0lBRkcsQ0FqQnJCO0lBcUJBLGlCQUFBLEVBQXFCLFFBQUEsQ0FBQyxRQUFELENBQUE7QUFDakIsVUFBQSxDQUFBLEVBQUEsT0FBQSxFQUFBLE1BQUEsRUFBQSxDQUFBLEVBQUE7TUFBQSxDQUFBLEdBQUk7TUFDSixPQUFBLEdBQVUsUUFBQSxDQUFDLENBQUQsQ0FBQTtRQUFPLElBQU8sQ0FBUDtpQkFBQSxDQUFBLEdBQUE7O01BQVA7TUFDUyxLQUFBLDBDQUFBOztRQUFuQixPQUFBLENBQVEsR0FBQSxDQUFJLE1BQUosQ0FBUjtNQUFtQjtNQUNuQixPQUFBLENBQVEsUUFBUjthQUNBO0lBTGlCLENBckJyQjtJQTRCQSxHQUFBLEVBQUssR0E1Qkw7SUE2QkEsVUFBQSxFQUFZO0VBN0JaOztFQStCSixNQUFNLENBQUMsT0FBUCxHQUFpQixLQUFBLENBQU0sTUFBTixFQUFjLEtBQWQ7QUExRmpCIiwic291cmNlc0NvbnRlbnQiOlsiXG5tZXJnZSAgID0gKHQsIG9zLi4uKSAtPiB0W2tdID0gdiBmb3Igayx2IG9mIG8gd2hlbiB2IG5vdCBpbiBbbnVsbCwgdW5kZWZpbmVkXSBmb3IgbyBpbiBvczsgdFxuc2hhbGxvd2lmID0gKG8sIGYpIC0+IHIgPSB7fTsgcltrXSA9IHYgZm9yIGssIHYgb2YgbyB3aGVuIGYoayx2KTsgclxuXG5sb29rdXAgPSB7fVxuXG5kb21lcmdlID0gKGlkLCBwcm9wcykgLT4gbG9va3VwW2lkXSA9IG1lcmdlIChsb29rdXBbaWRdID8ge30pLCBwcm9wc1xuXG5hZGQgPSAoZW50aXR5LCBvcHRzID0gc2lsZW50OmZhbHNlKSAtPlxuICAgIHtnYWlhX2lkLCBjaGF0X2lkfSA9IGVudGl0eT8uaWQgPyB7fVxuICAgIHJldHVybiBudWxsIHVubGVzcyBnYWlhX2lkIG9yIGNoYXRfaWRcblxuICAgICMgZW5zdXJlIHRoZXJlIGlzIGF0IGxlYXN0IHNvbWV0aGluZ1xuICAgIGxvb2t1cFtjaGF0X2lkXSA9IHt9IHVubGVzcyBsb29rdXBbY2hhdF9pZF1cblxuICAgICMgZGVyZWZlcmVuY2UgLnByb3BlcnRpZXMgdG8gYmUgb24gbWFpbiBvYmpcbiAgICBpZiBlbnRpdHkucHJvcGVydGllc1xuICAgICAgICBkb21lcmdlIGNoYXRfaWQsIGVudGl0eS5wcm9wZXJ0aWVzXG5cbiAgICAjIG1lcmdlIHJlc3Qgb2YgcHJvcHNcbiAgICBjbG9uZSA9IHNoYWxsb3dpZiBlbnRpdHksIChrKSAtPiBrIG5vdCBpbiBbJ2lkJywgJ3Byb3BlcnRpZXMnXVxuICAgIGRvbWVyZ2UgY2hhdF9pZCwgY2xvbmVcblxuICAgIGxvb2t1cFtjaGF0X2lkXS5pZCA9IGNoYXRfaWRcblxuICAgICMgaGFuZGxlIGRpZmZlcmVudCBjaGF0X2lkIHRvIGdhaWFfaWRcbiAgICBsb29rdXBbZ2FpYV9pZF0gPSBsb29rdXBbY2hhdF9pZF0gaWYgY2hhdF9pZCAhPSBnYWlhX2lkXG5cbiAgICB1cGRhdGVkICdlbnRpdHknIHVubGVzcyBvcHRzLnNpbGVudFxuXG4gICAgIyByZXR1cm4gdGhlIHJlc3VsdFxuICAgIGxvb2t1cFtjaGF0X2lkXVxuXG5cbm5lZWRFbnRpdHkgPSBkbyAtPlxuICAgIHRpbSA9IG51bGxcbiAgICBnYXRoZXIgPSBbXVxuICAgIGZldGNoID0gLT5cbiAgICAgICAgdGltID0gbnVsbFxuICAgICAgICBhY3Rpb24gJ2dldGVudGl0eScsIGdhdGhlclxuICAgICAgICBnYXRoZXIgPSBbXVxuICAgIChpZCwgd2FpdD0xMDAwKSAtPlxuICAgICAgICByZXR1cm4gaWYgbG9va3VwW2lkXT8uZmV0Y2hpbmdcbiAgICAgICAgaWYgbG9va3VwW2lkXVxuICAgICAgICAgICAgbG9va3VwW2lkXS5mZXRjaGluZyA9IHRydWVcbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgbG9va3VwW2lkXSA9IHtcbiAgICAgICAgICAgICAgICBpZDogaWRcbiAgICAgICAgICAgICAgICBmZXRjaGluZzogdHJ1ZVxuICAgICAgICAgICAgfVxuICAgICAgICBjbGVhclRpbWVvdXQgdGltIGlmIHRpbVxuICAgICAgICB0aW0gPSBzZXRUaW1lb3V0IGZldGNoLCB3YWl0XG4gICAgICAgIGdhdGhlci5wdXNoIGlkXG5cbmxpc3QgPSAtPlxuICAgIHYgZm9yIGssIHYgb2YgbG9va3VwIHdoZW4gdHlwZW9mIHYgPT0gJ29iamVjdCdcblxuXG5cbmZ1bmNzID1cbiAgICBjb3VudDogLT5cbiAgICAgICAgYyA9IDA7IChjKysgZm9yIGssIHYgb2YgbG9va3VwIHdoZW4gdHlwZW9mIHYgPT0gJ29iamVjdCcpOyBjXG5cbiAgICBsaXN0OiBsaXN0XG5cbiAgICBzZXRQcmVzZW5jZTogKGlkLCBwKSAtPlxuICAgICAgICByZXR1cm4gbmVlZEVudGl0eShpZCkgaWYgbm90IGxvb2t1cFtpZF1cbiAgICAgICAgbG9va3VwW2lkXS5wcmVzZW5jZSA9IHBcbiAgICAgICAgdXBkYXRlZCAnZW50aXR5J1xuXG4gICAgaXNTZWxmOiAoY2hhdF9pZCkgLT4gcmV0dXJuICEhbG9va3VwLnNlbGYgYW5kIGxvb2t1cFtjaGF0X2lkXSA9PSBsb29rdXAuc2VsZlxuXG4gICAgX3Jlc2V0OiAtPlxuICAgICAgICBkZWxldGUgbG9va3VwW2tdIGZvciBrLCB2IG9mIGxvb2t1cCB3aGVuIHR5cGVvZiB2ID09ICdvYmplY3QnXG4gICAgICAgIHVwZGF0ZWQgJ2VudGl0eSdcbiAgICAgICAgbnVsbFxuXG4gICAgX2luaXRGcm9tU2VsZkVudGl0eTogKHNlbGYpIC0+XG4gICAgICAgIHVwZGF0ZWQgJ2VudGl0eSdcbiAgICAgICAgbG9va3VwLnNlbGYgPSBhZGQgc2VsZlxuXG4gICAgX2luaXRGcm9tRW50aXRpZXM6ICAgKGVudGl0aWVzKSAtPlxuICAgICAgICBjID0gMFxuICAgICAgICBjb3VudElmID0gKGEpIC0+IGMrKyBpZiBhXG4gICAgICAgIGNvdW50SWYgYWRkIGVudGl0eSBmb3IgZW50aXR5IGluIGVudGl0aWVzXG4gICAgICAgIHVwZGF0ZWQgJ2VudGl0eSdcbiAgICAgICAgY1xuXG4gICAgYWRkOiBhZGRcbiAgICBuZWVkRW50aXR5OiBuZWVkRW50aXR5XG5cbm1vZHVsZS5leHBvcnRzID0gbWVyZ2UgbG9va3VwLCBmdW5jc1xuIl19
