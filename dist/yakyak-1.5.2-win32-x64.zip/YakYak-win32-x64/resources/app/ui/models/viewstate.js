(function() {
  var Client, STATES, autoLauncher, exp, later, merge, ref, ref1, ref10, ref11, ref12, ref13, ref14, ref15, ref16, ref17, ref2, ref3, ref4, ref5, ref6, ref7, ref8, ref9, throttle, tryparse;

  Client = require('hangupsjs');

  merge = function(t, ...os) {
    var j, k, len, o, v;
    for (j = 0, len = os.length; j < len; j++) {
      o = os[j];
      for (k in o) {
        v = o[k];
        if (v !== null && v !== (void 0)) {
          t[k] = v;
        }
      }
    }
    return t;
  };

  ({throttle, later, tryparse, autoLauncher} = require('../util'));

  STATES = {
    STATE_STARTUP: 'startup',
    STATE_NORMAL: 'normal',
    STATE_ADD_CONVERSATION: 'add_conversation',
    STATE_ABOUT: 'about'
  };

  module.exports = exp = {
    state: null,
    attop: false, // tells whether message list is scrolled to top
    atbottom: true, // tells whether message list is scrolled to bottom
    selectedConv: localStorage.selectedConv,
    lastActivity: null,
    leftSize: (ref = tryparse(localStorage.leftSize)) != null ? ref : 240,
    size: tryparse((ref1 = localStorage.size) != null ? ref1 : "[940, 600]"),
    pos: tryparse((ref2 = localStorage.pos) != null ? ref2 : "[100, 100]"),
    showConvMin: (ref3 = tryparse(localStorage.showConvMin)) != null ? ref3 : false,
    showConvThumbs: (ref4 = tryparse(localStorage.showConvThumbs)) != null ? ref4 : true,
    showAnimatedThumbs: (ref5 = tryparse(localStorage.showAnimatedThumbs)) != null ? ref5 : true,
    showConvTime: (ref6 = tryparse(localStorage.showConvTime)) != null ? ref6 : true,
    showConvLast: (ref7 = tryparse(localStorage.showConvLast)) != null ? ref7 : true,
    showPopUpNotifications: (ref8 = tryparse(localStorage.showPopUpNotifications)) != null ? ref8 : true,
    showMessageInNotification: (ref9 = tryparse(localStorage.showMessageInNotification)) != null ? ref9 : true,
    showUsernameInNotification: (ref10 = tryparse(localStorage.showUsernameInNotification)) != null ? ref10 : true,
    convertEmoji: (ref11 = tryparse(localStorage.convertEmoji)) != null ? ref11 : true,
    suggestEmoji: (ref12 = tryparse(localStorage.suggestEmoji)) != null ? ref12 : true,
    colorScheme: localStorage.colorScheme || 'default',
    fontSize: localStorage.fontSize || 'medium',
    zoom: tryparse((ref13 = localStorage.zoom) != null ? ref13 : "1.0"),
    loggedin: false,
    escapeClearsInput: tryparse(localStorage.escapeClearsInput) || false,
    showtray: tryparse(localStorage.showtray) || false,
    hidedockicon: tryparse(localStorage.hidedockicon) || false,
    startminimizedtotray: tryparse(localStorage.startminimizedtotray) || false,
    closetotray: tryparse(localStorage.closetotray) || false,
    showDockOnce: true,
    showIconNotification: (ref14 = tryparse(localStorage.showIconNotification)) != null ? ref14 : true,
    muteSoundNotification: (ref15 = tryparse(localStorage.muteSoundNotification)) != null ? ref15 : false,
    forceCustomSound: (ref16 = tryparse(localStorage.forceCustomSound)) != null ? ref16 : false,
    language: (ref17 = localStorage.language) != null ? ref17 : 'en',
    useSystemDateFormat: localStorage.useSystemDateFormat === "true",
    // non persistent!
    messageMemory: {},
    cachedInitialsCode: {},
    // contacts are loaded
    loadedContacts: false,
    openOnSystemStartup: false,
    setUseSystemDateFormat: function(val) {
      this.useSystemDateFormat = val;
      localStorage.useSystemDateFormat = val;
      return updated('language');
    },
    setContacts: function(state) {
      if (state === this.loadedContacts) {
        return;
      }
      this.loadedContacts = state;
      return updated('viewstate');
    },
    setState: function(state) {
      if (this.state === state) {
        return;
      }
      this.state = state;
      if (state === STATES.STATE_STARTUP) {
        // set a first active timestamp to avoid requesting
        // syncallnewevents on startup
        require('./connection').setLastActive(Date.now(), true);
      }
      return updated('viewstate');
    },
    setLanguage: function(language) {
      if (this.language === language) {
        return;
      }
      i18n.locale = language;
      i18n.setLocale(language);
      this.language = localStorage.language = language;
      return updated('language');
    },
    switchInput: function(next_conversation_id) {
      var el;
      // if conversation is changing, save input
      el = document.getElementById('message-input');
      if (el == null) {
        console.log('Warning: could not retrieve message input to store.');
        return;
      }
      // save current input
      this.messageMemory[this.selectedConv] = el.value;
      // either reset or fetch previous input of the new conv
      if (this.messageMemory[next_conversation_id] != null) {
        el.value = this.messageMemory[next_conversation_id];
        // once old conversation is retrieved memory is wiped
        return this.messageMemory[next_conversation_id] = "";
      } else {
        return el.value = '';
      }
    },
    
    setSelectedConv: function(c) {
      var conv, conv_id, ref18, ref19, ref20, ref21, ref22, ref23;
      conv = require('./conv'); // circular
      conv_id = (ref18 = (ref19 = c != null ? (ref20 = c.conversation_id) != null ? ref20.id : void 0 : void 0) != null ? ref19 : c != null ? c.id : void 0) != null ? ref18 : c;
      if (!conv_id) {
        conv_id = (ref21 = conv.list()) != null ? (ref22 = ref21[0]) != null ? (ref23 = ref22.conversation_id) != null ? ref23.id : void 0 : void 0 : void 0;
      }
      if (this.selectedConv === conv_id) {
        return;
      }
      this.switchInput(conv_id);
      this.selectedConv = localStorage.selectedConv = conv_id;
      this.setLastKeyDown(0);
      updated('viewstate');
      return updated('switchConv');
    },
    selectNextConv: function(offset = 1) {
      var c, candidate, conv, i, id, index, j, len, list, results;
      conv = require('./conv');
      id = this.selectedConv;
      c = conv[id];
      list = (function() {
        var j, len, ref18, results;
        ref18 = conv.list();
        results = [];
        for (j = 0, len = ref18.length; j < len; j++) {
          i = ref18[j];
          if (!conv.isPureHangout(i)) {
            results.push(i);
          }
        }
        return results;
      })();
      results = [];
      for (index = j = 0, len = list.length; j < len; index = ++j) {
        c = list[index];
        if (id === c.conversation_id.id) {
          candidate = index + offset;
          if (list[candidate]) {
            results.push(this.setSelectedConv(list[candidate]));
          } else {
            results.push(void 0);
          }
        } else {
          results.push(void 0);
        }
      }
      return results;
    },
    selectConvIndex: function(index = 0) {
      var conv, i, list;
      conv = require('./conv');
      list = (function() {
        var j, len, ref18, results;
        ref18 = conv.list();
        results = [];
        for (j = 0, len = ref18.length; j < len; j++) {
          i = ref18[j];
          if (!conv.isPureHangout(i)) {
            results.push(i);
          }
        }
        return results;
      })();
      return this.setSelectedConv(list[index]);
    },
    updateAtTop: function(attop) {
      if (this.attop === attop) {
        return;
      }
      this.attop = attop;
      return updated('viewstate');
    },
    updateAtBottom: function(atbottom) {
      if (this.atbottom === atbottom) {
        return;
      }
      this.atbottom = atbottom;
      return this.updateActivity(Date.now());
    },
    updateActivity: function(time) {
      var c, conv, ur;
      conv = require('./conv'); // circular
      this.lastActivity = time;
      later(function() {
        return action('lastActivity');
      });
      if (!(document.hasFocus() && this.atbottom && this.state === STATES.STATE_NORMAL)) {
        return;
      }
      c = conv[this.selectedConv];
      if (!c) {
        return;
      }
      ur = conv.unread(c);
      if (ur > 0) {
        return later(function() {
          return action('updatewatermark');
        });
      }
    },
    setSize: function(size) {
      localStorage.size = JSON.stringify(size);
      return this.size = size;
    },
    // updated 'viewstate'
    setPosition: function(pos) {
      localStorage.pos = JSON.stringify(pos);
      return this.pos = pos;
    },
    // updated 'viewstate'
    setLeftSize: function(size) {
      if (this.leftSize === size || size < 180) {
        return;
      }
      this.leftSize = localStorage.leftSize = size;
      return updated('viewstate');
    },
    setZoom: function(zoom) {
      this.zoom = localStorage.zoom = document.body.style.zoom = zoom;
      return document.body.style.setProperty('--zoom', zoom);
    },
    setLoggedin: function(val) {
      this.loggedin = val;
      return updated('viewstate');
    },
    setShowSeenStatus: function(val) {
      this.showseenstatus = localStorage.showseenstatus = !!val;
      return updated('viewstate');
    },
    setLastKeyDown: (function() {
      var PAUSED, STOPPED, TYPING, lastEmitted, timeout, update;
      ({TYPING, PAUSED, STOPPED} = Client.TypingStatus);
      lastEmitted = 0;
      timeout = 0;
      return update = throttle(500, function(time) {
        if (timeout) {
          clearTimeout(timeout);
        }
        timeout = null;
        if (!time) {
          return lastEmitted = 0;
        } else {
          if (time - lastEmitted > 5000) {
            later(function() {
              return action('settyping', TYPING);
            });
            lastEmitted = time;
          }
          return timeout = setTimeout(function() {
            // after 6 secods of no keyboard, we consider the
            // user took a break.
            lastEmitted = 0;
            action('settyping', PAUSED);
            return timeout = setTimeout(function() {
              // and after another 6 seconds (12 total), we
              // consider the typing stopped altogether.
              return action('settyping', STOPPED);
            }, 6000);
          }, 6000);
        }
      });
    })(),
    setShowConvMin: function(doshow) {
      if (this.showConvMin === doshow) {
        return;
      }
      this.showConvMin = localStorage.showConvMin = doshow;
      if (doshow) {
        this.setShowConvThumbs(true);
      }
      return updated('viewstate');
    },
    setShowConvThumbs: function(doshow) {
      if (this.showConvThumbs === doshow) {
        return;
      }
      this.showConvThumbs = localStorage.showConvThumbs = doshow;
      if (!doshow) {
        this.setShowConvMin(false);
      }
      return updated('viewstate');
    },
    setShowAnimatedThumbs: function(doshow) {
      if (this.showAnimatedThumbs === doshow) {
        return;
      }
      this.showAnimatedThumbs = localStorage.showAnimatedThumbs = doshow;
      return updated('viewstate');
    },
    setShowConvTime: function(doshow) {
      if (this.showConvTime === doshow) {
        return;
      }
      this.showConvTime = localStorage.showConvTime = doshow;
      return updated('viewstate');
    },
    setShowConvLast: function(doshow) {
      if (this.showConvLast === doshow) {
        return;
      }
      this.showConvLast = localStorage.showConvLast = doshow;
      return updated('viewstate');
    },
    setShowPopUpNotifications: function(doshow) {
      if (this.showPopUpNotifications === doshow) {
        return;
      }
      this.showPopUpNotifications = localStorage.showPopUpNotifications = doshow;
      return updated('viewstate');
    },
    setShowMessageInNotification: function(doshow) {
      if (this.showMessageInNotification === doshow) {
        return;
      }
      this.showMessageInNotification = localStorage.showMessageInNotification = doshow;
      return updated('viewstate');
    },
    setShowUsernameInNotification: function(doshow) {
      if (this.showUsernameInNotification === doshow) {
        return;
      }
      this.showUsernameInNotification = localStorage.showUsernameInNotification = doshow;
      return updated('viewstate');
    },
    setForceCustomSound: function(doshow) {
      if (localStorage.forceCustomSound === doshow) {
        return;
      }
      this.forceCustomSound = localStorage.forceCustomSound = doshow;
      return updated('viewstate');
    },
    setShowIconNotification: function(doshow) {
      if (localStorage.showIconNotification === doshow) {
        return;
      }
      this.showIconNotification = localStorage.showIconNotification = doshow;
      return updated('viewstate');
    },
    setMuteSoundNotification: function(doshow) {
      if (localStorage.muteSoundNotification === doshow) {
        return;
      }
      this.muteSoundNotification = localStorage.muteSoundNotification = doshow;
      return updated('viewstate');
    },
    setConvertEmoji: function(doshow) {
      if (this.convertEmoji === doshow) {
        return;
      }
      this.convertEmoji = localStorage.convertEmoji = doshow;
      return updated('viewstate');
    },
    setSuggestEmoji: function(doshow) {
      if (this.suggestEmoji === doshow) {
        return;
      }
      this.suggestEmoji = localStorage.suggestEmoji = doshow;
      return updated('viewstate');
    },
    setColorScheme: function(colorscheme) {
      this.colorScheme = localStorage.colorScheme = colorscheme;
      while (document.querySelector('html').classList.length > 0) {
        document.querySelector('html').classList.remove(document.querySelector('html').classList.item(0));
      }
      return document.querySelector('html').classList.add(colorscheme);
    },
    setFontSize: function(fontsize) {
      this.fontSize = localStorage.fontSize = fontsize;
      while (document.querySelector('html').classList.length > 0) {
        document.querySelector('html').classList.remove(document.querySelector('html').classList.item(0));
      }
      document.querySelector('html').classList.add(localStorage.colorScheme);
      return document.querySelector('html').classList.add(fontsize);
    },
    setEscapeClearsInput: function(value) {
      this.escapeClearsInput = localStorage.escapeClearsInput = value;
      return updated('viewstate');
    },
    setShowTray: function(value) {
      this.showtray = localStorage.showtray = value;
      if (!this.showtray) {
        this.setCloseToTray(false);
        return this.setStartMinimizedToTray(false);
      } else {
        return updated('viewstate');
      }
    },
    setHideDockIcon: function(value) {
      this.hidedockicon = localStorage.hidedockicon = value;
      return updated('viewstate');
    },
    setStartMinimizedToTray: function(value) {
      this.startminimizedtotray = localStorage.startminimizedtotray = value;
      return updated('viewstate');
    },
    setShowDockIconOnce: function(value) {
      return this.showDockIconOnce = value;
    },
    setCloseToTray: function(value) {
      this.closetotray = localStorage.closetotray = !!value;
      return updated('viewstate');
    },
    setOpenOnSystemStartup: function(open) {
      if (this.openOnSystemStartup === open) {
        return;
      }
      if (open) {
        autoLauncher.enable();
      } else {
        autoLauncher.disable();
      }
      this.openOnSystemStartup = open;
      return updated('viewstate');
    },
    initOpenOnSystemStartup: function(isEnabled) {
      this.openOnSystemStartup = isEnabled;
      return updated('viewstate');
    }
  };

  merge(exp, STATES);

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvbW9kZWxzL3ZpZXdzdGF0ZS5qcyIsInNvdXJjZXMiOlsidWkvbW9kZWxzL3ZpZXdzdGF0ZS5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLE1BQUEsRUFBQSxNQUFBLEVBQUEsWUFBQSxFQUFBLEdBQUEsRUFBQSxLQUFBLEVBQUEsS0FBQSxFQUFBLEdBQUEsRUFBQSxJQUFBLEVBQUEsS0FBQSxFQUFBLEtBQUEsRUFBQSxLQUFBLEVBQUEsS0FBQSxFQUFBLEtBQUEsRUFBQSxLQUFBLEVBQUEsS0FBQSxFQUFBLEtBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLFFBQUEsRUFBQTs7RUFBQSxNQUFBLEdBQVMsT0FBQSxDQUFRLFdBQVI7O0VBRVQsS0FBQSxHQUFVLFFBQUEsQ0FBQyxDQUFELEVBQUEsR0FBSSxFQUFKLENBQUE7QUFBYyxRQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsR0FBQSxFQUFBLENBQUEsRUFBQTtJQUFzRCxLQUFBLG9DQUFBOztNQUE3QyxLQUFBLE1BQUE7O1lBQWtCLENBQUEsS0FBVSxJQUFWLElBQUEsQ0FBQSxLQUFnQjtVQUEzQyxDQUFFLENBQUEsQ0FBQSxDQUFGLEdBQU87O01BQUU7SUFBNkM7V0FBYTtFQUFqRjs7RUFFVixDQUFBLENBQUMsUUFBRCxFQUFXLEtBQVgsRUFBa0IsUUFBbEIsRUFBNEIsWUFBNUIsQ0FBQSxHQUE0QyxPQUFBLENBQVEsU0FBUixDQUE1Qzs7RUFFQSxNQUFBLEdBQ0k7SUFBQSxhQUFBLEVBQWUsU0FBZjtJQUNBLFlBQUEsRUFBYyxRQURkO0lBRUEsc0JBQUEsRUFBd0Isa0JBRnhCO0lBR0EsV0FBQSxFQUFhO0VBSGI7O0VBS0osTUFBTSxDQUFDLE9BQVAsR0FBaUIsR0FBQSxHQUFNO0lBQ25CLEtBQUEsRUFBTyxJQURZO0lBRW5CLEtBQUEsRUFBTyxLQUZZO0lBR25CLFFBQUEsRUFBVSxJQUhTO0lBSW5CLFlBQUEsRUFBYyxZQUFZLENBQUMsWUFKUjtJQUtuQixZQUFBLEVBQWMsSUFMSztJQU1uQixRQUFBLDBEQUE0QyxHQU56QjtJQU9uQixJQUFBLEVBQU0sUUFBQSw2Q0FBNkIsWUFBN0IsQ0FQYTtJQVFuQixHQUFBLEVBQUssUUFBQSw0Q0FBNEIsWUFBNUIsQ0FSYztJQVNuQixXQUFBLCtEQUFrRCxLQVQvQjtJQVVuQixjQUFBLGtFQUF3RCxJQVZyQztJQVduQixrQkFBQSxzRUFBZ0UsSUFYN0M7SUFZbkIsWUFBQSxnRUFBb0QsSUFaakM7SUFhbkIsWUFBQSxnRUFBb0QsSUFiakM7SUFjbkIsc0JBQUEsMEVBQXdFLElBZHJEO0lBZW5CLHlCQUFBLDZFQUE4RSxJQWYzRDtJQWdCbkIsMEJBQUEsZ0ZBQWdGLElBaEI3RDtJQWlCbkIsWUFBQSxrRUFBb0QsSUFqQmpDO0lBa0JuQixZQUFBLGtFQUFvRCxJQWxCakM7SUFtQm5CLFdBQUEsRUFBYSxZQUFZLENBQUMsV0FBYixJQUE0QixTQW5CdEI7SUFvQm5CLFFBQUEsRUFBVSxZQUFZLENBQUMsUUFBYixJQUF5QixRQXBCaEI7SUFxQm5CLElBQUEsRUFBTSxRQUFBLCtDQUE2QixLQUE3QixDQXJCYTtJQXNCbkIsUUFBQSxFQUFVLEtBdEJTO0lBdUJuQixpQkFBQSxFQUFtQixRQUFBLENBQVMsWUFBWSxDQUFDLGlCQUF0QixDQUFBLElBQTRDLEtBdkI1QztJQXdCbkIsUUFBQSxFQUFVLFFBQUEsQ0FBUyxZQUFZLENBQUMsUUFBdEIsQ0FBQSxJQUFtQyxLQXhCMUI7SUF5Qm5CLFlBQUEsRUFBYyxRQUFBLENBQVMsWUFBWSxDQUFDLFlBQXRCLENBQUEsSUFBdUMsS0F6QmxDO0lBMEJuQixvQkFBQSxFQUFzQixRQUFBLENBQVMsWUFBWSxDQUFDLG9CQUF0QixDQUFBLElBQStDLEtBMUJsRDtJQTJCbkIsV0FBQSxFQUFhLFFBQUEsQ0FBUyxZQUFZLENBQUMsV0FBdEIsQ0FBQSxJQUFzQyxLQTNCaEM7SUE0Qm5CLFlBQUEsRUFBYyxJQTVCSztJQTZCbkIsb0JBQUEsMEVBQW9FLElBN0JqRDtJQThCbkIscUJBQUEsMkVBQXNFLEtBOUJuRDtJQStCbkIsZ0JBQUEsc0VBQTRELEtBL0J6QztJQWdDbkIsUUFBQSxvREFBa0MsSUFoQ2Y7SUFpQ25CLG1CQUFBLEVBQXFCLFlBQVksQ0FBQyxtQkFBYixLQUFvQyxNQWpDdEM7O0lBbUNuQixhQUFBLEVBQWUsQ0FBQSxDQW5DSTtJQW9DbkIsa0JBQUEsRUFBb0IsQ0FBQSxDQXBDRDs7SUFzQ25CLGNBQUEsRUFBZ0IsS0F0Q0c7SUF1Q25CLG1CQUFBLEVBQXFCLEtBdkNGO0lBeUNuQixzQkFBQSxFQUF3QixRQUFBLENBQUMsR0FBRCxDQUFBO01BQ3BCLElBQUMsQ0FBQSxtQkFBRCxHQUF1QjtNQUN2QixZQUFZLENBQUMsbUJBQWIsR0FBbUM7YUFDbkMsT0FBQSxDQUFRLFVBQVI7SUFIb0IsQ0F6Q0w7SUE4Q25CLFdBQUEsRUFBYSxRQUFBLENBQUMsS0FBRCxDQUFBO01BQ1QsSUFBVSxLQUFBLEtBQVMsSUFBQyxDQUFBLGNBQXBCO0FBQUEsZUFBQTs7TUFDQSxJQUFDLENBQUEsY0FBRCxHQUFrQjthQUNsQixPQUFBLENBQVEsV0FBUjtJQUhTLENBOUNNO0lBbURuQixRQUFBLEVBQVUsUUFBQSxDQUFDLEtBQUQsQ0FBQTtNQUNOLElBQVUsSUFBQyxDQUFBLEtBQUQsS0FBVSxLQUFwQjtBQUFBLGVBQUE7O01BQ0EsSUFBQyxDQUFBLEtBQUQsR0FBUztNQUNULElBQUcsS0FBQSxLQUFTLE1BQU0sQ0FBQyxhQUFuQjs7O1FBR0ksT0FBQSxDQUFRLGNBQVIsQ0FBdUIsQ0FBQyxhQUF4QixDQUFzQyxJQUFJLENBQUMsR0FBTCxDQUFBLENBQXRDLEVBQWtELElBQWxELEVBSEo7O2FBSUEsT0FBQSxDQUFRLFdBQVI7SUFQTSxDQW5EUztJQTREbkIsV0FBQSxFQUFhLFFBQUEsQ0FBQyxRQUFELENBQUE7TUFDVCxJQUFVLElBQUMsQ0FBQSxRQUFELEtBQWEsUUFBdkI7QUFBQSxlQUFBOztNQUNBLElBQUksQ0FBQyxNQUFMLEdBQWM7TUFDZCxJQUFJLENBQUMsU0FBTCxDQUFlLFFBQWY7TUFDQSxJQUFDLENBQUEsUUFBRCxHQUFZLFlBQVksQ0FBQyxRQUFiLEdBQXdCO2FBQ3BDLE9BQUEsQ0FBUSxVQUFSO0lBTFMsQ0E1RE07SUFtRW5CLFdBQUEsRUFBYSxRQUFBLENBQUMsb0JBQUQsQ0FBQTtBQUVULFVBQUEsRUFBQTs7TUFBQSxFQUFBLEdBQUssUUFBUSxDQUFDLGNBQVQsQ0FBd0IsZUFBeEI7TUFDTCxJQUFJLFVBQUo7UUFDSSxPQUFPLENBQUMsR0FBUixDQUFZLHFEQUFaO0FBQ0EsZUFGSjtPQURBOztNQUtBLElBQUMsQ0FBQSxhQUFjLENBQUEsSUFBQyxDQUFBLFlBQUQsQ0FBZixHQUFnQyxFQUFFLENBQUMsTUFMbkM7O01BT0EsSUFBRyxnREFBSDtRQUNJLEVBQUUsQ0FBQyxLQUFILEdBQVcsSUFBQyxDQUFBLGFBQWMsQ0FBQSxvQkFBQSxFQUExQjs7ZUFFQSxJQUFDLENBQUEsYUFBYyxDQUFBLG9CQUFBLENBQWYsR0FBdUMsR0FIM0M7T0FBQSxNQUFBO2VBS0ksRUFBRSxDQUFDLEtBQUgsR0FBVyxHQUxmOztJQVRTLENBbkVNOztJQW9GbkIsZUFBQSxFQUFpQixRQUFBLENBQUMsQ0FBRCxDQUFBO0FBQ2IsVUFBQSxJQUFBLEVBQUEsT0FBQSxFQUFBLEtBQUEsRUFBQSxLQUFBLEVBQUEsS0FBQSxFQUFBLEtBQUEsRUFBQSxLQUFBLEVBQUE7TUFBQSxJQUFBLEdBQU8sT0FBQSxDQUFRLFFBQVIsRUFBUDtNQUNBLE9BQUEsa0tBQTJDO01BQzNDLElBQUEsQ0FBTyxPQUFQO1FBQ0ksT0FBQSwrR0FBMEMsQ0FBRSw4QkFEaEQ7O01BRUEsSUFBVSxJQUFDLENBQUEsWUFBRCxLQUFpQixPQUEzQjtBQUFBLGVBQUE7O01BQ0EsSUFBQyxDQUFBLFdBQUQsQ0FBYSxPQUFiO01BQ0EsSUFBQyxDQUFBLFlBQUQsR0FBZ0IsWUFBWSxDQUFDLFlBQWIsR0FBNEI7TUFDNUMsSUFBQyxDQUFBLGNBQUQsQ0FBZ0IsQ0FBaEI7TUFDQSxPQUFBLENBQVEsV0FBUjthQUNBLE9BQUEsQ0FBUSxZQUFSO0lBVmEsQ0FwRkU7SUFnR25CLGNBQUEsRUFBZ0IsUUFBQSxDQUFDLFNBQVMsQ0FBVixDQUFBO0FBQ1osVUFBQSxDQUFBLEVBQUEsU0FBQSxFQUFBLElBQUEsRUFBQSxDQUFBLEVBQUEsRUFBQSxFQUFBLEtBQUEsRUFBQSxDQUFBLEVBQUEsR0FBQSxFQUFBLElBQUEsRUFBQTtNQUFBLElBQUEsR0FBTyxPQUFBLENBQVEsUUFBUjtNQUNQLEVBQUEsR0FBSyxJQUFDLENBQUE7TUFDTixDQUFBLEdBQUksSUFBSyxDQUFBLEVBQUE7TUFDVCxJQUFBOztBQUFVO0FBQUE7UUFBQSxLQUFBLHVDQUFBOztjQUEwQixDQUFJLElBQUksQ0FBQyxhQUFMLENBQW1CLENBQW5CO3lCQUFoQzs7UUFBRSxDQUFBOzs7QUFDVjtNQUFBLEtBQUEsc0RBQUE7O1FBQ0ksSUFBRyxFQUFBLEtBQU0sQ0FBQyxDQUFDLGVBQWUsQ0FBQyxFQUEzQjtVQUNJLFNBQUEsR0FBWSxLQUFBLEdBQVE7VUFDcEIsSUFBb0MsSUFBSyxDQUFBLFNBQUEsQ0FBekM7eUJBQUEsSUFBQyxDQUFBLGVBQUQsQ0FBaUIsSUFBSyxDQUFBLFNBQUEsQ0FBdEIsR0FBQTtXQUFBLE1BQUE7aUNBQUE7V0FGSjtTQUFBLE1BQUE7K0JBQUE7O01BREosQ0FBQTs7SUFMWSxDQWhHRztJQTBHbkIsZUFBQSxFQUFpQixRQUFBLENBQUMsUUFBUSxDQUFULENBQUE7QUFDYixVQUFBLElBQUEsRUFBQSxDQUFBLEVBQUE7TUFBQSxJQUFBLEdBQU8sT0FBQSxDQUFRLFFBQVI7TUFDUCxJQUFBOztBQUFVO0FBQUE7UUFBQSxLQUFBLHVDQUFBOztjQUEwQixDQUFJLElBQUksQ0FBQyxhQUFMLENBQW1CLENBQW5CO3lCQUFoQzs7UUFBRSxDQUFBOzs7YUFDVixJQUFDLENBQUEsZUFBRCxDQUFpQixJQUFLLENBQUEsS0FBQSxDQUF0QjtJQUhhLENBMUdFO0lBK0duQixXQUFBLEVBQWEsUUFBQSxDQUFDLEtBQUQsQ0FBQTtNQUNULElBQVUsSUFBQyxDQUFBLEtBQUQsS0FBVSxLQUFwQjtBQUFBLGVBQUE7O01BQ0EsSUFBQyxDQUFBLEtBQUQsR0FBUzthQUNULE9BQUEsQ0FBUSxXQUFSO0lBSFMsQ0EvR007SUFvSG5CLGNBQUEsRUFBZ0IsUUFBQSxDQUFDLFFBQUQsQ0FBQTtNQUNaLElBQVUsSUFBQyxDQUFBLFFBQUQsS0FBYSxRQUF2QjtBQUFBLGVBQUE7O01BQ0EsSUFBQyxDQUFBLFFBQUQsR0FBWTthQUNaLElBQUMsQ0FBQSxjQUFELENBQWdCLElBQUksQ0FBQyxHQUFMLENBQUEsQ0FBaEI7SUFIWSxDQXBIRztJQXlIbkIsY0FBQSxFQUFnQixRQUFBLENBQUMsSUFBRCxDQUFBO0FBQ1osVUFBQSxDQUFBLEVBQUEsSUFBQSxFQUFBO01BQUEsSUFBQSxHQUFPLE9BQUEsQ0FBUSxRQUFSLEVBQVA7TUFDQSxJQUFDLENBQUEsWUFBRCxHQUFnQjtNQUNoQixLQUFBLENBQU0sUUFBQSxDQUFBLENBQUE7ZUFBRyxNQUFBLENBQU8sY0FBUDtNQUFILENBQU47TUFDQSxJQUFBLENBQUEsQ0FBYyxRQUFRLENBQUMsUUFBVCxDQUFBLENBQUEsSUFBd0IsSUFBQyxDQUFBLFFBQXpCLElBQXNDLElBQUMsQ0FBQSxLQUFELEtBQVUsTUFBTSxDQUFDLFlBQXJFLENBQUE7QUFBQSxlQUFBOztNQUNBLENBQUEsR0FBSSxJQUFLLENBQUEsSUFBQyxDQUFBLFlBQUQ7TUFDVCxJQUFBLENBQWMsQ0FBZDtBQUFBLGVBQUE7O01BQ0EsRUFBQSxHQUFLLElBQUksQ0FBQyxNQUFMLENBQVksQ0FBWjtNQUNMLElBQUcsRUFBQSxHQUFLLENBQVI7ZUFDSSxLQUFBLENBQU0sUUFBQSxDQUFBLENBQUE7aUJBQUcsTUFBQSxDQUFPLGlCQUFQO1FBQUgsQ0FBTixFQURKOztJQVJZLENBekhHO0lBb0luQixPQUFBLEVBQVMsUUFBQSxDQUFDLElBQUQsQ0FBQTtNQUNMLFlBQVksQ0FBQyxJQUFiLEdBQW9CLElBQUksQ0FBQyxTQUFMLENBQWUsSUFBZjthQUNwQixJQUFDLENBQUEsSUFBRCxHQUFRO0lBRkgsQ0FwSVU7O0lBeUluQixXQUFBLEVBQWEsUUFBQSxDQUFDLEdBQUQsQ0FBQTtNQUNULFlBQVksQ0FBQyxHQUFiLEdBQW1CLElBQUksQ0FBQyxTQUFMLENBQWUsR0FBZjthQUNuQixJQUFDLENBQUEsR0FBRCxHQUFPO0lBRkUsQ0F6SU07O0lBOEluQixXQUFBLEVBQWEsUUFBQSxDQUFDLElBQUQsQ0FBQTtNQUNULElBQVUsSUFBQyxDQUFBLFFBQUQsS0FBYSxJQUFiLElBQXFCLElBQUEsR0FBTyxHQUF0QztBQUFBLGVBQUE7O01BQ0EsSUFBQyxDQUFBLFFBQUQsR0FBWSxZQUFZLENBQUMsUUFBYixHQUF3QjthQUNwQyxPQUFBLENBQVEsV0FBUjtJQUhTLENBOUlNO0lBbUpuQixPQUFBLEVBQVMsUUFBQSxDQUFDLElBQUQsQ0FBQTtNQUNMLElBQUMsQ0FBQSxJQUFELEdBQVEsWUFBWSxDQUFDLElBQWIsR0FBb0IsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBcEIsR0FBMkI7YUFDdkQsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBcEIsQ0FBZ0MsUUFBaEMsRUFBMEMsSUFBMUM7SUFGSyxDQW5KVTtJQXVKbkIsV0FBQSxFQUFhLFFBQUEsQ0FBQyxHQUFELENBQUE7TUFDVCxJQUFDLENBQUEsUUFBRCxHQUFZO2FBQ1osT0FBQSxDQUFRLFdBQVI7SUFGUyxDQXZKTTtJQTJKbkIsaUJBQUEsRUFBbUIsUUFBQSxDQUFDLEdBQUQsQ0FBQTtNQUNmLElBQUMsQ0FBQSxjQUFELEdBQWtCLFlBQVksQ0FBQyxjQUFiLEdBQThCLENBQUMsQ0FBQzthQUNsRCxPQUFBLENBQVEsV0FBUjtJQUZlLENBM0pBO0lBK0puQixjQUFBLEVBQW1CLENBQUEsUUFBQSxDQUFBLENBQUE7QUFDZixVQUFBLE1BQUEsRUFBQSxPQUFBLEVBQUEsTUFBQSxFQUFBLFdBQUEsRUFBQSxPQUFBLEVBQUE7TUFBQSxDQUFBLENBQUMsTUFBRCxFQUFTLE1BQVQsRUFBaUIsT0FBakIsQ0FBQSxHQUE0QixNQUFNLENBQUMsWUFBbkM7TUFDQSxXQUFBLEdBQWM7TUFDZCxPQUFBLEdBQVU7YUFDVixNQUFBLEdBQVMsUUFBQSxDQUFTLEdBQVQsRUFBYyxRQUFBLENBQUMsSUFBRCxDQUFBO1FBQ25CLElBQXdCLE9BQXhCO1VBQUEsWUFBQSxDQUFhLE9BQWIsRUFBQTs7UUFDQSxPQUFBLEdBQVU7UUFDVixJQUFBLENBQU8sSUFBUDtpQkFDSSxXQUFBLEdBQWMsRUFEbEI7U0FBQSxNQUFBO1VBR0ksSUFBRyxJQUFBLEdBQU8sV0FBUCxHQUFxQixJQUF4QjtZQUNJLEtBQUEsQ0FBTSxRQUFBLENBQUEsQ0FBQTtxQkFBRyxNQUFBLENBQU8sV0FBUCxFQUFvQixNQUFwQjtZQUFILENBQU47WUFDQSxXQUFBLEdBQWMsS0FGbEI7O2lCQUdBLE9BQUEsR0FBVSxVQUFBLENBQVcsUUFBQSxDQUFBLENBQUEsRUFBQTs7O1lBR2pCLFdBQUEsR0FBYztZQUNkLE1BQUEsQ0FBTyxXQUFQLEVBQW9CLE1BQXBCO21CQUNBLE9BQUEsR0FBVSxVQUFBLENBQVcsUUFBQSxDQUFBLENBQUEsRUFBQTs7O3FCQUdqQixNQUFBLENBQU8sV0FBUCxFQUFvQixPQUFwQjtZQUhpQixDQUFYLEVBSVIsSUFKUTtVQUxPLENBQVgsRUFVUixJQVZRLEVBTmQ7O01BSG1CLENBQWQ7SUFKTSxDQUFBLENBQUgsQ0FBQSxDQS9KRztJQXdMbkIsY0FBQSxFQUFnQixRQUFBLENBQUMsTUFBRCxDQUFBO01BQ1osSUFBVSxJQUFDLENBQUEsV0FBRCxLQUFnQixNQUExQjtBQUFBLGVBQUE7O01BQ0EsSUFBQyxDQUFBLFdBQUQsR0FBZSxZQUFZLENBQUMsV0FBYixHQUEyQjtNQUMxQyxJQUFHLE1BQUg7UUFDSSxJQUFJLENBQUMsaUJBQUwsQ0FBdUIsSUFBdkIsRUFESjs7YUFFQSxPQUFBLENBQVEsV0FBUjtJQUxZLENBeExHO0lBK0xuQixpQkFBQSxFQUFtQixRQUFBLENBQUMsTUFBRCxDQUFBO01BQ2YsSUFBVSxJQUFDLENBQUEsY0FBRCxLQUFtQixNQUE3QjtBQUFBLGVBQUE7O01BQ0EsSUFBQyxDQUFBLGNBQUQsR0FBa0IsWUFBWSxDQUFDLGNBQWIsR0FBOEI7TUFDaEQsSUFBQSxDQUFPLE1BQVA7UUFDSSxJQUFJLENBQUMsY0FBTCxDQUFvQixLQUFwQixFQURKOzthQUVBLE9BQUEsQ0FBUSxXQUFSO0lBTGUsQ0EvTEE7SUFzTW5CLHFCQUFBLEVBQXVCLFFBQUEsQ0FBQyxNQUFELENBQUE7TUFDbkIsSUFBVSxJQUFDLENBQUEsa0JBQUQsS0FBdUIsTUFBakM7QUFBQSxlQUFBOztNQUNBLElBQUMsQ0FBQSxrQkFBRCxHQUFzQixZQUFZLENBQUMsa0JBQWIsR0FBa0M7YUFDeEQsT0FBQSxDQUFRLFdBQVI7SUFIbUIsQ0F0TUo7SUEyTW5CLGVBQUEsRUFBaUIsUUFBQSxDQUFDLE1BQUQsQ0FBQTtNQUNiLElBQVUsSUFBQyxDQUFBLFlBQUQsS0FBaUIsTUFBM0I7QUFBQSxlQUFBOztNQUNBLElBQUMsQ0FBQSxZQUFELEdBQWdCLFlBQVksQ0FBQyxZQUFiLEdBQTRCO2FBQzVDLE9BQUEsQ0FBUSxXQUFSO0lBSGEsQ0EzTUU7SUFnTm5CLGVBQUEsRUFBaUIsUUFBQSxDQUFDLE1BQUQsQ0FBQTtNQUNiLElBQVUsSUFBQyxDQUFBLFlBQUQsS0FBaUIsTUFBM0I7QUFBQSxlQUFBOztNQUNBLElBQUMsQ0FBQSxZQUFELEdBQWdCLFlBQVksQ0FBQyxZQUFiLEdBQTRCO2FBQzVDLE9BQUEsQ0FBUSxXQUFSO0lBSGEsQ0FoTkU7SUFxTm5CLHlCQUFBLEVBQTJCLFFBQUEsQ0FBQyxNQUFELENBQUE7TUFDdkIsSUFBVSxJQUFDLENBQUEsc0JBQUQsS0FBMkIsTUFBckM7QUFBQSxlQUFBOztNQUNBLElBQUMsQ0FBQSxzQkFBRCxHQUEwQixZQUFZLENBQUMsc0JBQWIsR0FBc0M7YUFDaEUsT0FBQSxDQUFRLFdBQVI7SUFIdUIsQ0FyTlI7SUEwTm5CLDRCQUFBLEVBQThCLFFBQUEsQ0FBQyxNQUFELENBQUE7TUFDMUIsSUFBVSxJQUFDLENBQUEseUJBQUQsS0FBOEIsTUFBeEM7QUFBQSxlQUFBOztNQUNBLElBQUMsQ0FBQSx5QkFBRCxHQUE2QixZQUFZLENBQUMseUJBQWIsR0FBeUM7YUFDdEUsT0FBQSxDQUFRLFdBQVI7SUFIMEIsQ0ExTlg7SUErTm5CLDZCQUFBLEVBQStCLFFBQUEsQ0FBQyxNQUFELENBQUE7TUFDM0IsSUFBVSxJQUFDLENBQUEsMEJBQUQsS0FBK0IsTUFBekM7QUFBQSxlQUFBOztNQUNBLElBQUMsQ0FBQSwwQkFBRCxHQUE4QixZQUFZLENBQUMsMEJBQWIsR0FBMEM7YUFDeEUsT0FBQSxDQUFRLFdBQVI7SUFIMkIsQ0EvTlo7SUFvT25CLG1CQUFBLEVBQXFCLFFBQUEsQ0FBQyxNQUFELENBQUE7TUFDakIsSUFBVSxZQUFZLENBQUMsZ0JBQWIsS0FBaUMsTUFBM0M7QUFBQSxlQUFBOztNQUNBLElBQUMsQ0FBQSxnQkFBRCxHQUFvQixZQUFZLENBQUMsZ0JBQWIsR0FBZ0M7YUFDcEQsT0FBQSxDQUFRLFdBQVI7SUFIaUIsQ0FwT0Y7SUF5T25CLHVCQUFBLEVBQXlCLFFBQUEsQ0FBQyxNQUFELENBQUE7TUFDckIsSUFBVSxZQUFZLENBQUMsb0JBQWIsS0FBcUMsTUFBL0M7QUFBQSxlQUFBOztNQUNBLElBQUMsQ0FBQSxvQkFBRCxHQUF3QixZQUFZLENBQUMsb0JBQWIsR0FBb0M7YUFDNUQsT0FBQSxDQUFRLFdBQVI7SUFIcUIsQ0F6T047SUE4T25CLHdCQUFBLEVBQTBCLFFBQUEsQ0FBQyxNQUFELENBQUE7TUFDdEIsSUFBVSxZQUFZLENBQUMscUJBQWIsS0FBc0MsTUFBaEQ7QUFBQSxlQUFBOztNQUNBLElBQUMsQ0FBQSxxQkFBRCxHQUF5QixZQUFZLENBQUMscUJBQWIsR0FBcUM7YUFDOUQsT0FBQSxDQUFRLFdBQVI7SUFIc0IsQ0E5T1A7SUFtUG5CLGVBQUEsRUFBaUIsUUFBQSxDQUFDLE1BQUQsQ0FBQTtNQUNiLElBQVUsSUFBQyxDQUFBLFlBQUQsS0FBaUIsTUFBM0I7QUFBQSxlQUFBOztNQUNBLElBQUMsQ0FBQSxZQUFELEdBQWdCLFlBQVksQ0FBQyxZQUFiLEdBQTRCO2FBQzVDLE9BQUEsQ0FBUSxXQUFSO0lBSGEsQ0FuUEU7SUF3UG5CLGVBQUEsRUFBaUIsUUFBQSxDQUFDLE1BQUQsQ0FBQTtNQUNiLElBQVUsSUFBQyxDQUFBLFlBQUQsS0FBaUIsTUFBM0I7QUFBQSxlQUFBOztNQUNBLElBQUMsQ0FBQSxZQUFELEdBQWdCLFlBQVksQ0FBQyxZQUFiLEdBQTRCO2FBQzVDLE9BQUEsQ0FBUSxXQUFSO0lBSGEsQ0F4UEU7SUE2UG5CLGNBQUEsRUFBZ0IsUUFBQSxDQUFDLFdBQUQsQ0FBQTtNQUNaLElBQUMsQ0FBQSxXQUFELEdBQWUsWUFBWSxDQUFDLFdBQWIsR0FBMkI7QUFDMUMsYUFBTSxRQUFRLENBQUMsYUFBVCxDQUF1QixNQUF2QixDQUE4QixDQUFDLFNBQVMsQ0FBQyxNQUF6QyxHQUFrRCxDQUF4RDtRQUNJLFFBQVEsQ0FBQyxhQUFULENBQXVCLE1BQXZCLENBQThCLENBQUMsU0FBUyxDQUFDLE1BQXpDLENBQWdELFFBQVEsQ0FBQyxhQUFULENBQXVCLE1BQXZCLENBQThCLENBQUMsU0FBUyxDQUFDLElBQXpDLENBQThDLENBQTlDLENBQWhEO01BREo7YUFFQSxRQUFRLENBQUMsYUFBVCxDQUF1QixNQUF2QixDQUE4QixDQUFDLFNBQVMsQ0FBQyxHQUF6QyxDQUE2QyxXQUE3QztJQUpZLENBN1BHO0lBbVFuQixXQUFBLEVBQWEsUUFBQSxDQUFDLFFBQUQsQ0FBQTtNQUNULElBQUMsQ0FBQSxRQUFELEdBQVksWUFBWSxDQUFDLFFBQWIsR0FBd0I7QUFDcEMsYUFBTSxRQUFRLENBQUMsYUFBVCxDQUF1QixNQUF2QixDQUE4QixDQUFDLFNBQVMsQ0FBQyxNQUF6QyxHQUFrRCxDQUF4RDtRQUNJLFFBQVEsQ0FBQyxhQUFULENBQXVCLE1BQXZCLENBQThCLENBQUMsU0FBUyxDQUFDLE1BQXpDLENBQWdELFFBQVEsQ0FBQyxhQUFULENBQXVCLE1BQXZCLENBQThCLENBQUMsU0FBUyxDQUFDLElBQXpDLENBQThDLENBQTlDLENBQWhEO01BREo7TUFFQSxRQUFRLENBQUMsYUFBVCxDQUF1QixNQUF2QixDQUE4QixDQUFDLFNBQVMsQ0FBQyxHQUF6QyxDQUE2QyxZQUFZLENBQUMsV0FBMUQ7YUFDQSxRQUFRLENBQUMsYUFBVCxDQUF1QixNQUF2QixDQUE4QixDQUFDLFNBQVMsQ0FBQyxHQUF6QyxDQUE2QyxRQUE3QztJQUxTLENBblFNO0lBMFFuQixvQkFBQSxFQUFzQixRQUFBLENBQUMsS0FBRCxDQUFBO01BQ2xCLElBQUMsQ0FBQSxpQkFBRCxHQUFxQixZQUFZLENBQUMsaUJBQWIsR0FBaUM7YUFDdEQsT0FBQSxDQUFRLFdBQVI7SUFGa0IsQ0ExUUg7SUE4UW5CLFdBQUEsRUFBYSxRQUFBLENBQUMsS0FBRCxDQUFBO01BQ1QsSUFBQyxDQUFBLFFBQUQsR0FBWSxZQUFZLENBQUMsUUFBYixHQUF3QjtNQUVwQyxJQUFHLENBQUksSUFBQyxDQUFBLFFBQVI7UUFDSSxJQUFDLENBQUEsY0FBRCxDQUFnQixLQUFoQjtlQUNBLElBQUMsQ0FBQSx1QkFBRCxDQUF5QixLQUF6QixFQUZKO09BQUEsTUFBQTtlQUlJLE9BQUEsQ0FBUSxXQUFSLEVBSko7O0lBSFMsQ0E5UU07SUF1Um5CLGVBQUEsRUFBaUIsUUFBQSxDQUFDLEtBQUQsQ0FBQTtNQUNiLElBQUMsQ0FBQSxZQUFELEdBQWdCLFlBQVksQ0FBQyxZQUFiLEdBQTRCO2FBQzVDLE9BQUEsQ0FBUSxXQUFSO0lBRmEsQ0F2UkU7SUEyUm5CLHVCQUFBLEVBQXlCLFFBQUEsQ0FBQyxLQUFELENBQUE7TUFDckIsSUFBQyxDQUFBLG9CQUFELEdBQXdCLFlBQVksQ0FBQyxvQkFBYixHQUFvQzthQUM1RCxPQUFBLENBQVEsV0FBUjtJQUZxQixDQTNSTjtJQStSbkIsbUJBQUEsRUFBcUIsUUFBQSxDQUFDLEtBQUQsQ0FBQTthQUNqQixJQUFDLENBQUEsZ0JBQUQsR0FBb0I7SUFESCxDQS9SRjtJQWtTbkIsY0FBQSxFQUFnQixRQUFBLENBQUMsS0FBRCxDQUFBO01BQ1osSUFBQyxDQUFBLFdBQUQsR0FBZSxZQUFZLENBQUMsV0FBYixHQUEyQixDQUFDLENBQUM7YUFDNUMsT0FBQSxDQUFRLFdBQVI7SUFGWSxDQWxTRztJQXNTbkIsc0JBQUEsRUFBd0IsUUFBQSxDQUFDLElBQUQsQ0FBQTtNQUNwQixJQUFVLElBQUMsQ0FBQSxtQkFBRCxLQUF3QixJQUFsQztBQUFBLGVBQUE7O01BRUEsSUFBRyxJQUFIO1FBQ0ksWUFBWSxDQUFDLE1BQWIsQ0FBQSxFQURKO09BQUEsTUFBQTtRQUdJLFlBQVksQ0FBQyxPQUFiLENBQUEsRUFISjs7TUFLQSxJQUFDLENBQUEsbUJBQUQsR0FBdUI7YUFFdkIsT0FBQSxDQUFRLFdBQVI7SUFWb0IsQ0F0U0w7SUFrVG5CLHVCQUFBLEVBQXlCLFFBQUEsQ0FBQyxTQUFELENBQUE7TUFDckIsSUFBQyxDQUFBLG1CQUFELEdBQXVCO2FBRXZCLE9BQUEsQ0FBUSxXQUFSO0lBSHFCO0VBbFROOztFQXdUdkIsS0FBQSxDQUFNLEdBQU4sRUFBVyxNQUFYO0FBcFVBIiwic291cmNlc0NvbnRlbnQiOlsiQ2xpZW50ID0gcmVxdWlyZSAnaGFuZ3Vwc2pzJ1xuXG5tZXJnZSAgID0gKHQsIG9zLi4uKSAtPiB0W2tdID0gdiBmb3Igayx2IG9mIG8gd2hlbiB2IG5vdCBpbiBbbnVsbCwgdW5kZWZpbmVkXSBmb3IgbyBpbiBvczsgdFxuXG57dGhyb3R0bGUsIGxhdGVyLCB0cnlwYXJzZSwgYXV0b0xhdW5jaGVyfSA9IHJlcXVpcmUgJy4uL3V0aWwnXG5cblNUQVRFUyA9XG4gICAgU1RBVEVfU1RBUlRVUDogJ3N0YXJ0dXAnXG4gICAgU1RBVEVfTk9STUFMOiAnbm9ybWFsJ1xuICAgIFNUQVRFX0FERF9DT05WRVJTQVRJT046ICdhZGRfY29udmVyc2F0aW9uJ1xuICAgIFNUQVRFX0FCT1VUOiAnYWJvdXQnXG5cbm1vZHVsZS5leHBvcnRzID0gZXhwID0ge1xuICAgIHN0YXRlOiBudWxsXG4gICAgYXR0b3A6IGZhbHNlICAgIyB0ZWxscyB3aGV0aGVyIG1lc3NhZ2UgbGlzdCBpcyBzY3JvbGxlZCB0byB0b3BcbiAgICBhdGJvdHRvbTogdHJ1ZSAjIHRlbGxzIHdoZXRoZXIgbWVzc2FnZSBsaXN0IGlzIHNjcm9sbGVkIHRvIGJvdHRvbVxuICAgIHNlbGVjdGVkQ29udjogbG9jYWxTdG9yYWdlLnNlbGVjdGVkQ29udlxuICAgIGxhc3RBY3Rpdml0eTogbnVsbFxuICAgIGxlZnRTaXplOiB0cnlwYXJzZShsb2NhbFN0b3JhZ2UubGVmdFNpemUpID8gMjQwXG4gICAgc2l6ZTogdHJ5cGFyc2UobG9jYWxTdG9yYWdlLnNpemUgPyBcIls5NDAsIDYwMF1cIilcbiAgICBwb3M6IHRyeXBhcnNlKGxvY2FsU3RvcmFnZS5wb3MgPyBcIlsxMDAsIDEwMF1cIilcbiAgICBzaG93Q29udk1pbjogdHJ5cGFyc2UobG9jYWxTdG9yYWdlLnNob3dDb252TWluKSA/IGZhbHNlXG4gICAgc2hvd0NvbnZUaHVtYnM6IHRyeXBhcnNlKGxvY2FsU3RvcmFnZS5zaG93Q29udlRodW1icykgPyB0cnVlXG4gICAgc2hvd0FuaW1hdGVkVGh1bWJzOiB0cnlwYXJzZShsb2NhbFN0b3JhZ2Uuc2hvd0FuaW1hdGVkVGh1bWJzKSA/IHRydWVcbiAgICBzaG93Q29udlRpbWU6IHRyeXBhcnNlKGxvY2FsU3RvcmFnZS5zaG93Q29udlRpbWUpID8gdHJ1ZVxuICAgIHNob3dDb252TGFzdDogdHJ5cGFyc2UobG9jYWxTdG9yYWdlLnNob3dDb252TGFzdCkgPyB0cnVlXG4gICAgc2hvd1BvcFVwTm90aWZpY2F0aW9uczogdHJ5cGFyc2UobG9jYWxTdG9yYWdlLnNob3dQb3BVcE5vdGlmaWNhdGlvbnMpID8gdHJ1ZVxuICAgIHNob3dNZXNzYWdlSW5Ob3RpZmljYXRpb246IHRyeXBhcnNlKGxvY2FsU3RvcmFnZS5zaG93TWVzc2FnZUluTm90aWZpY2F0aW9uKSA/IHRydWVcbiAgICBzaG93VXNlcm5hbWVJbk5vdGlmaWNhdGlvbjogdHJ5cGFyc2UobG9jYWxTdG9yYWdlLnNob3dVc2VybmFtZUluTm90aWZpY2F0aW9uKSA/IHRydWVcbiAgICBjb252ZXJ0RW1vamk6IHRyeXBhcnNlKGxvY2FsU3RvcmFnZS5jb252ZXJ0RW1vamkpID8gdHJ1ZVxuICAgIHN1Z2dlc3RFbW9qaTogdHJ5cGFyc2UobG9jYWxTdG9yYWdlLnN1Z2dlc3RFbW9qaSkgPyB0cnVlXG4gICAgY29sb3JTY2hlbWU6IGxvY2FsU3RvcmFnZS5jb2xvclNjaGVtZSBvciAnZGVmYXVsdCdcbiAgICBmb250U2l6ZTogbG9jYWxTdG9yYWdlLmZvbnRTaXplIG9yICdtZWRpdW0nXG4gICAgem9vbTogdHJ5cGFyc2UobG9jYWxTdG9yYWdlLnpvb20gPyBcIjEuMFwiKVxuICAgIGxvZ2dlZGluOiBmYWxzZVxuICAgIGVzY2FwZUNsZWFyc0lucHV0OiB0cnlwYXJzZShsb2NhbFN0b3JhZ2UuZXNjYXBlQ2xlYXJzSW5wdXQpIG9yIGZhbHNlXG4gICAgc2hvd3RyYXk6IHRyeXBhcnNlKGxvY2FsU3RvcmFnZS5zaG93dHJheSkgb3IgZmFsc2VcbiAgICBoaWRlZG9ja2ljb246IHRyeXBhcnNlKGxvY2FsU3RvcmFnZS5oaWRlZG9ja2ljb24pIG9yIGZhbHNlXG4gICAgc3RhcnRtaW5pbWl6ZWR0b3RyYXk6IHRyeXBhcnNlKGxvY2FsU3RvcmFnZS5zdGFydG1pbmltaXplZHRvdHJheSkgb3IgZmFsc2VcbiAgICBjbG9zZXRvdHJheTogdHJ5cGFyc2UobG9jYWxTdG9yYWdlLmNsb3NldG90cmF5KSBvciBmYWxzZVxuICAgIHNob3dEb2NrT25jZTogdHJ1ZVxuICAgIHNob3dJY29uTm90aWZpY2F0aW9uOiB0cnlwYXJzZShsb2NhbFN0b3JhZ2Uuc2hvd0ljb25Ob3RpZmljYXRpb24pID8gdHJ1ZVxuICAgIG11dGVTb3VuZE5vdGlmaWNhdGlvbjogdHJ5cGFyc2UobG9jYWxTdG9yYWdlLm11dGVTb3VuZE5vdGlmaWNhdGlvbikgPyBmYWxzZVxuICAgIGZvcmNlQ3VzdG9tU291bmQ6IHRyeXBhcnNlKGxvY2FsU3RvcmFnZS5mb3JjZUN1c3RvbVNvdW5kKSA/IGZhbHNlXG4gICAgbGFuZ3VhZ2U6IGxvY2FsU3RvcmFnZS5sYW5ndWFnZSA/ICdlbidcbiAgICB1c2VTeXN0ZW1EYXRlRm9ybWF0OiBsb2NhbFN0b3JhZ2UudXNlU3lzdGVtRGF0ZUZvcm1hdCBpcyBcInRydWVcIlxuICAgICMgbm9uIHBlcnNpc3RlbnQhXG4gICAgbWVzc2FnZU1lbW9yeToge30gICAgICAjIHN0b3JlcyBpbnB1dCB3aGVuIHN3aXRoY2hpbmcgY29udmVyc2F0aW9uc1xuICAgIGNhY2hlZEluaXRpYWxzQ29kZToge30gIyBjb2RlIHVzZWQgZm9yIGNvbG9yZWQgaW5pdGlhbHMsIGlmIG5vIGF2YXRhclxuICAgICMgY29udGFjdHMgYXJlIGxvYWRlZFxuICAgIGxvYWRlZENvbnRhY3RzOiBmYWxzZVxuICAgIG9wZW5PblN5c3RlbVN0YXJ0dXA6IGZhbHNlXG5cbiAgICBzZXRVc2VTeXN0ZW1EYXRlRm9ybWF0OiAodmFsKSAtPlxuICAgICAgICBAdXNlU3lzdGVtRGF0ZUZvcm1hdCA9IHZhbFxuICAgICAgICBsb2NhbFN0b3JhZ2UudXNlU3lzdGVtRGF0ZUZvcm1hdCA9IHZhbFxuICAgICAgICB1cGRhdGVkICdsYW5ndWFnZSdcblxuICAgIHNldENvbnRhY3RzOiAoc3RhdGUpIC0+XG4gICAgICAgIHJldHVybiBpZiBzdGF0ZSA9PSBAbG9hZGVkQ29udGFjdHNcbiAgICAgICAgQGxvYWRlZENvbnRhY3RzID0gc3RhdGVcbiAgICAgICAgdXBkYXRlZCAndmlld3N0YXRlJ1xuXG4gICAgc2V0U3RhdGU6IChzdGF0ZSkgLT5cbiAgICAgICAgcmV0dXJuIGlmIEBzdGF0ZSA9PSBzdGF0ZVxuICAgICAgICBAc3RhdGUgPSBzdGF0ZVxuICAgICAgICBpZiBzdGF0ZSA9PSBTVEFURVMuU1RBVEVfU1RBUlRVUFxuICAgICAgICAgICAgIyBzZXQgYSBmaXJzdCBhY3RpdmUgdGltZXN0YW1wIHRvIGF2b2lkIHJlcXVlc3RpbmdcbiAgICAgICAgICAgICMgc3luY2FsbG5ld2V2ZW50cyBvbiBzdGFydHVwXG4gICAgICAgICAgICByZXF1aXJlKCcuL2Nvbm5lY3Rpb24nKS5zZXRMYXN0QWN0aXZlKERhdGUubm93KCksIHRydWUpXG4gICAgICAgIHVwZGF0ZWQgJ3ZpZXdzdGF0ZSdcblxuICAgIHNldExhbmd1YWdlOiAobGFuZ3VhZ2UpIC0+XG4gICAgICAgIHJldHVybiBpZiBAbGFuZ3VhZ2UgPT0gbGFuZ3VhZ2VcbiAgICAgICAgaTE4bi5sb2NhbGUgPSBsYW5ndWFnZVxuICAgICAgICBpMThuLnNldExvY2FsZShsYW5ndWFnZSlcbiAgICAgICAgQGxhbmd1YWdlID0gbG9jYWxTdG9yYWdlLmxhbmd1YWdlID0gbGFuZ3VhZ2VcbiAgICAgICAgdXBkYXRlZCAnbGFuZ3VhZ2UnXG5cbiAgICBzd2l0Y2hJbnB1dDogKG5leHRfY29udmVyc2F0aW9uX2lkKSAtPlxuICAgICAgICAjIGlmIGNvbnZlcnNhdGlvbiBpcyBjaGFuZ2luZywgc2F2ZSBpbnB1dFxuICAgICAgICBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdtZXNzYWdlLWlucHV0JylcbiAgICAgICAgaWYgIWVsP1xuICAgICAgICAgICAgY29uc29sZS5sb2cgJ1dhcm5pbmc6IGNvdWxkIG5vdCByZXRyaWV2ZSBtZXNzYWdlIGlucHV0IHRvIHN0b3JlLidcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICAjIHNhdmUgY3VycmVudCBpbnB1dFxuICAgICAgICBAbWVzc2FnZU1lbW9yeVtAc2VsZWN0ZWRDb252XSA9IGVsLnZhbHVlXG4gICAgICAgICMgZWl0aGVyIHJlc2V0IG9yIGZldGNoIHByZXZpb3VzIGlucHV0IG9mIHRoZSBuZXcgY29udlxuICAgICAgICBpZiBAbWVzc2FnZU1lbW9yeVtuZXh0X2NvbnZlcnNhdGlvbl9pZF0/XG4gICAgICAgICAgICBlbC52YWx1ZSA9IEBtZXNzYWdlTWVtb3J5W25leHRfY29udmVyc2F0aW9uX2lkXVxuICAgICAgICAgICAgIyBvbmNlIG9sZCBjb252ZXJzYXRpb24gaXMgcmV0cmlldmVkIG1lbW9yeSBpcyB3aXBlZFxuICAgICAgICAgICAgQG1lc3NhZ2VNZW1vcnlbbmV4dF9jb252ZXJzYXRpb25faWRdID0gXCJcIlxuICAgICAgICBlbHNlXG4gICAgICAgICAgICBlbC52YWx1ZSA9ICcnXG4gICAgICAgICNcblxuICAgIHNldFNlbGVjdGVkQ29udjogKGMpIC0+XG4gICAgICAgIGNvbnYgPSByZXF1aXJlICcuL2NvbnYnICMgY2lyY3VsYXJcbiAgICAgICAgY29udl9pZCA9IGM/LmNvbnZlcnNhdGlvbl9pZD8uaWQgPyBjPy5pZCA/IGNcbiAgICAgICAgdW5sZXNzIGNvbnZfaWRcbiAgICAgICAgICAgIGNvbnZfaWQgPSBjb252Lmxpc3QoKT9bMF0/LmNvbnZlcnNhdGlvbl9pZD8uaWRcbiAgICAgICAgcmV0dXJuIGlmIEBzZWxlY3RlZENvbnYgPT0gY29udl9pZFxuICAgICAgICBAc3dpdGNoSW5wdXQoY29udl9pZClcbiAgICAgICAgQHNlbGVjdGVkQ29udiA9IGxvY2FsU3RvcmFnZS5zZWxlY3RlZENvbnYgPSBjb252X2lkXG4gICAgICAgIEBzZXRMYXN0S2V5RG93biAwXG4gICAgICAgIHVwZGF0ZWQgJ3ZpZXdzdGF0ZSdcbiAgICAgICAgdXBkYXRlZCAnc3dpdGNoQ29udidcblxuICAgIHNlbGVjdE5leHRDb252OiAob2Zmc2V0ID0gMSkgLT5cbiAgICAgICAgY29udiA9IHJlcXVpcmUgJy4vY29udidcbiAgICAgICAgaWQgPSBAc2VsZWN0ZWRDb252XG4gICAgICAgIGMgPSBjb252W2lkXVxuICAgICAgICBsaXN0ID0gKGkgZm9yIGkgaW4gY29udi5saXN0KCkgd2hlbiBub3QgY29udi5pc1B1cmVIYW5nb3V0KGkpKVxuICAgICAgICBmb3IgYywgaW5kZXggaW4gbGlzdFxuICAgICAgICAgICAgaWYgaWQgPT0gYy5jb252ZXJzYXRpb25faWQuaWRcbiAgICAgICAgICAgICAgICBjYW5kaWRhdGUgPSBpbmRleCArIG9mZnNldFxuICAgICAgICAgICAgICAgIEBzZXRTZWxlY3RlZENvbnYgbGlzdFtjYW5kaWRhdGVdIGlmIGxpc3RbY2FuZGlkYXRlXVxuXG4gICAgc2VsZWN0Q29udkluZGV4OiAoaW5kZXggPSAwKSAtPlxuICAgICAgICBjb252ID0gcmVxdWlyZSAnLi9jb252J1xuICAgICAgICBsaXN0ID0gKGkgZm9yIGkgaW4gY29udi5saXN0KCkgd2hlbiBub3QgY29udi5pc1B1cmVIYW5nb3V0KGkpKVxuICAgICAgICBAc2V0U2VsZWN0ZWRDb252IGxpc3RbaW5kZXhdXG5cbiAgICB1cGRhdGVBdFRvcDogKGF0dG9wKSAtPlxuICAgICAgICByZXR1cm4gaWYgQGF0dG9wID09IGF0dG9wXG4gICAgICAgIEBhdHRvcCA9IGF0dG9wXG4gICAgICAgIHVwZGF0ZWQgJ3ZpZXdzdGF0ZSdcblxuICAgIHVwZGF0ZUF0Qm90dG9tOiAoYXRib3R0b20pIC0+XG4gICAgICAgIHJldHVybiBpZiBAYXRib3R0b20gPT0gYXRib3R0b21cbiAgICAgICAgQGF0Ym90dG9tID0gYXRib3R0b21cbiAgICAgICAgQHVwZGF0ZUFjdGl2aXR5IERhdGUubm93KClcblxuICAgIHVwZGF0ZUFjdGl2aXR5OiAodGltZSkgLT5cbiAgICAgICAgY29udiA9IHJlcXVpcmUgJy4vY29udicgIyBjaXJjdWxhclxuICAgICAgICBAbGFzdEFjdGl2aXR5ID0gdGltZVxuICAgICAgICBsYXRlciAtPiBhY3Rpb24gJ2xhc3RBY3Rpdml0eSdcbiAgICAgICAgcmV0dXJuIHVubGVzcyBkb2N1bWVudC5oYXNGb2N1cygpIGFuZCBAYXRib3R0b20gYW5kIEBzdGF0ZSA9PSBTVEFURVMuU1RBVEVfTk9STUFMXG4gICAgICAgIGMgPSBjb252W0BzZWxlY3RlZENvbnZdXG4gICAgICAgIHJldHVybiB1bmxlc3MgY1xuICAgICAgICB1ciA9IGNvbnYudW5yZWFkIGNcbiAgICAgICAgaWYgdXIgPiAwXG4gICAgICAgICAgICBsYXRlciAtPiBhY3Rpb24gJ3VwZGF0ZXdhdGVybWFyaydcblxuICAgIHNldFNpemU6IChzaXplKSAtPlxuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2l6ZSA9IEpTT04uc3RyaW5naWZ5KHNpemUpXG4gICAgICAgIEBzaXplID0gc2l6ZVxuICAgICAgICAjIHVwZGF0ZWQgJ3ZpZXdzdGF0ZSdcblxuICAgIHNldFBvc2l0aW9uOiAocG9zKSAtPlxuICAgICAgICBsb2NhbFN0b3JhZ2UucG9zID0gSlNPTi5zdHJpbmdpZnkocG9zKVxuICAgICAgICBAcG9zID0gcG9zXG4gICAgICAgICMgdXBkYXRlZCAndmlld3N0YXRlJ1xuXG4gICAgc2V0TGVmdFNpemU6IChzaXplKSAtPlxuICAgICAgICByZXR1cm4gaWYgQGxlZnRTaXplID09IHNpemUgb3Igc2l6ZSA8IDE4MFxuICAgICAgICBAbGVmdFNpemUgPSBsb2NhbFN0b3JhZ2UubGVmdFNpemUgPSBzaXplXG4gICAgICAgIHVwZGF0ZWQgJ3ZpZXdzdGF0ZSdcblxuICAgIHNldFpvb206ICh6b29tKSAtPlxuICAgICAgICBAem9vbSA9IGxvY2FsU3RvcmFnZS56b29tID0gZG9jdW1lbnQuYm9keS5zdHlsZS56b29tID0gem9vbVxuICAgICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLnNldFByb3BlcnR5KCctLXpvb20nLCB6b29tKVxuXG4gICAgc2V0TG9nZ2VkaW46ICh2YWwpIC0+XG4gICAgICAgIEBsb2dnZWRpbiA9IHZhbFxuICAgICAgICB1cGRhdGVkICd2aWV3c3RhdGUnXG5cbiAgICBzZXRTaG93U2VlblN0YXR1czogKHZhbCkgLT5cbiAgICAgICAgQHNob3dzZWVuc3RhdHVzID0gbG9jYWxTdG9yYWdlLnNob3dzZWVuc3RhdHVzID0gISF2YWxcbiAgICAgICAgdXBkYXRlZCAndmlld3N0YXRlJ1xuXG4gICAgc2V0TGFzdEtleURvd246IGRvIC0+XG4gICAgICAgIHtUWVBJTkcsIFBBVVNFRCwgU1RPUFBFRH0gPSBDbGllbnQuVHlwaW5nU3RhdHVzXG4gICAgICAgIGxhc3RFbWl0dGVkID0gMFxuICAgICAgICB0aW1lb3V0ID0gMFxuICAgICAgICB1cGRhdGUgPSB0aHJvdHRsZSA1MDAsICh0aW1lKSAtPlxuICAgICAgICAgICAgY2xlYXJUaW1lb3V0IHRpbWVvdXQgaWYgdGltZW91dFxuICAgICAgICAgICAgdGltZW91dCA9IG51bGxcbiAgICAgICAgICAgIHVubGVzcyB0aW1lXG4gICAgICAgICAgICAgICAgbGFzdEVtaXR0ZWQgPSAwXG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgaWYgdGltZSAtIGxhc3RFbWl0dGVkID4gNTAwMFxuICAgICAgICAgICAgICAgICAgICBsYXRlciAtPiBhY3Rpb24gJ3NldHR5cGluZycsIFRZUElOR1xuICAgICAgICAgICAgICAgICAgICBsYXN0RW1pdHRlZCA9IHRpbWVcbiAgICAgICAgICAgICAgICB0aW1lb3V0ID0gc2V0VGltZW91dCAtPlxuICAgICAgICAgICAgICAgICAgICAjIGFmdGVyIDYgc2Vjb2RzIG9mIG5vIGtleWJvYXJkLCB3ZSBjb25zaWRlciB0aGVcbiAgICAgICAgICAgICAgICAgICAgIyB1c2VyIHRvb2sgYSBicmVhay5cbiAgICAgICAgICAgICAgICAgICAgbGFzdEVtaXR0ZWQgPSAwXG4gICAgICAgICAgICAgICAgICAgIGFjdGlvbiAnc2V0dHlwaW5nJywgUEFVU0VEXG4gICAgICAgICAgICAgICAgICAgIHRpbWVvdXQgPSBzZXRUaW1lb3V0IC0+XG4gICAgICAgICAgICAgICAgICAgICAgICAjIGFuZCBhZnRlciBhbm90aGVyIDYgc2Vjb25kcyAoMTIgdG90YWwpLCB3ZVxuICAgICAgICAgICAgICAgICAgICAgICAgIyBjb25zaWRlciB0aGUgdHlwaW5nIHN0b3BwZWQgYWx0b2dldGhlci5cbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbiAnc2V0dHlwaW5nJywgU1RPUFBFRFxuICAgICAgICAgICAgICAgICAgICAsIDYwMDBcbiAgICAgICAgICAgICAgICAsIDYwMDBcblxuICAgIHNldFNob3dDb252TWluOiAoZG9zaG93KSAtPlxuICAgICAgICByZXR1cm4gaWYgQHNob3dDb252TWluID09IGRvc2hvd1xuICAgICAgICBAc2hvd0NvbnZNaW4gPSBsb2NhbFN0b3JhZ2Uuc2hvd0NvbnZNaW4gPSBkb3Nob3dcbiAgICAgICAgaWYgZG9zaG93XG4gICAgICAgICAgICB0aGlzLnNldFNob3dDb252VGh1bWJzKHRydWUpXG4gICAgICAgIHVwZGF0ZWQgJ3ZpZXdzdGF0ZSdcblxuICAgIHNldFNob3dDb252VGh1bWJzOiAoZG9zaG93KSAtPlxuICAgICAgICByZXR1cm4gaWYgQHNob3dDb252VGh1bWJzID09IGRvc2hvd1xuICAgICAgICBAc2hvd0NvbnZUaHVtYnMgPSBsb2NhbFN0b3JhZ2Uuc2hvd0NvbnZUaHVtYnMgPSBkb3Nob3dcbiAgICAgICAgdW5sZXNzIGRvc2hvd1xuICAgICAgICAgICAgdGhpcy5zZXRTaG93Q29udk1pbihmYWxzZSlcbiAgICAgICAgdXBkYXRlZCAndmlld3N0YXRlJ1xuXG4gICAgc2V0U2hvd0FuaW1hdGVkVGh1bWJzOiAoZG9zaG93KSAtPlxuICAgICAgICByZXR1cm4gaWYgQHNob3dBbmltYXRlZFRodW1icyA9PSBkb3Nob3dcbiAgICAgICAgQHNob3dBbmltYXRlZFRodW1icyA9IGxvY2FsU3RvcmFnZS5zaG93QW5pbWF0ZWRUaHVtYnMgPSBkb3Nob3dcbiAgICAgICAgdXBkYXRlZCAndmlld3N0YXRlJ1xuXG4gICAgc2V0U2hvd0NvbnZUaW1lOiAoZG9zaG93KSAtPlxuICAgICAgICByZXR1cm4gaWYgQHNob3dDb252VGltZSA9PSBkb3Nob3dcbiAgICAgICAgQHNob3dDb252VGltZSA9IGxvY2FsU3RvcmFnZS5zaG93Q29udlRpbWUgPSBkb3Nob3dcbiAgICAgICAgdXBkYXRlZCAndmlld3N0YXRlJ1xuXG4gICAgc2V0U2hvd0NvbnZMYXN0OiAoZG9zaG93KSAtPlxuICAgICAgICByZXR1cm4gaWYgQHNob3dDb252TGFzdCA9PSBkb3Nob3dcbiAgICAgICAgQHNob3dDb252TGFzdCA9IGxvY2FsU3RvcmFnZS5zaG93Q29udkxhc3QgPSBkb3Nob3dcbiAgICAgICAgdXBkYXRlZCAndmlld3N0YXRlJ1xuXG4gICAgc2V0U2hvd1BvcFVwTm90aWZpY2F0aW9uczogKGRvc2hvdykgLT5cbiAgICAgICAgcmV0dXJuIGlmIEBzaG93UG9wVXBOb3RpZmljYXRpb25zID09IGRvc2hvd1xuICAgICAgICBAc2hvd1BvcFVwTm90aWZpY2F0aW9ucyA9IGxvY2FsU3RvcmFnZS5zaG93UG9wVXBOb3RpZmljYXRpb25zID0gZG9zaG93XG4gICAgICAgIHVwZGF0ZWQgJ3ZpZXdzdGF0ZSdcblxuICAgIHNldFNob3dNZXNzYWdlSW5Ob3RpZmljYXRpb246IChkb3Nob3cpIC0+XG4gICAgICAgIHJldHVybiBpZiBAc2hvd01lc3NhZ2VJbk5vdGlmaWNhdGlvbiA9PSBkb3Nob3dcbiAgICAgICAgQHNob3dNZXNzYWdlSW5Ob3RpZmljYXRpb24gPSBsb2NhbFN0b3JhZ2Uuc2hvd01lc3NhZ2VJbk5vdGlmaWNhdGlvbiA9IGRvc2hvd1xuICAgICAgICB1cGRhdGVkICd2aWV3c3RhdGUnXG5cbiAgICBzZXRTaG93VXNlcm5hbWVJbk5vdGlmaWNhdGlvbjogKGRvc2hvdykgLT5cbiAgICAgICAgcmV0dXJuIGlmIEBzaG93VXNlcm5hbWVJbk5vdGlmaWNhdGlvbiA9PSBkb3Nob3dcbiAgICAgICAgQHNob3dVc2VybmFtZUluTm90aWZpY2F0aW9uID0gbG9jYWxTdG9yYWdlLnNob3dVc2VybmFtZUluTm90aWZpY2F0aW9uID0gZG9zaG93XG4gICAgICAgIHVwZGF0ZWQgJ3ZpZXdzdGF0ZSdcblxuICAgIHNldEZvcmNlQ3VzdG9tU291bmQ6IChkb3Nob3cpIC0+XG4gICAgICAgIHJldHVybiBpZiBsb2NhbFN0b3JhZ2UuZm9yY2VDdXN0b21Tb3VuZCA9PSBkb3Nob3dcbiAgICAgICAgQGZvcmNlQ3VzdG9tU291bmQgPSBsb2NhbFN0b3JhZ2UuZm9yY2VDdXN0b21Tb3VuZCA9IGRvc2hvd1xuICAgICAgICB1cGRhdGVkICd2aWV3c3RhdGUnXG5cbiAgICBzZXRTaG93SWNvbk5vdGlmaWNhdGlvbjogKGRvc2hvdykgLT5cbiAgICAgICAgcmV0dXJuIGlmIGxvY2FsU3RvcmFnZS5zaG93SWNvbk5vdGlmaWNhdGlvbiA9PSBkb3Nob3dcbiAgICAgICAgQHNob3dJY29uTm90aWZpY2F0aW9uID0gbG9jYWxTdG9yYWdlLnNob3dJY29uTm90aWZpY2F0aW9uID0gZG9zaG93XG4gICAgICAgIHVwZGF0ZWQgJ3ZpZXdzdGF0ZSdcblxuICAgIHNldE11dGVTb3VuZE5vdGlmaWNhdGlvbjogKGRvc2hvdykgLT5cbiAgICAgICAgcmV0dXJuIGlmIGxvY2FsU3RvcmFnZS5tdXRlU291bmROb3RpZmljYXRpb24gPT0gZG9zaG93XG4gICAgICAgIEBtdXRlU291bmROb3RpZmljYXRpb24gPSBsb2NhbFN0b3JhZ2UubXV0ZVNvdW5kTm90aWZpY2F0aW9uID0gZG9zaG93XG4gICAgICAgIHVwZGF0ZWQgJ3ZpZXdzdGF0ZSdcblxuICAgIHNldENvbnZlcnRFbW9qaTogKGRvc2hvdykgLT5cbiAgICAgICAgcmV0dXJuIGlmIEBjb252ZXJ0RW1vamkgPT0gZG9zaG93XG4gICAgICAgIEBjb252ZXJ0RW1vamkgPSBsb2NhbFN0b3JhZ2UuY29udmVydEVtb2ppID0gZG9zaG93XG4gICAgICAgIHVwZGF0ZWQgJ3ZpZXdzdGF0ZSdcblxuICAgIHNldFN1Z2dlc3RFbW9qaTogKGRvc2hvdykgLT5cbiAgICAgICAgcmV0dXJuIGlmIEBzdWdnZXN0RW1vamkgPT0gZG9zaG93XG4gICAgICAgIEBzdWdnZXN0RW1vamkgPSBsb2NhbFN0b3JhZ2Uuc3VnZ2VzdEVtb2ppID0gZG9zaG93XG4gICAgICAgIHVwZGF0ZWQgJ3ZpZXdzdGF0ZSdcblxuICAgIHNldENvbG9yU2NoZW1lOiAoY29sb3JzY2hlbWUpIC0+XG4gICAgICAgIEBjb2xvclNjaGVtZSA9IGxvY2FsU3RvcmFnZS5jb2xvclNjaGVtZSA9IGNvbG9yc2NoZW1lXG4gICAgICAgIHdoaWxlIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2h0bWwnKS5jbGFzc0xpc3QubGVuZ3RoID4gMFxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignaHRtbCcpLmNsYXNzTGlzdC5yZW1vdmUgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignaHRtbCcpLmNsYXNzTGlzdC5pdGVtKDApXG4gICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2h0bWwnKS5jbGFzc0xpc3QuYWRkKGNvbG9yc2NoZW1lKVxuXG4gICAgc2V0Rm9udFNpemU6IChmb250c2l6ZSkgLT5cbiAgICAgICAgQGZvbnRTaXplID0gbG9jYWxTdG9yYWdlLmZvbnRTaXplID0gZm9udHNpemVcbiAgICAgICAgd2hpbGUgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignaHRtbCcpLmNsYXNzTGlzdC5sZW5ndGggPiAwXG4gICAgICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdodG1sJykuY2xhc3NMaXN0LnJlbW92ZSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdodG1sJykuY2xhc3NMaXN0Lml0ZW0oMClcbiAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignaHRtbCcpLmNsYXNzTGlzdC5hZGQobG9jYWxTdG9yYWdlLmNvbG9yU2NoZW1lKVxuICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdodG1sJykuY2xhc3NMaXN0LmFkZChmb250c2l6ZSlcblxuICAgIHNldEVzY2FwZUNsZWFyc0lucHV0OiAodmFsdWUpIC0+XG4gICAgICAgIEBlc2NhcGVDbGVhcnNJbnB1dCA9IGxvY2FsU3RvcmFnZS5lc2NhcGVDbGVhcnNJbnB1dCA9IHZhbHVlXG4gICAgICAgIHVwZGF0ZWQgJ3ZpZXdzdGF0ZSdcblxuICAgIHNldFNob3dUcmF5OiAodmFsdWUpIC0+XG4gICAgICAgIEBzaG93dHJheSA9IGxvY2FsU3RvcmFnZS5zaG93dHJheSA9IHZhbHVlXG5cbiAgICAgICAgaWYgbm90IEBzaG93dHJheVxuICAgICAgICAgICAgQHNldENsb3NlVG9UcmF5KGZhbHNlKVxuICAgICAgICAgICAgQHNldFN0YXJ0TWluaW1pemVkVG9UcmF5KGZhbHNlKVxuICAgICAgICBlbHNlXG4gICAgICAgICAgICB1cGRhdGVkICd2aWV3c3RhdGUnXG5cbiAgICBzZXRIaWRlRG9ja0ljb246ICh2YWx1ZSkgLT5cbiAgICAgICAgQGhpZGVkb2NraWNvbiA9IGxvY2FsU3RvcmFnZS5oaWRlZG9ja2ljb24gPSB2YWx1ZVxuICAgICAgICB1cGRhdGVkICd2aWV3c3RhdGUnXG5cbiAgICBzZXRTdGFydE1pbmltaXplZFRvVHJheTogKHZhbHVlKSAtPlxuICAgICAgICBAc3RhcnRtaW5pbWl6ZWR0b3RyYXkgPSBsb2NhbFN0b3JhZ2Uuc3RhcnRtaW5pbWl6ZWR0b3RyYXkgPSB2YWx1ZVxuICAgICAgICB1cGRhdGVkICd2aWV3c3RhdGUnXG5cbiAgICBzZXRTaG93RG9ja0ljb25PbmNlOiAodmFsdWUpIC0+XG4gICAgICAgIEBzaG93RG9ja0ljb25PbmNlID0gdmFsdWVcblxuICAgIHNldENsb3NlVG9UcmF5OiAodmFsdWUpIC0+XG4gICAgICAgIEBjbG9zZXRvdHJheSA9IGxvY2FsU3RvcmFnZS5jbG9zZXRvdHJheSA9ICEhdmFsdWVcbiAgICAgICAgdXBkYXRlZCAndmlld3N0YXRlJ1xuXG4gICAgc2V0T3Blbk9uU3lzdGVtU3RhcnR1cDogKG9wZW4pIC0+XG4gICAgICAgIHJldHVybiBpZiBAb3Blbk9uU3lzdGVtU3RhcnR1cCA9PSBvcGVuXG5cbiAgICAgICAgaWYgb3BlblxuICAgICAgICAgICAgYXV0b0xhdW5jaGVyLmVuYWJsZSgpXG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIGF1dG9MYXVuY2hlci5kaXNhYmxlKClcblxuICAgICAgICBAb3Blbk9uU3lzdGVtU3RhcnR1cCA9IG9wZW5cblxuICAgICAgICB1cGRhdGVkICd2aWV3c3RhdGUnXG5cbiAgICBpbml0T3Blbk9uU3lzdGVtU3RhcnR1cDogKGlzRW5hYmxlZCkgLT5cbiAgICAgICAgQG9wZW5PblN5c3RlbVN0YXJ0dXAgPSBpc0VuYWJsZWRcblxuICAgICAgICB1cGRhdGVkICd2aWV3c3RhdGUnXG59XG5cbm1lcmdlIGV4cCwgU1RBVEVTXG4iXX0=
