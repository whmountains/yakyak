(function() {
  var nameof, scrollToBottom;

  ({scrollToBottom} = require('./messages'));

  ({nameof} = require('../util'));

  module.exports = view(function(models) {
    var c, conv, conv_id, entity, ref, viewstate;
    ({viewstate, conv, entity} = models);
    conv_id = viewstate != null ? viewstate.selectedConv : void 0;
    c = conv[conv_id];
    return div({
      class: 'typing ' + ((c != null ? (ref = c.typing) != null ? ref.length : void 0 : void 0) ? 'typingnow' : void 0)
    }, function() {
      var i, j, len, name, ref1, ref2, ref3, ref4, t;
      if (!c) {
        return;
      }
      if (c != null ? (ref1 = c.typing) != null ? ref1.length : void 0 : void 0) {
        span({
          class: 'material-icons'
        }, 'more_horiz');
      }
      ref3 = (ref2 = c.typing) != null ? ref2 : [];
      for (i = j = 0, len = ref3.length; j < len; i = ++j) {
        t = ref3[i];
        name = nameof(entity[t.user_id.chat_id]);
        span({
          class: `typing_${t.status}`
        }, name);
        if (i < (c.typing.length - 1)) {
          pass(', ');
        }
      }
      if (c != null ? (ref4 = c.typing) != null ? ref4.length : void 0 : void 0) {
        return pass(` ${i18n.__('input.typing:is typing')}`);
      }
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvdmlld3MvdHlwaW5naW5mby5qcyIsInNvdXJjZXMiOlsidWkvdmlld3MvdHlwaW5naW5mby5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLE1BQUEsRUFBQTs7RUFBQSxDQUFBLENBQUMsY0FBRCxDQUFBLEdBQW1CLE9BQUEsQ0FBUSxZQUFSLENBQW5COztFQUNBLENBQUEsQ0FBQyxNQUFELENBQUEsR0FBWSxPQUFBLENBQVEsU0FBUixDQUFaOztFQUVBLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLElBQUEsQ0FBSyxRQUFBLENBQUMsTUFBRCxDQUFBO0FBQ2xCLFFBQUEsQ0FBQSxFQUFBLElBQUEsRUFBQSxPQUFBLEVBQUEsTUFBQSxFQUFBLEdBQUEsRUFBQTtJQUFBLENBQUEsQ0FBQyxTQUFELEVBQVksSUFBWixFQUFrQixNQUFsQixDQUFBLEdBQTRCLE1BQTVCO0lBRUEsT0FBQSx1QkFBVSxTQUFTLENBQUU7SUFDckIsQ0FBQSxHQUFJLElBQUssQ0FBQSxPQUFBO1dBRVQsR0FBQSxDQUFJO01BQUEsS0FBQSxFQUFNLFNBQUEsR0FBVSw0Q0FBeUIsQ0FBRSx5QkFBMUIsR0FBQSxXQUFBLEdBQUEsTUFBRDtJQUFoQixDQUFKLEVBQXdELFFBQUEsQ0FBQSxDQUFBO0FBQ3BELFVBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxHQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQTtNQUFBLElBQUEsQ0FBYyxDQUFkO0FBQUEsZUFBQTs7TUFDQSxnREFBc0QsQ0FBRSx3QkFBeEQ7UUFBQSxJQUFBLENBQUs7VUFBQSxLQUFBLEVBQU07UUFBTixDQUFMLEVBQTZCLFlBQTdCLEVBQUE7O0FBQ0E7TUFBQSxLQUFBLDhDQUFBOztRQUNJLElBQUEsR0FBTyxNQUFBLENBQU8sTUFBTyxDQUFBLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBVixDQUFkO1FBQ1AsSUFBQSxDQUFLO1VBQUEsS0FBQSxFQUFNLENBQUEsT0FBQSxDQUFBLENBQVUsQ0FBQyxDQUFDLE1BQVosQ0FBQTtRQUFOLENBQUwsRUFBaUMsSUFBakM7UUFDQSxJQUFhLENBQUEsR0FBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBVCxHQUFrQixDQUFuQixDQUFqQjtVQUFBLElBQUEsQ0FBSyxJQUFMLEVBQUE7O01BSEo7TUFJQSxnREFBd0QsQ0FBRSx3QkFBMUQ7ZUFBQSxJQUFBLENBQUssRUFBQSxDQUFBLENBQUksSUFBSSxDQUFDLEVBQUwsQ0FBUSx3QkFBUixDQUFKLENBQUEsQ0FBTCxFQUFBOztJQVBvRCxDQUF4RDtFQU5rQixDQUFMO0FBSGpCIiwic291cmNlc0NvbnRlbnQiOlsie3Njcm9sbFRvQm90dG9tfSA9IHJlcXVpcmUgJy4vbWVzc2FnZXMnXG57bmFtZW9mfSAgPSByZXF1aXJlICcuLi91dGlsJ1xuXG5tb2R1bGUuZXhwb3J0cyA9IHZpZXcgKG1vZGVscykgLT5cbiAgICB7dmlld3N0YXRlLCBjb252LCBlbnRpdHl9ID0gbW9kZWxzXG5cbiAgICBjb252X2lkID0gdmlld3N0YXRlPy5zZWxlY3RlZENvbnZcbiAgICBjID0gY29udltjb252X2lkXVxuXG4gICAgZGl2IGNsYXNzOid0eXBpbmcgJysoJ3R5cGluZ25vdycgaWYgYz8udHlwaW5nPy5sZW5ndGgpLCAtPlxuICAgICAgICByZXR1cm4gdW5sZXNzIGNcbiAgICAgICAgc3BhbiBjbGFzczonbWF0ZXJpYWwtaWNvbnMnLCAnbW9yZV9ob3JpeicgaWYgYz8udHlwaW5nPy5sZW5ndGhcbiAgICAgICAgZm9yIHQsIGkgaW4gKGMudHlwaW5nID8gW10pXG4gICAgICAgICAgICBuYW1lID0gbmFtZW9mIGVudGl0eVt0LnVzZXJfaWQuY2hhdF9pZF1cbiAgICAgICAgICAgIHNwYW4gY2xhc3M6XCJ0eXBpbmdfI3t0LnN0YXR1c31cIiwgbmFtZVxuICAgICAgICAgICAgcGFzcyAnLCAnIGlmIGkgPCAoYy50eXBpbmcubGVuZ3RoIC0gMSlcbiAgICAgICAgcGFzcyBcIiAje2kxOG4uX18gJ2lucHV0LnR5cGluZzppcyB0eXBpbmcnfVwiIGlmIGM/LnR5cGluZz8ubGVuZ3RoXG4iXX0=
