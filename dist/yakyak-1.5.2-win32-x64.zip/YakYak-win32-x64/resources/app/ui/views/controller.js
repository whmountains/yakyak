(function() {
  var about, applayout, connection, conninfo, controls, convadd, convhead, convlist, dockicon, input, later, listhead, menu, messages, models, notifications, redraw, remote, setConvMin, setLeftSize, startup, throttle, trayicon, typinginfo, viewstate;

  remote = require('electron').remote;

  ({applayout, convlist, listhead, messages, convhead, input, conninfo, convadd, controls, notifications, typinginfo, menu, trayicon, dockicon, startup, about} = require('./index'));

  models = require('../models');

  ({viewstate, connection} = models);

  ({later} = require('../util'));

  handle('update:connection', (function() {
    var el;
    el = null;
    return function() {
      // draw view
      conninfo(connection);
      // place in layout
      if (connection.state === connection.CONNECTED) {
        later(function() {
          return action('lastActivity');
        });
        if (el != null) {
          if (typeof el.hide === "function") {
            el.hide();
          }
        }
        return el = null;
      } else if (viewstate.state !== viewstate.STATE_STARTUP) {
        return el = notr({
          html: conninfo.el.innerHTML,
          stay: 0,
          id: 'conn'
        });
      } else {
        // update startup with connection information
        return redraw();
      }
    };
  })());

  setLeftSize = function(left) {
    document.querySelector('.left').style.width = left + 'px';
    return document.querySelector('.leftresize').style.left = (left - 2) + 'px';
  };

  setConvMin = function(convmin) {
    if (convmin) {
      document.querySelector('.left').classList.add("minimal");
      return document.querySelector('.leftresize').classList.add("minimal");
    } else {
      document.querySelector('.left').classList.remove("minimal");
      return document.querySelector('.leftresize').classList.remove("minimal");
    }
  };

  handle('update:viewstate', function() {
    var height, i, len, maxH, maxW, maxX, maxY, ref, reposition, screen, width, winSize, x, xWindowPos, y, yWindowPos;
    setLeftSize(viewstate.leftSize);
    setConvMin(viewstate.showConvMin);
    if (viewstate.state === viewstate.STATE_STARTUP) {
      if (Array.isArray(viewstate.size)) {
        later(function() {
          return remote.getCurrentWindow().setSize(...viewstate.size);
        });
      }
      
      // It will not allow the window to be placed offscreen (fully or partial)

      // For that it needs to iterate on all screens and see if position is valid.
      //  If it is not valid, then it will approximate the best position possible
      if (Array.isArray(viewstate.pos)) {
        // uses max X and Y as a fallback method in case it can't be placed on any
        //  current display, by approximating a new position
        maxX = maxY = maxW = maxH = 0;
        reposition = false;
        // helper variable to determine valid coordinates to be used, initialized with
        //  desired coordinates
        xWindowPos = viewstate.pos[0];
        yWindowPos = viewstate.pos[1];
        // window size to be used in rounding the position, i.e. avoiding partial offscreen
        winSize = remote.getCurrentWindow().getSize();
        ref = remote.screen.getAllDisplays();
        // iterate on all displays to see if the desired position is valid
        for (i = 0, len = ref.length; i < len; i++) {
          screen = ref[i];
          // get bounds of each display
          ({width, height} = screen.workAreaSize);
          ({x, y} = screen.workArea);
          // see if this improves on maxY and maxX
          if (x + width > maxW) {
            maxX = x;
            maxW = x + width;
          }
          if (y + height > maxH) {
            maxY = y;
            maxH = y + height;
          }
          // check if window will be placed in this display
          if (xWindowPos >= x && xWindowPos < x + width && yWindowPos >= y && yWindowPos < y + height) {
            // if window will be partially placed outside of this display, then it will
            //  move it all inside the display

            // for X
            if (winSize[0] > width) {
              xWindowPos = x;
            } else if (xWindowPos > x + width - winSize[0] / 2) {
              xWindowPos = x + width - winSize[0] / 2;
            }
            // for Y
            if (winSize[1] > height) {
              yWindowPos = y;
            } else if (yWindowPos > y + width - winSize[1] / 2) {
              yWindowPos = y + width - winSize[1] / 2;
            }
            // making sure no negative positions on displays
            xWindowPos = Math.max(xWindowPos, x);
            yWindowPos = Math.max(yWindowPos, y);
            
            reposition = true; // coordinates have been calculated
            break; // break the loop
          }
        }
        if (!reposition) {
          if (xWindowPos > maxW) {
            xWindowPos = maxW - winSize[0];
          }
          if (yWindowPos > maxH) {
            yWindowPos = maxY;
          }
          xWindowPos = Math.max(xWindowPos, maxX);
          yWindowPos = Math.max(yWindowPos, maxY);
        }
        later(function() {
          return remote.getCurrentWindow().setPosition(xWindowPos, yWindowPos);
        });
      }
      // only render startup
      startup(models);
      applayout.left(null);
      applayout.convhead(null);
      applayout.main(null);
      applayout.maininfo(null);
      applayout.foot(null);
      applayout.last(startup);
      document.body.style.zoom = viewstate.zoom;
      return document.body.style.setProperty('--zoom', viewstate.zoom);
    } else if (viewstate.state === viewstate.STATE_NORMAL) {
      redraw();
      applayout.lfoot(controls);
      applayout.listhead(listhead);
      applayout.left(convlist);
      applayout.convhead(convhead);
      applayout.main(messages);
      applayout.maininfo(typinginfo);
      applayout.foot(input);
      applayout.last(null);
      menu(viewstate);
      dockicon(viewstate);
      return trayicon(models);
    } else if (viewstate.state === viewstate.STATE_ABOUT) {
      redraw();
      about(models);
      applayout.left(convlist);
      applayout.main(about);
      applayout.convhead(null);
      applayout.maininfo(null);
      return applayout.foot(null);
    } else if (viewstate.state === viewstate.STATE_ADD_CONVERSATION) {
      redraw();
      applayout.left(convlist);
      applayout.main(convadd);
      applayout.maininfo(null);
      return applayout.foot(null);
    } else {
      return console.log('unknown viewstate.state', viewstate.state);
    }
  });

  handle('update:entity', function() {
    return redraw();
  });

  handle('update:conv', function() {
    return redraw();
  });

  handle('update:conv_count', function() {
    dockicon(viewstate);
    return trayicon(models);
  });

  handle('update:searchedentities', function() {
    return redraw();
  });

  handle('update:selectedEntities', function() {
    return redraw();
  });

  handle('update:convsettings', function() {
    return redraw();
  });

  redraw = function() {
    notifications(models);
    convhead(models);
    controls(models);
    convlist(models);
    listhead(models);
    messages(models);
    typinginfo(models);
    input(models);
    convadd(models);
    return startup(models);
  };

  handle('update:language', function() {
    menu(viewstate);
    return redraw();
  });

  throttle = function(fn, time = 10) {
    var throttled, timeout;
    timeout = false;
    // return a throttled version of fn
    // which executes on the trailing end of `time`
    return throttled = function() {
      if (timeout) {
        return;
      }
      return timeout = setTimeout(function() {
        fn();
        return timeout = false;
      }, time);
    };
  };

  redraw = throttle(redraw, 20);

  handle('update:language', function() {
    menu(viewstate);
    return redraw();
  });

  handle('update:switchConv', function() {
    return messages.scrollToBottom();
  });

  handle('update:beforeHistory', function() {
    return applayout.recordMainPos();
  });

  handle('update:afterHistory', function() {
    return applayout.adjustMainPos();
  });

  handle('update:beforeImg', function() {
    return applayout.recordMainPos();
  });

  handle('update:afterImg', function() {
    if (viewstate.atbottom) {
      return messages.scrollToBottom();
    } else {
      return applayout.adjustMainPos();
    }
  });

  handle('update:startTyping', function() {
    if (viewstate.atbottom) {
      return messages.scrollToBottom();
    }
  });

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvdmlld3MvY29udHJvbGxlci5qcyIsInNvdXJjZXMiOlsidWkvdmlld3MvY29udHJvbGxlci5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLEtBQUEsRUFBQSxTQUFBLEVBQUEsVUFBQSxFQUFBLFFBQUEsRUFBQSxRQUFBLEVBQUEsT0FBQSxFQUFBLFFBQUEsRUFBQSxRQUFBLEVBQUEsUUFBQSxFQUFBLEtBQUEsRUFBQSxLQUFBLEVBQUEsUUFBQSxFQUFBLElBQUEsRUFBQSxRQUFBLEVBQUEsTUFBQSxFQUFBLGFBQUEsRUFBQSxNQUFBLEVBQUEsTUFBQSxFQUFBLFVBQUEsRUFBQSxXQUFBLEVBQUEsT0FBQSxFQUFBLFFBQUEsRUFBQSxRQUFBLEVBQUEsVUFBQSxFQUFBOztFQUFBLE1BQUEsR0FBUyxPQUFBLENBQVEsVUFBUixDQUFtQixDQUFDOztFQUU3QixDQUFBLENBQUMsU0FBRCxFQUFZLFFBQVosRUFBc0IsUUFBdEIsRUFBZ0MsUUFBaEMsRUFBMEMsUUFBMUMsRUFBb0QsS0FBcEQsRUFBMkQsUUFBM0QsRUFBcUUsT0FBckUsRUFBOEUsUUFBOUUsRUFDQSxhQURBLEVBQ2UsVUFEZixFQUMyQixJQUQzQixFQUNpQyxRQURqQyxFQUMyQyxRQUQzQyxFQUNxRCxPQURyRCxFQUM4RCxLQUQ5RCxDQUFBLEdBQ3VFLE9BQUEsQ0FBUSxTQUFSLENBRHZFOztFQUdBLE1BQUEsR0FBYyxPQUFBLENBQVEsV0FBUjs7RUFDZCxDQUFBLENBQUMsU0FBRCxFQUFZLFVBQVosQ0FBQSxHQUEwQixNQUExQjs7RUFFQSxDQUFBLENBQUMsS0FBRCxDQUFBLEdBQVUsT0FBQSxDQUFRLFNBQVIsQ0FBVjs7RUFHQSxNQUFBLENBQU8sbUJBQVAsRUFBK0IsQ0FBQSxRQUFBLENBQUEsQ0FBQTtBQUMzQixRQUFBO0lBQUEsRUFBQSxHQUFLO1dBQ0wsUUFBQSxDQUFBLENBQUEsRUFBQTs7TUFFSSxRQUFBLENBQVMsVUFBVCxFQUFBOztNQUdBLElBQUcsVUFBVSxDQUFDLEtBQVgsS0FBb0IsVUFBVSxDQUFDLFNBQWxDO1FBQ0ksS0FBQSxDQUFNLFFBQUEsQ0FBQSxDQUFBO2lCQUFHLE1BQUEsQ0FBTyxjQUFQO1FBQUgsQ0FBTjs7O1lBQ0EsRUFBRSxDQUFFOzs7ZUFDSixFQUFBLEdBQUssS0FIVDtPQUFBLE1BSUssSUFBRyxTQUFTLENBQUMsS0FBVixLQUFtQixTQUFTLENBQUMsYUFBaEM7ZUFDRCxFQUFBLEdBQUssSUFBQSxDQUFLO1VBQUMsSUFBQSxFQUFLLFFBQVEsQ0FBQyxFQUFFLENBQUMsU0FBbEI7VUFBNkIsSUFBQSxFQUFLLENBQWxDO1VBQXFDLEVBQUEsRUFBRztRQUF4QyxDQUFMLEVBREo7T0FBQSxNQUFBOztlQUlELE1BQUEsQ0FBQSxFQUpDOztJQVRUO0VBRjJCLENBQUEsQ0FBSCxDQUFBLENBQTVCOztFQWlCQSxXQUFBLEdBQWMsUUFBQSxDQUFDLElBQUQsQ0FBQTtJQUNWLFFBQVEsQ0FBQyxhQUFULENBQXVCLE9BQXZCLENBQStCLENBQUMsS0FBSyxDQUFDLEtBQXRDLEdBQThDLElBQUEsR0FBTztXQUNyRCxRQUFRLENBQUMsYUFBVCxDQUF1QixhQUF2QixDQUFxQyxDQUFDLEtBQUssQ0FBQyxJQUE1QyxHQUFtRCxDQUFDLElBQUEsR0FBTyxDQUFSLENBQUEsR0FBYTtFQUZ0RDs7RUFJZCxVQUFBLEdBQWEsUUFBQSxDQUFDLE9BQUQsQ0FBQTtJQUNULElBQUcsT0FBSDtNQUNJLFFBQVEsQ0FBQyxhQUFULENBQXVCLE9BQXZCLENBQStCLENBQUMsU0FBUyxDQUFDLEdBQTFDLENBQThDLFNBQTlDO2FBQ0EsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsYUFBdkIsQ0FBcUMsQ0FBQyxTQUFTLENBQUMsR0FBaEQsQ0FBb0QsU0FBcEQsRUFGSjtLQUFBLE1BQUE7TUFJSSxRQUFRLENBQUMsYUFBVCxDQUF1QixPQUF2QixDQUErQixDQUFDLFNBQVMsQ0FBQyxNQUExQyxDQUFpRCxTQUFqRDthQUNBLFFBQVEsQ0FBQyxhQUFULENBQXVCLGFBQXZCLENBQXFDLENBQUMsU0FBUyxDQUFDLE1BQWhELENBQXVELFNBQXZELEVBTEo7O0VBRFM7O0VBUWIsTUFBQSxDQUFPLGtCQUFQLEVBQTJCLFFBQUEsQ0FBQSxDQUFBO0FBQ3ZCLFFBQUEsTUFBQSxFQUFBLENBQUEsRUFBQSxHQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLEdBQUEsRUFBQSxVQUFBLEVBQUEsTUFBQSxFQUFBLEtBQUEsRUFBQSxPQUFBLEVBQUEsQ0FBQSxFQUFBLFVBQUEsRUFBQSxDQUFBLEVBQUE7SUFBQSxXQUFBLENBQVksU0FBUyxDQUFDLFFBQXRCO0lBQ0EsVUFBQSxDQUFXLFNBQVMsQ0FBQyxXQUFyQjtJQUNBLElBQUcsU0FBUyxDQUFDLEtBQVYsS0FBbUIsU0FBUyxDQUFDLGFBQWhDO01BQ0ksSUFBRyxLQUFLLENBQUMsT0FBTixDQUFjLFNBQVMsQ0FBQyxJQUF4QixDQUFIO1FBQ0ksS0FBQSxDQUFNLFFBQUEsQ0FBQSxDQUFBO2lCQUFHLE1BQU0sQ0FBQyxnQkFBUCxDQUFBLENBQXlCLENBQUMsT0FBMUIsQ0FBa0MsR0FBQSxTQUFTLENBQUMsSUFBNUM7UUFBSCxDQUFOLEVBREo7T0FBQTs7Ozs7O01BUUEsSUFBRyxLQUFLLENBQUMsT0FBTixDQUFjLFNBQVMsQ0FBQyxHQUF4QixDQUFIOzs7UUFHSSxJQUFBLEdBQU8sSUFBQSxHQUFPLElBQUEsR0FBTyxJQUFBLEdBQU87UUFDNUIsVUFBQSxHQUFhLE1BRGI7OztRQUlBLFVBQUEsR0FBYSxTQUFTLENBQUMsR0FBSSxDQUFBLENBQUE7UUFDM0IsVUFBQSxHQUFhLFNBQVMsQ0FBQyxHQUFJLENBQUEsQ0FBQSxFQUwzQjs7UUFPQSxPQUFBLEdBQVUsTUFBTSxDQUFDLGdCQUFQLENBQUEsQ0FBeUIsQ0FBQyxPQUExQixDQUFBO0FBRVY7O1FBQUEsS0FBQSxxQ0FBQTswQkFBQTs7VUFFSSxDQUFBLENBQUMsS0FBRCxFQUFRLE1BQVIsQ0FBQSxHQUFrQixNQUFNLENBQUMsWUFBekI7VUFDQSxDQUFBLENBQUMsQ0FBRCxFQUFJLENBQUosQ0FBQSxHQUFTLE1BQU0sQ0FBQyxRQUFoQixFQURBOztVQUlBLElBQUcsQ0FBQSxHQUFJLEtBQUosR0FBWSxJQUFmO1lBQ0ksSUFBQSxHQUFPO1lBQ1AsSUFBQSxHQUFPLENBQUEsR0FBSSxNQUZmOztVQUdBLElBQUcsQ0FBQSxHQUFJLE1BQUosR0FBYSxJQUFoQjtZQUNJLElBQUEsR0FBTztZQUNQLElBQUEsR0FBTyxDQUFBLEdBQUksT0FGZjtXQVBBOztVQWFBLElBQUcsVUFBQSxJQUFjLENBQWQsSUFBb0IsVUFBQSxHQUFhLENBQUEsR0FBSSxLQUFyQyxJQUErQyxVQUFBLElBQWMsQ0FBN0QsSUFBbUUsVUFBQSxHQUFhLENBQUEsR0FBSSxNQUF2Rjs7Ozs7WUFLSSxJQUFHLE9BQVEsQ0FBQSxDQUFBLENBQVIsR0FBYSxLQUFoQjtjQUNJLFVBQUEsR0FBYSxFQURqQjthQUFBLE1BRUssSUFBRyxVQUFBLEdBQWEsQ0FBQSxHQUFJLEtBQUosR0FBWSxPQUFRLENBQUEsQ0FBQSxDQUFSLEdBQWEsQ0FBekM7Y0FDRCxVQUFBLEdBQWEsQ0FBQSxHQUFJLEtBQUosR0FBWSxPQUFRLENBQUEsQ0FBQSxDQUFSLEdBQWEsRUFEckM7YUFGTDs7WUFNQSxJQUFHLE9BQVEsQ0FBQSxDQUFBLENBQVIsR0FBYSxNQUFoQjtjQUNJLFVBQUEsR0FBYSxFQURqQjthQUFBLE1BRUssSUFBRyxVQUFBLEdBQWEsQ0FBQSxHQUFJLEtBQUosR0FBWSxPQUFRLENBQUEsQ0FBQSxDQUFSLEdBQWEsQ0FBekM7Y0FDRCxVQUFBLEdBQWEsQ0FBQSxHQUFJLEtBQUosR0FBWSxPQUFRLENBQUEsQ0FBQSxDQUFSLEdBQWEsRUFEckM7YUFSTDs7WUFXQSxVQUFBLEdBQWEsSUFBSSxDQUFDLEdBQUwsQ0FBUyxVQUFULEVBQXFCLENBQXJCO1lBQ2IsVUFBQSxHQUFhLElBQUksQ0FBQyxHQUFMLENBQVMsVUFBVCxFQUFxQixDQUFyQjs7WUFFYixVQUFBLEdBQWEsS0FkYjtBQWVBLGtCQXBCSjs7UUFmSjtRQW9DQSxJQUFHLENBQUksVUFBUDtVQUNJLElBQWtDLFVBQUEsR0FBYSxJQUEvQztZQUFBLFVBQUEsR0FBYSxJQUFBLEdBQU8sT0FBUSxDQUFBLENBQUEsRUFBNUI7O1VBQ0EsSUFBcUIsVUFBQSxHQUFhLElBQWxDO1lBQUEsVUFBQSxHQUFhLEtBQWI7O1VBQ0EsVUFBQSxHQUFhLElBQUksQ0FBQyxHQUFMLENBQVMsVUFBVCxFQUFxQixJQUFyQjtVQUNiLFVBQUEsR0FBYSxJQUFJLENBQUMsR0FBTCxDQUFTLFVBQVQsRUFBcUIsSUFBckIsRUFKakI7O1FBS0EsS0FBQSxDQUFNLFFBQUEsQ0FBQSxDQUFBO2lCQUFHLE1BQU0sQ0FBQyxnQkFBUCxDQUFBLENBQXlCLENBQUMsV0FBMUIsQ0FBc0MsVUFBdEMsRUFBa0QsVUFBbEQ7UUFBSCxDQUFOLEVBckRKO09BUkE7O01BK0RBLE9BQUEsQ0FBUSxNQUFSO01BRUEsU0FBUyxDQUFDLElBQVYsQ0FBZSxJQUFmO01BQ0EsU0FBUyxDQUFDLFFBQVYsQ0FBbUIsSUFBbkI7TUFDQSxTQUFTLENBQUMsSUFBVixDQUFlLElBQWY7TUFDQSxTQUFTLENBQUMsUUFBVixDQUFtQixJQUFuQjtNQUNBLFNBQVMsQ0FBQyxJQUFWLENBQWUsSUFBZjtNQUNBLFNBQVMsQ0FBQyxJQUFWLENBQWUsT0FBZjtNQUVBLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQXBCLEdBQTJCLFNBQVMsQ0FBQzthQUNyQyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFwQixDQUFnQyxRQUFoQyxFQUEwQyxTQUFTLENBQUMsSUFBcEQsRUExRUo7S0FBQSxNQTJFSyxJQUFHLFNBQVMsQ0FBQyxLQUFWLEtBQW1CLFNBQVMsQ0FBQyxZQUFoQztNQUNELE1BQUEsQ0FBQTtNQUNBLFNBQVMsQ0FBQyxLQUFWLENBQWdCLFFBQWhCO01BQ0EsU0FBUyxDQUFDLFFBQVYsQ0FBbUIsUUFBbkI7TUFDQSxTQUFTLENBQUMsSUFBVixDQUFlLFFBQWY7TUFDQSxTQUFTLENBQUMsUUFBVixDQUFtQixRQUFuQjtNQUNBLFNBQVMsQ0FBQyxJQUFWLENBQWUsUUFBZjtNQUNBLFNBQVMsQ0FBQyxRQUFWLENBQW1CLFVBQW5CO01BQ0EsU0FBUyxDQUFDLElBQVYsQ0FBZSxLQUFmO01BRUEsU0FBUyxDQUFDLElBQVYsQ0FBZSxJQUFmO01BRUEsSUFBQSxDQUFLLFNBQUw7TUFDQSxRQUFBLENBQVMsU0FBVDthQUNBLFFBQUEsQ0FBUyxNQUFULEVBZEM7S0FBQSxNQWdCQSxJQUFHLFNBQVMsQ0FBQyxLQUFWLEtBQW1CLFNBQVMsQ0FBQyxXQUFoQztNQUNELE1BQUEsQ0FBQTtNQUNBLEtBQUEsQ0FBTSxNQUFOO01BQ0EsU0FBUyxDQUFDLElBQVYsQ0FBZSxRQUFmO01BQ0EsU0FBUyxDQUFDLElBQVYsQ0FBZSxLQUFmO01BQ0EsU0FBUyxDQUFDLFFBQVYsQ0FBbUIsSUFBbkI7TUFDQSxTQUFTLENBQUMsUUFBVixDQUFtQixJQUFuQjthQUNBLFNBQVMsQ0FBQyxJQUFWLENBQWUsSUFBZixFQVBDO0tBQUEsTUFRQSxJQUFHLFNBQVMsQ0FBQyxLQUFWLEtBQW1CLFNBQVMsQ0FBQyxzQkFBaEM7TUFDRCxNQUFBLENBQUE7TUFDQSxTQUFTLENBQUMsSUFBVixDQUFlLFFBQWY7TUFDQSxTQUFTLENBQUMsSUFBVixDQUFlLE9BQWY7TUFDQSxTQUFTLENBQUMsUUFBVixDQUFtQixJQUFuQjthQUNBLFNBQVMsQ0FBQyxJQUFWLENBQWUsSUFBZixFQUxDO0tBQUEsTUFBQTthQU9ELE9BQU8sQ0FBQyxHQUFSLENBQVkseUJBQVosRUFBdUMsU0FBUyxDQUFDLEtBQWpELEVBUEM7O0VBdEdrQixDQUEzQjs7RUErR0EsTUFBQSxDQUFPLGVBQVAsRUFBd0IsUUFBQSxDQUFBLENBQUE7V0FDcEIsTUFBQSxDQUFBO0VBRG9CLENBQXhCOztFQUdBLE1BQUEsQ0FBTyxhQUFQLEVBQXNCLFFBQUEsQ0FBQSxDQUFBO1dBQ2xCLE1BQUEsQ0FBQTtFQURrQixDQUF0Qjs7RUFHQSxNQUFBLENBQU8sbUJBQVAsRUFBNEIsUUFBQSxDQUFBLENBQUE7SUFDeEIsUUFBQSxDQUFTLFNBQVQ7V0FDQSxRQUFBLENBQVMsTUFBVDtFQUZ3QixDQUE1Qjs7RUFJQSxNQUFBLENBQU8seUJBQVAsRUFBa0MsUUFBQSxDQUFBLENBQUE7V0FDaEMsTUFBQSxDQUFBO0VBRGdDLENBQWxDOztFQUdBLE1BQUEsQ0FBTyx5QkFBUCxFQUFrQyxRQUFBLENBQUEsQ0FBQTtXQUNoQyxNQUFBLENBQUE7RUFEZ0MsQ0FBbEM7O0VBR0EsTUFBQSxDQUFPLHFCQUFQLEVBQThCLFFBQUEsQ0FBQSxDQUFBO1dBQUcsTUFBQSxDQUFBO0VBQUgsQ0FBOUI7O0VBRUEsTUFBQSxHQUFTLFFBQUEsQ0FBQSxDQUFBO0lBQ0wsYUFBQSxDQUFjLE1BQWQ7SUFDQSxRQUFBLENBQVMsTUFBVDtJQUNBLFFBQUEsQ0FBUyxNQUFUO0lBQ0EsUUFBQSxDQUFTLE1BQVQ7SUFDQSxRQUFBLENBQVMsTUFBVDtJQUNBLFFBQUEsQ0FBUyxNQUFUO0lBQ0EsVUFBQSxDQUFXLE1BQVg7SUFDQSxLQUFBLENBQU0sTUFBTjtJQUNBLE9BQUEsQ0FBUSxNQUFSO1dBQ0EsT0FBQSxDQUFRLE1BQVI7RUFWSzs7RUFhVCxNQUFBLENBQU8saUJBQVAsRUFBMEIsUUFBQSxDQUFBLENBQUE7SUFDdEIsSUFBQSxDQUFLLFNBQUw7V0FDQSxNQUFBLENBQUE7RUFGc0IsQ0FBMUI7O0VBSUEsUUFBQSxHQUFXLFFBQUEsQ0FBQyxFQUFELEVBQUssT0FBSyxFQUFWLENBQUE7QUFDUCxRQUFBLFNBQUEsRUFBQTtJQUFBLE9BQUEsR0FBVSxNQUFWOzs7V0FHQSxTQUFBLEdBQVksUUFBQSxDQUFBLENBQUE7TUFDUixJQUFVLE9BQVY7QUFBQSxlQUFBOzthQUNBLE9BQUEsR0FBVSxVQUFBLENBQVcsUUFBQSxDQUFBLENBQUE7UUFDakIsRUFBQSxDQUFBO2VBQ0EsT0FBQSxHQUFVO01BRk8sQ0FBWCxFQUlOLElBSk07SUFGRjtFQUpMOztFQVlYLE1BQUEsR0FBUyxRQUFBLENBQVMsTUFBVCxFQUFpQixFQUFqQjs7RUFFVCxNQUFBLENBQU8saUJBQVAsRUFBMEIsUUFBQSxDQUFBLENBQUE7SUFDdEIsSUFBQSxDQUFLLFNBQUw7V0FDQSxNQUFBLENBQUE7RUFGc0IsQ0FBMUI7O0VBSUEsTUFBQSxDQUFPLG1CQUFQLEVBQTRCLFFBQUEsQ0FBQSxDQUFBO1dBQ3hCLFFBQVEsQ0FBQyxjQUFULENBQUE7RUFEd0IsQ0FBNUI7O0VBR0EsTUFBQSxDQUFPLHNCQUFQLEVBQStCLFFBQUEsQ0FBQSxDQUFBO1dBQzNCLFNBQVMsQ0FBQyxhQUFWLENBQUE7RUFEMkIsQ0FBL0I7O0VBRUEsTUFBQSxDQUFPLHFCQUFQLEVBQThCLFFBQUEsQ0FBQSxDQUFBO1dBQzFCLFNBQVMsQ0FBQyxhQUFWLENBQUE7RUFEMEIsQ0FBOUI7O0VBR0EsTUFBQSxDQUFPLGtCQUFQLEVBQTJCLFFBQUEsQ0FBQSxDQUFBO1dBQ3ZCLFNBQVMsQ0FBQyxhQUFWLENBQUE7RUFEdUIsQ0FBM0I7O0VBRUEsTUFBQSxDQUFPLGlCQUFQLEVBQTBCLFFBQUEsQ0FBQSxDQUFBO0lBQ3RCLElBQUcsU0FBUyxDQUFDLFFBQWI7YUFDSSxRQUFRLENBQUMsY0FBVCxDQUFBLEVBREo7S0FBQSxNQUFBO2FBR0ksU0FBUyxDQUFDLGFBQVYsQ0FBQSxFQUhKOztFQURzQixDQUExQjs7RUFNQSxNQUFBLENBQU8sb0JBQVAsRUFBNkIsUUFBQSxDQUFBLENBQUE7SUFDekIsSUFBRyxTQUFTLENBQUMsUUFBYjthQUNJLFFBQVEsQ0FBQyxjQUFULENBQUEsRUFESjs7RUFEeUIsQ0FBN0I7QUE1TkEiLCJzb3VyY2VzQ29udGVudCI6WyJyZW1vdGUgPSByZXF1aXJlKCdlbGVjdHJvbicpLnJlbW90ZVxuXG57YXBwbGF5b3V0LCBjb252bGlzdCwgbGlzdGhlYWQsIG1lc3NhZ2VzLCBjb252aGVhZCwgaW5wdXQsIGNvbm5pbmZvLCBjb252YWRkLCBjb250cm9scyxcbm5vdGlmaWNhdGlvbnMsIHR5cGluZ2luZm8sIG1lbnUsIHRyYXlpY29uLCBkb2NraWNvbiwgc3RhcnR1cCwgYWJvdXR9ID0gcmVxdWlyZSAnLi9pbmRleCdcblxubW9kZWxzICAgICAgPSByZXF1aXJlICcuLi9tb2RlbHMnXG57dmlld3N0YXRlLCBjb25uZWN0aW9ufSA9IG1vZGVsc1xuXG57bGF0ZXJ9ID0gcmVxdWlyZSAnLi4vdXRpbCdcblxuXG5oYW5kbGUgJ3VwZGF0ZTpjb25uZWN0aW9uJywgZG8gLT5cbiAgICBlbCA9IG51bGxcbiAgICAtPlxuICAgICAgICAjIGRyYXcgdmlld1xuICAgICAgICBjb25uaW5mbyBjb25uZWN0aW9uXG5cbiAgICAgICAgIyBwbGFjZSBpbiBsYXlvdXRcbiAgICAgICAgaWYgY29ubmVjdGlvbi5zdGF0ZSA9PSBjb25uZWN0aW9uLkNPTk5FQ1RFRFxuICAgICAgICAgICAgbGF0ZXIgLT4gYWN0aW9uICdsYXN0QWN0aXZpdHknXG4gICAgICAgICAgICBlbD8uaGlkZT8oKVxuICAgICAgICAgICAgZWwgPSBudWxsXG4gICAgICAgIGVsc2UgaWYgdmlld3N0YXRlLnN0YXRlICE9IHZpZXdzdGF0ZS5TVEFURV9TVEFSVFVQXG4gICAgICAgICAgICBlbCA9IG5vdHIge2h0bWw6Y29ubmluZm8uZWwuaW5uZXJIVE1MLCBzdGF5OjAsIGlkOidjb25uJ31cbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgIyB1cGRhdGUgc3RhcnR1cCB3aXRoIGNvbm5lY3Rpb24gaW5mb3JtYXRpb25cbiAgICAgICAgICAgIHJlZHJhdygpXG5cbnNldExlZnRTaXplID0gKGxlZnQpIC0+XG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmxlZnQnKS5zdHlsZS53aWR0aCA9IGxlZnQgKyAncHgnXG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmxlZnRyZXNpemUnKS5zdHlsZS5sZWZ0ID0gKGxlZnQgLSAyKSArICdweCdcblxuc2V0Q29udk1pbiA9IChjb252bWluKSAtPlxuICAgIGlmIGNvbnZtaW5cbiAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmxlZnQnKS5jbGFzc0xpc3QuYWRkKFwibWluaW1hbFwiKVxuICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcubGVmdHJlc2l6ZScpLmNsYXNzTGlzdC5hZGQoXCJtaW5pbWFsXCIpXG4gICAgZWxzZVxuICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcubGVmdCcpLmNsYXNzTGlzdC5yZW1vdmUoXCJtaW5pbWFsXCIpXG4gICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5sZWZ0cmVzaXplJykuY2xhc3NMaXN0LnJlbW92ZShcIm1pbmltYWxcIilcblxuaGFuZGxlICd1cGRhdGU6dmlld3N0YXRlJywgLT5cbiAgICBzZXRMZWZ0U2l6ZSB2aWV3c3RhdGUubGVmdFNpemVcbiAgICBzZXRDb252TWluIHZpZXdzdGF0ZS5zaG93Q29udk1pblxuICAgIGlmIHZpZXdzdGF0ZS5zdGF0ZSA9PSB2aWV3c3RhdGUuU1RBVEVfU1RBUlRVUFxuICAgICAgICBpZiBBcnJheS5pc0FycmF5IHZpZXdzdGF0ZS5zaXplXG4gICAgICAgICAgICBsYXRlciAtPiByZW1vdGUuZ2V0Q3VycmVudFdpbmRvdygpLnNldFNpemUgdmlld3N0YXRlLnNpemUuLi5cbiAgICAgICAgI1xuICAgICAgICAjXG4gICAgICAgICMgSXQgd2lsbCBub3QgYWxsb3cgdGhlIHdpbmRvdyB0byBiZSBwbGFjZWQgb2Zmc2NyZWVuIChmdWxseSBvciBwYXJ0aWFsKVxuICAgICAgICAjXG4gICAgICAgICMgRm9yIHRoYXQgaXQgbmVlZHMgdG8gaXRlcmF0ZSBvbiBhbGwgc2NyZWVucyBhbmQgc2VlIGlmIHBvc2l0aW9uIGlzIHZhbGlkLlxuICAgICAgICAjICBJZiBpdCBpcyBub3QgdmFsaWQsIHRoZW4gaXQgd2lsbCBhcHByb3hpbWF0ZSB0aGUgYmVzdCBwb3NpdGlvbiBwb3NzaWJsZVxuICAgICAgICBpZiBBcnJheS5pc0FycmF5IHZpZXdzdGF0ZS5wb3NcbiAgICAgICAgICAgICMgdXNlcyBtYXggWCBhbmQgWSBhcyBhIGZhbGxiYWNrIG1ldGhvZCBpbiBjYXNlIGl0IGNhbid0IGJlIHBsYWNlZCBvbiBhbnlcbiAgICAgICAgICAgICMgIGN1cnJlbnQgZGlzcGxheSwgYnkgYXBwcm94aW1hdGluZyBhIG5ldyBwb3NpdGlvblxuICAgICAgICAgICAgbWF4WCA9IG1heFkgPSBtYXhXID0gbWF4SCA9IDBcbiAgICAgICAgICAgIHJlcG9zaXRpb24gPSBmYWxzZVxuICAgICAgICAgICAgIyBoZWxwZXIgdmFyaWFibGUgdG8gZGV0ZXJtaW5lIHZhbGlkIGNvb3JkaW5hdGVzIHRvIGJlIHVzZWQsIGluaXRpYWxpemVkIHdpdGhcbiAgICAgICAgICAgICMgIGRlc2lyZWQgY29vcmRpbmF0ZXNcbiAgICAgICAgICAgIHhXaW5kb3dQb3MgPSB2aWV3c3RhdGUucG9zWzBdXG4gICAgICAgICAgICB5V2luZG93UG9zID0gdmlld3N0YXRlLnBvc1sxXVxuICAgICAgICAgICAgIyB3aW5kb3cgc2l6ZSB0byBiZSB1c2VkIGluIHJvdW5kaW5nIHRoZSBwb3NpdGlvbiwgaS5lLiBhdm9pZGluZyBwYXJ0aWFsIG9mZnNjcmVlblxuICAgICAgICAgICAgd2luU2l6ZSA9IHJlbW90ZS5nZXRDdXJyZW50V2luZG93KCkuZ2V0U2l6ZSgpXG4gICAgICAgICAgICAjIGl0ZXJhdGUgb24gYWxsIGRpc3BsYXlzIHRvIHNlZSBpZiB0aGUgZGVzaXJlZCBwb3NpdGlvbiBpcyB2YWxpZFxuICAgICAgICAgICAgZm9yIHNjcmVlbiBpbiByZW1vdGUuc2NyZWVuLmdldEFsbERpc3BsYXlzKClcbiAgICAgICAgICAgICAgICAjIGdldCBib3VuZHMgb2YgZWFjaCBkaXNwbGF5XG4gICAgICAgICAgICAgICAge3dpZHRoLCBoZWlnaHR9ID0gc2NyZWVuLndvcmtBcmVhU2l6ZVxuICAgICAgICAgICAgICAgIHt4LCB5fSA9IHNjcmVlbi53b3JrQXJlYVxuXG4gICAgICAgICAgICAgICAgIyBzZWUgaWYgdGhpcyBpbXByb3ZlcyBvbiBtYXhZIGFuZCBtYXhYXG4gICAgICAgICAgICAgICAgaWYgeCArIHdpZHRoID4gbWF4V1xuICAgICAgICAgICAgICAgICAgICBtYXhYID0geFxuICAgICAgICAgICAgICAgICAgICBtYXhXID0geCArIHdpZHRoXG4gICAgICAgICAgICAgICAgaWYgeSArIGhlaWdodCA+IG1heEhcbiAgICAgICAgICAgICAgICAgICAgbWF4WSA9IHlcbiAgICAgICAgICAgICAgICAgICAgbWF4SCA9IHkgKyBoZWlnaHRcblxuXG4gICAgICAgICAgICAgICAgIyBjaGVjayBpZiB3aW5kb3cgd2lsbCBiZSBwbGFjZWQgaW4gdGhpcyBkaXNwbGF5XG4gICAgICAgICAgICAgICAgaWYgeFdpbmRvd1BvcyA+PSB4IGFuZCB4V2luZG93UG9zIDwgeCArIHdpZHRoIGFuZCB5V2luZG93UG9zID49IHkgYW5kIHlXaW5kb3dQb3MgPCB5ICsgaGVpZ2h0XG4gICAgICAgICAgICAgICAgICAgICMgaWYgd2luZG93IHdpbGwgYmUgcGFydGlhbGx5IHBsYWNlZCBvdXRzaWRlIG9mIHRoaXMgZGlzcGxheSwgdGhlbiBpdCB3aWxsXG4gICAgICAgICAgICAgICAgICAgICMgIG1vdmUgaXQgYWxsIGluc2lkZSB0aGUgZGlzcGxheVxuXG4gICAgICAgICAgICAgICAgICAgICMgZm9yIFhcbiAgICAgICAgICAgICAgICAgICAgaWYgd2luU2l6ZVswXSA+IHdpZHRoXG4gICAgICAgICAgICAgICAgICAgICAgICB4V2luZG93UG9zID0geFxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIHhXaW5kb3dQb3MgPiB4ICsgd2lkdGggLSB3aW5TaXplWzBdIC8gMlxuICAgICAgICAgICAgICAgICAgICAgICAgeFdpbmRvd1BvcyA9IHggKyB3aWR0aCAtIHdpblNpemVbMF0gLyAyXG5cbiAgICAgICAgICAgICAgICAgICAgIyBmb3IgWVxuICAgICAgICAgICAgICAgICAgICBpZiB3aW5TaXplWzFdID4gaGVpZ2h0XG4gICAgICAgICAgICAgICAgICAgICAgICB5V2luZG93UG9zID0geVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIHlXaW5kb3dQb3MgPiB5ICsgd2lkdGggLSB3aW5TaXplWzFdIC8gMlxuICAgICAgICAgICAgICAgICAgICAgICAgeVdpbmRvd1BvcyA9IHkgKyB3aWR0aCAtIHdpblNpemVbMV0gLyAyXG4gICAgICAgICAgICAgICAgICAgICMgbWFraW5nIHN1cmUgbm8gbmVnYXRpdmUgcG9zaXRpb25zIG9uIGRpc3BsYXlzXG4gICAgICAgICAgICAgICAgICAgIHhXaW5kb3dQb3MgPSBNYXRoLm1heCh4V2luZG93UG9zLCB4KVxuICAgICAgICAgICAgICAgICAgICB5V2luZG93UG9zID0gTWF0aC5tYXgoeVdpbmRvd1BvcywgeSlcbiAgICAgICAgICAgICAgICAgICAgI1xuICAgICAgICAgICAgICAgICAgICByZXBvc2l0aW9uID0gdHJ1ZSAjIGNvb3JkaW5hdGVzIGhhdmUgYmVlbiBjYWxjdWxhdGVkXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrICMgYnJlYWsgdGhlIGxvb3BcbiAgICAgICAgICAgIGlmIG5vdCByZXBvc2l0aW9uXG4gICAgICAgICAgICAgICAgeFdpbmRvd1BvcyA9IG1heFcgLSB3aW5TaXplWzBdIGlmIHhXaW5kb3dQb3MgPiBtYXhXXG4gICAgICAgICAgICAgICAgeVdpbmRvd1BvcyA9IG1heFkgaWYgeVdpbmRvd1BvcyA+IG1heEhcbiAgICAgICAgICAgICAgICB4V2luZG93UG9zID0gTWF0aC5tYXgoeFdpbmRvd1BvcywgbWF4WClcbiAgICAgICAgICAgICAgICB5V2luZG93UG9zID0gTWF0aC5tYXgoeVdpbmRvd1BvcywgbWF4WSlcbiAgICAgICAgICAgIGxhdGVyIC0+IHJlbW90ZS5nZXRDdXJyZW50V2luZG93KCkuc2V0UG9zaXRpb24oeFdpbmRvd1BvcywgeVdpbmRvd1BvcylcbiAgICAgICAgIyBvbmx5IHJlbmRlciBzdGFydHVwXG4gICAgICAgIHN0YXJ0dXAobW9kZWxzKVxuXG4gICAgICAgIGFwcGxheW91dC5sZWZ0IG51bGxcbiAgICAgICAgYXBwbGF5b3V0LmNvbnZoZWFkIG51bGxcbiAgICAgICAgYXBwbGF5b3V0Lm1haW4gbnVsbFxuICAgICAgICBhcHBsYXlvdXQubWFpbmluZm8gbnVsbFxuICAgICAgICBhcHBsYXlvdXQuZm9vdCBudWxsXG4gICAgICAgIGFwcGxheW91dC5sYXN0IHN0YXJ0dXBcblxuICAgICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLnpvb20gPSB2aWV3c3RhdGUuem9vbVxuICAgICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLnNldFByb3BlcnR5KCctLXpvb20nLCB2aWV3c3RhdGUuem9vbSlcbiAgICBlbHNlIGlmIHZpZXdzdGF0ZS5zdGF0ZSA9PSB2aWV3c3RhdGUuU1RBVEVfTk9STUFMXG4gICAgICAgIHJlZHJhdygpXG4gICAgICAgIGFwcGxheW91dC5sZm9vdCBjb250cm9sc1xuICAgICAgICBhcHBsYXlvdXQubGlzdGhlYWQgbGlzdGhlYWRcbiAgICAgICAgYXBwbGF5b3V0LmxlZnQgY29udmxpc3RcbiAgICAgICAgYXBwbGF5b3V0LmNvbnZoZWFkIGNvbnZoZWFkXG4gICAgICAgIGFwcGxheW91dC5tYWluIG1lc3NhZ2VzXG4gICAgICAgIGFwcGxheW91dC5tYWluaW5mbyB0eXBpbmdpbmZvXG4gICAgICAgIGFwcGxheW91dC5mb290IGlucHV0XG5cbiAgICAgICAgYXBwbGF5b3V0Lmxhc3QgbnVsbFxuXG4gICAgICAgIG1lbnUgdmlld3N0YXRlXG4gICAgICAgIGRvY2tpY29uIHZpZXdzdGF0ZVxuICAgICAgICB0cmF5aWNvbiBtb2RlbHNcblxuICAgIGVsc2UgaWYgdmlld3N0YXRlLnN0YXRlID09IHZpZXdzdGF0ZS5TVEFURV9BQk9VVFxuICAgICAgICByZWRyYXcoKVxuICAgICAgICBhYm91dCBtb2RlbHNcbiAgICAgICAgYXBwbGF5b3V0LmxlZnQgY29udmxpc3RcbiAgICAgICAgYXBwbGF5b3V0Lm1haW4gYWJvdXRcbiAgICAgICAgYXBwbGF5b3V0LmNvbnZoZWFkIG51bGxcbiAgICAgICAgYXBwbGF5b3V0Lm1haW5pbmZvIG51bGxcbiAgICAgICAgYXBwbGF5b3V0LmZvb3QgbnVsbFxuICAgIGVsc2UgaWYgdmlld3N0YXRlLnN0YXRlID09IHZpZXdzdGF0ZS5TVEFURV9BRERfQ09OVkVSU0FUSU9OXG4gICAgICAgIHJlZHJhdygpXG4gICAgICAgIGFwcGxheW91dC5sZWZ0IGNvbnZsaXN0XG4gICAgICAgIGFwcGxheW91dC5tYWluIGNvbnZhZGRcbiAgICAgICAgYXBwbGF5b3V0Lm1haW5pbmZvIG51bGxcbiAgICAgICAgYXBwbGF5b3V0LmZvb3QgbnVsbFxuICAgIGVsc2VcbiAgICAgICAgY29uc29sZS5sb2cgJ3Vua25vd24gdmlld3N0YXRlLnN0YXRlJywgdmlld3N0YXRlLnN0YXRlXG5cbmhhbmRsZSAndXBkYXRlOmVudGl0eScsIC0+XG4gICAgcmVkcmF3KClcblxuaGFuZGxlICd1cGRhdGU6Y29udicsIC0+XG4gICAgcmVkcmF3KClcblxuaGFuZGxlICd1cGRhdGU6Y29udl9jb3VudCcsIC0+XG4gICAgZG9ja2ljb24gdmlld3N0YXRlXG4gICAgdHJheWljb24gbW9kZWxzXG5cbmhhbmRsZSAndXBkYXRlOnNlYXJjaGVkZW50aXRpZXMnLCAtPlxuICByZWRyYXcoKVxuXG5oYW5kbGUgJ3VwZGF0ZTpzZWxlY3RlZEVudGl0aWVzJywgLT5cbiAgcmVkcmF3KClcblxuaGFuZGxlICd1cGRhdGU6Y29udnNldHRpbmdzJywgLT4gcmVkcmF3KClcblxucmVkcmF3ID0gLT5cbiAgICBub3RpZmljYXRpb25zIG1vZGVsc1xuICAgIGNvbnZoZWFkIG1vZGVsc1xuICAgIGNvbnRyb2xzIG1vZGVsc1xuICAgIGNvbnZsaXN0IG1vZGVsc1xuICAgIGxpc3RoZWFkIG1vZGVsc1xuICAgIG1lc3NhZ2VzIG1vZGVsc1xuICAgIHR5cGluZ2luZm8gbW9kZWxzXG4gICAgaW5wdXQgbW9kZWxzXG4gICAgY29udmFkZCBtb2RlbHNcbiAgICBzdGFydHVwIG1vZGVsc1xuXG5cbmhhbmRsZSAndXBkYXRlOmxhbmd1YWdlJywgLT5cbiAgICBtZW51IHZpZXdzdGF0ZVxuICAgIHJlZHJhdygpXG5cbnRocm90dGxlID0gKGZuLCB0aW1lPTEwKSAtPlxuICAgIHRpbWVvdXQgPSBmYWxzZVxuICAgICMgcmV0dXJuIGEgdGhyb3R0bGVkIHZlcnNpb24gb2YgZm5cbiAgICAjIHdoaWNoIGV4ZWN1dGVzIG9uIHRoZSB0cmFpbGluZyBlbmQgb2YgYHRpbWVgXG4gICAgdGhyb3R0bGVkID0gLT5cbiAgICAgICAgcmV0dXJuIGlmIHRpbWVvdXRcbiAgICAgICAgdGltZW91dCA9IHNldFRpbWVvdXQgLT5cbiAgICAgICAgICAgIGZuKClcbiAgICAgICAgICAgIHRpbWVvdXQgPSBmYWxzZVxuICAgICAgICAsXG4gICAgICAgICAgICB0aW1lXG5cbnJlZHJhdyA9IHRocm90dGxlKHJlZHJhdywgMjApXG5cbmhhbmRsZSAndXBkYXRlOmxhbmd1YWdlJywgLT5cbiAgICBtZW51IHZpZXdzdGF0ZVxuICAgIHJlZHJhdygpXG5cbmhhbmRsZSAndXBkYXRlOnN3aXRjaENvbnYnLCAtPlxuICAgIG1lc3NhZ2VzLnNjcm9sbFRvQm90dG9tKClcblxuaGFuZGxlICd1cGRhdGU6YmVmb3JlSGlzdG9yeScsIC0+XG4gICAgYXBwbGF5b3V0LnJlY29yZE1haW5Qb3MoKVxuaGFuZGxlICd1cGRhdGU6YWZ0ZXJIaXN0b3J5JywgLT5cbiAgICBhcHBsYXlvdXQuYWRqdXN0TWFpblBvcygpXG5cbmhhbmRsZSAndXBkYXRlOmJlZm9yZUltZycsIC0+XG4gICAgYXBwbGF5b3V0LnJlY29yZE1haW5Qb3MoKVxuaGFuZGxlICd1cGRhdGU6YWZ0ZXJJbWcnLCAtPlxuICAgIGlmIHZpZXdzdGF0ZS5hdGJvdHRvbVxuICAgICAgICBtZXNzYWdlcy5zY3JvbGxUb0JvdHRvbSgpXG4gICAgZWxzZVxuICAgICAgICBhcHBsYXlvdXQuYWRqdXN0TWFpblBvcygpXG5cbmhhbmRsZSAndXBkYXRlOnN0YXJ0VHlwaW5nJywgLT5cbiAgICBpZiB2aWV3c3RhdGUuYXRib3R0b21cbiAgICAgICAgbWVzc2FnZXMuc2Nyb2xsVG9Cb3R0b20oKVxuIl19
