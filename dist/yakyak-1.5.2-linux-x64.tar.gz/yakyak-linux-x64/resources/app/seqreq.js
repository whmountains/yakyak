(function() {
  var totallyunique;

  totallyunique = function(...as) {
    return String(Date.now()) + (Math.random() * 1000000);
  };

  // fn is expected to return a promised that finishes
  // when fn is finished.

  // retry is whether we retry failures of fn

  // dedupe is a function that mashes the arguments to fn
  // into a dedupe value.
  module.exports = function(fn, retry, dedupe = totallyunique) {
    var deduped, execNext, execing, queue;
    queue = []; // the queue of args to exec
    deduped = []; // the dedupe(args) for deduping
    execing = false; // flag indicating whether execNext is running
    
    // will perpetually exec next until queue is empty
    execNext = function() {
      var args;
      if (!queue.length) {
        execing = false;
        return;
      }
      execing = true;
      args = queue[0];
      return fn(...args).then(function() {
        // it finished, drop args
        queue.shift();
        return deduped.shift();
      }).fail(function(err) {
        if (!retry) {
          // it failed.
          // no retry? then just drop args
          queue.shift();
          return deduped.shift();
        }
      }).then(function() {
        return execNext();
      });
    };
    return function(...as) {
      var d, i;
      d = dedupe(...as);
      if ((i = deduped.indexOf(d)) >= 0) {
        // replace entry, notice this can replace
        // a currently execing entry
        queue[i] = as;
      } else {
        // push a new entry
        queue.push(as);
        deduped.push(d);
      }
      if (!execing) {
        return execNext();
      }
    };
  };

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VxcmVxLmpzIiwic291cmNlcyI6WyJzZXFyZXEuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0FBQUEsTUFBQTs7RUFBQSxhQUFBLEdBQWdCLFFBQUEsQ0FBQSxHQUFDLEVBQUQsQ0FBQTtXQUFXLE1BQUEsQ0FBTyxJQUFJLENBQUMsR0FBTCxDQUFBLENBQVAsQ0FBQSxHQUFxQixDQUFDLElBQUksQ0FBQyxNQUFMLENBQUEsQ0FBQSxHQUFnQixPQUFqQjtFQUFoQyxFQUFoQjs7Ozs7Ozs7O0VBU0EsTUFBTSxDQUFDLE9BQVAsR0FBaUIsUUFBQSxDQUFDLEVBQUQsRUFBSyxLQUFMLEVBQVksU0FBUyxhQUFyQixDQUFBO0FBRWIsUUFBQSxPQUFBLEVBQUEsUUFBQSxFQUFBLE9BQUEsRUFBQTtJQUFBLEtBQUEsR0FBUSxHQUFSO0lBQ0EsT0FBQSxHQUFVLEdBRFY7SUFFQSxPQUFBLEdBQVUsTUFGVjs7O0lBS0EsUUFBQSxHQUFXLFFBQUEsQ0FBQSxDQUFBO0FBQ1AsVUFBQTtNQUFBLElBQUEsQ0FBTyxLQUFLLENBQUMsTUFBYjtRQUNJLE9BQUEsR0FBVTtBQUNWLGVBRko7O01BR0EsT0FBQSxHQUFVO01BQ1YsSUFBQSxHQUFPLEtBQU0sQ0FBQSxDQUFBO2FBQ2IsRUFBQSxDQUFHLEdBQUEsSUFBSCxDQUFXLENBQUMsSUFBWixDQUFpQixRQUFBLENBQUEsQ0FBQSxFQUFBOztRQUViLEtBQUssQ0FBQyxLQUFOLENBQUE7ZUFBZSxPQUFPLENBQUMsS0FBUixDQUFBO01BRkYsQ0FBakIsQ0FHQSxDQUFDLElBSEQsQ0FHTSxRQUFBLENBQUMsR0FBRCxDQUFBO1FBR0YsSUFBQSxDQUF3QyxLQUF4Qzs7O1VBQUMsS0FBSyxDQUFDLEtBQU4sQ0FBQTtpQkFBZSxPQUFPLENBQUMsS0FBUixDQUFBLEVBQWhCOztNQUhFLENBSE4sQ0FPQSxDQUFDLElBUEQsQ0FPTSxRQUFBLENBQUEsQ0FBQTtlQUNGLFFBQUEsQ0FBQTtNQURFLENBUE47SUFOTztXQWdCWCxRQUFBLENBQUEsR0FBQyxFQUFELENBQUE7QUFDSSxVQUFBLENBQUEsRUFBQTtNQUFBLENBQUEsR0FBSSxNQUFBLENBQU8sR0FBQSxFQUFQO01BQ0osSUFBRyxDQUFDLENBQUEsR0FBSSxPQUFPLENBQUMsT0FBUixDQUFnQixDQUFoQixDQUFMLENBQUEsSUFBNEIsQ0FBL0I7OztRQUdJLEtBQU0sQ0FBQSxDQUFBLENBQU4sR0FBVyxHQUhmO09BQUEsTUFBQTs7UUFNSSxLQUFLLENBQUMsSUFBTixDQUFXLEVBQVg7UUFDQSxPQUFPLENBQUMsSUFBUixDQUFhLENBQWIsRUFQSjs7TUFRQSxJQUFBLENBQWtCLE9BQWxCO2VBQUEsUUFBQSxDQUFBLEVBQUE7O0lBVko7RUF2QmE7QUFUakIiLCJzb3VyY2VzQ29udGVudCI6WyJcbnRvdGFsbHl1bmlxdWUgPSAoYXMuLi4pIC0+IFN0cmluZyhEYXRlLm5vdygpKSArIChNYXRoLnJhbmRvbSgpICogMTAwMDAwMClcblxuIyBmbiBpcyBleHBlY3RlZCB0byByZXR1cm4gYSBwcm9taXNlZCB0aGF0IGZpbmlzaGVzXG4jIHdoZW4gZm4gaXMgZmluaXNoZWQuXG4jXG4jIHJldHJ5IGlzIHdoZXRoZXIgd2UgcmV0cnkgZmFpbHVyZXMgb2YgZm5cbiNcbiMgZGVkdXBlIGlzIGEgZnVuY3Rpb24gdGhhdCBtYXNoZXMgdGhlIGFyZ3VtZW50cyB0byBmblxuIyBpbnRvIGEgZGVkdXBlIHZhbHVlLlxubW9kdWxlLmV4cG9ydHMgPSAoZm4sIHJldHJ5LCBkZWR1cGUgPSB0b3RhbGx5dW5pcXVlKSAtPlxuXG4gICAgcXVldWUgPSBbXSAgICAgICMgdGhlIHF1ZXVlIG9mIGFyZ3MgdG8gZXhlY1xuICAgIGRlZHVwZWQgPSBbXSAgICAjIHRoZSBkZWR1cGUoYXJncykgZm9yIGRlZHVwaW5nXG4gICAgZXhlY2luZyA9IGZhbHNlICMgZmxhZyBpbmRpY2F0aW5nIHdoZXRoZXIgZXhlY05leHQgaXMgcnVubmluZ1xuXG4gICAgIyB3aWxsIHBlcnBldHVhbGx5IGV4ZWMgbmV4dCB1bnRpbCBxdWV1ZSBpcyBlbXB0eVxuICAgIGV4ZWNOZXh0ID0gLT5cbiAgICAgICAgdW5sZXNzIHF1ZXVlLmxlbmd0aFxuICAgICAgICAgICAgZXhlY2luZyA9IGZhbHNlXG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgZXhlY2luZyA9IHRydWVcbiAgICAgICAgYXJncyA9IHF1ZXVlWzBdICMgbmV4dCBhcmdzIHRvIHRyeVxuICAgICAgICBmbihhcmdzLi4uKS50aGVuIC0+XG4gICAgICAgICAgICAjIGl0IGZpbmlzaGVkLCBkcm9wIGFyZ3NcbiAgICAgICAgICAgIHF1ZXVlLnNoaWZ0KCk7IGRlZHVwZWQuc2hpZnQoKVxuICAgICAgICAuZmFpbCAoZXJyKSAtPlxuICAgICAgICAgICAgIyBpdCBmYWlsZWQuXG4gICAgICAgICAgICAjIG5vIHJldHJ5PyB0aGVuIGp1c3QgZHJvcCBhcmdzXG4gICAgICAgICAgICAocXVldWUuc2hpZnQoKTsgZGVkdXBlZC5zaGlmdCgpKSB1bmxlc3MgcmV0cnlcbiAgICAgICAgLnRoZW4gLT5cbiAgICAgICAgICAgIGV4ZWNOZXh0KClcblxuICAgIChhcy4uLikgLT5cbiAgICAgICAgZCA9IGRlZHVwZSBhcy4uLlxuICAgICAgICBpZiAoaSA9IGRlZHVwZWQuaW5kZXhPZihkKSkgPj0gMFxuICAgICAgICAgICAgIyByZXBsYWNlIGVudHJ5LCBub3RpY2UgdGhpcyBjYW4gcmVwbGFjZVxuICAgICAgICAgICAgIyBhIGN1cnJlbnRseSBleGVjaW5nIGVudHJ5XG4gICAgICAgICAgICBxdWV1ZVtpXSA9IGFzXG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgICMgcHVzaCBhIG5ldyBlbnRyeVxuICAgICAgICAgICAgcXVldWUucHVzaCBhc1xuICAgICAgICAgICAgZGVkdXBlZC5wdXNoIGRcbiAgICAgICAgZXhlY05leHQoKSB1bmxlc3MgZXhlY2luZ1xuIl19
