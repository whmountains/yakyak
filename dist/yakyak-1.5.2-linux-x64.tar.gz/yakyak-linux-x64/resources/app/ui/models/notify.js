(function() {
  var tonotify;

  tonotify = [];

  module.exports = {
    addToNotify: function(ev) {
      return tonotify.push(ev);
    },
    popToNotify: function() {
      var t;
      if (!tonotify.length) {
        return [];
      }
      t = tonotify;
      tonotify = [];
      return t;
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvbW9kZWxzL25vdGlmeS5qcyIsInNvdXJjZXMiOlsidWkvbW9kZWxzL25vdGlmeS5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7QUFBQSxNQUFBOztFQUFBLFFBQUEsR0FBVzs7RUFFWCxNQUFNLENBQUMsT0FBUCxHQUNJO0lBQUEsV0FBQSxFQUFhLFFBQUEsQ0FBQyxFQUFELENBQUE7YUFBUSxRQUFRLENBQUMsSUFBVCxDQUFjLEVBQWQ7SUFBUixDQUFiO0lBQ0EsV0FBQSxFQUFhLFFBQUEsQ0FBQSxDQUFBO0FBQ1QsVUFBQTtNQUFBLElBQUEsQ0FBaUIsUUFBUSxDQUFDLE1BQTFCO0FBQUEsZUFBTyxHQUFQOztNQUNBLENBQUEsR0FBSTtNQUNKLFFBQUEsR0FBVztBQUNYLGFBQU87SUFKRTtFQURiO0FBSEoiLCJzb3VyY2VzQ29udGVudCI6WyJcbnRvbm90aWZ5ID0gW11cblxubW9kdWxlLmV4cG9ydHMgPVxuICAgIGFkZFRvTm90aWZ5OiAoZXYpIC0+IHRvbm90aWZ5LnB1c2ggZXZcbiAgICBwb3BUb05vdGlmeTogLT5cbiAgICAgICAgcmV0dXJuIFtdIHVubGVzcyB0b25vdGlmeS5sZW5ndGhcbiAgICAgICAgdCA9IHRvbm90aWZ5XG4gICAgICAgIHRvbm90aWZ5ID0gW11cbiAgICAgICAgcmV0dXJuIHRcbiJdfQ==
