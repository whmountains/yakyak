(function() {
  var entity, exp;

  entity = require('./entity');

  module.exports = exp = {
    // This handles the data of conversation add / edit
    // where you can specify participants conversation name, etc
    searchedEntities: [],
    selectedEntities: [],
    initialName: null,
    initialSearchQuery: null,
    name: "",
    searchQuery: "",
    id: null,
    group: false,
    setSearchedEntities: function(entities) {
      this.searchedEntities = entities || [];
      return updated('searchedentities');
    },
    addSelectedEntity: function(entity) {
      var e, exists, id, ref;
      id = ((ref = entity.id) != null ? ref.chat_id : void 0) || entity; // may pass id directly
      exists = ((function() {
        var i, len, ref1, results;
        ref1 = this.selectedEntities;
        results = [];
        for (i = 0, len = ref1.length; i < len; i++) {
          e = ref1[i];
          if (e.id.chat_id === id) {
            results.push(e);
          }
        }
        return results;
      }).call(this)).length !== 0;
      if (!exists) {
        this.selectedEntities.push(entity);
        this.group = this.selectedEntities.length > 1;
        return updated('convsettings');
      }
    },
    removeSelectedEntity: function(entity) {
      var e, id, ref;
      id = ((ref = entity.id) != null ? ref.chat_id : void 0) || entity; // may pass id directly
      // if the conversation we are editing is one to one we don't want
      // to remove the selected entity
      this.selectedEntities = (function() {
        var i, len, ref1, results;
        ref1 = this.selectedEntities;
        results = [];
        for (i = 0, len = ref1.length; i < len; i++) {
          e = ref1[i];
          if (e.id.chat_id !== id) {
            results.push(e);
          }
        }
        return results;
      }).call(this);
      this.group = this.selectedEntities.length > 1;
      return updated('selectedEntities');
    },
    setSelectedEntities: function(entities) {
      this.group = entities.length > 1;
      return this.selectedEntities = entities || [];
    },
    setGroup: function(val) {
      this.group = val;
      return updated('convsettings');
    },
    setInitialName: function(name) {
      return this.initialName = name;
    },
    getInitialName: function() {
      var v;
      v = this.initialName;
      this.initialName = null;
      return v;
    },
    setInitialSearchQuery: function(query) {
      return this.initialSearchQuery = query;
    },
    getInitialSearchQuery: function() {
      var v;
      v = this.initialSearchQuery;
      this.initialSearchQuery = null;
      return v;
    },
    setName: function(name) {
      return this.name = name;
    },
    setSearchQuery: function(query) {
      return this.searchQuery = query;
    },
    loadConversation: function(c) {
      var ref, ref1;
      c.participant_data.forEach((p) => {
        var id;
        id = p.id.chat_id || p.id.gaia_id;
        if (entity.isSelf(id)) {
          return;
        }
        p = entity[id];
        return this.selectedEntities.push({
          id: {
            chat_id: id
          },
          properties: {
            photo_url: p.photo_url,
            display_name: p.display_name || p.fallback_name
          }
        });
      });
      this.group = this.selectedEntities.length > 1;
      this.id = ((ref = c.conversation_id) != null ? ref.id : void 0) || ((ref1 = c.id) != null ? ref1.id : void 0);
      this.initialName = this.name = c.name || "";
      this.initialSearchQuery = "";
      return updated('convsettings');
    },
    reset: function() {
      this.searchedEntities = [];
      this.selectedEntities = [];
      this.initialName = "";
      this.initialSearchQuery = "";
      this.searchQuery = "";
      this.name = "";
      this.id = null;
      this.group = false;
      return updated('convsettings');
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvbW9kZWxzL2NvbnZzZXR0aW5ncy5qcyIsInNvdXJjZXMiOlsidWkvbW9kZWxzL2NvbnZzZXR0aW5ncy5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLE1BQUEsRUFBQTs7RUFBQSxNQUFBLEdBQVMsT0FBQSxDQUFRLFVBQVI7O0VBRVQsTUFBTSxDQUFDLE9BQVAsR0FBaUIsR0FBQSxHQUFNLENBQUE7OztJQUduQixnQkFBQSxFQUFrQixFQUhDO0lBSW5CLGdCQUFBLEVBQWtCLEVBSkM7SUFLbkIsV0FBQSxFQUFhLElBTE07SUFNbkIsa0JBQUEsRUFBb0IsSUFORDtJQU9uQixJQUFBLEVBQU0sRUFQYTtJQVFuQixXQUFBLEVBQWEsRUFSTTtJQVNuQixFQUFBLEVBQUksSUFUZTtJQVVuQixLQUFBLEVBQU8sS0FWWTtJQVluQixtQkFBQSxFQUFxQixRQUFBLENBQUMsUUFBRCxDQUFBO01BQ2pCLElBQUMsQ0FBQSxnQkFBRCxHQUFvQixRQUFBLElBQVk7YUFDaEMsT0FBQSxDQUFRLGtCQUFSO0lBRmlCLENBWkY7SUFnQm5CLGlCQUFBLEVBQW1CLFFBQUEsQ0FBQyxNQUFELENBQUE7QUFDZixVQUFBLENBQUEsRUFBQSxNQUFBLEVBQUEsRUFBQSxFQUFBO01BQUEsRUFBQSxtQ0FBYyxDQUFFLGlCQUFYLElBQXNCLE9BQTNCO01BQ0EsTUFBQSxHQUFTOztBQUFHO0FBQUE7UUFBQSxLQUFBLHNDQUFBOztjQUFnQyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQUwsS0FBZ0I7eUJBQWxEOztRQUFFLENBQUE7O21CQUFILENBQXNELENBQUMsTUFBdkQsS0FBaUU7TUFDMUUsSUFBRyxDQUFJLE1BQVA7UUFDSSxJQUFDLENBQUEsZ0JBQWdCLENBQUMsSUFBbEIsQ0FBdUIsTUFBdkI7UUFDQSxJQUFDLENBQUEsS0FBRCxHQUFTLElBQUMsQ0FBQSxnQkFBZ0IsQ0FBQyxNQUFsQixHQUEyQjtlQUNwQyxPQUFBLENBQVEsY0FBUixFQUhKOztJQUhlLENBaEJBO0lBd0JuQixvQkFBQSxFQUFzQixRQUFBLENBQUMsTUFBRCxDQUFBO0FBQ2xCLFVBQUEsQ0FBQSxFQUFBLEVBQUEsRUFBQTtNQUFBLEVBQUEsbUNBQWMsQ0FBRSxpQkFBWCxJQUFzQixPQUEzQjs7O01BR0EsSUFBQyxDQUFBLGdCQUFEOztBQUF1QjtBQUFBO1FBQUEsS0FBQSxzQ0FBQTs7Y0FBZ0MsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFMLEtBQWdCO3lCQUFsRDs7UUFBRSxDQUFBOzs7TUFDdkIsSUFBQyxDQUFBLEtBQUQsR0FBUyxJQUFDLENBQUEsZ0JBQWdCLENBQUMsTUFBbEIsR0FBMkI7YUFDcEMsT0FBQSxDQUFRLGtCQUFSO0lBTmtCLENBeEJIO0lBZ0NuQixtQkFBQSxFQUFxQixRQUFBLENBQUMsUUFBRCxDQUFBO01BQ2pCLElBQUMsQ0FBQSxLQUFELEdBQVMsUUFBUSxDQUFDLE1BQVQsR0FBa0I7YUFDM0IsSUFBQyxDQUFBLGdCQUFELEdBQW9CLFFBQUEsSUFBWTtJQUZmLENBaENGO0lBb0NuQixRQUFBLEVBQVUsUUFBQSxDQUFDLEdBQUQsQ0FBQTtNQUFTLElBQUMsQ0FBQSxLQUFELEdBQVM7YUFBSyxPQUFBLENBQVEsY0FBUjtJQUF2QixDQXBDUztJQXNDbkIsY0FBQSxFQUFnQixRQUFBLENBQUMsSUFBRCxDQUFBO2FBQVUsSUFBQyxDQUFBLFdBQUQsR0FBZTtJQUF6QixDQXRDRztJQXVDbkIsY0FBQSxFQUFnQixRQUFBLENBQUEsQ0FBQTtBQUFHLFVBQUE7TUFBQSxDQUFBLEdBQUksSUFBQyxDQUFBO01BQWEsSUFBQyxDQUFBLFdBQUQsR0FBZTthQUFNO0lBQTFDLENBdkNHO0lBeUNuQixxQkFBQSxFQUF1QixRQUFBLENBQUMsS0FBRCxDQUFBO2FBQVcsSUFBQyxDQUFBLGtCQUFELEdBQXNCO0lBQWpDLENBekNKO0lBMENuQixxQkFBQSxFQUF1QixRQUFBLENBQUEsQ0FBQTtBQUFHLFVBQUE7TUFBQSxDQUFBLEdBQUksSUFBQyxDQUFBO01BQW9CLElBQUMsQ0FBQSxrQkFBRCxHQUFzQjthQUFNO0lBQXhELENBMUNKO0lBNENuQixPQUFBLEVBQVMsUUFBQSxDQUFDLElBQUQsQ0FBQTthQUFVLElBQUMsQ0FBQSxJQUFELEdBQVE7SUFBbEIsQ0E1Q1U7SUE4Q25CLGNBQUEsRUFBZ0IsUUFBQSxDQUFDLEtBQUQsQ0FBQTthQUFXLElBQUMsQ0FBQSxXQUFELEdBQWU7SUFBMUIsQ0E5Q0c7SUFnRG5CLGdCQUFBLEVBQWtCLFFBQUEsQ0FBQyxDQUFELENBQUE7QUFDZCxVQUFBLEdBQUEsRUFBQTtNQUFBLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFuQixDQUEyQixDQUFDLENBQUQsQ0FBQSxHQUFBO0FBQ3ZCLFlBQUE7UUFBQSxFQUFBLEdBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFMLElBQWdCLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDMUIsSUFBRyxNQUFNLENBQUMsTUFBUCxDQUFjLEVBQWQsQ0FBSDtBQUF5QixpQkFBekI7O1FBQ0EsQ0FBQSxHQUFJLE1BQU8sQ0FBQSxFQUFBO2VBQ1gsSUFBQyxDQUFBLGdCQUFnQixDQUFDLElBQWxCLENBQ0k7VUFBQSxFQUFBLEVBQUk7WUFBQSxPQUFBLEVBQVM7VUFBVCxDQUFKO1VBQ0EsVUFBQSxFQUNJO1lBQUEsU0FBQSxFQUFXLENBQUMsQ0FBQyxTQUFiO1lBQ0EsWUFBQSxFQUFjLENBQUMsQ0FBQyxZQUFGLElBQWtCLENBQUMsQ0FBQztVQURsQztRQUZKLENBREo7TUFKdUIsQ0FBM0I7TUFTQSxJQUFDLENBQUEsS0FBRCxHQUFTLElBQUMsQ0FBQSxnQkFBZ0IsQ0FBQyxNQUFsQixHQUEyQjtNQUNwQyxJQUFDLENBQUEsRUFBRCwyQ0FBdUIsQ0FBRSxZQUFuQixpQ0FBNkIsQ0FBRTtNQUNyQyxJQUFDLENBQUEsV0FBRCxHQUFlLElBQUMsQ0FBQSxJQUFELEdBQVEsQ0FBQyxDQUFDLElBQUYsSUFBVTtNQUNqQyxJQUFDLENBQUEsa0JBQUQsR0FBc0I7YUFFdEIsT0FBQSxDQUFRLGNBQVI7SUFmYyxDQWhEQztJQWlFbkIsS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO01BQ0gsSUFBQyxDQUFBLGdCQUFELEdBQW9CO01BQ3BCLElBQUMsQ0FBQSxnQkFBRCxHQUFvQjtNQUNwQixJQUFDLENBQUEsV0FBRCxHQUFlO01BQ2YsSUFBQyxDQUFBLGtCQUFELEdBQXNCO01BQ3RCLElBQUMsQ0FBQSxXQUFELEdBQWU7TUFDZixJQUFDLENBQUEsSUFBRCxHQUFRO01BQ1IsSUFBQyxDQUFBLEVBQUQsR0FBTTtNQUNOLElBQUMsQ0FBQSxLQUFELEdBQVM7YUFDVCxPQUFBLENBQVEsY0FBUjtJQVRHO0VBakVZO0FBRnZCIiwic291cmNlc0NvbnRlbnQiOlsiZW50aXR5ID0gcmVxdWlyZSAnLi9lbnRpdHknXG5cbm1vZHVsZS5leHBvcnRzID0gZXhwID0ge1xuICAgICMgVGhpcyBoYW5kbGVzIHRoZSBkYXRhIG9mIGNvbnZlcnNhdGlvbiBhZGQgLyBlZGl0XG4gICAgIyB3aGVyZSB5b3UgY2FuIHNwZWNpZnkgcGFydGljaXBhbnRzIGNvbnZlcnNhdGlvbiBuYW1lLCBldGNcbiAgICBzZWFyY2hlZEVudGl0aWVzOiBbXVxuICAgIHNlbGVjdGVkRW50aXRpZXM6IFtdXG4gICAgaW5pdGlhbE5hbWU6IG51bGxcbiAgICBpbml0aWFsU2VhcmNoUXVlcnk6IG51bGxcbiAgICBuYW1lOiBcIlwiXG4gICAgc2VhcmNoUXVlcnk6IFwiXCJcbiAgICBpZDogbnVsbFxuICAgIGdyb3VwOiBmYWxzZVxuXG4gICAgc2V0U2VhcmNoZWRFbnRpdGllczogKGVudGl0aWVzKSAtPlxuICAgICAgICBAc2VhcmNoZWRFbnRpdGllcyA9IGVudGl0aWVzIG9yIFtdXG4gICAgICAgIHVwZGF0ZWQgJ3NlYXJjaGVkZW50aXRpZXMnXG5cbiAgICBhZGRTZWxlY3RlZEVudGl0eTogKGVudGl0eSkgLT5cbiAgICAgICAgaWQgPSBlbnRpdHkuaWQ/LmNoYXRfaWQgb3IgZW50aXR5ICPCoG1heSBwYXNzIGlkIGRpcmVjdGx5XG4gICAgICAgIGV4aXN0cyA9IChlIGZvciBlIGluIEBzZWxlY3RlZEVudGl0aWVzIHdoZW4gZS5pZC5jaGF0X2lkID09IGlkKS5sZW5ndGggIT0gMFxuICAgICAgICBpZiBub3QgZXhpc3RzXG4gICAgICAgICAgICBAc2VsZWN0ZWRFbnRpdGllcy5wdXNoIGVudGl0eVxuICAgICAgICAgICAgQGdyb3VwID0gQHNlbGVjdGVkRW50aXRpZXMubGVuZ3RoID4gMVxuICAgICAgICAgICAgdXBkYXRlZCAnY29udnNldHRpbmdzJ1xuXG4gICAgcmVtb3ZlU2VsZWN0ZWRFbnRpdHk6IChlbnRpdHkpIC0+XG4gICAgICAgIGlkID0gZW50aXR5LmlkPy5jaGF0X2lkIG9yIGVudGl0eSAjwqBtYXkgcGFzcyBpZCBkaXJlY3RseVxuICAgICAgICAjIGlmIHRoZSBjb252ZXJzYXRpb24gd2UgYXJlIGVkaXRpbmcgaXMgb25lIHRvIG9uZSB3ZSBkb24ndCB3YW50XG4gICAgICAgICMgdG8gcmVtb3ZlIHRoZSBzZWxlY3RlZCBlbnRpdHlcbiAgICAgICAgQHNlbGVjdGVkRW50aXRpZXMgPSAoZSBmb3IgZSBpbiBAc2VsZWN0ZWRFbnRpdGllcyB3aGVuIGUuaWQuY2hhdF9pZCAhPSBpZClcbiAgICAgICAgQGdyb3VwID0gQHNlbGVjdGVkRW50aXRpZXMubGVuZ3RoID4gMVxuICAgICAgICB1cGRhdGVkICdzZWxlY3RlZEVudGl0aWVzJ1xuXG4gICAgc2V0U2VsZWN0ZWRFbnRpdGllczogKGVudGl0aWVzKSAtPlxuICAgICAgICBAZ3JvdXAgPSBlbnRpdGllcy5sZW5ndGggPiAxXG4gICAgICAgIEBzZWxlY3RlZEVudGl0aWVzID0gZW50aXRpZXMgb3IgW10gIyBubyBuZWVkIHRvIHVwZGF0ZVxuICAgIFxuICAgIHNldEdyb3VwOiAodmFsKSAtPiBAZ3JvdXAgPSB2YWw7IHVwZGF0ZWQgJ2NvbnZzZXR0aW5ncydcblxuICAgIHNldEluaXRpYWxOYW1lOiAobmFtZSkgLT4gQGluaXRpYWxOYW1lID0gbmFtZVxuICAgIGdldEluaXRpYWxOYW1lOiAtPiB2ID0gQGluaXRpYWxOYW1lOyBAaW5pdGlhbE5hbWUgPSBudWxsOyB2XG5cbiAgICBzZXRJbml0aWFsU2VhcmNoUXVlcnk6IChxdWVyeSkgLT4gQGluaXRpYWxTZWFyY2hRdWVyeSA9IHF1ZXJ5XG4gICAgZ2V0SW5pdGlhbFNlYXJjaFF1ZXJ5OiAtPiB2ID0gQGluaXRpYWxTZWFyY2hRdWVyeTsgQGluaXRpYWxTZWFyY2hRdWVyeSA9IG51bGw7IHZcblxuICAgIHNldE5hbWU6IChuYW1lKSAtPiBAbmFtZSA9IG5hbWVcblxuICAgIHNldFNlYXJjaFF1ZXJ5OiAocXVlcnkpIC0+IEBzZWFyY2hRdWVyeSA9IHF1ZXJ5XG4gICAgXG4gICAgbG9hZENvbnZlcnNhdGlvbjogKGMpIC0+XG4gICAgICAgIGMucGFydGljaXBhbnRfZGF0YS5mb3JFYWNoIChwKSA9PlxuICAgICAgICAgICAgaWQgPSBwLmlkLmNoYXRfaWQgb3IgcC5pZC5nYWlhX2lkXG4gICAgICAgICAgICBpZiBlbnRpdHkuaXNTZWxmIGlkIHRoZW4gcmV0dXJuXG4gICAgICAgICAgICBwID0gZW50aXR5W2lkXVxuICAgICAgICAgICAgQHNlbGVjdGVkRW50aXRpZXMucHVzaFxuICAgICAgICAgICAgICAgIGlkOiBjaGF0X2lkOiBpZFxuICAgICAgICAgICAgICAgIHByb3BlcnRpZXM6XG4gICAgICAgICAgICAgICAgICAgIHBob3RvX3VybDogcC5waG90b191cmxcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheV9uYW1lOiBwLmRpc3BsYXlfbmFtZSBvciBwLmZhbGxiYWNrX25hbWVcbiAgICAgICAgQGdyb3VwID0gQHNlbGVjdGVkRW50aXRpZXMubGVuZ3RoID4gMVxuICAgICAgICBAaWQgPSBjLmNvbnZlcnNhdGlvbl9pZD8uaWQgb3IgYy5pZD8uaWRcbiAgICAgICAgQGluaXRpYWxOYW1lID0gQG5hbWUgPSBjLm5hbWUgb3IgXCJcIlxuICAgICAgICBAaW5pdGlhbFNlYXJjaFF1ZXJ5ID0gXCJcIlxuICAgICAgICBcbiAgICAgICAgdXBkYXRlZCAnY29udnNldHRpbmdzJ1xuXG4gICAgcmVzZXQ6IC0+XG4gICAgICAgIEBzZWFyY2hlZEVudGl0aWVzID0gW11cbiAgICAgICAgQHNlbGVjdGVkRW50aXRpZXMgPSBbXVxuICAgICAgICBAaW5pdGlhbE5hbWUgPSBcIlwiXG4gICAgICAgIEBpbml0aWFsU2VhcmNoUXVlcnkgPSBcIlwiXG4gICAgICAgIEBzZWFyY2hRdWVyeSA9IFwiXCJcbiAgICAgICAgQG5hbWUgPSBcIlwiXG4gICAgICAgIEBpZCA9IG51bGxcbiAgICAgICAgQGdyb3VwID0gZmFsc2VcbiAgICAgICAgdXBkYXRlZCAnY29udnNldHRpbmdzJ1xuXG5cbn1cblxuIl19
