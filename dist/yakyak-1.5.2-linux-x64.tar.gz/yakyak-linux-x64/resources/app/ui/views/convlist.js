(function() {
  var MESSAGE_CLASSES, drawAvatar, drawMessage, fixlink, format, ifpass, initialsof, moment, nameof, nameofconv;

  moment = require('moment');

  ({nameof, initialsof, nameofconv, fixlink, drawAvatar} = require('../util'));

  module.exports = view(function(models) {
    var clz, conv, entity, viewstate;
    ({conv, entity, viewstate} = models);
    clz = ['convlist'];
    if (viewstate.showConvThumbs) {
      clz.push('showconvthumbs');
    }
    if (viewstate.showAnimatedThumbs) {
      clz.push('showanimatedthumbs');
    }
    return div({
      class: clz.join(' ')
    }, function() {
      var c, convs, others, renderConv, starred;
      if (!viewstate.useSystemDateFormat) {
        moment.locale(i18n.getLocale());
      } else {
        moment.locale(window.navigator.language);
      }
      convs = conv.list();
      renderConv = function(c) {
        var cid, lastChanged, pureHang, ref, ur;
        // remove emoji suggestions on renderConv
        if (document.querySelectorAll('.emoji-sugg-container').length) {
          document.querySelectorAll('.emoji-sugg-container')[0].parentNode.removeChild(document.querySelectorAll('.emoji-sugg-container')[0]);
        }
        pureHang = conv.isPureHangout(c);
        lastChanged = conv.lastChanged(c);
        // don't list pure hangouts that are older than 24h
        if (pureHang && (Date.now() - lastChanged) > 24 * 60 * 60 * 1000) {
          return;
        }
        cid = c != null ? (ref = c.conversation_id) != null ? ref.id : void 0 : void 0;
        ur = conv.unread(c);
        clz = ['conv'];
        clz.push(`type_${c.type}`);
        if (models.viewstate.selectedConv === cid) {
          clz.push("selected");
        }
        if (ur) {
          clz.push("unread");
        }
        if (pureHang) {
          clz.push("purehang");
        }
        return div({
          key: cid,
          class: clz.join(' ')
        }, function() {
          var ents, lbl, name, p, part, ref1;
          part = (ref1 = c != null ? c.current_participant : void 0) != null ? ref1 : [];
          ents = (function() {
            var j, len, results;
            results = [];
            for (j = 0, len = part.length; j < len; j++) {
              p = part[j];
              if (!entity.isSelf(p.chat_id)) {
                results.push(entity[p.chat_id]);
              }
            }
            return results;
          })();
          name = nameofconv(c);
          if (viewstate.showConvThumbs || viewstate.showConvMin) {
            div({
              class: 'thumbs thumbs-' + (ents.length > 4 ? '4' : ents.length)
            }, function() {
              var additional, index, j, lbl, len;
              additional = [];
              for (index = j = 0, len = ents.length; j < len; index = ++j) {
                p = ents[index];
                // if there are up to 4 people in the conversation
                //   then draw them all, otherwise, draw 3 avatars
                //   and then add a +X , where X is the remaining
                //   number of people
                if (index < 3 || ents.length === 4) {
                  entity.needEntity(p.id);
                  drawAvatar(p.id, viewstate, entity);
                } else {
                  additional.push(nameof(entity[p.id]));
                }
              }
              if (ents.length > 4) {
                div({
                  class: 'moreuser'
                }, `+${ents.length - 3}`, {
                  title: additional.join('\n')
                });
              }
              if (ur > 0 && !conv.isQuiet(c)) {
                lbl = ur >= conv.MAX_UNREAD ? `${conv.MAX_UNREAD}+` : ur + '';
                span({
                  class: 'unreadcount'
                }, lbl);
              }
              if (ents.length === 1) {
                return div({
                  class: 'presence ' + ents[0].presence
                });
              }
            });
          } else {
            if (ur > 0 && !conv.isQuiet(c)) {
              lbl = ur >= conv.MAX_UNREAD ? `${conv.MAX_UNREAD}+` : ur + '';
              span({
                class: 'unreadcount'
              }, lbl);
            }
            if (ents.length === 1) {
              div({
                class: 'presence ' + ents[0].presence
              });
            }
          }
          if (!viewstate.showConvMin) {
            div({
              class: 'convinfos'
            }, function() {
              if (viewstate.showConvTime) {
                span({
                  class: 'lasttime'
                }, moment(conv.lastChanged(c)).calendar());
              }
              span({
                class: 'convname'
              }, name);
              if (viewstate.showConvLast) {
                return div({
                  class: 'lastmessage'
                }, function() {
                  var ref2;
                  return drawMessage(c != null ? (ref2 = c.event) != null ? ref2.slice(-1)[0] : void 0 : void 0, entity);
                });
              }
            });
          }
          return div({
            class: 'divider'
          });
        }, {
          onclick: function(ev) {
            ev.preventDefault();
            return action('selectConv', c);
          }
        });
      };
      starred = (function() {
        var j, len, results;
        results = [];
        for (j = 0, len = convs.length; j < len; j++) {
          c = convs[j];
          if (conv.isStarred(c)) {
            results.push(c);
          }
        }
        return results;
      })();
      others = (function() {
        var j, len, results;
        results = [];
        for (j = 0, len = convs.length; j < len; j++) {
          c = convs[j];
          if (!conv.isStarred(c)) {
            results.push(c);
          }
        }
        return results;
      })();
      div({
        class: 'starred'
      }, function() {
        if (starred.length > 0) {
          div({
            class: 'label'
          }, i18n.__n('favorite.title:Favorites', 2));
          return starred.forEach(renderConv);
        }
      });
      return div({
        class: 'others'
      }, function() {
        if (starred.length > 0) {
          div({
            class: 'label'
          }, i18n.__('recent:Recent'));
        }
        return others.forEach(renderConv);
      });
    });
  });

  // possible classes of messages
  MESSAGE_CLASSES = ['placeholder', 'chat_message', 'conversation_rename', 'membership_change'];

  drawMessage = function(e, entity) {
    var c, j, len, mclz, title;
    mclz = ['message'];
    for (j = 0, len = MESSAGE_CLASSES.length; j < len; j++) {
      c = MESSAGE_CLASSES[j];
      if (e[c] != null) {
        mclz.push(c);
      }
    }
    title = e.timestamp ? moment(e.timestamp / 1000).calendar() : null;
    return div({
      id: `list_${e.event_id}`,
      key: `list_${e.event_id}`,
      class: mclz.join(' '),
      title: title
    }, function() {
      var content, ents, names, ref, t;
      if (e.chat_message) {
        content = (ref = e.chat_message) != null ? ref.message_content : void 0;
        return format(content);
      } else if (e.conversation_rename) {
        return pass(`renamed conversation to ${e.conversation_rename.new_name}`);
      // {new_name: "labbot" old_name: ""}
      } else if (e.membership_change) {
        t = e.membership_change.type;
        ents = e.membership_change.participant_ids.map(function(p) {
          return entity[p.chat_id];
        });
        names = ents.map(nameof).join(', ');
        if (t === 'JOIN') {
          return pass(`invited ${names}`);
        } else if (t === 'LEAVE') {
          return pass(`${names} left the conversation`);
        }
      }
    });
  };

  ifpass = function(t, f) {
    if (t) {
      return f;
    } else {
      return pass;
    }
  };

  format = function(cont) {
    var f, i, j, len, ref, ref1, ref2, seg;
    ref1 = (ref = cont != null ? cont.segment : void 0) != null ? ref : [];
    for (i = j = 0, len = ref1.length; j < len; i = ++j) {
      seg = ref1[i];
      if (cont.proxied && i < 1) {
        continue;
      }
      f = (ref2 = seg.formatting) != null ? ref2 : {};
      // these are links to images that we try loading
      // as images and show inline. (not attachments)
      ifpass(f.bold, b)(function() {
        return ifpass(f.italics, i)(function() {
          return ifpass(f.underline, u)(function() {
            return ifpass(f.strikethrough, s)(function() {
              // preload returns whether the image
              // has been loaded. redraw when it
              // loads.
              return pass(cont.proxied ? stripProxiedColon(seg.text) : seg.text);
            });
          });
        });
      });
    }
    return null;
  };

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvdmlld3MvY29udmxpc3QuanMiLCJzb3VyY2VzIjpbInVpL3ZpZXdzL2NvbnZsaXN0LmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUEsZUFBQSxFQUFBLFVBQUEsRUFBQSxXQUFBLEVBQUEsT0FBQSxFQUFBLE1BQUEsRUFBQSxNQUFBLEVBQUEsVUFBQSxFQUFBLE1BQUEsRUFBQSxNQUFBLEVBQUE7O0VBQUEsTUFBQSxHQUFTLE9BQUEsQ0FBUSxRQUFSOztFQUNULENBQUEsQ0FBQyxNQUFELEVBQVMsVUFBVCxFQUFxQixVQUFyQixFQUFpQyxPQUFqQyxFQUEwQyxVQUExQyxDQUFBLEdBQXdELE9BQUEsQ0FBUSxTQUFSLENBQXhEOztFQUVBLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLElBQUEsQ0FBSyxRQUFBLENBQUMsTUFBRCxDQUFBO0FBRWxCLFFBQUEsR0FBQSxFQUFBLElBQUEsRUFBQSxNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUMsSUFBRCxFQUFPLE1BQVAsRUFBZSxTQUFmLENBQUEsR0FBNEIsTUFBNUI7SUFDQSxHQUFBLEdBQU0sQ0FBQyxVQUFEO0lBQ04sSUFBNkIsU0FBUyxDQUFDLGNBQXZDO01BQUEsR0FBRyxDQUFDLElBQUosQ0FBUyxnQkFBVCxFQUFBOztJQUNBLElBQWlDLFNBQVMsQ0FBQyxrQkFBM0M7TUFBQSxHQUFHLENBQUMsSUFBSixDQUFTLG9CQUFULEVBQUE7O1dBQ0EsR0FBQSxDQUFJO01BQUEsS0FBQSxFQUFNLEdBQUcsQ0FBQyxJQUFKLENBQVMsR0FBVDtJQUFOLENBQUosRUFBeUIsUUFBQSxDQUFBLENBQUE7QUFDckIsVUFBQSxDQUFBLEVBQUEsS0FBQSxFQUFBLE1BQUEsRUFBQSxVQUFBLEVBQUE7TUFBQSxJQUFHLENBQUMsU0FBUyxDQUFDLG1CQUFkO1FBQ0ksTUFBTSxDQUFDLE1BQVAsQ0FBYyxJQUFJLENBQUMsU0FBTCxDQUFBLENBQWQsRUFESjtPQUFBLE1BQUE7UUFHSSxNQUFNLENBQUMsTUFBUCxDQUFjLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBL0IsRUFISjs7TUFJQSxLQUFBLEdBQVEsSUFBSSxDQUFDLElBQUwsQ0FBQTtNQUNSLFVBQUEsR0FBYSxRQUFBLENBQUMsQ0FBRCxDQUFBO0FBRVQsWUFBQSxHQUFBLEVBQUEsV0FBQSxFQUFBLFFBQUEsRUFBQSxHQUFBLEVBQUEsRUFBQTs7UUFBQSxJQUFHLFFBQVEsQ0FBQyxnQkFBVCxDQUEwQix1QkFBMUIsQ0FBa0QsQ0FBQyxNQUF0RDtVQUNJLFFBQVEsQ0FBQyxnQkFBVCxDQUEwQix1QkFBMUIsQ0FBbUQsQ0FBQSxDQUFBLENBQUUsQ0FBQyxVQUFVLENBQUMsV0FBakUsQ0FBNkUsUUFBUSxDQUFDLGdCQUFULENBQTBCLHVCQUExQixDQUFtRCxDQUFBLENBQUEsQ0FBaEksRUFESjs7UUFFQSxRQUFBLEdBQVcsSUFBSSxDQUFDLGFBQUwsQ0FBbUIsQ0FBbkI7UUFDWCxXQUFBLEdBQWMsSUFBSSxDQUFDLFdBQUwsQ0FBaUIsQ0FBakIsRUFIZDs7UUFLQSxJQUFVLFFBQUEsSUFBYSxDQUFDLElBQUksQ0FBQyxHQUFMLENBQUEsQ0FBQSxHQUFhLFdBQWQsQ0FBQSxHQUE2QixFQUFBLEdBQUssRUFBTCxHQUFVLEVBQVYsR0FBZSxJQUFuRTtBQUFBLGlCQUFBOztRQUNBLEdBQUEsc0RBQXdCLENBQUU7UUFDMUIsRUFBQSxHQUFLLElBQUksQ0FBQyxNQUFMLENBQVksQ0FBWjtRQUNMLEdBQUEsR0FBTSxDQUFDLE1BQUQ7UUFDTixHQUFHLENBQUMsSUFBSixDQUFTLENBQUEsS0FBQSxDQUFBLENBQVEsQ0FBQyxDQUFDLElBQVYsQ0FBQSxDQUFUO1FBQ0EsSUFBdUIsTUFBTSxDQUFDLFNBQVMsQ0FBQyxZQUFqQixLQUFpQyxHQUF4RDtVQUFBLEdBQUcsQ0FBQyxJQUFKLENBQVMsVUFBVCxFQUFBOztRQUNBLElBQXFCLEVBQXJCO1VBQUEsR0FBRyxDQUFDLElBQUosQ0FBUyxRQUFULEVBQUE7O1FBQ0EsSUFBdUIsUUFBdkI7VUFBQSxHQUFHLENBQUMsSUFBSixDQUFTLFVBQVQsRUFBQTs7ZUFDQSxHQUFBLENBQUk7VUFBQSxHQUFBLEVBQUksR0FBSjtVQUFTLEtBQUEsRUFBTSxHQUFHLENBQUMsSUFBSixDQUFTLEdBQVQ7UUFBZixDQUFKLEVBQWtDLFFBQUEsQ0FBQSxDQUFBO0FBQzlCLGNBQUEsSUFBQSxFQUFBLEdBQUEsRUFBQSxJQUFBLEVBQUEsQ0FBQSxFQUFBLElBQUEsRUFBQTtVQUFBLElBQUEsd0VBQWdDO1VBQ2hDLElBQUE7O0FBQU87WUFBQSxLQUFBLHNDQUFBOztrQkFBbUIsQ0FBSSxNQUFNLENBQUMsTUFBUCxDQUFjLENBQUMsQ0FBQyxPQUFoQjs2QkFDMUIsTUFBTyxDQUFBLENBQUMsQ0FBQyxPQUFGOztZQURKLENBQUE7OztVQUVQLElBQUEsR0FBTyxVQUFBLENBQVcsQ0FBWDtVQUNQLElBQUcsU0FBUyxDQUFDLGNBQVYsSUFBNEIsU0FBUyxDQUFDLFdBQXpDO1lBQ0ksR0FBQSxDQUFJO2NBQUEsS0FBQSxFQUFPLGdCQUFBLEdBQWlCLENBQUksSUFBSSxDQUFDLE1BQUwsR0FBWSxDQUFmLEdBQXNCLEdBQXRCLEdBQStCLElBQUksQ0FBQyxNQUFyQztZQUF4QixDQUFKLEVBQTBFLFFBQUEsQ0FBQSxDQUFBO0FBQ3RFLGtCQUFBLFVBQUEsRUFBQSxLQUFBLEVBQUEsQ0FBQSxFQUFBLEdBQUEsRUFBQTtjQUFBLFVBQUEsR0FBYTtjQUNiLEtBQUEsc0RBQUE7Z0NBQUE7Ozs7O2dCQUtJLElBQUcsS0FBQSxHQUFRLENBQVIsSUFBYyxJQUFJLENBQUMsTUFBTCxLQUFlLENBQWhDO2tCQUNJLE1BQU0sQ0FBQyxVQUFQLENBQWtCLENBQUMsQ0FBQyxFQUFwQjtrQkFDQSxVQUFBLENBQVcsQ0FBQyxDQUFDLEVBQWIsRUFBaUIsU0FBakIsRUFBNEIsTUFBNUIsRUFGSjtpQkFBQSxNQUFBO2tCQUlJLFVBQVUsQ0FBQyxJQUFYLENBQWdCLE1BQUEsQ0FBTyxNQUFPLENBQUEsQ0FBQyxDQUFDLEVBQUYsQ0FBZCxDQUFoQixFQUpKOztjQUxKO2NBVUEsSUFBRyxJQUFJLENBQUMsTUFBTCxHQUFjLENBQWpCO2dCQUNJLEdBQUEsQ0FBSTtrQkFBQSxLQUFBLEVBQU07Z0JBQU4sQ0FBSixFQUFzQixDQUFBLENBQUEsQ0FBQSxDQUFJLElBQUksQ0FBQyxNQUFMLEdBQWMsQ0FBbEIsQ0FBQSxDQUF0QixFQUNFO2tCQUFBLEtBQUEsRUFBTyxVQUFVLENBQUMsSUFBWCxDQUFnQixJQUFoQjtnQkFBUCxDQURGLEVBREo7O2NBR0EsSUFBRyxFQUFBLEdBQUssQ0FBTCxJQUFXLENBQUksSUFBSSxDQUFDLE9BQUwsQ0FBYSxDQUFiLENBQWxCO2dCQUNJLEdBQUEsR0FBUyxFQUFBLElBQU0sSUFBSSxDQUFDLFVBQWQsR0FBOEIsQ0FBQSxDQUFBLENBQUcsSUFBSSxDQUFDLFVBQVIsQ0FBbUIsQ0FBbkIsQ0FBOUIsR0FBeUQsRUFBQSxHQUFLO2dCQUNwRSxJQUFBLENBQUs7a0JBQUEsS0FBQSxFQUFNO2dCQUFOLENBQUwsRUFBMEIsR0FBMUIsRUFGSjs7Y0FHQSxJQUFHLElBQUksQ0FBQyxNQUFMLEtBQWUsQ0FBbEI7dUJBQ0ksR0FBQSxDQUFJO2tCQUFBLEtBQUEsRUFBTSxXQUFBLEdBQVksSUFBSyxDQUFBLENBQUEsQ0FBRSxDQUFDO2dCQUExQixDQUFKLEVBREo7O1lBbEJzRSxDQUExRSxFQURKO1dBQUEsTUFBQTtZQXNCSSxJQUFHLEVBQUEsR0FBSyxDQUFMLElBQVcsQ0FBSSxJQUFJLENBQUMsT0FBTCxDQUFhLENBQWIsQ0FBbEI7Y0FDSSxHQUFBLEdBQVMsRUFBQSxJQUFNLElBQUksQ0FBQyxVQUFkLEdBQThCLENBQUEsQ0FBQSxDQUFHLElBQUksQ0FBQyxVQUFSLENBQW1CLENBQW5CLENBQTlCLEdBQXlELEVBQUEsR0FBSztjQUNwRSxJQUFBLENBQUs7Z0JBQUEsS0FBQSxFQUFNO2NBQU4sQ0FBTCxFQUEwQixHQUExQixFQUZKOztZQUdBLElBQUcsSUFBSSxDQUFDLE1BQUwsS0FBZSxDQUFsQjtjQUNJLEdBQUEsQ0FBSTtnQkFBQSxLQUFBLEVBQU0sV0FBQSxHQUFZLElBQUssQ0FBQSxDQUFBLENBQUUsQ0FBQztjQUExQixDQUFKLEVBREo7YUF6Qko7O1VBMkJBLElBQUEsQ0FBTyxTQUFTLENBQUMsV0FBakI7WUFDSSxHQUFBLENBQUk7Y0FBQSxLQUFBLEVBQU07WUFBTixDQUFKLEVBQXVCLFFBQUEsQ0FBQSxDQUFBO2NBQ25CLElBQUcsU0FBUyxDQUFDLFlBQWI7Z0JBQ0ksSUFBQSxDQUFLO2tCQUFBLEtBQUEsRUFBTTtnQkFBTixDQUFMLEVBQXVCLE1BQUEsQ0FBTyxJQUFJLENBQUMsV0FBTCxDQUFpQixDQUFqQixDQUFQLENBQTJCLENBQUMsUUFBNUIsQ0FBQSxDQUF2QixFQURKOztjQUVBLElBQUEsQ0FBSztnQkFBQSxLQUFBLEVBQU07Y0FBTixDQUFMLEVBQXVCLElBQXZCO2NBQ0EsSUFBRyxTQUFTLENBQUMsWUFBYjt1QkFDSSxHQUFBLENBQUk7a0JBQUEsS0FBQSxFQUFNO2dCQUFOLENBQUosRUFBeUIsUUFBQSxDQUFBLENBQUE7QUFDckIsc0JBQUE7eUJBQUEsV0FBQSw0Q0FBb0IsQ0FBRSxLQUFWLENBQWdCLENBQUMsQ0FBakIsQ0FBb0IsQ0FBQSxDQUFBLG1CQUFoQyxFQUFvQyxNQUFwQztnQkFEcUIsQ0FBekIsRUFESjs7WUFKbUIsQ0FBdkIsRUFESjs7aUJBUUEsR0FBQSxDQUFJO1lBQUEsS0FBQSxFQUFNO1VBQU4sQ0FBSjtRQXhDOEIsQ0FBbEMsRUF5Q0U7VUFBQSxPQUFBLEVBQVMsUUFBQSxDQUFDLEVBQUQsQ0FBQTtZQUNQLEVBQUUsQ0FBQyxjQUFILENBQUE7bUJBQ0EsTUFBQSxDQUFPLFlBQVAsRUFBcUIsQ0FBckI7VUFGTztRQUFULENBekNGO01BZlM7TUE0RGIsT0FBQTs7QUFBYTtRQUFBLEtBQUEsdUNBQUE7O2NBQW9CLElBQUksQ0FBQyxTQUFMLENBQWUsQ0FBZjt5QkFBdEI7O1FBQUUsQ0FBQTs7O01BQ2IsTUFBQTs7QUFBWTtRQUFBLEtBQUEsdUNBQUE7O2NBQW9CLENBQUksSUFBSSxDQUFDLFNBQUwsQ0FBZSxDQUFmO3lCQUExQjs7UUFBRSxDQUFBOzs7TUFDWixHQUFBLENBQUk7UUFBQSxLQUFBLEVBQU87TUFBUCxDQUFKLEVBQXNCLFFBQUEsQ0FBQSxDQUFBO1FBQ2xCLElBQUcsT0FBTyxDQUFDLE1BQVIsR0FBaUIsQ0FBcEI7VUFDSSxHQUFBLENBQUk7WUFBQSxLQUFBLEVBQU87VUFBUCxDQUFKLEVBQW9CLElBQUksQ0FBQyxHQUFMLENBQVMsMEJBQVQsRUFBcUMsQ0FBckMsQ0FBcEI7aUJBQ0EsT0FBTyxDQUFDLE9BQVIsQ0FBZ0IsVUFBaEIsRUFGSjs7TUFEa0IsQ0FBdEI7YUFJQSxHQUFBLENBQUk7UUFBQSxLQUFBLEVBQU87TUFBUCxDQUFKLEVBQXFCLFFBQUEsQ0FBQSxDQUFBO1FBQ2pCLElBQUcsT0FBTyxDQUFDLE1BQVIsR0FBaUIsQ0FBcEI7VUFDSSxHQUFBLENBQUk7WUFBQSxLQUFBLEVBQU87VUFBUCxDQUFKLEVBQW9CLElBQUksQ0FBQyxFQUFMLENBQVEsZUFBUixDQUFwQixFQURKOztlQUVBLE1BQU0sQ0FBQyxPQUFQLENBQWUsVUFBZjtNQUhpQixDQUFyQjtJQXhFcUIsQ0FBekI7RUFOa0IsQ0FBTCxFQUhqQjs7O0VBdUZBLGVBQUEsR0FBa0IsQ0FBQyxhQUFELEVBQWdCLGNBQWhCLEVBQ2xCLHFCQURrQixFQUNLLG1CQURMOztFQUdsQixXQUFBLEdBQWMsUUFBQSxDQUFDLENBQUQsRUFBSSxNQUFKLENBQUE7QUFDVixRQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsR0FBQSxFQUFBLElBQUEsRUFBQTtJQUFBLElBQUEsR0FBTyxDQUFDLFNBQUQ7SUFDSyxLQUFBLGlEQUFBOztVQUE4QjtRQUExQyxJQUFJLENBQUMsSUFBTCxDQUFVLENBQVY7O0lBQVk7SUFDWixLQUFBLEdBQVcsQ0FBQyxDQUFDLFNBQUwsR0FBb0IsTUFBQSxDQUFPLENBQUMsQ0FBQyxTQUFGLEdBQWMsSUFBckIsQ0FBMEIsQ0FBQyxRQUEzQixDQUFBLENBQXBCLEdBQStEO1dBQ3ZFLEdBQUEsQ0FBSTtNQUFBLEVBQUEsRUFBRyxDQUFBLEtBQUEsQ0FBQSxDQUFRLENBQUMsQ0FBQyxRQUFWLENBQUEsQ0FBSDtNQUF5QixHQUFBLEVBQUksQ0FBQSxLQUFBLENBQUEsQ0FBUSxDQUFDLENBQUMsUUFBVixDQUFBLENBQTdCO01BQW1ELEtBQUEsRUFBTSxJQUFJLENBQUMsSUFBTCxDQUFVLEdBQVYsQ0FBekQ7TUFBeUUsS0FBQSxFQUFNO0lBQS9FLENBQUosRUFBMEYsUUFBQSxDQUFBLENBQUE7QUFDdEYsVUFBQSxPQUFBLEVBQUEsSUFBQSxFQUFBLEtBQUEsRUFBQSxHQUFBLEVBQUE7TUFBQSxJQUFHLENBQUMsQ0FBQyxZQUFMO1FBQ0ksT0FBQSx1Q0FBd0IsQ0FBRTtlQUMxQixNQUFBLENBQU8sT0FBUCxFQUZKO09BQUEsTUFHSyxJQUFHLENBQUMsQ0FBQyxtQkFBTDtlQUNELElBQUEsQ0FBSyxDQUFBLHdCQUFBLENBQUEsQ0FBMkIsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLFFBQWpELENBQUEsQ0FBTCxFQURDOztPQUFBLE1BR0EsSUFBRyxDQUFDLENBQUMsaUJBQUw7UUFDRCxDQUFBLEdBQUksQ0FBQyxDQUFDLGlCQUFpQixDQUFDO1FBQ3hCLElBQUEsR0FBTyxDQUFDLENBQUMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLEdBQXBDLENBQXdDLFFBQUEsQ0FBQyxDQUFELENBQUE7aUJBQU8sTUFBTyxDQUFBLENBQUMsQ0FBQyxPQUFGO1FBQWQsQ0FBeEM7UUFDUCxLQUFBLEdBQVEsSUFBSSxDQUFDLEdBQUwsQ0FBUyxNQUFULENBQWdCLENBQUMsSUFBakIsQ0FBc0IsSUFBdEI7UUFDUixJQUFHLENBQUEsS0FBSyxNQUFSO2lCQUNJLElBQUEsQ0FBSyxDQUFBLFFBQUEsQ0FBQSxDQUFXLEtBQVgsQ0FBQSxDQUFMLEVBREo7U0FBQSxNQUVLLElBQUcsQ0FBQSxLQUFLLE9BQVI7aUJBQ0QsSUFBQSxDQUFLLENBQUEsQ0FBQSxDQUFHLEtBQUgsQ0FBUyxzQkFBVCxDQUFMLEVBREM7U0FOSjs7SUFQaUYsQ0FBMUY7RUFKVTs7RUFvQmQsTUFBQSxHQUFTLFFBQUEsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUFBO0lBQVUsSUFBRyxDQUFIO2FBQVUsRUFBVjtLQUFBLE1BQUE7YUFBaUIsS0FBakI7O0VBQVY7O0VBRVQsTUFBQSxHQUFTLFFBQUEsQ0FBQyxJQUFELENBQUE7QUFDTCxRQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBLEdBQUEsRUFBQSxHQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQTtBQUFBO0lBQUEsS0FBQSw4Q0FBQTs7TUFDSSxJQUFZLElBQUksQ0FBQyxPQUFMLElBQWlCLENBQUEsR0FBSSxDQUFqQztBQUFBLGlCQUFBOztNQUNBLENBQUEsNENBQXFCLENBQUEsRUFEckI7OztNQUlBLE1BQUEsQ0FBTyxDQUFDLENBQUMsSUFBVCxFQUFlLENBQWYsQ0FBQSxDQUFrQixRQUFBLENBQUEsQ0FBQTtlQUNkLE1BQUEsQ0FBTyxDQUFDLENBQUMsT0FBVCxFQUFrQixDQUFsQixDQUFBLENBQXFCLFFBQUEsQ0FBQSxDQUFBO2lCQUNqQixNQUFBLENBQU8sQ0FBQyxDQUFDLFNBQVQsRUFBb0IsQ0FBcEIsQ0FBQSxDQUF1QixRQUFBLENBQUEsQ0FBQTttQkFDbkIsTUFBQSxDQUFPLENBQUMsQ0FBQyxhQUFULEVBQXdCLENBQXhCLENBQUEsQ0FBMkIsUUFBQSxDQUFBLENBQUEsRUFBQTs7OztxQkFJdkIsSUFBQSxDQUFRLElBQUksQ0FBQyxPQUFSLEdBQ0QsaUJBQUEsQ0FBa0IsR0FBRyxDQUFDLElBQXRCLENBREMsR0FHRCxHQUFHLENBQUMsSUFIUjtZQUp1QixDQUEzQjtVQURtQixDQUF2QjtRQURpQixDQUFyQjtNQURjLENBQWxCO0lBTEo7V0FnQkE7RUFqQks7QUFoSFQiLCJzb3VyY2VzQ29udGVudCI6WyJtb21lbnQgPSByZXF1aXJlICdtb21lbnQnXG57bmFtZW9mLCBpbml0aWFsc29mLCBuYW1lb2Zjb252LCBmaXhsaW5rLCBkcmF3QXZhdGFyfSA9IHJlcXVpcmUgJy4uL3V0aWwnXG5cbm1vZHVsZS5leHBvcnRzID0gdmlldyAobW9kZWxzKSAtPlxuXG4gICAge2NvbnYsIGVudGl0eSwgdmlld3N0YXRlfSA9IG1vZGVsc1xuICAgIGNseiA9IFsnY29udmxpc3QnXVxuICAgIGNsei5wdXNoICdzaG93Y29udnRodW1icycgaWYgdmlld3N0YXRlLnNob3dDb252VGh1bWJzXG4gICAgY2x6LnB1c2ggJ3Nob3dhbmltYXRlZHRodW1icycgaWYgdmlld3N0YXRlLnNob3dBbmltYXRlZFRodW1ic1xuICAgIGRpdiBjbGFzczpjbHouam9pbignICcpLCAtPlxuICAgICAgICBpZiAhdmlld3N0YXRlLnVzZVN5c3RlbURhdGVGb3JtYXRcbiAgICAgICAgICAgIG1vbWVudC5sb2NhbGUoaTE4bi5nZXRMb2NhbGUoKSlcbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgbW9tZW50LmxvY2FsZSh3aW5kb3cubmF2aWdhdG9yLmxhbmd1YWdlKVxuICAgICAgICBjb252cyA9IGNvbnYubGlzdCgpXG4gICAgICAgIHJlbmRlckNvbnYgPSAoYykgLT5cbiAgICAgICAgICAgICPCoHJlbW92ZSBlbW9qaSBzdWdnZXN0aW9ucyBvbiByZW5kZXJDb252XG4gICAgICAgICAgICBpZiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuZW1vamktc3VnZy1jb250YWluZXInKS5sZW5ndGhcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuZW1vamktc3VnZy1jb250YWluZXInKVswXS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy5lbW9qaS1zdWdnLWNvbnRhaW5lcicpWzBdKVxuICAgICAgICAgICAgcHVyZUhhbmcgPSBjb252LmlzUHVyZUhhbmdvdXQoYylcbiAgICAgICAgICAgIGxhc3RDaGFuZ2VkID0gY29udi5sYXN0Q2hhbmdlZChjKVxuICAgICAgICAgICAgIyBkb24ndCBsaXN0IHB1cmUgaGFuZ291dHMgdGhhdCBhcmUgb2xkZXIgdGhhbiAyNGhcbiAgICAgICAgICAgIHJldHVybiBpZiBwdXJlSGFuZyBhbmQgKERhdGUubm93KCkgLSBsYXN0Q2hhbmdlZCkgPiAyNCAqIDYwICogNjAgKiAxMDAwXG4gICAgICAgICAgICBjaWQgPSBjPy5jb252ZXJzYXRpb25faWQ/LmlkXG4gICAgICAgICAgICB1ciA9IGNvbnYudW5yZWFkIGNcbiAgICAgICAgICAgIGNseiA9IFsnY29udiddXG4gICAgICAgICAgICBjbHoucHVzaCBcInR5cGVfI3tjLnR5cGV9XCJcbiAgICAgICAgICAgIGNsei5wdXNoIFwic2VsZWN0ZWRcIiBpZiBtb2RlbHMudmlld3N0YXRlLnNlbGVjdGVkQ29udiA9PSBjaWRcbiAgICAgICAgICAgIGNsei5wdXNoIFwidW5yZWFkXCIgaWYgdXJcbiAgICAgICAgICAgIGNsei5wdXNoIFwicHVyZWhhbmdcIiBpZiBwdXJlSGFuZ1xuICAgICAgICAgICAgZGl2IGtleTpjaWQsIGNsYXNzOmNsei5qb2luKCcgJyksIC0+XG4gICAgICAgICAgICAgICAgcGFydCA9IGM/LmN1cnJlbnRfcGFydGljaXBhbnQgPyBbXVxuICAgICAgICAgICAgICAgIGVudHMgPSBmb3IgcCBpbiBwYXJ0IHdoZW4gbm90IGVudGl0eS5pc1NlbGYgcC5jaGF0X2lkXG4gICAgICAgICAgICAgICAgICAgIGVudGl0eVtwLmNoYXRfaWRdXG4gICAgICAgICAgICAgICAgbmFtZSA9IG5hbWVvZmNvbnYgY1xuICAgICAgICAgICAgICAgIGlmIHZpZXdzdGF0ZS5zaG93Q29udlRodW1icyBvciB2aWV3c3RhdGUuc2hvd0NvbnZNaW5cbiAgICAgICAgICAgICAgICAgICAgZGl2IGNsYXNzOiAndGh1bWJzIHRodW1icy0nKyhpZiBlbnRzLmxlbmd0aD40IHRoZW4gJzQnIGVsc2UgZW50cy5sZW5ndGgpLCAtPlxuICAgICAgICAgICAgICAgICAgICAgICAgYWRkaXRpb25hbCA9IFtdXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgcCwgaW5kZXggaW4gZW50c1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICMgaWYgdGhlcmUgYXJlIHVwIHRvIDQgcGVvcGxlIGluIHRoZSBjb252ZXJzYXRpb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAjICAgdGhlbiBkcmF3IHRoZW0gYWxsLCBvdGhlcndpc2UsIGRyYXcgMyBhdmF0YXJzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIyAgIGFuZCB0aGVuIGFkZCBhICtYICwgd2hlcmUgWCBpcyB0aGUgcmVtYWluaW5nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIyAgIG51bWJlciBvZiBwZW9wbGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiBpbmRleCA8IDMgfHwgIGVudHMubGVuZ3RoID09IDRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50aXR5Lm5lZWRFbnRpdHkocC5pZClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZHJhd0F2YXRhcihwLmlkLCB2aWV3c3RhdGUsIGVudGl0eSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZGl0aW9uYWwucHVzaCBuYW1lb2YgZW50aXR5W3AuaWRdXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiBlbnRzLmxlbmd0aCA+IDRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXYgY2xhc3M6J21vcmV1c2VyJywgXCIrI3tlbnRzLmxlbmd0aCAtIDN9XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAsIHRpdGxlOiBhZGRpdGlvbmFsLmpvaW4oJ1xcbicpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiB1ciA+IDAgYW5kIG5vdCBjb252LmlzUXVpZXQoYylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYmwgPSBpZiB1ciA+PSBjb252Lk1BWF9VTlJFQUQgdGhlbiBcIiN7Y29udi5NQVhfVU5SRUFEfStcIiBlbHNlIHVyICsgJydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcGFuIGNsYXNzOid1bnJlYWRjb3VudCcsIGxibFxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgZW50cy5sZW5ndGggPT0gMVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpdiBjbGFzczoncHJlc2VuY2UgJytlbnRzWzBdLnByZXNlbmNlXG4gICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICBpZiB1ciA+IDAgYW5kIG5vdCBjb252LmlzUXVpZXQoYylcbiAgICAgICAgICAgICAgICAgICAgICAgIGxibCA9IGlmIHVyID49IGNvbnYuTUFYX1VOUkVBRCB0aGVuIFwiI3tjb252Lk1BWF9VTlJFQUR9K1wiIGVsc2UgdXIgKyAnJ1xuICAgICAgICAgICAgICAgICAgICAgICAgc3BhbiBjbGFzczondW5yZWFkY291bnQnLCBsYmxcbiAgICAgICAgICAgICAgICAgICAgaWYgZW50cy5sZW5ndGggPT0gMVxuICAgICAgICAgICAgICAgICAgICAgICAgZGl2IGNsYXNzOidwcmVzZW5jZSAnK2VudHNbMF0ucHJlc2VuY2VcbiAgICAgICAgICAgICAgICB1bmxlc3Mgdmlld3N0YXRlLnNob3dDb252TWluXG4gICAgICAgICAgICAgICAgICAgIGRpdiBjbGFzczonY29udmluZm9zJywgLT5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIHZpZXdzdGF0ZS5zaG93Q29udlRpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcGFuIGNsYXNzOidsYXN0dGltZScsIG1vbWVudChjb252Lmxhc3RDaGFuZ2VkKGMpKS5jYWxlbmRhcigpXG4gICAgICAgICAgICAgICAgICAgICAgICBzcGFuIGNsYXNzOidjb252bmFtZScsIG5hbWVcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIHZpZXdzdGF0ZS5zaG93Q29udkxhc3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXYgY2xhc3M6J2xhc3RtZXNzYWdlJywgLT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZHJhd01lc3NhZ2UoYz8uZXZlbnQ/LnNsaWNlKC0xKVswXSwgZW50aXR5KVxuICAgICAgICAgICAgICAgIGRpdiBjbGFzczonZGl2aWRlcidcbiAgICAgICAgICAgICwgb25jbGljazogKGV2KSAtPlxuICAgICAgICAgICAgICAgIGV2LnByZXZlbnREZWZhdWx0KClcbiAgICAgICAgICAgICAgICBhY3Rpb24gJ3NlbGVjdENvbnYnLCBjXG5cbiAgICAgICAgc3RhcnJlZCA9IChjIGZvciBjIGluIGNvbnZzIHdoZW4gY29udi5pc1N0YXJyZWQoYykpXG4gICAgICAgIG90aGVycyA9IChjIGZvciBjIGluIGNvbnZzIHdoZW4gbm90IGNvbnYuaXNTdGFycmVkKGMpKVxuICAgICAgICBkaXYgY2xhc3M6ICdzdGFycmVkJywgLT5cbiAgICAgICAgICAgIGlmIHN0YXJyZWQubGVuZ3RoID4gMFxuICAgICAgICAgICAgICAgIGRpdiBjbGFzczogJ2xhYmVsJywgaTE4bi5fX24oJ2Zhdm9yaXRlLnRpdGxlOkZhdm9yaXRlcycsIDIpXG4gICAgICAgICAgICAgICAgc3RhcnJlZC5mb3JFYWNoIHJlbmRlckNvbnZcbiAgICAgICAgZGl2IGNsYXNzOiAnb3RoZXJzJywgLT5cbiAgICAgICAgICAgIGlmIHN0YXJyZWQubGVuZ3RoID4gMFxuICAgICAgICAgICAgICAgIGRpdiBjbGFzczogJ2xhYmVsJywgaTE4bi5fXyAncmVjZW50OlJlY2VudCdcbiAgICAgICAgICAgIG90aGVycy5mb3JFYWNoIHJlbmRlckNvbnZcblxuIyBwb3NzaWJsZSBjbGFzc2VzIG9mIG1lc3NhZ2VzXG5NRVNTQUdFX0NMQVNTRVMgPSBbJ3BsYWNlaG9sZGVyJywgJ2NoYXRfbWVzc2FnZScsXG4nY29udmVyc2F0aW9uX3JlbmFtZScsICdtZW1iZXJzaGlwX2NoYW5nZSddXG5cbmRyYXdNZXNzYWdlID0gKGUsIGVudGl0eSkgLT5cbiAgICBtY2x6ID0gWydtZXNzYWdlJ11cbiAgICBtY2x6LnB1c2ggYyBmb3IgYyBpbiBNRVNTQUdFX0NMQVNTRVMgd2hlbiBlW2NdP1xuICAgIHRpdGxlID0gaWYgZS50aW1lc3RhbXAgdGhlbiBtb21lbnQoZS50aW1lc3RhbXAgLyAxMDAwKS5jYWxlbmRhcigpIGVsc2UgbnVsbFxuICAgIGRpdiBpZDpcImxpc3RfI3tlLmV2ZW50X2lkfVwiLCBrZXk6XCJsaXN0XyN7ZS5ldmVudF9pZH1cIiwgY2xhc3M6bWNsei5qb2luKCcgJyksIHRpdGxlOnRpdGxlLCAtPlxuICAgICAgICBpZiBlLmNoYXRfbWVzc2FnZVxuICAgICAgICAgICAgY29udGVudCA9IGUuY2hhdF9tZXNzYWdlPy5tZXNzYWdlX2NvbnRlbnRcbiAgICAgICAgICAgIGZvcm1hdCBjb250ZW50XG4gICAgICAgIGVsc2UgaWYgZS5jb252ZXJzYXRpb25fcmVuYW1lXG4gICAgICAgICAgICBwYXNzIFwicmVuYW1lZCBjb252ZXJzYXRpb24gdG8gI3tlLmNvbnZlcnNhdGlvbl9yZW5hbWUubmV3X25hbWV9XCJcbiAgICAgICAgICAgICMge25ld19uYW1lOiBcImxhYmJvdFwiIG9sZF9uYW1lOiBcIlwifVxuICAgICAgICBlbHNlIGlmIGUubWVtYmVyc2hpcF9jaGFuZ2VcbiAgICAgICAgICAgIHQgPSBlLm1lbWJlcnNoaXBfY2hhbmdlLnR5cGVcbiAgICAgICAgICAgIGVudHMgPSBlLm1lbWJlcnNoaXBfY2hhbmdlLnBhcnRpY2lwYW50X2lkcy5tYXAgKHApIC0+IGVudGl0eVtwLmNoYXRfaWRdXG4gICAgICAgICAgICBuYW1lcyA9IGVudHMubWFwKG5hbWVvZikuam9pbignLCAnKVxuICAgICAgICAgICAgaWYgdCA9PSAnSk9JTidcbiAgICAgICAgICAgICAgICBwYXNzIFwiaW52aXRlZCAje25hbWVzfVwiXG4gICAgICAgICAgICBlbHNlIGlmIHQgPT0gJ0xFQVZFJ1xuICAgICAgICAgICAgICAgIHBhc3MgXCIje25hbWVzfSBsZWZ0IHRoZSBjb252ZXJzYXRpb25cIlxuXG5pZnBhc3MgPSAodCwgZikgLT4gaWYgdCB0aGVuIGYgZWxzZSBwYXNzXG5cbmZvcm1hdCA9IChjb250KSAtPlxuICAgIGZvciBzZWcsIGkgaW4gY29udD8uc2VnbWVudCA/IFtdXG4gICAgICAgIGNvbnRpbnVlIGlmIGNvbnQucHJveGllZCBhbmQgaSA8IDFcbiAgICAgICAgZiA9IHNlZy5mb3JtYXR0aW5nID8ge31cbiAgICAgICAgIyB0aGVzZSBhcmUgbGlua3MgdG8gaW1hZ2VzIHRoYXQgd2UgdHJ5IGxvYWRpbmdcbiAgICAgICAgICMgYXMgaW1hZ2VzIGFuZCBzaG93IGlubGluZS4gKG5vdCBhdHRhY2htZW50cylcbiAgICAgICAgaWZwYXNzKGYuYm9sZCwgYikgLT5cbiAgICAgICAgICAgIGlmcGFzcyhmLml0YWxpY3MsIGkpIC0+XG4gICAgICAgICAgICAgICAgaWZwYXNzKGYudW5kZXJsaW5lLCB1KSAtPlxuICAgICAgICAgICAgICAgICAgICBpZnBhc3MoZi5zdHJpa2V0aHJvdWdoLCBzKSAtPlxuICAgICAgICAgICAgICAgICAgICAgICAgIyBwcmVsb2FkIHJldHVybnMgd2hldGhlciB0aGUgaW1hZ2VcbiAgICAgICAgICAgICAgICAgICAgICAgICMgaGFzIGJlZW4gbG9hZGVkLiByZWRyYXcgd2hlbiBpdFxuICAgICAgICAgICAgICAgICAgICAgICAgIyBsb2Fkcy5cbiAgICAgICAgICAgICAgICAgICAgICAgIHBhc3MgaWYgY29udC5wcm94aWVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyaXBQcm94aWVkQ29sb24gc2VnLnRleHRcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWcudGV4dFxuICAgIG51bGxcbiJdfQ==
