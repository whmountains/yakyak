(function() {
  var chilledaction, drawAvatar, fixlink, initialsof, inputSetValue, mayRestoreInitialValues, nameof, onclickaction, throttle, unique,
    indexOf = [].indexOf;

  ({initialsof, throttle, nameof, fixlink, drawAvatar} = require('../util'));

  chilledaction = throttle(1500, action);

  unique = function(obj) {
    return obj.id.chat_id || obj.id.gaia_id;
  };

  mayRestoreInitialValues = function(models) {
    var convsettings, initialName, initialSearchQuery;
    // If there is an initial value we set it an then invalidate it
    ({convsettings} = models);
    initialName = convsettings.getInitialName();
    if (initialName !== null) {
      setTimeout(function() {
        var name;
        name = document.querySelector('.name-input');
        if (name) {
          return name.value = initialName;
        }
      }, 1);
    }
    initialSearchQuery = convsettings.getInitialSearchQuery();
    if (initialSearchQuery !== null) {
      setTimeout(function() {
        var search;
        search = document.querySelector('.search-input');
        if (search) {
          return search.value = initialSearchQuery;
        }
      }, 1);
    }
    setTimeout(function() {
      var group;
      group = document.querySelector('.group');
      if (group) {
        return group.checked = convsettings.group;
      }
    });
    return null;
  };

  inputSetValue = function(sel, val) {
    setTimeout(function() {
      var el;
      el = document.querySelector(sel);
      if (el !== null) {
        return el.value = val;
      }
    }, 1);
    return null;
  };

  module.exports = view(function(models) {
    var conv, conversation, convsettings, editing, entity, viewstate;
    ({viewstate, convsettings, entity, conv} = models);
    editing = convsettings.id !== null;
    conversation = conv[viewstate.selectedConv];
    return div({
      class: 'convadd'
    }, function() {
      var style;
      if (editing) {
        h1(i18n.__('conversation.edit:Conversation edit'));
      } else {
        h1(i18n.__('conversation.new:New conversation'));
      }
      style = {};
      if (!convsettings.group) {
        style = {
          display: 'none'
        };
      }
      div({
        class: 'input'
      }, {style}, function() {
        return div(function() {
          return input({
            class: 'name-input',
            style: style,
            placeholder: i18n.__('conversation.name:Conversation name'),
            onkeyup: function(e) {
              return action('conversationname', e.currentTarget.value);
            }
          });
        });
      });
      div({
        class: 'input'
      }, function() {
        return div(function() {
          return input({
            class: 'search-input',
            placeholder: i18n.__('conversation.search:Search people'),
            onkeyup: function(e) {
              chilledaction('searchentities', e.currentTarget.value, 7);
              return action('conversationquery', e.currentTarget.value, 7);
            }
          });
        });
      });
      div({
        class: 'input'
      }, function() {
        return div(function() {
          return p(function() {
            var opts;
            opts = {
              type: 'checkbox',
              class: 'group',
              style: {
                width: 'auto',
                'margin-right': '5px'
              },
              onchange: function(e) {
                return action('togglegroup');
              }
            };
            if (convsettings.selectedEntities.length !== 1) {
              opts.disabled = 'disabled';
            }
            input(opts);
            return i18n.__('conversation.multiuser:Create multiuser chat');
          });
        });
      });
      ul(function() {
        var c, selected_ids;
        convsettings.selectedEntities.forEach(function(r) {
          var cid, email, ref, ref1, ref2, ref3, ref4, ref5;
          cid = r != null ? (ref = r.id) != null ? ref.chat_id : void 0 : void 0;
          email = (ref1 = (ref2 = r.properties) != null ? (ref3 = ref2.email) != null ? ref3[0] : void 0 : void 0) != null ? ref1 : (ref4 = entity[cid]) != null ? (ref5 = ref4.emails) != null ? ref5[0] : void 0 : void 0;
          return li({
            class: 'selected',
            title: email
          }, function() {
            var ref6, ref7, ref8;
            drawAvatar(cid, viewstate, entity, (ref6 = (ref7 = r.properties) != null ? ref7.photo_url : void 0) != null ? ref6 : (ref8 = entity[cid]) != null ? ref8.photo_url : void 0, email, (r.properties != null ? initialsof(r.properties != null) : void 0));
            return p(nameof(r.properties));
          }, {
            onclick: function(e) {
              if (!editing) {
                return action('deselectentity', r);
              }
            }
          });
        });
        selected_ids = (function() {
          var i, len, ref, results;
          ref = convsettings.selectedEntities;
          results = [];
          for (i = 0, len = ref.length; i < len; i++) {
            c = ref[i];
            results.push(unique(c));
          }
          return results;
        })();
        return convsettings.searchedEntities.forEach(function(r) {
          var cid, email, ref, ref1, ref2, ref3, ref4, ref5, ref6;
          cid = r != null ? (ref = r.id) != null ? ref.chat_id : void 0 : void 0;
          email = (ref1 = (ref2 = r.properties) != null ? (ref3 = ref2.email) != null ? ref3[0] : void 0 : void 0) != null ? ref1 : (ref4 = entity[cid]) != null ? (ref5 = ref4.emails) != null ? ref5[0] : void 0 : void 0;
          if (ref6 = unique(r), indexOf.call(selected_ids, ref6) >= 0) {
            return;
          }
          return li({
            title: email
          }, function() {
            var ref7, ref8, ref9;
            drawAvatar(cid, viewstate, entity, (ref7 = (ref8 = r.properties) != null ? ref8.photo_url : void 0) != null ? ref7 : (ref9 = entity[cid]) != null ? ref9.photo_url : void 0, email, (r.properties != null ? initialsof(r.properties != null) : void 0));
            return p(nameof(r.properties));
          }, {
            onclick: function(e) {
              return action('selectentity', r);
            }
          });
        });
      });
      if (editing) {
        div({
          class: 'leave'
        }, function() {
          var ref;
          if ((conversation != null ? (ref = conversation.type) != null ? ref.indexOf('ONE_TO_ONE') : void 0 : void 0) > 0) {
            return div({
              class: 'button',
              title: i18n.__('conversation.delete:Delete conversation'),
              onclick: onclickaction('deleteconv')
            }, function() {
              span({
                class: 'material-icons'
              }, 'close');
              return span(i18n.__('conversation.delete:Delete conversation'));
            });
          } else {
            return div({
              class: 'button',
              title: i18n.__('conversation.leave:Leave conversation'),
              onclick: onclickaction('leaveconv')
            }, function() {
              span({
                class: 'material-icons'
              }, 'close');
              return span(i18n.__('conversation.leave:Leave conversation'));
            });
          }
        });
      }
      div({
        class: 'validate'
      }, function() {
        var disabled;
        disabled = null;
        if (convsettings.selectedEntities.length <= 0) {
          disabled = {
            disabled: 'disabled'
          };
        }
        return div(disabled, {
          class: 'button',
          onclick: onclickaction('saveconversation')
        }, function() {
          span({
            class: 'material-icons'
          }, 'done');
          return span(i18n.__("actions.ok:OK"));
        });
      });
      return mayRestoreInitialValues(models);
    });
  });

  onclickaction = function(a) {
    return function(ev) {
      return action(a);
    };
  };

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvdmlld3MvY29udmFkZC5qcyIsInNvdXJjZXMiOlsidWkvdmlld3MvY29udmFkZC5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7QUFBQSxNQUFBLGFBQUEsRUFBQSxVQUFBLEVBQUEsT0FBQSxFQUFBLFVBQUEsRUFBQSxhQUFBLEVBQUEsdUJBQUEsRUFBQSxNQUFBLEVBQUEsYUFBQSxFQUFBLFFBQUEsRUFBQSxNQUFBO0lBQUE7O0VBQUEsQ0FBQSxDQUFDLFVBQUQsRUFBYSxRQUFiLEVBQXVCLE1BQXZCLEVBQStCLE9BQS9CLEVBQXdDLFVBQXhDLENBQUEsR0FBc0QsT0FBQSxDQUFRLFNBQVIsQ0FBdEQ7O0VBQ0EsYUFBQSxHQUFnQixRQUFBLENBQVMsSUFBVCxFQUFlLE1BQWY7O0VBRWhCLE1BQUEsR0FBUyxRQUFBLENBQUMsR0FBRCxDQUFBO1dBQVMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxPQUFQLElBQWtCLEdBQUcsQ0FBQyxFQUFFLENBQUM7RUFBbEM7O0VBRVQsdUJBQUEsR0FBMEIsUUFBQSxDQUFDLE1BQUQsQ0FBQTtBQUV0QixRQUFBLFlBQUEsRUFBQSxXQUFBLEVBQUEsa0JBQUE7O0lBQUEsQ0FBQSxDQUFDLFlBQUQsQ0FBQSxHQUFpQixNQUFqQjtJQUNBLFdBQUEsR0FBYyxZQUFZLENBQUMsY0FBYixDQUFBO0lBQ2QsSUFBRyxXQUFBLEtBQWUsSUFBbEI7TUFDSSxVQUFBLENBQVcsUUFBQSxDQUFBLENBQUE7QUFDUCxZQUFBO1FBQUEsSUFBQSxHQUFPLFFBQVEsQ0FBQyxhQUFULENBQXVCLGFBQXZCO1FBQ1AsSUFBNEIsSUFBNUI7aUJBQUEsSUFBSSxDQUFDLEtBQUwsR0FBYSxZQUFiOztNQUZPLENBQVgsRUFHRSxDQUhGLEVBREo7O0lBS0Esa0JBQUEsR0FBcUIsWUFBWSxDQUFDLHFCQUFiLENBQUE7SUFDckIsSUFBRyxrQkFBQSxLQUFzQixJQUF6QjtNQUNJLFVBQUEsQ0FBVyxRQUFBLENBQUEsQ0FBQTtBQUNQLFlBQUE7UUFBQSxNQUFBLEdBQVMsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsZUFBdkI7UUFDVCxJQUFxQyxNQUFyQztpQkFBQSxNQUFNLENBQUMsS0FBUCxHQUFlLG1CQUFmOztNQUZPLENBQVgsRUFHRSxDQUhGLEVBREo7O0lBS0EsVUFBQSxDQUFXLFFBQUEsQ0FBQSxDQUFBO0FBQ1AsVUFBQTtNQUFBLEtBQUEsR0FBUSxRQUFRLENBQUMsYUFBVCxDQUF1QixRQUF2QjtNQUNSLElBQXNDLEtBQXRDO2VBQUEsS0FBSyxDQUFDLE9BQU4sR0FBZ0IsWUFBWSxDQUFDLE1BQTdCOztJQUZPLENBQVg7V0FHQTtFQWxCc0I7O0VBb0IxQixhQUFBLEdBQWdCLFFBQUEsQ0FBQyxHQUFELEVBQU0sR0FBTixDQUFBO0lBQ1osVUFBQSxDQUFXLFFBQUEsQ0FBQSxDQUFBO0FBQ1AsVUFBQTtNQUFBLEVBQUEsR0FBSyxRQUFRLENBQUMsYUFBVCxDQUF1QixHQUF2QjtNQUNMLElBQWtCLEVBQUEsS0FBTSxJQUF4QjtlQUFBLEVBQUUsQ0FBQyxLQUFILEdBQVcsSUFBWDs7SUFGTyxDQUFYLEVBR0UsQ0FIRjtXQUlBO0VBTFk7O0VBT2hCLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLElBQUEsQ0FBSyxRQUFBLENBQUMsTUFBRCxDQUFBO0FBQ2xCLFFBQUEsSUFBQSxFQUFBLFlBQUEsRUFBQSxZQUFBLEVBQUEsT0FBQSxFQUFBLE1BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQyxTQUFELEVBQVksWUFBWixFQUEwQixNQUExQixFQUFrQyxJQUFsQyxDQUFBLEdBQTBDLE1BQTFDO0lBRUEsT0FBQSxHQUFVLFlBQVksQ0FBQyxFQUFiLEtBQW1CO0lBQzdCLFlBQUEsR0FBZSxJQUFLLENBQUEsU0FBUyxDQUFDLFlBQVY7V0FFcEIsR0FBQSxDQUFJO01BQUEsS0FBQSxFQUFPO0lBQVAsQ0FBSixFQUFzQixRQUFBLENBQUEsQ0FBQTtBQUNsQixVQUFBO01BQUEsSUFBRyxPQUFIO1FBQ0ksRUFBQSxDQUFHLElBQUksQ0FBQyxFQUFMLENBQVEscUNBQVIsQ0FBSCxFQURKO09BQUEsTUFBQTtRQUdJLEVBQUEsQ0FBRyxJQUFJLENBQUMsRUFBTCxDQUFRLG1DQUFSLENBQUgsRUFISjs7TUFLQSxLQUFBLEdBQVEsQ0FBQTtNQUNSLElBQUcsQ0FBSSxZQUFZLENBQUMsS0FBcEI7UUFDSSxLQUFBLEdBQVE7VUFBQSxPQUFBLEVBQVM7UUFBVCxFQURaOztNQUdBLEdBQUEsQ0FBSTtRQUFBLEtBQUEsRUFBTztNQUFQLENBQUosRUFBb0IsQ0FBQyxLQUFELENBQXBCLEVBQTZCLFFBQUEsQ0FBQSxDQUFBO2VBQ3pCLEdBQUEsQ0FBSSxRQUFBLENBQUEsQ0FBQTtpQkFDQSxLQUFBLENBQ0k7WUFBQSxLQUFBLEVBQU8sWUFBUDtZQUNBLEtBQUEsRUFBTyxLQURQO1lBRUEsV0FBQSxFQUFhLElBQUksQ0FBQyxFQUFMLENBQVEscUNBQVIsQ0FGYjtZQUdBLE9BQUEsRUFBUyxRQUFBLENBQUMsQ0FBRCxDQUFBO3FCQUNMLE1BQUEsQ0FBTyxrQkFBUCxFQUEyQixDQUFDLENBQUMsYUFBYSxDQUFDLEtBQTNDO1lBREs7VUFIVCxDQURKO1FBREEsQ0FBSjtNQUR5QixDQUE3QjtNQVNBLEdBQUEsQ0FBSTtRQUFBLEtBQUEsRUFBTztNQUFQLENBQUosRUFBb0IsUUFBQSxDQUFBLENBQUE7ZUFDaEIsR0FBQSxDQUFJLFFBQUEsQ0FBQSxDQUFBO2lCQUNBLEtBQUEsQ0FDSTtZQUFBLEtBQUEsRUFBTyxjQUFQO1lBQ0EsV0FBQSxFQUFhLElBQUksQ0FBQyxFQUFMLENBQVEsbUNBQVIsQ0FEYjtZQUVBLE9BQUEsRUFBUyxRQUFBLENBQUMsQ0FBRCxDQUFBO2NBQ0wsYUFBQSxDQUFjLGdCQUFkLEVBQWdDLENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBaEQsRUFBdUQsQ0FBdkQ7cUJBQ0EsTUFBQSxDQUFPLG1CQUFQLEVBQTRCLENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBNUMsRUFBbUQsQ0FBbkQ7WUFGSztVQUZULENBREo7UUFEQSxDQUFKO01BRGdCLENBQXBCO01BU0EsR0FBQSxDQUFJO1FBQUEsS0FBQSxFQUFPO01BQVAsQ0FBSixFQUFvQixRQUFBLENBQUEsQ0FBQTtlQUNoQixHQUFBLENBQUksUUFBQSxDQUFBLENBQUE7aUJBQ0EsQ0FBQSxDQUFFLFFBQUEsQ0FBQSxDQUFBO0FBQ0UsZ0JBQUE7WUFBQSxJQUFBLEdBQ0k7Y0FBQSxJQUFBLEVBQU0sVUFBTjtjQUNBLEtBQUEsRUFBTyxPQURQO2NBRUEsS0FBQSxFQUFPO2dCQUFFLEtBQUEsRUFBTyxNQUFUO2dCQUFpQixjQUFBLEVBQWdCO2NBQWpDLENBRlA7Y0FHQSxRQUFBLEVBQVUsUUFBQSxDQUFDLENBQUQsQ0FBQTt1QkFBTyxNQUFBLENBQVMsYUFBVDtjQUFQO1lBSFY7WUFJSixJQUFHLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUE5QixLQUF3QyxDQUEzQztjQUNJLElBQUksQ0FBQyxRQUFMLEdBQWdCLFdBRHBCOztZQUVBLEtBQUEsQ0FBTSxJQUFOO21CQUNBLElBQUksQ0FBQyxFQUFMLENBQVEsOENBQVI7VUFURixDQUFGO1FBREEsQ0FBSjtNQURnQixDQUFwQjtNQWNBLEVBQUEsQ0FBRyxRQUFBLENBQUEsQ0FBQTtBQUNDLFlBQUEsQ0FBQSxFQUFBO1FBQUEsWUFBWSxDQUFDLGdCQUFnQixDQUFDLE9BQTlCLENBQXNDLFFBQUEsQ0FBQyxDQUFELENBQUE7QUFDbEMsY0FBQSxHQUFBLEVBQUEsS0FBQSxFQUFBLEdBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUE7VUFBQSxHQUFBLHlDQUFXLENBQUU7VUFDYixLQUFBLHVMQUF3RCxDQUFBLENBQUE7aUJBQ3hELEVBQUEsQ0FBRztZQUFBLEtBQUEsRUFBTyxVQUFQO1lBQW1CLEtBQUEsRUFBTztVQUExQixDQUFILEVBQW9DLFFBQUEsQ0FBQSxDQUFBO0FBQ2hDLGdCQUFBLElBQUEsRUFBQSxJQUFBLEVBQUE7WUFBQSxVQUFBLENBQVcsR0FBWCxFQUFnQixTQUFoQixFQUEyQixNQUEzQix1SEFDd0MsQ0FBRSxrQkFEMUMsRUFFRSxLQUZGLEVBR0UsQ0FBSSxvQkFBSCxHQUFzQixVQUFBLENBQVcsb0JBQVgsQ0FBdEIsR0FBQSxNQUFELENBSEY7bUJBSUEsQ0FBQSxDQUFFLE1BQUEsQ0FBTyxDQUFDLENBQUMsVUFBVCxDQUFGO1VBTGdDLENBQXBDLEVBTUU7WUFBQSxPQUFBLEVBQVEsUUFBQSxDQUFDLENBQUQsQ0FBQTtjQUFPLElBQUcsQ0FBSSxPQUFQO3VCQUFvQixNQUFBLENBQU8sZ0JBQVAsRUFBeUIsQ0FBekIsRUFBcEI7O1lBQVA7VUFBUixDQU5GO1FBSGtDLENBQXRDO1FBV0EsWUFBQTs7QUFBMEI7QUFBQTtVQUFBLEtBQUEscUNBQUE7O3lCQUFWLE1BQUEsQ0FBTyxDQUFQO1VBQVUsQ0FBQTs7O2VBRTFCLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUE5QixDQUFzQyxRQUFBLENBQUMsQ0FBRCxDQUFBO0FBQ2xDLGNBQUEsR0FBQSxFQUFBLEtBQUEsRUFBQSxHQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQTtVQUFBLEdBQUEseUNBQVcsQ0FBRTtVQUNiLEtBQUEsdUxBQXdELENBQUEsQ0FBQTtVQUN4RCxXQUFHLE1BQUEsQ0FBTyxDQUFQLENBQUEsRUFBQSxhQUFhLFlBQWIsRUFBQSxJQUFBLE1BQUg7QUFBa0MsbUJBQWxDOztpQkFDQSxFQUFBLENBQUc7WUFBQSxLQUFBLEVBQU87VUFBUCxDQUFILEVBQWlCLFFBQUEsQ0FBQSxDQUFBO0FBQ2IsZ0JBQUEsSUFBQSxFQUFBLElBQUEsRUFBQTtZQUFBLFVBQUEsQ0FBVyxHQUFYLEVBQWdCLFNBQWhCLEVBQTJCLE1BQTNCLHVIQUN3QyxDQUFFLGtCQUQxQyxFQUVFLEtBRkYsRUFHRSxDQUFJLG9CQUFILEdBQXNCLFVBQUEsQ0FBVyxvQkFBWCxDQUF0QixHQUFBLE1BQUQsQ0FIRjttQkFJQSxDQUFBLENBQUUsTUFBQSxDQUFPLENBQUMsQ0FBQyxVQUFULENBQUY7VUFMYSxDQUFqQixFQU1FO1lBQUEsT0FBQSxFQUFRLFFBQUEsQ0FBQyxDQUFELENBQUE7cUJBQU8sTUFBQSxDQUFPLGNBQVAsRUFBdUIsQ0FBdkI7WUFBUDtVQUFSLENBTkY7UUFKa0MsQ0FBdEM7TUFkRCxDQUFIO01BMEJBLElBQUcsT0FBSDtRQUNJLEdBQUEsQ0FBSTtVQUFBLEtBQUEsRUFBTTtRQUFOLENBQUosRUFBbUIsUUFBQSxDQUFBLENBQUE7QUFDZixjQUFBO1VBQUEsbUVBQXFCLENBQUUsT0FBcEIsQ0FBNEIsWUFBNUIsb0JBQUEsR0FBNEMsQ0FBL0M7bUJBQ0ksR0FBQSxDQUFJO2NBQUEsS0FBQSxFQUFNLFFBQU47Y0FDRixLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx5Q0FBUixDQURMO2NBRUYsT0FBQSxFQUFRLGFBQUEsQ0FBYyxZQUFkO1lBRk4sQ0FBSixFQUV1QyxRQUFBLENBQUEsQ0FBQTtjQUNuQyxJQUFBLENBQUs7Z0JBQUEsS0FBQSxFQUFNO2NBQU4sQ0FBTCxFQUE2QixPQUE3QjtxQkFDQSxJQUFBLENBQUssSUFBSSxDQUFDLEVBQUwsQ0FBUSx5Q0FBUixDQUFMO1lBRm1DLENBRnZDLEVBREo7V0FBQSxNQUFBO21CQU9JLEdBQUEsQ0FBSTtjQUFBLEtBQUEsRUFBTSxRQUFOO2NBQ0YsS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsdUNBQVIsQ0FETDtjQUVGLE9BQUEsRUFBUSxhQUFBLENBQWMsV0FBZDtZQUZOLENBQUosRUFFc0MsUUFBQSxDQUFBLENBQUE7Y0FDbEMsSUFBQSxDQUFLO2dCQUFBLEtBQUEsRUFBTTtjQUFOLENBQUwsRUFBNkIsT0FBN0I7cUJBQ0EsSUFBQSxDQUFLLElBQUksQ0FBQyxFQUFMLENBQVEsdUNBQVIsQ0FBTDtZQUZrQyxDQUZ0QyxFQVBKOztRQURlLENBQW5CLEVBREo7O01BZUEsR0FBQSxDQUFJO1FBQUEsS0FBQSxFQUFNO01BQU4sQ0FBSixFQUFzQixRQUFBLENBQUEsQ0FBQTtBQUNsQixZQUFBO1FBQUEsUUFBQSxHQUFXO1FBQ1gsSUFBRyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsTUFBOUIsSUFBd0MsQ0FBM0M7VUFDSSxRQUFBLEdBQVk7WUFBQSxRQUFBLEVBQVU7VUFBVixFQURoQjs7ZUFFQSxHQUFBLENBQUksUUFBSixFQUFjO1VBQUEsS0FBQSxFQUFNLFFBQU47VUFDWixPQUFBLEVBQVEsYUFBQSxDQUFjLGtCQUFkO1FBREksQ0FBZCxFQUM2QyxRQUFBLENBQUEsQ0FBQTtVQUN6QyxJQUFBLENBQUs7WUFBQSxLQUFBLEVBQU07VUFBTixDQUFMLEVBQTZCLE1BQTdCO2lCQUNBLElBQUEsQ0FBSyxJQUFJLENBQUMsRUFBTCxDQUFRLGVBQVIsQ0FBTDtRQUZ5QyxDQUQ3QztNQUprQixDQUF0QjthQVNBLHVCQUFBLENBQXdCLE1BQXhCO0lBNUZrQixDQUF0QjtFQU5rQixDQUFMOztFQW9HakIsYUFBQSxHQUFnQixRQUFBLENBQUMsQ0FBRCxDQUFBO1dBQU8sUUFBQSxDQUFDLEVBQUQsQ0FBQTthQUFRLE1BQUEsQ0FBTyxDQUFQO0lBQVI7RUFBUDtBQXBJaEIiLCJzb3VyY2VzQ29udGVudCI6WyJcbntpbml0aWFsc29mLCB0aHJvdHRsZSwgbmFtZW9mLCBmaXhsaW5rLCBkcmF3QXZhdGFyfSA9IHJlcXVpcmUgJy4uL3V0aWwnXG5jaGlsbGVkYWN0aW9uID0gdGhyb3R0bGUgMTUwMCwgYWN0aW9uXG5cbnVuaXF1ZSA9IChvYmopIC0+IG9iai5pZC5jaGF0X2lkIG9yIG9iai5pZC5nYWlhX2lkXG5cbm1heVJlc3RvcmVJbml0aWFsVmFsdWVzID0gKG1vZGVscykgLT5cbiAgICAjIElmIHRoZXJlIGlzIGFuIGluaXRpYWwgdmFsdWUgd2Ugc2V0IGl0IGFuIHRoZW4gaW52YWxpZGF0ZSBpdFxuICAgIHtjb252c2V0dGluZ3N9ID0gbW9kZWxzXG4gICAgaW5pdGlhbE5hbWUgPSBjb252c2V0dGluZ3MuZ2V0SW5pdGlhbE5hbWUoKVxuICAgIGlmIGluaXRpYWxOYW1lICE9IG51bGxcbiAgICAgICAgc2V0VGltZW91dCAtPlxuICAgICAgICAgICAgbmFtZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IgJy5uYW1lLWlucHV0J1xuICAgICAgICAgICAgbmFtZS52YWx1ZSA9IGluaXRpYWxOYW1lIGlmIG5hbWVcbiAgICAgICAgLCAxXG4gICAgaW5pdGlhbFNlYXJjaFF1ZXJ5ID0gY29udnNldHRpbmdzLmdldEluaXRpYWxTZWFyY2hRdWVyeSgpXG4gICAgaWYgaW5pdGlhbFNlYXJjaFF1ZXJ5ICE9IG51bGxcbiAgICAgICAgc2V0VGltZW91dCAtPlxuICAgICAgICAgICAgc2VhcmNoID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciAnLnNlYXJjaC1pbnB1dCdcbiAgICAgICAgICAgIHNlYXJjaC52YWx1ZSA9IGluaXRpYWxTZWFyY2hRdWVyeSBpZiBzZWFyY2hcbiAgICAgICAgLCAxXG4gICAgc2V0VGltZW91dCAtPlxuICAgICAgICBncm91cCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IgJy5ncm91cCdcbiAgICAgICAgZ3JvdXAuY2hlY2tlZCA9IGNvbnZzZXR0aW5ncy5ncm91cCBpZiBncm91cFxuICAgIG51bGxcblxuaW5wdXRTZXRWYWx1ZSA9IChzZWwsIHZhbCkgLT5cbiAgICBzZXRUaW1lb3V0IC0+XG4gICAgICAgIGVsID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciBzZWxcbiAgICAgICAgZWwudmFsdWUgPSB2YWwgaWYgZWwgIT0gbnVsbFxuICAgICwgMVxuICAgIG51bGxcblxubW9kdWxlLmV4cG9ydHMgPSB2aWV3IChtb2RlbHMpIC0+XG4gICAge3ZpZXdzdGF0ZSwgY29udnNldHRpbmdzLCBlbnRpdHksIGNvbnZ9ID0gbW9kZWxzXG5cbiAgICBlZGl0aW5nID0gY29udnNldHRpbmdzLmlkICE9IG51bGxcbiAgICBjb252ZXJzYXRpb24gPSBjb252W3ZpZXdzdGF0ZS5zZWxlY3RlZENvbnZdXG5cbiAgICBkaXYgY2xhc3M6ICdjb252YWRkJywgLT5cbiAgICAgICAgaWYgZWRpdGluZ1xuICAgICAgICAgICAgaDEgaTE4bi5fXyAnY29udmVyc2F0aW9uLmVkaXQ6Q29udmVyc2F0aW9uIGVkaXQnXG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIGgxIGkxOG4uX18gJ2NvbnZlcnNhdGlvbi5uZXc6TmV3IGNvbnZlcnNhdGlvbidcblxuICAgICAgICBzdHlsZSA9IHt9XG4gICAgICAgIGlmIG5vdCBjb252c2V0dGluZ3MuZ3JvdXBcbiAgICAgICAgICAgIHN0eWxlID0gZGlzcGxheTogJ25vbmUnXG5cbiAgICAgICAgZGl2IGNsYXNzOiAnaW5wdXQnLCB7c3R5bGV9LCAtPlxuICAgICAgICAgICAgZGl2IC0+XG4gICAgICAgICAgICAgICAgaW5wdXRcbiAgICAgICAgICAgICAgICAgICAgY2xhc3M6ICduYW1lLWlucHV0J1xuICAgICAgICAgICAgICAgICAgICBzdHlsZTogc3R5bGVcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI6IGkxOG4uX18gJ2NvbnZlcnNhdGlvbi5uYW1lOkNvbnZlcnNhdGlvbiBuYW1lJ1xuICAgICAgICAgICAgICAgICAgICBvbmtleXVwOiAoZSkgLT5cbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbiAnY29udmVyc2F0aW9ubmFtZScsIGUuY3VycmVudFRhcmdldC52YWx1ZVxuXG4gICAgICAgIGRpdiBjbGFzczogJ2lucHV0JywgLT5cbiAgICAgICAgICAgIGRpdiAtPlxuICAgICAgICAgICAgICAgIGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzOiAnc2VhcmNoLWlucHV0J1xuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcjogaTE4bi5fXyAnY29udmVyc2F0aW9uLnNlYXJjaDpTZWFyY2ggcGVvcGxlJ1xuICAgICAgICAgICAgICAgICAgICBvbmtleXVwOiAoZSkgLT5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNoaWxsZWRhY3Rpb24gJ3NlYXJjaGVudGl0aWVzJywgZS5jdXJyZW50VGFyZ2V0LnZhbHVlLCA3XG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb24gJ2NvbnZlcnNhdGlvbnF1ZXJ5JywgZS5jdXJyZW50VGFyZ2V0LnZhbHVlLCA3XG5cbiAgICAgICAgZGl2IGNsYXNzOiAnaW5wdXQnLCAtPlxuICAgICAgICAgICAgZGl2IC0+XG4gICAgICAgICAgICAgICAgcCAtPlxuICAgICAgICAgICAgICAgICAgICBvcHRzID1cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdjaGVja2JveCdcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzOiAnZ3JvdXAnXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZTogeyB3aWR0aDogJ2F1dG8nLCAnbWFyZ2luLXJpZ2h0JzogJzVweCcgfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25jaGFuZ2U6IChlKSAtPiBhY3Rpb24gICAndG9nZ2xlZ3JvdXAnXG4gICAgICAgICAgICAgICAgICAgIGlmIGNvbnZzZXR0aW5ncy5zZWxlY3RlZEVudGl0aWVzLmxlbmd0aCAhPSAxXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRzLmRpc2FibGVkID0gJ2Rpc2FibGVkJ1xuICAgICAgICAgICAgICAgICAgICBpbnB1dCBvcHRzXG4gICAgICAgICAgICAgICAgICAgIGkxOG4uX18gJ2NvbnZlcnNhdGlvbi5tdWx0aXVzZXI6Q3JlYXRlIG11bHRpdXNlciBjaGF0J1xuXG5cbiAgICAgICAgdWwgLT5cbiAgICAgICAgICAgIGNvbnZzZXR0aW5ncy5zZWxlY3RlZEVudGl0aWVzLmZvckVhY2ggKHIpIC0+XG4gICAgICAgICAgICAgICAgY2lkID0gcj8uaWQ/LmNoYXRfaWRcbiAgICAgICAgICAgICAgICBlbWFpbCA9IChyLnByb3BlcnRpZXM/LmVtYWlsP1swXSA/IGVudGl0eVtjaWRdPy5lbWFpbHM/WzBdKTtcbiAgICAgICAgICAgICAgICBsaSBjbGFzczogJ3NlbGVjdGVkJywgdGl0bGU6IGVtYWlsLCAtPlxuICAgICAgICAgICAgICAgICAgICBkcmF3QXZhdGFyIGNpZCwgdmlld3N0YXRlLCBlbnRpdHlcbiAgICAgICAgICAgICAgICAgICAgLCAoci5wcm9wZXJ0aWVzPy5waG90b191cmwgPyBlbnRpdHlbY2lkXT8ucGhvdG9fdXJsKVxuICAgICAgICAgICAgICAgICAgICAsIGVtYWlsXG4gICAgICAgICAgICAgICAgICAgICwgKGlmIHIucHJvcGVydGllcz8gdGhlbiBpbml0aWFsc29mIHIucHJvcGVydGllcz8pXG4gICAgICAgICAgICAgICAgICAgIHAgbmFtZW9mIHIucHJvcGVydGllc1xuICAgICAgICAgICAgICAgICwgb25jbGljazooZSkgLT4gaWYgbm90IGVkaXRpbmcgdGhlbiBhY3Rpb24gJ2Rlc2VsZWN0ZW50aXR5JywgclxuXG4gICAgICAgICAgICBzZWxlY3RlZF9pZHMgPSAodW5pcXVlKGMpIGZvciBjIGluIGNvbnZzZXR0aW5ncy5zZWxlY3RlZEVudGl0aWVzKVxuXG4gICAgICAgICAgICBjb252c2V0dGluZ3Muc2VhcmNoZWRFbnRpdGllcy5mb3JFYWNoIChyKSAtPlxuICAgICAgICAgICAgICAgIGNpZCA9IHI/LmlkPy5jaGF0X2lkXG4gICAgICAgICAgICAgICAgZW1haWwgPSAoci5wcm9wZXJ0aWVzPy5lbWFpbD9bMF0gPyBlbnRpdHlbY2lkXT8uZW1haWxzP1swXSk7XG4gICAgICAgICAgICAgICAgaWYgdW5pcXVlKHIpIGluIHNlbGVjdGVkX2lkcyB0aGVuIHJldHVyblxuICAgICAgICAgICAgICAgIGxpIHRpdGxlOiBlbWFpbCwgLT5cbiAgICAgICAgICAgICAgICAgICAgZHJhd0F2YXRhciBjaWQsIHZpZXdzdGF0ZSwgZW50aXR5XG4gICAgICAgICAgICAgICAgICAgICwgKHIucHJvcGVydGllcz8ucGhvdG9fdXJsID8gZW50aXR5W2NpZF0/LnBob3RvX3VybClcbiAgICAgICAgICAgICAgICAgICAgLCBlbWFpbFxuICAgICAgICAgICAgICAgICAgICAsIChpZiByLnByb3BlcnRpZXM/IHRoZW4gaW5pdGlhbHNvZiByLnByb3BlcnRpZXM/KVxuICAgICAgICAgICAgICAgICAgICBwIG5hbWVvZiByLnByb3BlcnRpZXNcbiAgICAgICAgICAgICAgICAsIG9uY2xpY2s6KGUpIC0+IGFjdGlvbiAnc2VsZWN0ZW50aXR5JywgclxuXG4gICAgICAgIGlmIGVkaXRpbmdcbiAgICAgICAgICAgIGRpdiBjbGFzczonbGVhdmUnLCAtPlxuICAgICAgICAgICAgICAgIGlmIGNvbnZlcnNhdGlvbj8udHlwZT8uaW5kZXhPZignT05FX1RPX09ORScpID4gMFxuICAgICAgICAgICAgICAgICAgICBkaXYgY2xhc3M6J2J1dHRvbidcbiAgICAgICAgICAgICAgICAgICAgLCB0aXRsZTogaTE4bi5fXygnY29udmVyc2F0aW9uLmRlbGV0ZTpEZWxldGUgY29udmVyc2F0aW9uJylcbiAgICAgICAgICAgICAgICAgICAgLCBvbmNsaWNrOm9uY2xpY2thY3Rpb24oJ2RlbGV0ZWNvbnYnKSwgLT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHNwYW4gY2xhc3M6J21hdGVyaWFsLWljb25zJywgJ2Nsb3NlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgc3BhbiBpMThuLl9fKCdjb252ZXJzYXRpb24uZGVsZXRlOkRlbGV0ZSBjb252ZXJzYXRpb24nKVxuICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgZGl2IGNsYXNzOididXR0b24nXG4gICAgICAgICAgICAgICAgICAgICwgdGl0bGU6IGkxOG4uX18oJ2NvbnZlcnNhdGlvbi5sZWF2ZTpMZWF2ZSBjb252ZXJzYXRpb24nKVxuICAgICAgICAgICAgICAgICAgICAsIG9uY2xpY2s6b25jbGlja2FjdGlvbignbGVhdmVjb252JyksIC0+XG4gICAgICAgICAgICAgICAgICAgICAgICBzcGFuIGNsYXNzOidtYXRlcmlhbC1pY29ucycsICdjbG9zZSdcbiAgICAgICAgICAgICAgICAgICAgICAgIHNwYW4gaTE4bi5fXygnY29udmVyc2F0aW9uLmxlYXZlOkxlYXZlIGNvbnZlcnNhdGlvbicpXG5cbiAgICAgICAgZGl2IGNsYXNzOid2YWxpZGF0ZScsIC0+XG4gICAgICAgICAgICBkaXNhYmxlZCA9IG51bGxcbiAgICAgICAgICAgIGlmIGNvbnZzZXR0aW5ncy5zZWxlY3RlZEVudGl0aWVzLmxlbmd0aCA8PSAwXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQgPSAgZGlzYWJsZWQ6ICdkaXNhYmxlZCdcbiAgICAgICAgICAgIGRpdiBkaXNhYmxlZCwgY2xhc3M6J2J1dHRvbidcbiAgICAgICAgICAgICwgb25jbGljazpvbmNsaWNrYWN0aW9uKCdzYXZlY29udmVyc2F0aW9uJyksIC0+XG4gICAgICAgICAgICAgICAgc3BhbiBjbGFzczonbWF0ZXJpYWwtaWNvbnMnLCAnZG9uZSdcbiAgICAgICAgICAgICAgICBzcGFuIGkxOG4uX18gXCJhY3Rpb25zLm9rOk9LXCJcblxuICAgICAgICBtYXlSZXN0b3JlSW5pdGlhbFZhbHVlcyBtb2RlbHNcblxub25jbGlja2FjdGlvbiA9IChhKSAtPiAoZXYpIC0+IGFjdGlvbiBhXG4iXX0=
