(function() {
  // some unused icons/actions
  //    {icon:'icon-user-add', action:'adduser'}
  //    {icon:'icon-pencil',   action:'renameconv'}
  //    {icon:'icon-videocam', action:'videocall'}
  //    {icon:'icon-phone',    action:'voicecall'}
  var onclickaction;

  onclickaction = function(a) {
    return function(ev) {
      return action(a);
    };
  };

  module.exports = view(function(models) {
    var c, conv, viewstate;
    ({conv, viewstate} = models);
    c = conv[viewstate.selectedConv];
    return div({
      class: 'controls'
    }, function() {
      return div({
        class: 'button',
        title: i18n.__('conversation.add:Add new conversation')
      }, {
        onclick: onclickaction('addconversation')
      }, function() {
        return span({
          class: 'material-icons'
        }, 'add');
      });
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvdmlld3MvY29udHJvbHMuanMiLCJzb3VyY2VzIjpbInVpL3ZpZXdzL2NvbnRyb2xzLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUFBOzs7OztBQUFBLE1BQUE7O0VBT0EsYUFBQSxHQUFnQixRQUFBLENBQUMsQ0FBRCxDQUFBO1dBQU8sUUFBQSxDQUFDLEVBQUQsQ0FBQTthQUFRLE1BQUEsQ0FBTyxDQUFQO0lBQVI7RUFBUDs7RUFFaEIsTUFBTSxDQUFDLE9BQVAsR0FBaUIsSUFBQSxDQUFLLFFBQUEsQ0FBQyxNQUFELENBQUE7QUFDbEIsUUFBQSxDQUFBLEVBQUEsSUFBQSxFQUFBO0lBQUEsQ0FBQSxDQUFDLElBQUQsRUFBTyxTQUFQLENBQUEsR0FBb0IsTUFBcEI7SUFDQSxDQUFBLEdBQUksSUFBSyxDQUFBLFNBQVMsQ0FBQyxZQUFWO1dBQ1QsR0FBQSxDQUFJO01BQUEsS0FBQSxFQUFNO0lBQU4sQ0FBSixFQUFzQixRQUFBLENBQUEsQ0FBQTthQUNsQixHQUFBLENBQUk7UUFBQSxLQUFBLEVBQU0sUUFBTjtRQUFnQixLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx1Q0FBUjtNQUF2QixDQUFKLEVBQ0k7UUFBQSxPQUFBLEVBQVEsYUFBQSxDQUFjLGlCQUFkO01BQVIsQ0FESixFQUM4QyxRQUFBLENBQUEsQ0FBQTtlQUFHLElBQUEsQ0FBSztVQUFBLEtBQUEsRUFBTTtRQUFOLENBQUwsRUFBNkIsS0FBN0I7TUFBSCxDQUQ5QztJQURrQixDQUF0QjtFQUhrQixDQUFMO0FBVGpCIiwic291cmNlc0NvbnRlbnQiOlsiXG4jIHNvbWUgdW51c2VkIGljb25zL2FjdGlvbnNcbiMgICAge2ljb246J2ljb24tdXNlci1hZGQnLCBhY3Rpb246J2FkZHVzZXInfVxuIyAgICB7aWNvbjonaWNvbi1wZW5jaWwnLCAgIGFjdGlvbjoncmVuYW1lY29udid9XG4jICAgIHtpY29uOidpY29uLXZpZGVvY2FtJywgYWN0aW9uOid2aWRlb2NhbGwnfVxuIyAgICB7aWNvbjonaWNvbi1waG9uZScsICAgIGFjdGlvbjondm9pY2VjYWxsJ31cblxub25jbGlja2FjdGlvbiA9IChhKSAtPiAoZXYpIC0+IGFjdGlvbiBhXG5cbm1vZHVsZS5leHBvcnRzID0gdmlldyAobW9kZWxzKSAtPlxuICAgIHtjb252LCB2aWV3c3RhdGV9ID0gbW9kZWxzXG4gICAgYyA9IGNvbnZbdmlld3N0YXRlLnNlbGVjdGVkQ29udl1cbiAgICBkaXYgY2xhc3M6J2NvbnRyb2xzJywgLT5cbiAgICAgICAgZGl2IGNsYXNzOididXR0b24nLCB0aXRsZTogaTE4bi5fXygnY29udmVyc2F0aW9uLmFkZDpBZGQgbmV3IGNvbnZlcnNhdGlvbicpLFxuICAgICAgICAgICAgb25jbGljazpvbmNsaWNrYWN0aW9uKCdhZGRjb252ZXJzYXRpb24nKSwgLT4gc3BhbiBjbGFzczonbWF0ZXJpYWwtaWNvbnMnLCAnYWRkJ1xuIl19
