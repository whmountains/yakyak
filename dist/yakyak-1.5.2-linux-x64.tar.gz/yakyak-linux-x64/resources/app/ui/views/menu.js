(function() {
  var Menu, acceleratorMap, getAccelerator, isDarwin, isLinux, isNotDarwin, notificationCenterSupportsSound, notifierSupportsSound, platform, remote, templateEdit, templateMenu, templateView, templateWindow, templateYakYak;

  remote = require('electron').remote;

  Menu = remote.Menu;

  ({notificationCenterSupportsSound} = require('../util'));

  platform = require('os').platform();

  // to reduce number of == comparisons
  isDarwin = platform === 'darwin';

  isLinux = platform === 'linux';

  isNotDarwin = platform !== 'darwin';

  // true if it does, false otherwise
  notifierSupportsSound = notificationCenterSupportsSound();

  acceleratorMap = {
    // MacOSX specific
    hideyakyak: {
      default: 'CmdOrCtrl+H'
    },
    hideothers: {
      default: '',
      darwin: 'Command+Shift+H'
    },
    showall: {
      default: '',
      darwin: ''
    },
    openinspector: {
      default: 'CmdOrCtrl+Alt+I'
    },
    close: {
      default: '',
      darwin: 'Command+W'
    },
    // Common shortcuts
    quit: {
      default: 'CmdOrCtrl+Q'
    },
    zoomin: {
      default: 'CmdOrCtrl+Plus'
    },
    // Platform specific
    previousconversation: {
      default: 'Ctrl+K',
      darwin: 'Command+Shift+Tab'
    },
    nextconversation: {
      default: 'Control+J',
      darwin: 'Command+Tab'
    },
    conversation1: {
      default: 'Alt+1',
      darwin: 'Command+1'
    },
    conversation2: {
      default: 'Alt+2',
      darwin: 'Command+2'
    },
    conversation3: {
      default: 'Alt+3',
      darwin: 'Command+3'
    },
    conversation4: {
      default: 'Alt+4',
      darwin: 'Command+4'
    },
    conversation5: {
      default: 'Alt+5',
      darwin: 'Command+5'
    },
    conversation6: {
      default: 'Alt+6',
      darwin: 'Command+6'
    },
    conversation7: {
      default: 'Alt+7',
      darwin: 'Command+7'
    },
    conversation8: {
      default: 'Alt+8',
      darwin: 'Command+8'
    },
    conversation9: {
      default: 'Alt+9',
      darwin: 'Command+9'
    }
  };

  getAccelerator = function(key) {
    if (acceleratorMap[key][platform] != null) {
      return acceleratorMap[key][platform];
    } else {
      return acceleratorMap[key]['default'];
    }
  };

  templateYakYak = function(viewstate) {
    return [
      isDarwin ? {
        label: i18n.__('menu.help.about.title:About YakYak'),
        click: function(it) {
          return action('show-about');
        }
      } : void 0,
      {
        type: 'checkbox',
        label: i18n.__('menu.help.about.startup:Open on Startup'),
        checked: viewstate.openOnSystemStartup,
        click: function(it) {
          return action('openonsystemstartup',
      it.checked);
        }
      },
      isDarwin ? {
        //{ type: 'separator' }
        // { label: 'Preferences...', accelerator: 'Command+,',
        // click: => delegate.openConfig() }
        type: 'separator'
      } : void 0,
      {
        label: i18n.__('menu.file.hide:Hide YakYak'),
        accelerator: getAccelerator('hideyakyak'),
        role: isDarwin ? 'hide' : 'minimize'
      },
      isDarwin ? {
        label: i18n.__('menu.file.hide_others:Hide Others'),
        accelerator: getAccelerator('hideothers'),
        role: 'hideothers'
      } : void 0,
      isDarwin ? { // old show all
        label: i18n.__("menu.file.show:Show All"),
        role: 'unhide'
      } : void 0,
      {
        type: 'separator'
      },
      {
        label: i18n.__('menu.file.inspector:Open Inspector'),
        accelerator: getAccelerator('openinspector'),
        click: function() {
          return action('devtools');
        }
      },
      {
        type: 'separator'
      },
      {
        label: i18n.__('menu.file.logout:Logout'),
        click: function() {
          return action('logout');
        },
        enabled: viewstate.loggedin
      },
      {
        label: i18n.__('menu.file.quit:Quit'),
        accelerator: getAccelerator('quit'),
        click: function() {
          return action('quit');
        }
      }
    ].filter(function(n) {
      return n !== void 0;
    });
  };

  templateEdit = function(viewstate) {
    var languages, loc;
    languages = (function() {
      var i, len, ref, results;
      ref = i18n.getLocales();
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        loc = ref[i];
        if (loc.length < 2) {
          continue;
        }
        results.push({
          label: i18n.getCatalog(loc).__MyLocaleLanguage__,
          type: 'radio',
          checked: viewstate.language === loc,
          value: loc,
          click: function(it) {
            return action('changelanguage', it.value);
          }
        });
      }
      return results;
    })();
    languages = languages.filter(function(n) {
      return n !== void 0;
    });
    return [
      {
        label: i18n.__('menu.edit.undo:Undo'),
        role: 'undo'
      },
      {
        label: i18n.__('menu.edit.redo:Redo'),
        role: 'redo'
      },
      {
        type: 'separator'
      },
      {
        label: i18n.__('menu.edit.cut:Cut'),
        role: 'cut'
      },
      {
        label: i18n.__('menu.edit.copy:Copy'),
        role: 'copy'
      },
      {
        label: i18n.__('menu.edit.paste:Paste'),
        role: 'paste'
      },
      {
        label: i18n.__('menu.edit.select_all:Select All'),
        role: 'selectall'
      },
      {
        type: 'separator'
      },
      {
        label: i18n.__('menu.edit.language:Language'),
        submenu: languages
      },
      {
        label: i18n.__('menu.edit.dateformat:Use system date format'),
        type: 'checkbox',
        checked: viewstate.useSystemDateFormat,
        enabled: true,
        click: function(it) {
          return action('setusesystemdateformat',
      it.checked);
        }
      }
    ].filter(function(n) {
      return n !== void 0;
    });
  };

  templateView = function(viewstate) {
    return [
      {
        label: i18n.__('menu.view.conversation.title:Conversation List'),
        submenu: [
          {
            type: 'checkbox',
            label: i18n.__('menu.view.conversation.thumbnails.show:Show Thumbnails'),
            checked: viewstate.showConvThumbs,
            enabled: viewstate.loggedin,
            click: function(it) {
              return action('showconvthumbs',
          it.checked);
            }
          },
          {
            type: 'checkbox',
            label: i18n.__('menu.view.conversation.thumbnails.only:Show Thumbnails Only'),
            checked: viewstate.showConvMin,
            enabled: viewstate.loggedin,
            click: function(it) {
              return action('showconvmin',
          it.checked);
            }
          },
          {
            type: 'checkbox',
            label: i18n.__('menu.view.conversation.thumbnails.animated:Show Animated Thumbnails'),
            checked: viewstate.showAnimatedThumbs,
            enabled: viewstate.loggedin,
            click: function(it) {
              return action('showanimatedthumbs',
          it.checked);
            }
          },
          {
            type: 'checkbox',
            label: i18n.__('menu.view.conversation.timestamp:Show Conversation Timestamp'),
            checked: viewstate.showConvTime,
            enabled: viewstate.loggedin && !viewstate.showConvMin,
            click: function(it) {
              return action('showconvtime',
          it.checked);
            }
          },
          {
            type: 'checkbox',
            label: i18n.__('menu.view.conversation.last:Show Conversation Last Message'),
            checked: viewstate.showConvLast,
            enabled: viewstate.loggedin && !viewstate.showConvMin,
            click: function(it) {
              return action('showconvlast',
          it.checked);
            }
          }
        ]
      },
      {
        label: i18n.__('menu.view.notification.title:Pop-Up Notification'),
        submenu: [
          {
            type: 'checkbox',
            label: i18n.__('menu.view.notification.show:Show notifications'),
            checked: viewstate.showPopUpNotifications,
            enabled: viewstate.loggedin,
            click: function(it) {
              return action('showpopupnotifications',
          it.checked);
            }
          },
          {
            type: 'checkbox',
            label: i18n.__('menu.view.notification.message:Show message in notifications'),
            checked: viewstate.showMessageInNotification,
            enabled: viewstate.loggedin && viewstate.showPopUpNotifications,
            click: function(it) {
              return action('showmessageinnotification',
          it.checked);
            }
          },
          {
            type: 'checkbox',
            label: i18n.__('menu.view.notification.username:Show username in notifications'),
            checked: viewstate.showUsernameInNotification,
            enabled: viewstate.loggedin && viewstate.showPopUpNotifications,
            click: function(it) {
              return action('showusernameinnotification',
          it.checked);
            }
          },
          {
            type: 'checkbox',
            label: i18n.__((isDarwin ? 'menu.view.notification.avatar:Show user avatar icon in notifications' : 'menu.view.notification.icon:Show YakYak icon in notifications')),
            enabled: viewstate.loggedin && viewstate.showPopUpNotifications,
            checked: viewstate.showIconNotification,
            click: function(it) {
              return action('showiconnotification',
          it.checked);
            }
          },
          {
            type: 'checkbox',
            label: i18n.__('menu.view.notification.mute:Disable sound in notifications'),
            checked: viewstate.muteSoundNotification,
            enabled: viewstate.loggedin && viewstate.showPopUpNotifications,
            click: function(it) {
              return action('mutesoundnotification',
          it.checked);
            }
          },
          notifierSupportsSound ? {
            type: 'checkbox',
            label: i18n.__('menu.view.notification.custom_sound:Use YakYak custom sound for notifications'),
            checked: viewstate.forceCustomSound,
            enabled: viewstate.loggedin && viewstate.showPopUpNotifications && !viewstate.muteSoundNotification,
            click: function(it) {
              return action('forcecustomsound',
          it.checked);
            }
          } : void 0
        ].filter(function(n) {
          return n !== void 0;
        })
      },
      {
        type: 'checkbox',
        label: i18n.__('menu.view.emoji:Convert text to emoji'),
        checked: viewstate.convertEmoji,
        enabled: viewstate.loggedin,
        click: function(it) {
          return action('convertemoji',
      it.checked);
        }
      },
      {
        type: 'checkbox',
        label: i18n.__('menu.view.suggestemoji:Suggest emoji on typing'),
        checked: viewstate.suggestEmoji,
        enabled: viewstate.loggedin,
        click: function(it) {
          return action('suggestemoji',
      it.checked);
        }
      },
      {
        label: i18n.__('menu.view.color_scheme.title:Color Scheme'),
        submenu: [
          {
            label: i18n.__('menu.view.color_scheme.default:Original'),
            type: 'radio',
            checked: viewstate.colorScheme === 'default',
            click: function() {
              return action('changetheme',
          'default');
            }
          },
          {
            label: i18n.__('menu.view.color_scheme.blue:Blue'),
            type: 'radio',
            checked: viewstate.colorScheme === 'blue',
            click: function() {
              return action('changetheme',
          'blue');
            }
          },
          {
            label: i18n.__('menu.view.color_scheme.dark:Dark'),
            type: 'radio',
            checked: viewstate.colorScheme === 'dark',
            click: function() {
              return action('changetheme',
          'dark');
            }
          },
          {
            label: i18n.__('menu.view.color_scheme.material:Material'),
            type: 'radio',
            checked: viewstate.colorScheme === 'material',
            click: function() {
              return action('changetheme',
          'material');
            }
          }
        ]
      },
      {
        label: i18n.__('menu.view.font.title:Font Size'),
        submenu: [
          {
            label: i18n.__('menu.view.font.extra_small:Extra Small'),
            type: 'radio',
            checked: viewstate.fontSize === 'x-small',
            click: function() {
              return action('changefontsize',
          'x-small');
            }
          },
          {
            label: i18n.__('menu.view.font.small:Small'),
            type: 'radio',
            checked: viewstate.fontSize === 'small',
            click: function() {
              return action('changefontsize',
          'small');
            }
          },
          {
            label: i18n.__('menu.view.font.medium:Medium'),
            type: 'radio',
            checked: viewstate.fontSize === 'medium',
            click: function() {
              return action('changefontsize',
          'medium');
            }
          },
          {
            label: i18n.__('menu.view.font.large:Large'),
            type: 'radio',
            checked: viewstate.fontSize === 'large',
            click: function() {
              return action('changefontsize',
          'large');
            }
          },
          {
            label: i18n.__('menu.view.font.extra_large:Extra Large'),
            type: 'radio',
            checked: viewstate.fontSize === 'x-large',
            click: function() {
              return action('changefontsize',
          'x-large');
            }
          }
        ]
      },
      {
        label: i18n.__('menu.view.fullscreen:Toggle Fullscreen'),
        role: 'togglefullscreen'
      },
      {
        label: i18n.__('menu.view.zoom.in:Zoom in'),
        // seee https://github.com/atom/electron/issues/1507
        role: 'zoomin'
      },
      {
        label: i18n.__('menu.view.zoom.out:Zoom out'),
        role: 'zoomout'
      },
      {
        label: i18n.__('menu.view.zoom.reset:Actual size'),
        role: 'resetzoom'
      },
      {
        type: 'separator'
      },
      {
        label: i18n.__('menu.view.conversation.previous:Previous Conversation'),
        accelerator: getAccelerator('previousconversation'),
        enabled: viewstate.loggedin,
        click: function() {
          return action('selectNextConv',
      -1);
        }
      },
      {
        label: i18n.__('menu.view.conversation.next:Next Conversation'),
        accelerator: getAccelerator('nextconversation'),
        enabled: viewstate.loggedin,
        click: function() {
          return action('selectNextConv',
      +1);
        }
      },
      {
        label: i18n.__('menu.view.conversation.select:Select Conversation'),
        enabled: viewstate.loggedin,
        submenu: [
          {
            label: i18n.__('conversation.numbered:Conversation %d',
          1),
            accelerator: getAccelerator('conversation1'),
            click: function() {
              return action('selectConvIndex',
          0);
            }
          },
          {
            label: i18n.__('conversation.numbered:Conversation %d',
          2),
            accelerator: getAccelerator('conversation2'),
            click: function() {
              return action('selectConvIndex',
          1);
            }
          },
          {
            label: i18n.__('conversation.numbered:Conversation %d',
          3),
            accelerator: getAccelerator('conversation3'),
            click: function() {
              return action('selectConvIndex',
          2);
            }
          },
          {
            label: i18n.__('conversation.numbered:Conversation %d',
          4),
            accelerator: getAccelerator('conversation4'),
            click: function() {
              return action('selectConvIndex',
          3);
            }
          },
          {
            label: i18n.__('conversation.numbered:Conversation %d',
          5),
            accelerator: getAccelerator('conversation5'),
            click: function() {
              return action('selectConvIndex',
          4);
            }
          },
          {
            label: i18n.__('conversation.numbered:Conversation %d',
          6),
            accelerator: getAccelerator('conversation6'),
            click: function() {
              return action('selectConvIndex',
          5);
            }
          },
          {
            label: i18n.__('conversation.numbered:Conversation %d',
          7),
            accelerator: getAccelerator('conversation7'),
            click: function() {
              return action('selectConvIndex',
          6);
            }
          },
          {
            label: i18n.__('conversation.numbered:Conversation %d',
          8),
            accelerator: getAccelerator('conversation8'),
            click: function() {
              return action('selectConvIndex',
          7);
            }
          },
          {
            label: i18n.__('conversation.numbered:Conversation %d',
          9),
            accelerator: getAccelerator('conversation9'),
            click: function() {
              return action('selectConvIndex',
          8);
            }
          }
        ]
      },
      {
        type: 'separator'
      },
      {
        label: i18n.__('menu.view.tray.main:Tray icon'),
        submenu: [
          {
            label: i18n.__('menu.view.tray.show_tray:Show tray icon'),
            type: 'checkbox',
            enabled: !viewstate.hidedockicon,
            checked: viewstate.showtray,
            click: function() {
              return action('toggleshowtray');
            }
          },
          {
            label: i18n.__("menu.view.tray.start_minimize:Start minimized to tray"),
            type: "checkbox",
            enabled: viewstate.showtray,
            checked: viewstate.startminimizedtotray,
            click: function() {
              return action('togglestartminimizedtotray');
            }
          },
          {
            label: i18n.__("menu.view.tray.close:Close to tray"),
            type: "checkbox",
            enabled: viewstate.showtray,
            checked: viewstate.closetotray,
            click: function() {
              return action('toggleclosetotray');
            }
          }
        ]
      },
      {
        label: i18n.__('menu.view.escape.title:Escape key behavior'),
        submenu: [
          {
            label: i18n.__('menu.view.escape.hide:Hides window'),
            type: 'radio',
            enabled: viewstate.showtray,
            checked: viewstate.showtray && !viewstate.escapeClearsInput,
            click: function() {
              return action('setescapeclearsinput',
          false);
            }
          },
          {
            label: i18n.__('menu.view.escape.clear:Clears input') + (!viewstate.showtray ? ` (${i18n.__('menu.view.escape.default:default when tray is not showing')})` : ''),
            type: 'radio',
            enabled: viewstate.showtray,
            checked: !viewstate.showtray || viewstate.escapeClearsInput,
            click: function() {
              return action('setescapeclearsinput',
          true);
            }
          }
        ]
      },
      isDarwin ? {
        label: i18n.__('menu.view.hide_dock:Hide Dock icon'),
        type: 'checkbox',
        enabled: viewstate.showtray,
        checked: viewstate.hidedockicon,
        click: function() {
          return action('togglehidedockicon');
        }
      } : void 0
    ].filter(function(n) {
      return n !== void 0;
    });
  };

  templateWindow = function(viewstate) {
    return [
      {
        label: i18n.__('menu.window.minimize:Minimize'),
        role: 'minimize'
      },
      {
        label: i18n.__('menu.window.close:Close'),
        accelerator: getAccelerator('close'),
        role: 'close'
      },
      {
        label: i18n.__('menu.view.tray.toggle_minimize:Toggle window show/hide'),
        click: function() {
          return action('togglewindow');
        }
      },
      {
        type: 'separator'
      },
      {
        label: i18n.__('menu.window.front:Bring All to Front'),
        role: 'front'
      }
    ];
  };

  // note: electron framework currently does not support undefined Menu
  //  entries, which requires a filter for undefined at menu/submenu entry
  //  to remove them

  //  [.., undefined, ..., undefined,.. ].filter (n) -> n != undefined

  templateMenu = function(viewstate) {
    return [
      isLinux ? {
        label: ''
      } : void 0,
      {
        label: i18n.__('menu.file.title:YakYak'),
        submenu: templateYakYak(viewstate)
      },
      {
        label: i18n.__('menu.edit.title:Edit'),
        submenu: templateEdit(viewstate)
      },
      {
        label: i18n.__('menu.view.title:View'),
        submenu: templateView(viewstate)
      },
      !isDarwin ? {
        label: i18n.__('menu.help.title:Help'),
        submenu: [
          {
            label: i18n.__('menu.help.about.title:About YakYak'),
            click: function() {
              return action('show-about');
            }
          }
        ]
      } : void 0,
      isDarwin ? {
        label: i18n.__('menu.window.title:Window'),
        submenu: templateWindow(viewstate)
      } : void 0
    ].filter(function(n) {
      return n !== void 0;
    });
  };

  module.exports = function(viewstate) {
    return Menu.setApplicationMenu(Menu.buildFromTemplate(templateMenu(viewstate)));
  };

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvdmlld3MvbWVudS5qcyIsInNvdXJjZXMiOlsidWkvdmlld3MvbWVudS5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLElBQUEsRUFBQSxjQUFBLEVBQUEsY0FBQSxFQUFBLFFBQUEsRUFBQSxPQUFBLEVBQUEsV0FBQSxFQUFBLCtCQUFBLEVBQUEscUJBQUEsRUFBQSxRQUFBLEVBQUEsTUFBQSxFQUFBLFlBQUEsRUFBQSxZQUFBLEVBQUEsWUFBQSxFQUFBLGNBQUEsRUFBQTs7RUFBQSxNQUFBLEdBQVMsT0FBQSxDQUFRLFVBQVIsQ0FBbUIsQ0FBQzs7RUFDN0IsSUFBQSxHQUFPLE1BQU0sQ0FBQzs7RUFFZCxDQUFBLENBQUMsK0JBQUQsQ0FBQSxHQUFvQyxPQUFBLENBQVEsU0FBUixDQUFwQzs7RUFFQSxRQUFBLEdBQVcsT0FBQSxDQUFRLElBQVIsQ0FBYSxDQUFDLFFBQWQsQ0FBQSxFQUxYOzs7RUFPQSxRQUFBLEdBQVcsUUFBQSxLQUFZOztFQUN2QixPQUFBLEdBQVUsUUFBQSxLQUFZOztFQUN0QixXQUFBLEdBQWMsUUFBQSxLQUFZLFNBVDFCOzs7RUFZQSxxQkFBQSxHQUF3QiwrQkFBQSxDQUFBOztFQUV4QixjQUFBLEdBQWlCLENBQUE7O0lBRWIsVUFBQSxFQUFZO01BQUUsT0FBQSxFQUFTO0lBQVgsQ0FGQztJQUdiLFVBQUEsRUFBWTtNQUFFLE9BQUEsRUFBUyxFQUFYO01BQWUsTUFBQSxFQUFPO0lBQXRCLENBSEM7SUFJYixPQUFBLEVBQVM7TUFBRSxPQUFBLEVBQVMsRUFBWDtNQUFlLE1BQUEsRUFBTztJQUF0QixDQUpJO0lBS2IsYUFBQSxFQUFlO01BQUUsT0FBQSxFQUFTO0lBQVgsQ0FMRjtJQU1iLEtBQUEsRUFBTztNQUFFLE9BQUEsRUFBUyxFQUFYO01BQWUsTUFBQSxFQUFPO0lBQXRCLENBTk07O0lBUWIsSUFBQSxFQUFNO01BQUUsT0FBQSxFQUFTO0lBQVgsQ0FSTztJQVNiLE1BQUEsRUFBUTtNQUFFLE9BQUEsRUFBUztJQUFYLENBVEs7O0lBV2Isb0JBQUEsRUFBc0I7TUFBRSxPQUFBLEVBQVMsUUFBWDtNQUFxQixNQUFBLEVBQU87SUFBNUIsQ0FYVDtJQVliLGdCQUFBLEVBQW1CO01BQUUsT0FBQSxFQUFTLFdBQVg7TUFBd0IsTUFBQSxFQUFPO0lBQS9CLENBWk47SUFhYixhQUFBLEVBQWU7TUFBRSxPQUFBLEVBQVMsT0FBWDtNQUFvQixNQUFBLEVBQU87SUFBM0IsQ0FiRjtJQWNiLGFBQUEsRUFBZTtNQUFFLE9BQUEsRUFBUyxPQUFYO01BQW9CLE1BQUEsRUFBTztJQUEzQixDQWRGO0lBZWIsYUFBQSxFQUFlO01BQUUsT0FBQSxFQUFTLE9BQVg7TUFBb0IsTUFBQSxFQUFPO0lBQTNCLENBZkY7SUFnQmIsYUFBQSxFQUFlO01BQUUsT0FBQSxFQUFTLE9BQVg7TUFBb0IsTUFBQSxFQUFPO0lBQTNCLENBaEJGO0lBaUJiLGFBQUEsRUFBZTtNQUFFLE9BQUEsRUFBUyxPQUFYO01BQW9CLE1BQUEsRUFBTztJQUEzQixDQWpCRjtJQWtCYixhQUFBLEVBQWU7TUFBRSxPQUFBLEVBQVMsT0FBWDtNQUFvQixNQUFBLEVBQU87SUFBM0IsQ0FsQkY7SUFtQmIsYUFBQSxFQUFlO01BQUUsT0FBQSxFQUFTLE9BQVg7TUFBb0IsTUFBQSxFQUFPO0lBQTNCLENBbkJGO0lBb0JiLGFBQUEsRUFBZTtNQUFFLE9BQUEsRUFBUyxPQUFYO01BQW9CLE1BQUEsRUFBTztJQUEzQixDQXBCRjtJQXFCYixhQUFBLEVBQWU7TUFBRSxPQUFBLEVBQVMsT0FBWDtNQUFvQixNQUFBLEVBQU87SUFBM0I7RUFyQkY7O0VBd0JqQixjQUFBLEdBQWlCLFFBQUEsQ0FBQyxHQUFELENBQUE7SUFDYixJQUFHLHFDQUFIO2FBQ0ksY0FBZSxDQUFBLEdBQUEsQ0FBSyxDQUFBLFFBQUEsRUFEeEI7S0FBQSxNQUFBO2FBR0ksY0FBZSxDQUFBLEdBQUEsQ0FBSyxDQUFBLFNBQUEsRUFIeEI7O0VBRGE7O0VBTWpCLGNBQUEsR0FBaUIsUUFBQSxDQUFDLFNBQUQsQ0FBQTtXQUViO01BSVMsUUFITCxHQUFBO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsb0NBQVIsQ0FEWDtRQUVJLEtBQUEsRUFBTyxRQUFBLENBQUMsRUFBRCxDQUFBO2lCQUFRLE1BQUEsQ0FBTyxZQUFQO1FBQVI7TUFGWCxDQUFBLEdBQUEsTUFESjtNQUtJO1FBQ0ksSUFBQSxFQUFNLFVBRFY7UUFFSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx5Q0FBUixDQUZYO1FBR0ksT0FBQSxFQUFTLFNBQVMsQ0FBQyxtQkFIdkI7UUFJSSxLQUFBLEVBQU8sUUFBQSxDQUFDLEVBQUQsQ0FBQTtpQkFBUSxNQUFBLENBQU8scUJBQVA7TUFBOEIsRUFBRSxDQUFDLE9BQWpDO1FBQVI7TUFKWCxDQUxKO01BYzZCLFFBQXpCLEdBQUEsQ0FBQTs7OztRQUFFLElBQUEsRUFBTTtNQUFSLENBQUEsR0FBQSxNQWRKO01BZUk7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSw0QkFBUixDQURYO1FBRUksV0FBQSxFQUFhLGNBQUEsQ0FBZSxZQUFmLENBRmpCO1FBR0ksSUFBQSxFQUFTLFFBQUgsR0FBaUIsTUFBakIsR0FBNkI7TUFIdkMsQ0FmSjtNQXdCUyxRQUpMLEdBQUE7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxtQ0FBUixDQURYO1FBRUksV0FBQSxFQUFhLGNBQUEsQ0FBZSxZQUFmLENBRmpCO1FBR0ksSUFBQSxFQUFNO01BSFYsQ0FBQSxHQUFBLE1BcEJKO01BNEJTLFFBSEwsR0FBQSxDQUFBO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEseUJBQVIsQ0FEWDtRQUVJLElBQUEsRUFBTTtNQUZWLENBQUEsR0FBQSxNQXpCSjtNQTZCSTtRQUFFLElBQUEsRUFBTTtNQUFSLENBN0JKO01BOEJJO1FBQ0UsS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsb0NBQVIsQ0FEVDtRQUVFLFdBQUEsRUFBYSxjQUFBLENBQWUsZUFBZixDQUZmO1FBR0UsS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO2lCQUFHLE1BQUEsQ0FBTyxVQUFQO1FBQUg7TUFIVCxDQTlCSjtNQW1DSTtRQUFFLElBQUEsRUFBTTtNQUFSLENBbkNKO01Bb0NJO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEseUJBQVIsQ0FEWDtRQUVJLEtBQUEsRUFBTyxRQUFBLENBQUEsQ0FBQTtpQkFBRyxNQUFBLENBQU8sUUFBUDtRQUFILENBRlg7UUFHSSxPQUFBLEVBQVMsU0FBUyxDQUFDO01BSHZCLENBcENKO01BeUNJO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEscUJBQVIsQ0FEWDtRQUVJLFdBQUEsRUFBYSxjQUFBLENBQWUsTUFBZixDQUZqQjtRQUdJLEtBQUEsRUFBTyxRQUFBLENBQUEsQ0FBQTtpQkFBRyxNQUFBLENBQU8sTUFBUDtRQUFIO01BSFgsQ0F6Q0o7S0E4Q0MsQ0FBQyxNQTlDRixDQThDUyxRQUFBLENBQUMsQ0FBRCxDQUFBO2FBQU8sQ0FBQSxLQUFLO0lBQVosQ0E5Q1Q7RUFGYTs7RUFrRGpCLFlBQUEsR0FBZSxRQUFBLENBQUMsU0FBRCxDQUFBO0FBQ1gsUUFBQSxTQUFBLEVBQUE7SUFBQSxTQUFBOztBQUFZO0FBQUE7TUFBQSxLQUFBLHFDQUFBOztRQUNSLElBQUcsR0FBRyxDQUFDLE1BQUosR0FBYSxDQUFoQjtBQUNJLG1CQURKOztxQkFFQTtVQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsVUFBTCxDQUFnQixHQUFoQixDQUFvQixDQUFDLG9CQURoQztVQUVJLElBQUEsRUFBTSxPQUZWO1VBR0ksT0FBQSxFQUFTLFNBQVMsQ0FBQyxRQUFWLEtBQXNCLEdBSG5DO1VBSUksS0FBQSxFQUFPLEdBSlg7VUFLSSxLQUFBLEVBQU8sUUFBQSxDQUFDLEVBQUQsQ0FBQTttQkFDSCxNQUFBLENBQU8sZ0JBQVAsRUFBeUIsRUFBRSxDQUFDLEtBQTVCO1VBREc7UUFMWDtNQUhRLENBQUE7OztJQVdaLFNBQUEsR0FBWSxTQUFTLENBQUMsTUFBVixDQUFpQixRQUFBLENBQUMsQ0FBRCxDQUFBO2FBQU8sQ0FBQSxLQUFLO0lBQVosQ0FBakI7V0FDWjtNQUNJO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEscUJBQVIsQ0FEWDtRQUVJLElBQUEsRUFBTTtNQUZWLENBREo7TUFLSTtRQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLHFCQUFSLENBRFg7UUFFSSxJQUFBLEVBQU07TUFGVixDQUxKO01BU0k7UUFBRSxJQUFBLEVBQU07TUFBUixDQVRKO01BVUk7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxtQkFBUixDQURYO1FBRUksSUFBQSxFQUFNO01BRlYsQ0FWSjtNQWNJO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEscUJBQVIsQ0FEWDtRQUVJLElBQUEsRUFBTTtNQUZWLENBZEo7TUFrQkk7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx1QkFBUixDQURYO1FBRUksSUFBQSxFQUFNO01BRlYsQ0FsQko7TUFzQkk7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxpQ0FBUixDQURYO1FBRUksSUFBQSxFQUFNO01BRlYsQ0F0Qko7TUEwQkk7UUFBRSxJQUFBLEVBQU07TUFBUixDQTFCSjtNQTJCSTtRQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLDZCQUFSLENBRFg7UUFFSSxPQUFBLEVBQVM7TUFGYixDQTNCSjtNQStCSTtRQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLDZDQUFSLENBRFg7UUFFSSxJQUFBLEVBQU0sVUFGVjtRQUdJLE9BQUEsRUFBUyxTQUFTLENBQUMsbUJBSHZCO1FBSUksT0FBQSxFQUFTLElBSmI7UUFLSSxLQUFBLEVBQU8sUUFBQSxDQUFDLEVBQUQsQ0FBQTtpQkFBUSxNQUFBLENBQU8sd0JBQVA7TUFBaUMsRUFBRSxDQUFDLE9BQXBDO1FBQVI7TUFMWCxDQS9CSjtLQXVDQyxDQUFDLE1BdkNGLENBdUNTLFFBQUEsQ0FBQyxDQUFELENBQUE7YUFBTyxDQUFBLEtBQUs7SUFBWixDQXZDVDtFQWJXOztFQXNEZixZQUFBLEdBQWUsUUFBQSxDQUFDLFNBQUQsQ0FBQTtXQUNYO01BQ0k7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxnREFBUixDQURYO1FBRUksT0FBQSxFQUFTO1VBQ1A7WUFDSSxJQUFBLEVBQU0sVUFEVjtZQUVJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLHdEQUFSLENBRlg7WUFHSSxPQUFBLEVBQVMsU0FBUyxDQUFDLGNBSHZCO1lBSUksT0FBQSxFQUFTLFNBQVMsQ0FBQyxRQUp2QjtZQUtJLEtBQUEsRUFBTyxRQUFBLENBQUMsRUFBRCxDQUFBO3FCQUFRLE1BQUEsQ0FBTyxnQkFBUDtVQUF5QixFQUFFLENBQUMsT0FBNUI7WUFBUjtVQUxYLENBRE87VUFRUDtZQUNJLElBQUEsRUFBTSxVQURWO1lBRUksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsNkRBQVIsQ0FGWDtZQUdJLE9BQUEsRUFBUSxTQUFTLENBQUMsV0FIdEI7WUFJSSxPQUFBLEVBQVMsU0FBUyxDQUFDLFFBSnZCO1lBS0ksS0FBQSxFQUFPLFFBQUEsQ0FBQyxFQUFELENBQUE7cUJBQVEsTUFBQSxDQUFPLGFBQVA7VUFBc0IsRUFBRSxDQUFDLE9BQXpCO1lBQVI7VUFMWCxDQVJPO1VBZVA7WUFDSSxJQUFBLEVBQU0sVUFEVjtZQUVJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLHFFQUFSLENBRlg7WUFHSSxPQUFBLEVBQVEsU0FBUyxDQUFDLGtCQUh0QjtZQUlJLE9BQUEsRUFBUyxTQUFTLENBQUMsUUFKdkI7WUFLSSxLQUFBLEVBQU8sUUFBQSxDQUFDLEVBQUQsQ0FBQTtxQkFBUSxNQUFBLENBQU8sb0JBQVA7VUFBNkIsRUFBRSxDQUFDLE9BQWhDO1lBQVI7VUFMWCxDQWZPO1VBc0JQO1lBQ0ksSUFBQSxFQUFNLFVBRFY7WUFFSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSw4REFBUixDQUZYO1lBR0ksT0FBQSxFQUFRLFNBQVMsQ0FBQyxZQUh0QjtZQUlJLE9BQUEsRUFBUyxTQUFTLENBQUMsUUFBVixJQUFzQixDQUFDLFNBQVMsQ0FBQyxXQUo5QztZQUtJLEtBQUEsRUFBTyxRQUFBLENBQUMsRUFBRCxDQUFBO3FCQUFRLE1BQUEsQ0FBTyxjQUFQO1VBQXVCLEVBQUUsQ0FBQyxPQUExQjtZQUFSO1VBTFgsQ0F0Qk87VUE2QlA7WUFDSSxJQUFBLEVBQU0sVUFEVjtZQUVJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLDREQUFSLENBRlg7WUFHSSxPQUFBLEVBQVEsU0FBUyxDQUFDLFlBSHRCO1lBSUksT0FBQSxFQUFTLFNBQVMsQ0FBQyxRQUFWLElBQXNCLENBQUMsU0FBUyxDQUFDLFdBSjlDO1lBS0ksS0FBQSxFQUFPLFFBQUEsQ0FBQyxFQUFELENBQUE7cUJBQVEsTUFBQSxDQUFPLGNBQVA7VUFBdUIsRUFBRSxDQUFDLE9BQTFCO1lBQVI7VUFMWCxDQTdCTzs7TUFGYixDQURKO01BeUNJO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsa0RBQVIsQ0FEWDtRQUVJLE9BQUEsRUFBUztVQUNMO1lBQ0ksSUFBQSxFQUFNLFVBRFY7WUFFSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxnREFBUixDQUZYO1lBR0ksT0FBQSxFQUFTLFNBQVMsQ0FBQyxzQkFIdkI7WUFJSSxPQUFBLEVBQVMsU0FBUyxDQUFDLFFBSnZCO1lBS0ksS0FBQSxFQUFPLFFBQUEsQ0FBQyxFQUFELENBQUE7cUJBQVEsTUFBQSxDQUFPLHdCQUFQO1VBQWlDLEVBQUUsQ0FBQyxPQUFwQztZQUFSO1VBTFgsQ0FESztVQU9GO1lBQ0MsSUFBQSxFQUFNLFVBRFA7WUFFQyxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSw4REFBUixDQUZSO1lBR0MsT0FBQSxFQUFTLFNBQVMsQ0FBQyx5QkFIcEI7WUFJQyxPQUFBLEVBQVMsU0FBUyxDQUFDLFFBQVYsSUFBc0IsU0FBUyxDQUFDLHNCQUoxQztZQUtDLEtBQUEsRUFBTyxRQUFBLENBQUMsRUFBRCxDQUFBO3FCQUFRLE1BQUEsQ0FBTywyQkFBUDtVQUFvQyxFQUFFLENBQUMsT0FBdkM7WUFBUjtVQUxSLENBUEU7VUFhRjtZQUNDLElBQUEsRUFBTSxVQURQO1lBRUMsS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsZ0VBQVIsQ0FGUjtZQUdDLE9BQUEsRUFBUyxTQUFTLENBQUMsMEJBSHBCO1lBSUMsT0FBQSxFQUFTLFNBQVMsQ0FBQyxRQUFWLElBQXNCLFNBQVMsQ0FBQyxzQkFKMUM7WUFLQyxLQUFBLEVBQU8sUUFBQSxDQUFDLEVBQUQsQ0FBQTtxQkFBUSxNQUFBLENBQU8sNEJBQVA7VUFBcUMsRUFBRSxDQUFDLE9BQXhDO1lBQVI7VUFMUixDQWJFO1VBb0JMO1lBQ0UsSUFBQSxFQUFNLFVBRFI7WUFFRSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxDQUFJLFFBQUgsR0FBaUIsc0VBQWpCLEdBQTZGLCtEQUE5RixDQUFSLENBRlQ7WUFHRSxPQUFBLEVBQVMsU0FBUyxDQUFDLFFBQVYsSUFBc0IsU0FBUyxDQUFDLHNCQUgzQztZQUlFLE9BQUEsRUFBUyxTQUFTLENBQUMsb0JBSnJCO1lBS0UsS0FBQSxFQUFPLFFBQUEsQ0FBQyxFQUFELENBQUE7cUJBQVEsTUFBQSxDQUFPLHNCQUFQO1VBQStCLEVBQUUsQ0FBQyxPQUFsQztZQUFSO1VBTFQsQ0FwQks7VUEyQkw7WUFDRSxJQUFBLEVBQU0sVUFEUjtZQUVFLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLDREQUFSLENBRlQ7WUFHRSxPQUFBLEVBQVMsU0FBUyxDQUFDLHFCQUhyQjtZQUlFLE9BQUEsRUFBUyxTQUFTLENBQUMsUUFBVixJQUFzQixTQUFTLENBQUMsc0JBSjNDO1lBS0UsS0FBQSxFQUFPLFFBQUEsQ0FBQyxFQUFELENBQUE7cUJBQVEsTUFBQSxDQUFPLHVCQUFQO1VBQWdDLEVBQUUsQ0FBQyxPQUFuQztZQUFSO1VBTFQsQ0EzQks7VUF3Q0EscUJBTkwsR0FBQTtZQUNFLElBQUEsRUFBTSxVQURSO1lBRUUsS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsK0VBQVIsQ0FGVDtZQUdFLE9BQUEsRUFBUyxTQUFTLENBQUMsZ0JBSHJCO1lBSUUsT0FBQSxFQUFTLFNBQVMsQ0FBQyxRQUFWLElBQXNCLFNBQVMsQ0FBQyxzQkFBaEMsSUFBMEQsQ0FBQyxTQUFTLENBQUMscUJBSmhGO1lBS0UsS0FBQSxFQUFPLFFBQUEsQ0FBQyxFQUFELENBQUE7cUJBQVEsTUFBQSxDQUFPLGtCQUFQO1VBQTJCLEVBQUUsQ0FBQyxPQUE5QjtZQUFSO1VBTFQsQ0FBQSxHQUFBLE1BbENLO1NBeUNSLENBQUMsTUF6Q08sQ0F5Q0EsUUFBQSxDQUFDLENBQUQsQ0FBQTtpQkFBTyxDQUFBLEtBQUs7UUFBWixDQXpDQTtNQUZiLENBekNKO01Bc0ZJO1FBQ0ksSUFBQSxFQUFNLFVBRFY7UUFFSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx1Q0FBUixDQUZYO1FBR0ksT0FBQSxFQUFTLFNBQVMsQ0FBQyxZQUh2QjtRQUlJLE9BQUEsRUFBUyxTQUFTLENBQUMsUUFKdkI7UUFLSSxLQUFBLEVBQU8sUUFBQSxDQUFDLEVBQUQsQ0FBQTtpQkFBUSxNQUFBLENBQU8sY0FBUDtNQUF1QixFQUFFLENBQUMsT0FBMUI7UUFBUjtNQUxYLENBdEZKO01BNkZJO1FBQ0ksSUFBQSxFQUFNLFVBRFY7UUFFSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxnREFBUixDQUZYO1FBR0ksT0FBQSxFQUFTLFNBQVMsQ0FBQyxZQUh2QjtRQUlJLE9BQUEsRUFBUyxTQUFTLENBQUMsUUFKdkI7UUFLSSxLQUFBLEVBQU8sUUFBQSxDQUFDLEVBQUQsQ0FBQTtpQkFBUSxNQUFBLENBQU8sY0FBUDtNQUF1QixFQUFFLENBQUMsT0FBMUI7UUFBUjtNQUxYLENBN0ZKO01Bb0dJO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsMkNBQVIsQ0FEWDtRQUVJLE9BQUEsRUFBUztVQUNQO1lBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEseUNBQVIsQ0FEWDtZQUVJLElBQUEsRUFBTSxPQUZWO1lBR0ksT0FBQSxFQUFTLFNBQVMsQ0FBQyxXQUFWLEtBQXlCLFNBSHRDO1lBSUksS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO3FCQUFHLE1BQUEsQ0FBTyxhQUFQO1VBQXNCLFNBQXRCO1lBQUg7VUFKWCxDQURPO1VBT1A7WUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxrQ0FBUixDQURYO1lBRUksSUFBQSxFQUFNLE9BRlY7WUFHSSxPQUFBLEVBQVMsU0FBUyxDQUFDLFdBQVYsS0FBeUIsTUFIdEM7WUFJSSxLQUFBLEVBQU8sUUFBQSxDQUFBLENBQUE7cUJBQUcsTUFBQSxDQUFPLGFBQVA7VUFBc0IsTUFBdEI7WUFBSDtVQUpYLENBUE87VUFhUDtZQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLGtDQUFSLENBRFg7WUFFSSxJQUFBLEVBQU0sT0FGVjtZQUdJLE9BQUEsRUFBUyxTQUFTLENBQUMsV0FBVixLQUF5QixNQUh0QztZQUlJLEtBQUEsRUFBTyxRQUFBLENBQUEsQ0FBQTtxQkFBRyxNQUFBLENBQU8sYUFBUDtVQUFzQixNQUF0QjtZQUFIO1VBSlgsQ0FiTztVQW1CUDtZQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLDBDQUFSLENBRFg7WUFFSSxJQUFBLEVBQU0sT0FGVjtZQUdJLE9BQUEsRUFBUyxTQUFTLENBQUMsV0FBVixLQUF5QixVQUh0QztZQUlJLEtBQUEsRUFBTyxRQUFBLENBQUEsQ0FBQTtxQkFBRyxNQUFBLENBQU8sYUFBUDtVQUFzQixVQUF0QjtZQUFIO1VBSlgsQ0FuQk87O01BRmIsQ0FwR0o7TUFpSUk7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxnQ0FBUixDQURYO1FBRUksT0FBQSxFQUFTO1VBQ1A7WUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx3Q0FBUixDQURYO1lBRUksSUFBQSxFQUFNLE9BRlY7WUFHSSxPQUFBLEVBQVMsU0FBUyxDQUFDLFFBQVYsS0FBc0IsU0FIbkM7WUFJSSxLQUFBLEVBQU8sUUFBQSxDQUFBLENBQUE7cUJBQUcsTUFBQSxDQUFPLGdCQUFQO1VBQXlCLFNBQXpCO1lBQUg7VUFKWCxDQURPO1VBT1A7WUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSw0QkFBUixDQURYO1lBRUksSUFBQSxFQUFNLE9BRlY7WUFHSSxPQUFBLEVBQVMsU0FBUyxDQUFDLFFBQVYsS0FBc0IsT0FIbkM7WUFJSSxLQUFBLEVBQU8sUUFBQSxDQUFBLENBQUE7cUJBQUcsTUFBQSxDQUFPLGdCQUFQO1VBQXlCLE9BQXpCO1lBQUg7VUFKWCxDQVBPO1VBYVA7WUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSw4QkFBUixDQURYO1lBRUksSUFBQSxFQUFNLE9BRlY7WUFHSSxPQUFBLEVBQVMsU0FBUyxDQUFDLFFBQVYsS0FBc0IsUUFIbkM7WUFJSSxLQUFBLEVBQU8sUUFBQSxDQUFBLENBQUE7cUJBQUcsTUFBQSxDQUFPLGdCQUFQO1VBQXlCLFFBQXpCO1lBQUg7VUFKWCxDQWJPO1VBbUJQO1lBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsNEJBQVIsQ0FEWDtZQUVJLElBQUEsRUFBTSxPQUZWO1lBR0ksT0FBQSxFQUFTLFNBQVMsQ0FBQyxRQUFWLEtBQXNCLE9BSG5DO1lBSUksS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO3FCQUFHLE1BQUEsQ0FBTyxnQkFBUDtVQUF5QixPQUF6QjtZQUFIO1VBSlgsQ0FuQk87VUF5QlA7WUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx3Q0FBUixDQURYO1lBRUksSUFBQSxFQUFNLE9BRlY7WUFHSSxPQUFBLEVBQVMsU0FBUyxDQUFDLFFBQVYsS0FBc0IsU0FIbkM7WUFJSSxLQUFBLEVBQU8sUUFBQSxDQUFBLENBQUE7cUJBQUcsTUFBQSxDQUFPLGdCQUFQO1VBQXlCLFNBQXpCO1lBQUg7VUFKWCxDQXpCTzs7TUFGYixDQWpJSjtNQW9LSTtRQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLHdDQUFSLENBRFg7UUFFSSxJQUFBLEVBQU07TUFGVixDQXBLSjtNQXdLSTtRQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLDJCQUFSLENBRFg7O1FBR0ksSUFBQSxFQUFNO01BSFYsQ0F4S0o7TUE2S0k7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSw2QkFBUixDQURYO1FBRUksSUFBQSxFQUFNO01BRlYsQ0E3S0o7TUFpTEk7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxrQ0FBUixDQURYO1FBRUksSUFBQSxFQUFNO01BRlYsQ0FqTEo7TUFxTEk7UUFBRSxJQUFBLEVBQU07TUFBUixDQXJMSjtNQXNMSTtRQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLHVEQUFSLENBRFg7UUFFSSxXQUFBLEVBQWEsY0FBQSxDQUFlLHNCQUFmLENBRmpCO1FBR0ksT0FBQSxFQUFTLFNBQVMsQ0FBQyxRQUh2QjtRQUlJLEtBQUEsRUFBTyxRQUFBLENBQUEsQ0FBQTtpQkFBRyxNQUFBLENBQU8sZ0JBQVA7TUFBeUIsQ0FBQyxDQUExQjtRQUFIO01BSlgsQ0F0TEo7TUE0TEk7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSwrQ0FBUixDQURYO1FBRUksV0FBQSxFQUFhLGNBQUEsQ0FBZSxrQkFBZixDQUZqQjtRQUdJLE9BQUEsRUFBUyxTQUFTLENBQUMsUUFIdkI7UUFJSSxLQUFBLEVBQU8sUUFBQSxDQUFBLENBQUE7aUJBQUcsTUFBQSxDQUFPLGdCQUFQO01BQXlCLENBQUMsQ0FBMUI7UUFBSDtNQUpYLENBNUxKO01Ba01JO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsbURBQVIsQ0FEWDtRQUVJLE9BQUEsRUFBUyxTQUFTLENBQUMsUUFGdkI7UUFHSSxPQUFBLEVBQVM7VUFDUDtZQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLHVDQUFSO1VBQWlELENBQWpELENBRFg7WUFFSSxXQUFBLEVBQWEsY0FBQSxDQUFlLGVBQWYsQ0FGakI7WUFHSSxLQUFBLEVBQU8sUUFBQSxDQUFBLENBQUE7cUJBQUcsTUFBQSxDQUFPLGlCQUFQO1VBQTBCLENBQTFCO1lBQUg7VUFIWCxDQURPO1VBTVA7WUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx1Q0FBUjtVQUFpRCxDQUFqRCxDQURYO1lBRUksV0FBQSxFQUFhLGNBQUEsQ0FBZSxlQUFmLENBRmpCO1lBR0ksS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO3FCQUFHLE1BQUEsQ0FBTyxpQkFBUDtVQUEwQixDQUExQjtZQUFIO1VBSFgsQ0FOTztVQVdQO1lBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsdUNBQVI7VUFBaUQsQ0FBakQsQ0FEWDtZQUVJLFdBQUEsRUFBYSxjQUFBLENBQWUsZUFBZixDQUZqQjtZQUdJLEtBQUEsRUFBTyxRQUFBLENBQUEsQ0FBQTtxQkFBRyxNQUFBLENBQU8saUJBQVA7VUFBMEIsQ0FBMUI7WUFBSDtVQUhYLENBWE87VUFnQlA7WUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx1Q0FBUjtVQUFpRCxDQUFqRCxDQURYO1lBRUksV0FBQSxFQUFhLGNBQUEsQ0FBZSxlQUFmLENBRmpCO1lBR0ksS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO3FCQUFHLE1BQUEsQ0FBTyxpQkFBUDtVQUEwQixDQUExQjtZQUFIO1VBSFgsQ0FoQk87VUFxQlA7WUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx1Q0FBUjtVQUFpRCxDQUFqRCxDQURYO1lBRUksV0FBQSxFQUFhLGNBQUEsQ0FBZSxlQUFmLENBRmpCO1lBR0ksS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO3FCQUFHLE1BQUEsQ0FBTyxpQkFBUDtVQUEwQixDQUExQjtZQUFIO1VBSFgsQ0FyQk87VUEwQlA7WUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx1Q0FBUjtVQUFpRCxDQUFqRCxDQURYO1lBRUksV0FBQSxFQUFhLGNBQUEsQ0FBZSxlQUFmLENBRmpCO1lBR0ksS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO3FCQUFHLE1BQUEsQ0FBTyxpQkFBUDtVQUEwQixDQUExQjtZQUFIO1VBSFgsQ0ExQk87VUErQlA7WUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx1Q0FBUjtVQUFpRCxDQUFqRCxDQURYO1lBRUksV0FBQSxFQUFhLGNBQUEsQ0FBZSxlQUFmLENBRmpCO1lBR0ksS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO3FCQUFHLE1BQUEsQ0FBTyxpQkFBUDtVQUEwQixDQUExQjtZQUFIO1VBSFgsQ0EvQk87VUFvQ1A7WUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx1Q0FBUjtVQUFpRCxDQUFqRCxDQURYO1lBRUksV0FBQSxFQUFhLGNBQUEsQ0FBZSxlQUFmLENBRmpCO1lBR0ksS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO3FCQUFHLE1BQUEsQ0FBTyxpQkFBUDtVQUEwQixDQUExQjtZQUFIO1VBSFgsQ0FwQ087VUF5Q1A7WUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx1Q0FBUjtVQUFpRCxDQUFqRCxDQURYO1lBRUksV0FBQSxFQUFhLGNBQUEsQ0FBZSxlQUFmLENBRmpCO1lBR0ksS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO3FCQUFHLE1BQUEsQ0FBTyxpQkFBUDtVQUEwQixDQUExQjtZQUFIO1VBSFgsQ0F6Q087O01BSGIsQ0FsTUo7TUFxUEk7UUFBRSxJQUFBLEVBQU07TUFBUixDQXJQSjtNQXNQSTtRQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLCtCQUFSLENBRFg7UUFFSSxPQUFBLEVBQVM7VUFDTDtZQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLHlDQUFSLENBRFg7WUFFSSxJQUFBLEVBQU0sVUFGVjtZQUdJLE9BQUEsRUFBUyxDQUFJLFNBQVMsQ0FBQyxZQUgzQjtZQUlJLE9BQUEsRUFBVSxTQUFTLENBQUMsUUFKeEI7WUFLSSxLQUFBLEVBQU8sUUFBQSxDQUFBLENBQUE7cUJBQUcsTUFBQSxDQUFPLGdCQUFQO1lBQUg7VUFMWCxDQURLO1VBUUw7WUFDRSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx1REFBUixDQURUO1lBRUUsSUFBQSxFQUFNLFVBRlI7WUFHRSxPQUFBLEVBQVMsU0FBUyxDQUFDLFFBSHJCO1lBSUUsT0FBQSxFQUFTLFNBQVMsQ0FBQyxvQkFKckI7WUFLRSxLQUFBLEVBQU8sUUFBQSxDQUFBLENBQUE7cUJBQUcsTUFBQSxDQUFPLDRCQUFQO1lBQUg7VUFMVCxDQVJLO1VBZUw7WUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxvQ0FBUixDQURYO1lBRUksSUFBQSxFQUFNLFVBRlY7WUFHSSxPQUFBLEVBQVMsU0FBUyxDQUFDLFFBSHZCO1lBSUksT0FBQSxFQUFTLFNBQVMsQ0FBQyxXQUp2QjtZQUtJLEtBQUEsRUFBTyxRQUFBLENBQUEsQ0FBQTtxQkFBRyxNQUFBLENBQU8sbUJBQVA7WUFBSDtVQUxYLENBZks7O01BRmIsQ0F0UEo7TUFnUkk7UUFDRSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSw0Q0FBUixDQURUO1FBRUUsT0FBQSxFQUFTO1VBQ0w7WUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSxvQ0FBUixDQURYO1lBRUksSUFBQSxFQUFNLE9BRlY7WUFHSSxPQUFBLEVBQVMsU0FBUyxDQUFDLFFBSHZCO1lBSUksT0FBQSxFQUFTLFNBQVMsQ0FBQyxRQUFWLElBQXNCLENBQUMsU0FBUyxDQUFDLGlCQUo5QztZQUtJLEtBQUEsRUFBTyxRQUFBLENBQUEsQ0FBQTtxQkFBRyxNQUFBLENBQU8sc0JBQVA7VUFBK0IsS0FBL0I7WUFBSDtVQUxYLENBREs7VUFRTDtZQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLHFDQUFSLENBQUEsR0FBaUQsQ0FBRyxDQUFDLFNBQVMsQ0FBQyxRQUFkLEdBQTRCLENBQUEsRUFBQSxDQUFBLENBQUssSUFBSSxDQUFDLEVBQUwsQ0FBUSwyREFBUixDQUFMLENBQXlFLENBQXpFLENBQTVCLEdBQTZHLEVBQTdHLENBRDVEO1lBRUksSUFBQSxFQUFNLE9BRlY7WUFHSSxPQUFBLEVBQVMsU0FBUyxDQUFDLFFBSHZCO1lBSUksT0FBQSxFQUFTLENBQUMsU0FBUyxDQUFDLFFBQVgsSUFBdUIsU0FBUyxDQUFDLGlCQUo5QztZQUtJLEtBQUEsRUFBTyxRQUFBLENBQUEsQ0FBQTtxQkFBRyxNQUFBLENBQU8sc0JBQVA7VUFBK0IsSUFBL0I7WUFBSDtVQUxYLENBUks7O01BRlgsQ0FoUko7TUF5U1MsUUFOTCxHQUFBO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsb0NBQVIsQ0FEWDtRQUVJLElBQUEsRUFBTSxVQUZWO1FBR0ksT0FBQSxFQUFTLFNBQVMsQ0FBQyxRQUh2QjtRQUlJLE9BQUEsRUFBVSxTQUFTLENBQUMsWUFKeEI7UUFLSSxLQUFBLEVBQU8sUUFBQSxDQUFBLENBQUE7aUJBQUcsTUFBQSxDQUFPLG9CQUFQO1FBQUg7TUFMWCxDQUFBLEdBQUEsTUFuU0o7S0EwU0MsQ0FBQyxNQTFTRixDQTBTUyxRQUFBLENBQUMsQ0FBRCxDQUFBO2FBQU8sQ0FBQSxLQUFLO0lBQVosQ0ExU1Q7RUFEVzs7RUE2U2YsY0FBQSxHQUFpQixRQUFBLENBQUMsU0FBRCxDQUFBO1dBQWU7TUFDNUI7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSwrQkFBUixDQURYO1FBRUksSUFBQSxFQUFNO01BRlYsQ0FENEI7TUFLNUI7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx5QkFBUixDQURYO1FBRUksV0FBQSxFQUFhLGNBQUEsQ0FBZSxPQUFmLENBRmpCO1FBR0ksSUFBQSxFQUFNO01BSFYsQ0FMNEI7TUFVNUI7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx3REFBUixDQURYO1FBRUksS0FBQSxFQUFPLFFBQUEsQ0FBQSxDQUFBO2lCQUFHLE1BQUEsQ0FBTyxjQUFQO1FBQUg7TUFGWCxDQVY0QjtNQWM1QjtRQUFFLElBQUEsRUFBTTtNQUFSLENBZDRCO01BZTVCO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsc0NBQVIsQ0FEWDtRQUVJLElBQUEsRUFBTTtNQUZWLENBZjRCOztFQUFmLEVBamNqQjs7Ozs7Ozs7RUE0ZEEsWUFBQSxHQUFlLFFBQUEsQ0FBQyxTQUFELENBQUE7V0FDWDtNQUdTLE9BRkwsR0FBQTtRQUNJLEtBQUEsRUFBTztNQURYLENBQUEsR0FBQSxNQURKO01BSUk7UUFDSSxLQUFBLEVBQU8sSUFBSSxDQUFDLEVBQUwsQ0FBUSx3QkFBUixDQURYO1FBRUksT0FBQSxFQUFTLGNBQUEsQ0FBZSxTQUFmO01BRmIsQ0FKSjtNQVFJO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsc0JBQVIsQ0FEWDtRQUVJLE9BQUEsRUFBUyxZQUFBLENBQWEsU0FBYjtNQUZiLENBUko7TUFZSTtRQUNJLEtBQUEsRUFBTyxJQUFJLENBQUMsRUFBTCxDQUFRLHNCQUFSLENBRFg7UUFFSSxPQUFBLEVBQVMsWUFBQSxDQUFhLFNBQWI7TUFGYixDQVpKO01Bd0JTLENBQUMsUUFSTixHQUFBO1FBQ0UsS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsc0JBQVIsQ0FEVDtRQUVFLE9BQUEsRUFBUztVQUNQO1lBQ0UsS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsb0NBQVIsQ0FEVDtZQUVFLEtBQUEsRUFBTyxRQUFBLENBQUEsQ0FBQTtxQkFBTSxNQUFBLENBQU8sWUFBUDtZQUFOO1VBRlQsQ0FETzs7TUFGWCxDQUFBLEdBQUEsTUFoQko7TUE0QlMsUUFITCxHQUFBO1FBQ0ksS0FBQSxFQUFPLElBQUksQ0FBQyxFQUFMLENBQVEsMEJBQVIsQ0FEWDtRQUVJLE9BQUEsRUFBUyxjQUFBLENBQWUsU0FBZjtNQUZiLENBQUEsR0FBQSxNQXpCSjtLQTZCQyxDQUFDLE1BN0JGLENBNkJTLFFBQUEsQ0FBQyxDQUFELENBQUE7YUFBTyxDQUFBLEtBQUs7SUFBWixDQTdCVDtFQURXOztFQWdDZixNQUFNLENBQUMsT0FBUCxHQUFpQixRQUFBLENBQUMsU0FBRCxDQUFBO1dBQ2IsSUFBSSxDQUFDLGtCQUFMLENBQXdCLElBQUksQ0FBQyxpQkFBTCxDQUF1QixZQUFBLENBQWEsU0FBYixDQUF2QixDQUF4QjtFQURhO0FBNWZqQiIsInNvdXJjZXNDb250ZW50IjpbInJlbW90ZSA9IHJlcXVpcmUoJ2VsZWN0cm9uJykucmVtb3RlXG5NZW51ID0gcmVtb3RlLk1lbnVcblxue25vdGlmaWNhdGlvbkNlbnRlclN1cHBvcnRzU291bmR9ID0gcmVxdWlyZSAnLi4vdXRpbCdcblxucGxhdGZvcm0gPSByZXF1aXJlKCdvcycpLnBsYXRmb3JtKClcbiMgdG8gcmVkdWNlIG51bWJlciBvZiA9PSBjb21wYXJpc29uc1xuaXNEYXJ3aW4gPSBwbGF0Zm9ybSA9PSAnZGFyd2luJ1xuaXNMaW51eCA9IHBsYXRmb3JtID09ICdsaW51eCdcbmlzTm90RGFyd2luID0gcGxhdGZvcm0gIT0gJ2RhcndpbidcblxuIyB0cnVlIGlmIGl0IGRvZXMsIGZhbHNlIG90aGVyd2lzZVxubm90aWZpZXJTdXBwb3J0c1NvdW5kID0gbm90aWZpY2F0aW9uQ2VudGVyU3VwcG9ydHNTb3VuZCgpXG5cbmFjY2VsZXJhdG9yTWFwID0ge1xuICAgICMgTWFjT1NYIHNwZWNpZmljXG4gICAgaGlkZXlha3lhazogeyBkZWZhdWx0OiAnQ21kT3JDdHJsK0gnIH1cbiAgICBoaWRlb3RoZXJzOiB7IGRlZmF1bHQ6ICcnLCBkYXJ3aW46J0NvbW1hbmQrU2hpZnQrSCcgfVxuICAgIHNob3dhbGw6IHsgZGVmYXVsdDogJycsIGRhcndpbjonJyB9XG4gICAgb3Blbmluc3BlY3RvcjogeyBkZWZhdWx0OiAnQ21kT3JDdHJsK0FsdCtJJyB9XG4gICAgY2xvc2U6IHsgZGVmYXVsdDogJycsIGRhcndpbjonQ29tbWFuZCtXJyB9XG4gICAgIyBDb21tb24gc2hvcnRjdXRzXG4gICAgcXVpdDogeyBkZWZhdWx0OiAnQ21kT3JDdHJsK1EnIH1cbiAgICB6b29taW46IHsgZGVmYXVsdDogJ0NtZE9yQ3RybCtQbHVzJyB9XG4gICAgIyBQbGF0Zm9ybSBzcGVjaWZpY1xuICAgIHByZXZpb3VzY29udmVyc2F0aW9uOiB7IGRlZmF1bHQ6ICdDdHJsK0snLCBkYXJ3aW46J0NvbW1hbmQrU2hpZnQrVGFiJyB9XG4gICAgbmV4dGNvbnZlcnNhdGlvbjogIHsgZGVmYXVsdDogJ0NvbnRyb2wrSicsIGRhcndpbjonQ29tbWFuZCtUYWInIH1cbiAgICBjb252ZXJzYXRpb24xOiB7IGRlZmF1bHQ6ICdBbHQrMScsIGRhcndpbjonQ29tbWFuZCsxJyB9XG4gICAgY29udmVyc2F0aW9uMjogeyBkZWZhdWx0OiAnQWx0KzInLCBkYXJ3aW46J0NvbW1hbmQrMicgfVxuICAgIGNvbnZlcnNhdGlvbjM6IHsgZGVmYXVsdDogJ0FsdCszJywgZGFyd2luOidDb21tYW5kKzMnIH1cbiAgICBjb252ZXJzYXRpb240OiB7IGRlZmF1bHQ6ICdBbHQrNCcsIGRhcndpbjonQ29tbWFuZCs0JyB9XG4gICAgY29udmVyc2F0aW9uNTogeyBkZWZhdWx0OiAnQWx0KzUnLCBkYXJ3aW46J0NvbW1hbmQrNScgfVxuICAgIGNvbnZlcnNhdGlvbjY6IHsgZGVmYXVsdDogJ0FsdCs2JywgZGFyd2luOidDb21tYW5kKzYnIH1cbiAgICBjb252ZXJzYXRpb243OiB7IGRlZmF1bHQ6ICdBbHQrNycsIGRhcndpbjonQ29tbWFuZCs3JyB9XG4gICAgY29udmVyc2F0aW9uODogeyBkZWZhdWx0OiAnQWx0KzgnLCBkYXJ3aW46J0NvbW1hbmQrOCcgfVxuICAgIGNvbnZlcnNhdGlvbjk6IHsgZGVmYXVsdDogJ0FsdCs5JywgZGFyd2luOidDb21tYW5kKzknIH1cbn1cblxuZ2V0QWNjZWxlcmF0b3IgPSAoa2V5KSAtPlxuICAgIGlmIChhY2NlbGVyYXRvck1hcFtrZXldW3BsYXRmb3JtXSk/XG4gICAgICAgIGFjY2VsZXJhdG9yTWFwW2tleV1bcGxhdGZvcm1dXG4gICAgZWxzZVxuICAgICAgICBhY2NlbGVyYXRvck1hcFtrZXldWydkZWZhdWx0J11cblxudGVtcGxhdGVZYWtZYWsgPSAodmlld3N0YXRlKSAtPlxuXG4gICAgW1xuICAgICAgICB7XG4gICAgICAgICAgICBsYWJlbDogaTE4bi5fXyAnbWVudS5oZWxwLmFib3V0LnRpdGxlOkFib3V0IFlha1lhaydcbiAgICAgICAgICAgIGNsaWNrOiAoaXQpIC0+IGFjdGlvbiAnc2hvdy1hYm91dCdcbiAgICAgICAgfSBpZiBpc0RhcndpblxuICAgICAgICB7XG4gICAgICAgICAgICB0eXBlOiAnY2hlY2tib3gnXG4gICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS5oZWxwLmFib3V0LnN0YXJ0dXA6T3BlbiBvbiBTdGFydHVwJylcbiAgICAgICAgICAgIGNoZWNrZWQ6IHZpZXdzdGF0ZS5vcGVuT25TeXN0ZW1TdGFydHVwXG4gICAgICAgICAgICBjbGljazogKGl0KSAtPiBhY3Rpb24gJ29wZW5vbnN5c3RlbXN0YXJ0dXAnLCBpdC5jaGVja2VkXG4gICAgICAgIH1cbiAgICAgICAgI3sgdHlwZTogJ3NlcGFyYXRvcicgfVxuICAgICAgICAjIHsgbGFiZWw6ICdQcmVmZXJlbmNlcy4uLicsIGFjY2VsZXJhdG9yOiAnQ29tbWFuZCssJyxcbiAgICAgICAgIyBjbGljazogPT4gZGVsZWdhdGUub3BlbkNvbmZpZygpIH1cbiAgICAgICAgeyB0eXBlOiAnc2VwYXJhdG9yJyB9IGlmIGlzRGFyd2luXG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fICdtZW51LmZpbGUuaGlkZTpIaWRlIFlha1lhaydcbiAgICAgICAgICAgIGFjY2VsZXJhdG9yOiBnZXRBY2NlbGVyYXRvcignaGlkZXlha3lhaycpXG4gICAgICAgICAgICByb2xlOiBpZiBpc0RhcndpbiB0aGVuICdoaWRlJyBlbHNlICdtaW5pbWl6ZSdcbiAgICAgICAgfVxuICAgICAgICB7XG4gICAgICAgICAgICBsYWJlbDogaTE4bi5fXyAnbWVudS5maWxlLmhpZGVfb3RoZXJzOkhpZGUgT3RoZXJzJ1xuICAgICAgICAgICAgYWNjZWxlcmF0b3I6IGdldEFjY2VsZXJhdG9yKCdoaWRlb3RoZXJzJylcbiAgICAgICAgICAgIHJvbGU6ICdoaWRlb3RoZXJzJ1xuICAgICAgICB9IGlmIGlzRGFyd2luXG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fIFwibWVudS5maWxlLnNob3c6U2hvdyBBbGxcIlxuICAgICAgICAgICAgcm9sZTogJ3VuaGlkZSdcbiAgICAgICAgfSBpZiBpc0RhcndpbiAjIG9sZCBzaG93IGFsbFxuICAgICAgICB7IHR5cGU6ICdzZXBhcmF0b3InIH1cbiAgICAgICAge1xuICAgICAgICAgIGxhYmVsOiBpMThuLl9fICdtZW51LmZpbGUuaW5zcGVjdG9yOk9wZW4gSW5zcGVjdG9yJ1xuICAgICAgICAgIGFjY2VsZXJhdG9yOiBnZXRBY2NlbGVyYXRvcignb3Blbmluc3BlY3RvcicpXG4gICAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAnZGV2dG9vbHMnXG4gICAgICAgIH1cbiAgICAgICAgeyB0eXBlOiAnc2VwYXJhdG9yJyB9XG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LmZpbGUubG9nb3V0OkxvZ291dCcpXG4gICAgICAgICAgICBjbGljazogLT4gYWN0aW9uICdsb2dvdXQnXG4gICAgICAgICAgICBlbmFibGVkOiB2aWV3c3RhdGUubG9nZ2VkaW5cbiAgICAgICAgfVxuICAgICAgICB7XG4gICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS5maWxlLnF1aXQ6UXVpdCcpXG4gICAgICAgICAgICBhY2NlbGVyYXRvcjogZ2V0QWNjZWxlcmF0b3IoJ3F1aXQnKVxuICAgICAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAncXVpdCdcbiAgICAgICAgfVxuICAgIF0uZmlsdGVyIChuKSAtPiBuICE9IHVuZGVmaW5lZFxuXG50ZW1wbGF0ZUVkaXQgPSAodmlld3N0YXRlKSAtPlxuICAgIGxhbmd1YWdlcyA9IGZvciBsb2MgaW4gaTE4bi5nZXRMb2NhbGVzKClcbiAgICAgICAgaWYgbG9jLmxlbmd0aCA8IDJcbiAgICAgICAgICAgIGNvbnRpbnVlXG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLmdldENhdGFsb2cobG9jKS5fX015TG9jYWxlTGFuZ3VhZ2VfX1xuICAgICAgICAgICAgdHlwZTogJ3JhZGlvJ1xuICAgICAgICAgICAgY2hlY2tlZDogdmlld3N0YXRlLmxhbmd1YWdlID09IGxvY1xuICAgICAgICAgICAgdmFsdWU6IGxvY1xuICAgICAgICAgICAgY2xpY2s6IChpdCkgLT5cbiAgICAgICAgICAgICAgICBhY3Rpb24gJ2NoYW5nZWxhbmd1YWdlJywgaXQudmFsdWVcbiAgICAgICAgfVxuICAgIGxhbmd1YWdlcyA9IGxhbmd1YWdlcy5maWx0ZXIgKG4pIC0+IG4gIT0gdW5kZWZpbmVkXG4gICAgW1xuICAgICAgICB7XG4gICAgICAgICAgICBsYWJlbDogaTE4bi5fXyAnbWVudS5lZGl0LnVuZG86VW5kbydcbiAgICAgICAgICAgIHJvbGU6ICd1bmRvJ1xuICAgICAgICB9XG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fICdtZW51LmVkaXQucmVkbzpSZWRvJ1xuICAgICAgICAgICAgcm9sZTogJ3JlZG8nXG4gICAgICAgIH1cbiAgICAgICAgeyB0eXBlOiAnc2VwYXJhdG9yJyB9XG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fICdtZW51LmVkaXQuY3V0OkN1dCdcbiAgICAgICAgICAgIHJvbGU6ICdjdXQnXG4gICAgICAgIH1cbiAgICAgICAge1xuICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18gJ21lbnUuZWRpdC5jb3B5OkNvcHknXG4gICAgICAgICAgICByb2xlOiAnY29weSdcbiAgICAgICAgfVxuICAgICAgICB7XG4gICAgICAgICAgICBsYWJlbDogaTE4bi5fXyAnbWVudS5lZGl0LnBhc3RlOlBhc3RlJ1xuICAgICAgICAgICAgcm9sZTogJ3Bhc3RlJ1xuICAgICAgICB9XG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fICdtZW51LmVkaXQuc2VsZWN0X2FsbDpTZWxlY3QgQWxsJ1xuICAgICAgICAgICAgcm9sZTogJ3NlbGVjdGFsbCdcbiAgICAgICAgfVxuICAgICAgICB7IHR5cGU6ICdzZXBhcmF0b3InIH1cbiAgICAgICAge1xuICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18oJ21lbnUuZWRpdC5sYW5ndWFnZTpMYW5ndWFnZScpXG4gICAgICAgICAgICBzdWJtZW51OiBsYW5ndWFnZXNcbiAgICAgICAgfVxuICAgICAgICB7XG4gICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS5lZGl0LmRhdGVmb3JtYXQ6VXNlIHN5c3RlbSBkYXRlIGZvcm1hdCcpXG4gICAgICAgICAgICB0eXBlOiAnY2hlY2tib3gnXG4gICAgICAgICAgICBjaGVja2VkOiB2aWV3c3RhdGUudXNlU3lzdGVtRGF0ZUZvcm1hdFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZVxuICAgICAgICAgICAgY2xpY2s6IChpdCkgLT4gYWN0aW9uICdzZXR1c2VzeXN0ZW1kYXRlZm9ybWF0JywgaXQuY2hlY2tlZFxuICAgICAgICB9XG5cbiAgICBdLmZpbHRlciAobikgLT4gbiAhPSB1bmRlZmluZWRcblxudGVtcGxhdGVWaWV3ID0gKHZpZXdzdGF0ZSkgLT5cbiAgICBbXG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LnZpZXcuY29udmVyc2F0aW9uLnRpdGxlOkNvbnZlcnNhdGlvbiBMaXN0JylcbiAgICAgICAgICAgIHN1Ym1lbnU6IFtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgdHlwZTogJ2NoZWNrYm94J1xuICAgICAgICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18oJ21lbnUudmlldy5jb252ZXJzYXRpb24udGh1bWJuYWlscy5zaG93OlNob3cgVGh1bWJuYWlscycpXG4gICAgICAgICAgICAgICAgICBjaGVja2VkOiB2aWV3c3RhdGUuc2hvd0NvbnZUaHVtYnNcbiAgICAgICAgICAgICAgICAgIGVuYWJsZWQ6IHZpZXdzdGF0ZS5sb2dnZWRpblxuICAgICAgICAgICAgICAgICAgY2xpY2s6IChpdCkgLT4gYWN0aW9uICdzaG93Y29udnRodW1icycsIGl0LmNoZWNrZWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICB0eXBlOiAnY2hlY2tib3gnXG4gICAgICAgICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS52aWV3LmNvbnZlcnNhdGlvbi50aHVtYm5haWxzLm9ubHk6U2hvdyBUaHVtYm5haWxzIE9ubHknKVxuICAgICAgICAgICAgICAgICAgY2hlY2tlZDp2aWV3c3RhdGUuc2hvd0NvbnZNaW5cbiAgICAgICAgICAgICAgICAgIGVuYWJsZWQ6IHZpZXdzdGF0ZS5sb2dnZWRpblxuICAgICAgICAgICAgICAgICAgY2xpY2s6IChpdCkgLT4gYWN0aW9uICdzaG93Y29udm1pbicsIGl0LmNoZWNrZWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICB0eXBlOiAnY2hlY2tib3gnXG4gICAgICAgICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS52aWV3LmNvbnZlcnNhdGlvbi50aHVtYm5haWxzLmFuaW1hdGVkOlNob3cgQW5pbWF0ZWQgVGh1bWJuYWlscycpXG4gICAgICAgICAgICAgICAgICBjaGVja2VkOnZpZXdzdGF0ZS5zaG93QW5pbWF0ZWRUaHVtYnNcbiAgICAgICAgICAgICAgICAgIGVuYWJsZWQ6IHZpZXdzdGF0ZS5sb2dnZWRpblxuICAgICAgICAgICAgICAgICAgY2xpY2s6IChpdCkgLT4gYWN0aW9uICdzaG93YW5pbWF0ZWR0aHVtYnMnLCBpdC5jaGVja2VkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgdHlwZTogJ2NoZWNrYm94J1xuICAgICAgICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18oJ21lbnUudmlldy5jb252ZXJzYXRpb24udGltZXN0YW1wOlNob3cgQ29udmVyc2F0aW9uIFRpbWVzdGFtcCcpXG4gICAgICAgICAgICAgICAgICBjaGVja2VkOnZpZXdzdGF0ZS5zaG93Q29udlRpbWVcbiAgICAgICAgICAgICAgICAgIGVuYWJsZWQ6IHZpZXdzdGF0ZS5sb2dnZWRpbiAmJiAhdmlld3N0YXRlLnNob3dDb252TWluXG4gICAgICAgICAgICAgICAgICBjbGljazogKGl0KSAtPiBhY3Rpb24gJ3Nob3djb252dGltZScsIGl0LmNoZWNrZWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICB0eXBlOiAnY2hlY2tib3gnXG4gICAgICAgICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS52aWV3LmNvbnZlcnNhdGlvbi5sYXN0OlNob3cgQ29udmVyc2F0aW9uIExhc3QgTWVzc2FnZScpXG4gICAgICAgICAgICAgICAgICBjaGVja2VkOnZpZXdzdGF0ZS5zaG93Q29udkxhc3RcbiAgICAgICAgICAgICAgICAgIGVuYWJsZWQ6IHZpZXdzdGF0ZS5sb2dnZWRpbiAmJiAhdmlld3N0YXRlLnNob3dDb252TWluXG4gICAgICAgICAgICAgICAgICBjbGljazogKGl0KSAtPiBhY3Rpb24gJ3Nob3djb252bGFzdCcsIGl0LmNoZWNrZWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIF1cbiAgICAgICAgfVxuICAgICAgICB7XG4gICAgICAgICAgICBsYWJlbDogaTE4bi5fXyAnbWVudS52aWV3Lm5vdGlmaWNhdGlvbi50aXRsZTpQb3AtVXAgTm90aWZpY2F0aW9uJ1xuICAgICAgICAgICAgc3VibWVudTogW1xuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2NoZWNrYm94J1xuICAgICAgICAgICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS52aWV3Lm5vdGlmaWNhdGlvbi5zaG93OlNob3cgbm90aWZpY2F0aW9ucycpXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ6IHZpZXdzdGF0ZS5zaG93UG9wVXBOb3RpZmljYXRpb25zXG4gICAgICAgICAgICAgICAgICAgIGVuYWJsZWQ6IHZpZXdzdGF0ZS5sb2dnZWRpblxuICAgICAgICAgICAgICAgICAgICBjbGljazogKGl0KSAtPiBhY3Rpb24gJ3Nob3dwb3B1cG5vdGlmaWNhdGlvbnMnLCBpdC5jaGVja2VkXG4gICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiAnY2hlY2tib3gnXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LnZpZXcubm90aWZpY2F0aW9uLm1lc3NhZ2U6U2hvdyBtZXNzYWdlIGluIG5vdGlmaWNhdGlvbnMnKVxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkOiB2aWV3c3RhdGUuc2hvd01lc3NhZ2VJbk5vdGlmaWNhdGlvblxuICAgICAgICAgICAgICAgICAgICBlbmFibGVkOiB2aWV3c3RhdGUubG9nZ2VkaW4gJiYgdmlld3N0YXRlLnNob3dQb3BVcE5vdGlmaWNhdGlvbnNcbiAgICAgICAgICAgICAgICAgICAgY2xpY2s6IChpdCkgLT4gYWN0aW9uICdzaG93bWVzc2FnZWlubm90aWZpY2F0aW9uJywgaXQuY2hlY2tlZFxuICAgICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2NoZWNrYm94J1xuICAgICAgICAgICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS52aWV3Lm5vdGlmaWNhdGlvbi51c2VybmFtZTpTaG93IHVzZXJuYW1lIGluIG5vdGlmaWNhdGlvbnMnKVxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkOiB2aWV3c3RhdGUuc2hvd1VzZXJuYW1lSW5Ob3RpZmljYXRpb25cbiAgICAgICAgICAgICAgICAgICAgZW5hYmxlZDogdmlld3N0YXRlLmxvZ2dlZGluICYmIHZpZXdzdGF0ZS5zaG93UG9wVXBOb3RpZmljYXRpb25zXG4gICAgICAgICAgICAgICAgICAgIGNsaWNrOiAoaXQpIC0+IGFjdGlvbiAnc2hvd3VzZXJuYW1laW5ub3RpZmljYXRpb24nLCBpdC5jaGVja2VkXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIHR5cGU6ICdjaGVja2JveCdcbiAgICAgICAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fIChpZiBpc0RhcndpbiB0aGVuICdtZW51LnZpZXcubm90aWZpY2F0aW9uLmF2YXRhcjpTaG93IHVzZXIgYXZhdGFyIGljb24gaW4gbm90aWZpY2F0aW9ucycgZWxzZSAnbWVudS52aWV3Lm5vdGlmaWNhdGlvbi5pY29uOlNob3cgWWFrWWFrIGljb24gaW4gbm90aWZpY2F0aW9ucycpXG4gICAgICAgICAgICAgICAgICBlbmFibGVkOiB2aWV3c3RhdGUubG9nZ2VkaW4gJiYgdmlld3N0YXRlLnNob3dQb3BVcE5vdGlmaWNhdGlvbnNcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ6IHZpZXdzdGF0ZS5zaG93SWNvbk5vdGlmaWNhdGlvblxuICAgICAgICAgICAgICAgICAgY2xpY2s6IChpdCkgLT4gYWN0aW9uICdzaG93aWNvbm5vdGlmaWNhdGlvbicsIGl0LmNoZWNrZWRcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgdHlwZTogJ2NoZWNrYm94J1xuICAgICAgICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18oJ21lbnUudmlldy5ub3RpZmljYXRpb24ubXV0ZTpEaXNhYmxlIHNvdW5kIGluIG5vdGlmaWNhdGlvbnMnKVxuICAgICAgICAgICAgICAgICAgY2hlY2tlZDogdmlld3N0YXRlLm11dGVTb3VuZE5vdGlmaWNhdGlvblxuICAgICAgICAgICAgICAgICAgZW5hYmxlZDogdmlld3N0YXRlLmxvZ2dlZGluICYmIHZpZXdzdGF0ZS5zaG93UG9wVXBOb3RpZmljYXRpb25zXG4gICAgICAgICAgICAgICAgICBjbGljazogKGl0KSAtPiBhY3Rpb24gJ211dGVzb3VuZG5vdGlmaWNhdGlvbicsIGl0LmNoZWNrZWRcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgdHlwZTogJ2NoZWNrYm94J1xuICAgICAgICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18oJ21lbnUudmlldy5ub3RpZmljYXRpb24uY3VzdG9tX3NvdW5kOlVzZSBZYWtZYWsgY3VzdG9tIHNvdW5kIGZvciBub3RpZmljYXRpb25zJylcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ6IHZpZXdzdGF0ZS5mb3JjZUN1c3RvbVNvdW5kXG4gICAgICAgICAgICAgICAgICBlbmFibGVkOiB2aWV3c3RhdGUubG9nZ2VkaW4gJiYgdmlld3N0YXRlLnNob3dQb3BVcE5vdGlmaWNhdGlvbnMgJiYgIXZpZXdzdGF0ZS5tdXRlU291bmROb3RpZmljYXRpb25cbiAgICAgICAgICAgICAgICAgIGNsaWNrOiAoaXQpIC0+IGFjdGlvbiAnZm9yY2VjdXN0b21zb3VuZCcsIGl0LmNoZWNrZWRcbiAgICAgICAgICAgICAgICB9IGlmIG5vdGlmaWVyU3VwcG9ydHNTb3VuZFxuICAgICAgICAgICAgXS5maWx0ZXIgKG4pIC0+IG4gIT0gdW5kZWZpbmVkXG4gICAgICAgIH1cbiAgICAgICAge1xuICAgICAgICAgICAgdHlwZTogJ2NoZWNrYm94J1xuICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18oJ21lbnUudmlldy5lbW9qaTpDb252ZXJ0IHRleHQgdG8gZW1vamknKVxuICAgICAgICAgICAgY2hlY2tlZDogdmlld3N0YXRlLmNvbnZlcnRFbW9qaVxuICAgICAgICAgICAgZW5hYmxlZDogdmlld3N0YXRlLmxvZ2dlZGluXG4gICAgICAgICAgICBjbGljazogKGl0KSAtPiBhY3Rpb24gJ2NvbnZlcnRlbW9qaScsIGl0LmNoZWNrZWRcbiAgICAgICAgfVxuICAgICAgICB7XG4gICAgICAgICAgICB0eXBlOiAnY2hlY2tib3gnXG4gICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS52aWV3LnN1Z2dlc3RlbW9qaTpTdWdnZXN0IGVtb2ppIG9uIHR5cGluZycpXG4gICAgICAgICAgICBjaGVja2VkOiB2aWV3c3RhdGUuc3VnZ2VzdEVtb2ppXG4gICAgICAgICAgICBlbmFibGVkOiB2aWV3c3RhdGUubG9nZ2VkaW5cbiAgICAgICAgICAgIGNsaWNrOiAoaXQpIC0+IGFjdGlvbiAnc3VnZ2VzdGVtb2ppJywgaXQuY2hlY2tlZFxuICAgICAgICB9XG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LnZpZXcuY29sb3Jfc2NoZW1lLnRpdGxlOkNvbG9yIFNjaGVtZScpXG4gICAgICAgICAgICBzdWJtZW51OiBbXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LnZpZXcuY29sb3Jfc2NoZW1lLmRlZmF1bHQ6T3JpZ2luYWwnKVxuICAgICAgICAgICAgICAgICAgdHlwZTogJ3JhZGlvJ1xuICAgICAgICAgICAgICAgICAgY2hlY2tlZDogdmlld3N0YXRlLmNvbG9yU2NoZW1lID09ICdkZWZhdWx0J1xuICAgICAgICAgICAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAnY2hhbmdldGhlbWUnLCAnZGVmYXVsdCdcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS52aWV3LmNvbG9yX3NjaGVtZS5ibHVlOkJsdWUnKVxuICAgICAgICAgICAgICAgICAgdHlwZTogJ3JhZGlvJ1xuICAgICAgICAgICAgICAgICAgY2hlY2tlZDogdmlld3N0YXRlLmNvbG9yU2NoZW1lID09ICdibHVlJ1xuICAgICAgICAgICAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAnY2hhbmdldGhlbWUnLCAnYmx1ZSdcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS52aWV3LmNvbG9yX3NjaGVtZS5kYXJrOkRhcmsnKVxuICAgICAgICAgICAgICAgICAgdHlwZTogJ3JhZGlvJ1xuICAgICAgICAgICAgICAgICAgY2hlY2tlZDogdmlld3N0YXRlLmNvbG9yU2NoZW1lID09ICdkYXJrJ1xuICAgICAgICAgICAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAnY2hhbmdldGhlbWUnLCAnZGFyaydcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS52aWV3LmNvbG9yX3NjaGVtZS5tYXRlcmlhbDpNYXRlcmlhbCcpXG4gICAgICAgICAgICAgICAgICB0eXBlOiAncmFkaW8nXG4gICAgICAgICAgICAgICAgICBjaGVja2VkOiB2aWV3c3RhdGUuY29sb3JTY2hlbWUgPT0gJ21hdGVyaWFsJ1xuICAgICAgICAgICAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAnY2hhbmdldGhlbWUnLCAnbWF0ZXJpYWwnXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF1cbiAgICAgICAgfVxuICAgICAgICB7XG4gICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS52aWV3LmZvbnQudGl0bGU6Rm9udCBTaXplJylcbiAgICAgICAgICAgIHN1Ym1lbnU6IFtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18oJ21lbnUudmlldy5mb250LmV4dHJhX3NtYWxsOkV4dHJhIFNtYWxsJylcbiAgICAgICAgICAgICAgICAgIHR5cGU6ICdyYWRpbydcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ6IHZpZXdzdGF0ZS5mb250U2l6ZSA9PSAneC1zbWFsbCdcbiAgICAgICAgICAgICAgICAgIGNsaWNrOiAtPiBhY3Rpb24gJ2NoYW5nZWZvbnRzaXplJywgJ3gtc21hbGwnXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18oJ21lbnUudmlldy5mb250LnNtYWxsOlNtYWxsJylcbiAgICAgICAgICAgICAgICAgIHR5cGU6ICdyYWRpbydcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ6IHZpZXdzdGF0ZS5mb250U2l6ZSA9PSAnc21hbGwnXG4gICAgICAgICAgICAgICAgICBjbGljazogLT4gYWN0aW9uICdjaGFuZ2Vmb250c2l6ZScsICdzbWFsbCdcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS52aWV3LmZvbnQubWVkaXVtOk1lZGl1bScpXG4gICAgICAgICAgICAgICAgICB0eXBlOiAncmFkaW8nXG4gICAgICAgICAgICAgICAgICBjaGVja2VkOiB2aWV3c3RhdGUuZm9udFNpemUgPT0gJ21lZGl1bSdcbiAgICAgICAgICAgICAgICAgIGNsaWNrOiAtPiBhY3Rpb24gJ2NoYW5nZWZvbnRzaXplJywgJ21lZGl1bSdcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS52aWV3LmZvbnQubGFyZ2U6TGFyZ2UnKVxuICAgICAgICAgICAgICAgICAgdHlwZTogJ3JhZGlvJ1xuICAgICAgICAgICAgICAgICAgY2hlY2tlZDogdmlld3N0YXRlLmZvbnRTaXplID09ICdsYXJnZSdcbiAgICAgICAgICAgICAgICAgIGNsaWNrOiAtPiBhY3Rpb24gJ2NoYW5nZWZvbnRzaXplJywgJ2xhcmdlJ1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LnZpZXcuZm9udC5leHRyYV9sYXJnZTpFeHRyYSBMYXJnZScpXG4gICAgICAgICAgICAgICAgICB0eXBlOiAncmFkaW8nXG4gICAgICAgICAgICAgICAgICBjaGVja2VkOiB2aWV3c3RhdGUuZm9udFNpemUgPT0gJ3gtbGFyZ2UnXG4gICAgICAgICAgICAgICAgICBjbGljazogLT4gYWN0aW9uICdjaGFuZ2Vmb250c2l6ZScsICd4LWxhcmdlJ1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBdXG4gICAgICAgIH1cbiAgICAgICAge1xuICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18gJ21lbnUudmlldy5mdWxsc2NyZWVuOlRvZ2dsZSBGdWxsc2NyZWVuJ1xuICAgICAgICAgICAgcm9sZTogJ3RvZ2dsZWZ1bGxzY3JlZW4nXG4gICAgICAgIH1cbiAgICAgICAge1xuICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18gJ21lbnUudmlldy56b29tLmluOlpvb20gaW4nXG4gICAgICAgICAgICAjIHNlZWUgaHR0cHM6Ly9naXRodWIuY29tL2F0b20vZWxlY3Ryb24vaXNzdWVzLzE1MDdcbiAgICAgICAgICAgIHJvbGU6ICd6b29taW4nXG4gICAgICAgIH1cbiAgICAgICAge1xuICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18gJ21lbnUudmlldy56b29tLm91dDpab29tIG91dCdcbiAgICAgICAgICAgIHJvbGU6ICd6b29tb3V0J1xuICAgICAgICB9XG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fICdtZW51LnZpZXcuem9vbS5yZXNldDpBY3R1YWwgc2l6ZSdcbiAgICAgICAgICAgIHJvbGU6ICdyZXNldHpvb20nXG4gICAgICAgIH1cbiAgICAgICAgeyB0eXBlOiAnc2VwYXJhdG9yJyB9XG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LnZpZXcuY29udmVyc2F0aW9uLnByZXZpb3VzOlByZXZpb3VzIENvbnZlcnNhdGlvbicpXG4gICAgICAgICAgICBhY2NlbGVyYXRvcjogZ2V0QWNjZWxlcmF0b3IoJ3ByZXZpb3VzY29udmVyc2F0aW9uJylcbiAgICAgICAgICAgIGVuYWJsZWQ6IHZpZXdzdGF0ZS5sb2dnZWRpblxuICAgICAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAnc2VsZWN0TmV4dENvbnYnLCAtMVxuICAgICAgICB9XG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LnZpZXcuY29udmVyc2F0aW9uLm5leHQ6TmV4dCBDb252ZXJzYXRpb24nKVxuICAgICAgICAgICAgYWNjZWxlcmF0b3I6IGdldEFjY2VsZXJhdG9yKCduZXh0Y29udmVyc2F0aW9uJylcbiAgICAgICAgICAgIGVuYWJsZWQ6IHZpZXdzdGF0ZS5sb2dnZWRpblxuICAgICAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAnc2VsZWN0TmV4dENvbnYnLCArMVxuICAgICAgICB9XG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LnZpZXcuY29udmVyc2F0aW9uLnNlbGVjdDpTZWxlY3QgQ29udmVyc2F0aW9uJylcbiAgICAgICAgICAgIGVuYWJsZWQ6IHZpZXdzdGF0ZS5sb2dnZWRpblxuICAgICAgICAgICAgc3VibWVudTogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnY29udmVyc2F0aW9uLm51bWJlcmVkOkNvbnZlcnNhdGlvbiAlZCcsIDEpXG4gICAgICAgICAgICAgICAgICBhY2NlbGVyYXRvcjogZ2V0QWNjZWxlcmF0b3IoJ2NvbnZlcnNhdGlvbjEnKVxuICAgICAgICAgICAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAnc2VsZWN0Q29udkluZGV4JywgMFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdjb252ZXJzYXRpb24ubnVtYmVyZWQ6Q29udmVyc2F0aW9uICVkJywgMilcbiAgICAgICAgICAgICAgICAgIGFjY2VsZXJhdG9yOiBnZXRBY2NlbGVyYXRvcignY29udmVyc2F0aW9uMicpXG4gICAgICAgICAgICAgICAgICBjbGljazogLT4gYWN0aW9uICdzZWxlY3RDb252SW5kZXgnLCAxXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18oJ2NvbnZlcnNhdGlvbi5udW1iZXJlZDpDb252ZXJzYXRpb24gJWQnLCAzKVxuICAgICAgICAgICAgICAgICAgYWNjZWxlcmF0b3I6IGdldEFjY2VsZXJhdG9yKCdjb252ZXJzYXRpb24zJylcbiAgICAgICAgICAgICAgICAgIGNsaWNrOiAtPiBhY3Rpb24gJ3NlbGVjdENvbnZJbmRleCcsIDJcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnY29udmVyc2F0aW9uLm51bWJlcmVkOkNvbnZlcnNhdGlvbiAlZCcsIDQpXG4gICAgICAgICAgICAgICAgICBhY2NlbGVyYXRvcjogZ2V0QWNjZWxlcmF0b3IoJ2NvbnZlcnNhdGlvbjQnKVxuICAgICAgICAgICAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAnc2VsZWN0Q29udkluZGV4JywgM1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdjb252ZXJzYXRpb24ubnVtYmVyZWQ6Q29udmVyc2F0aW9uICVkJywgNSlcbiAgICAgICAgICAgICAgICAgIGFjY2VsZXJhdG9yOiBnZXRBY2NlbGVyYXRvcignY29udmVyc2F0aW9uNScpXG4gICAgICAgICAgICAgICAgICBjbGljazogLT4gYWN0aW9uICdzZWxlY3RDb252SW5kZXgnLCA0XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18oJ2NvbnZlcnNhdGlvbi5udW1iZXJlZDpDb252ZXJzYXRpb24gJWQnLCA2KVxuICAgICAgICAgICAgICAgICAgYWNjZWxlcmF0b3I6IGdldEFjY2VsZXJhdG9yKCdjb252ZXJzYXRpb242JylcbiAgICAgICAgICAgICAgICAgIGNsaWNrOiAtPiBhY3Rpb24gJ3NlbGVjdENvbnZJbmRleCcsIDVcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnY29udmVyc2F0aW9uLm51bWJlcmVkOkNvbnZlcnNhdGlvbiAlZCcsIDcpXG4gICAgICAgICAgICAgICAgICBhY2NlbGVyYXRvcjogZ2V0QWNjZWxlcmF0b3IoJ2NvbnZlcnNhdGlvbjcnKVxuICAgICAgICAgICAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAnc2VsZWN0Q29udkluZGV4JywgNlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdjb252ZXJzYXRpb24ubnVtYmVyZWQ6Q29udmVyc2F0aW9uICVkJywgOClcbiAgICAgICAgICAgICAgICAgIGFjY2VsZXJhdG9yOiBnZXRBY2NlbGVyYXRvcignY29udmVyc2F0aW9uOCcpXG4gICAgICAgICAgICAgICAgICBjbGljazogLT4gYWN0aW9uICdzZWxlY3RDb252SW5kZXgnLCA3XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18oJ2NvbnZlcnNhdGlvbi5udW1iZXJlZDpDb252ZXJzYXRpb24gJWQnLCA5KVxuICAgICAgICAgICAgICAgICAgYWNjZWxlcmF0b3I6IGdldEFjY2VsZXJhdG9yKCdjb252ZXJzYXRpb245JylcbiAgICAgICAgICAgICAgICAgIGNsaWNrOiAtPiBhY3Rpb24gJ3NlbGVjdENvbnZJbmRleCcsIDhcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgXVxuICAgICAgICB9XG4gICAgICAgIHsgdHlwZTogJ3NlcGFyYXRvcicgfVxuICAgICAgICB7XG4gICAgICAgICAgICBsYWJlbDogaTE4bi5fXygnbWVudS52aWV3LnRyYXkubWFpbjpUcmF5IGljb24nKVxuICAgICAgICAgICAgc3VibWVudTogW1xuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18oJ21lbnUudmlldy50cmF5LnNob3dfdHJheTpTaG93IHRyYXkgaWNvbicpXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdjaGVja2JveCdcbiAgICAgICAgICAgICAgICAgICAgZW5hYmxlZDogbm90IHZpZXdzdGF0ZS5oaWRlZG9ja2ljb25cbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZDogIHZpZXdzdGF0ZS5zaG93dHJheVxuICAgICAgICAgICAgICAgICAgICBjbGljazogLT4gYWN0aW9uICd0b2dnbGVzaG93dHJheSdcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18gXCJtZW51LnZpZXcudHJheS5zdGFydF9taW5pbWl6ZTpTdGFydCBtaW5pbWl6ZWQgdG8gdHJheVwiXG4gICAgICAgICAgICAgICAgICB0eXBlOiBcImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgIGVuYWJsZWQ6IHZpZXdzdGF0ZS5zaG93dHJheVxuICAgICAgICAgICAgICAgICAgY2hlY2tlZDogdmlld3N0YXRlLnN0YXJ0bWluaW1pemVkdG90cmF5XG4gICAgICAgICAgICAgICAgICBjbGljazogLT4gYWN0aW9uICd0b2dnbGVzdGFydG1pbmltaXplZHRvdHJheSdcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBsYWJlbDogaTE4bi5fXyBcIm1lbnUudmlldy50cmF5LmNsb3NlOkNsb3NlIHRvIHRyYXlcIlxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBcImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgZW5hYmxlZDogdmlld3N0YXRlLnNob3d0cmF5XG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ6IHZpZXdzdGF0ZS5jbG9zZXRvdHJheVxuICAgICAgICAgICAgICAgICAgICBjbGljazogLT4gYWN0aW9uICd0b2dnbGVjbG9zZXRvdHJheSdcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBdXG4gICAgICAgIH1cbiAgICAgICAge1xuICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LnZpZXcuZXNjYXBlLnRpdGxlOkVzY2FwZSBrZXkgYmVoYXZpb3InKVxuICAgICAgICAgIHN1Ym1lbnU6IFtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18oJ21lbnUudmlldy5lc2NhcGUuaGlkZTpIaWRlcyB3aW5kb3cnKVxuICAgICAgICAgICAgICAgICAgdHlwZTogJ3JhZGlvJ1xuICAgICAgICAgICAgICAgICAgZW5hYmxlZDogdmlld3N0YXRlLnNob3d0cmF5XG4gICAgICAgICAgICAgICAgICBjaGVja2VkOiB2aWV3c3RhdGUuc2hvd3RyYXkgJiYgIXZpZXdzdGF0ZS5lc2NhcGVDbGVhcnNJbnB1dFxuICAgICAgICAgICAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAnc2V0ZXNjYXBlY2xlYXJzaW5wdXQnLCBmYWxzZVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LnZpZXcuZXNjYXBlLmNsZWFyOkNsZWFycyBpbnB1dCcpICsgaWYgIXZpZXdzdGF0ZS5zaG93dHJheSB0aGVuIFwiICgje2kxOG4uX18gJ21lbnUudmlldy5lc2NhcGUuZGVmYXVsdDpkZWZhdWx0IHdoZW4gdHJheSBpcyBub3Qgc2hvd2luZyd9KVwiIGVsc2UgJydcbiAgICAgICAgICAgICAgICAgIHR5cGU6ICdyYWRpbydcbiAgICAgICAgICAgICAgICAgIGVuYWJsZWQ6IHZpZXdzdGF0ZS5zaG93dHJheVxuICAgICAgICAgICAgICAgICAgY2hlY2tlZDogIXZpZXdzdGF0ZS5zaG93dHJheSB8fCB2aWV3c3RhdGUuZXNjYXBlQ2xlYXJzSW5wdXRcbiAgICAgICAgICAgICAgICAgIGNsaWNrOiAtPiBhY3Rpb24gJ3NldGVzY2FwZWNsZWFyc2lucHV0JywgdHJ1ZVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgXVxuICAgICAgICB9XG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LnZpZXcuaGlkZV9kb2NrOkhpZGUgRG9jayBpY29uJylcbiAgICAgICAgICAgIHR5cGU6ICdjaGVja2JveCdcbiAgICAgICAgICAgIGVuYWJsZWQ6IHZpZXdzdGF0ZS5zaG93dHJheVxuICAgICAgICAgICAgY2hlY2tlZDogIHZpZXdzdGF0ZS5oaWRlZG9ja2ljb25cbiAgICAgICAgICAgIGNsaWNrOiAtPiBhY3Rpb24gJ3RvZ2dsZWhpZGVkb2NraWNvbidcbiAgICAgICAgfSBpZiBpc0RhcndpblxuICAgIF0uZmlsdGVyIChuKSAtPiBuICE9IHVuZGVmaW5lZFxuXG50ZW1wbGF0ZVdpbmRvdyA9ICh2aWV3c3RhdGUpIC0+IFtcbiAgICB7XG4gICAgICAgIGxhYmVsOiBpMThuLl9fICdtZW51LndpbmRvdy5taW5pbWl6ZTpNaW5pbWl6ZSdcbiAgICAgICAgcm9sZTogJ21pbmltaXplJ1xuICAgIH1cbiAgICB7XG4gICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LndpbmRvdy5jbG9zZTpDbG9zZScpXG4gICAgICAgIGFjY2VsZXJhdG9yOiBnZXRBY2NlbGVyYXRvcignY2xvc2UnKVxuICAgICAgICByb2xlOiAnY2xvc2UnXG4gICAgfVxuICAgIHtcbiAgICAgICAgbGFiZWw6IGkxOG4uX18gJ21lbnUudmlldy50cmF5LnRvZ2dsZV9taW5pbWl6ZTpUb2dnbGUgd2luZG93IHNob3cvaGlkZSdcbiAgICAgICAgY2xpY2s6IC0+IGFjdGlvbiAndG9nZ2xld2luZG93J1xuICAgIH1cbiAgICB7IHR5cGU6ICdzZXBhcmF0b3InIH1cbiAgICB7XG4gICAgICAgIGxhYmVsOiBpMThuLl9fKCdtZW51LndpbmRvdy5mcm9udDpCcmluZyBBbGwgdG8gRnJvbnQnKVxuICAgICAgICByb2xlOiAnZnJvbnQnXG4gICAgfVxuXVxuXG4jIG5vdGU6IGVsZWN0cm9uIGZyYW1ld29yayBjdXJyZW50bHkgZG9lcyBub3Qgc3VwcG9ydCB1bmRlZmluZWQgTWVudVxuIyAgZW50cmllcywgd2hpY2ggcmVxdWlyZXMgYSBmaWx0ZXIgZm9yIHVuZGVmaW5lZCBhdCBtZW51L3N1Ym1lbnUgZW50cnlcbiMgIHRvIHJlbW92ZSB0aGVtXG4jXG4jICBbLi4sIHVuZGVmaW5lZCwgLi4uLCB1bmRlZmluZWQsLi4gXS5maWx0ZXIgKG4pIC0+IG4gIT0gdW5kZWZpbmVkXG4jXG50ZW1wbGF0ZU1lbnUgPSAodmlld3N0YXRlKSAtPlxuICAgIFtcbiAgICAgICAge1xuICAgICAgICAgICAgbGFiZWw6ICcnXG4gICAgICAgIH0gaWYgaXNMaW51eFxuICAgICAgICB7XG4gICAgICAgICAgICBsYWJlbDogaTE4bi5fXyAnbWVudS5maWxlLnRpdGxlOllha1lhaydcbiAgICAgICAgICAgIHN1Ym1lbnU6IHRlbXBsYXRlWWFrWWFrIHZpZXdzdGF0ZVxuICAgICAgICB9XG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fICdtZW51LmVkaXQudGl0bGU6RWRpdCdcbiAgICAgICAgICAgIHN1Ym1lbnU6IHRlbXBsYXRlRWRpdCB2aWV3c3RhdGVcbiAgICAgICAgfVxuICAgICAgICB7XG4gICAgICAgICAgICBsYWJlbDogaTE4bi5fXyAnbWVudS52aWV3LnRpdGxlOlZpZXcnXG4gICAgICAgICAgICBzdWJtZW51OiB0ZW1wbGF0ZVZpZXcgdmlld3N0YXRlXG4gICAgICAgIH1cbiAgICAgICAge1xuICAgICAgICAgIGxhYmVsOiBpMThuLl9fICdtZW51LmhlbHAudGl0bGU6SGVscCdcbiAgICAgICAgICBzdWJtZW51OiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGxhYmVsOiBpMThuLl9fICdtZW51LmhlbHAuYWJvdXQudGl0bGU6QWJvdXQgWWFrWWFrJ1xuICAgICAgICAgICAgICBjbGljazogKCkgLT4gYWN0aW9uICdzaG93LWFib3V0J1xuICAgICAgICAgICAgfVxuICAgICAgICAgIF1cbiAgICAgICAgfSBpZiAhaXNEYXJ3aW5cbiAgICAgICAge1xuICAgICAgICAgICAgbGFiZWw6IGkxOG4uX18gJ21lbnUud2luZG93LnRpdGxlOldpbmRvdydcbiAgICAgICAgICAgIHN1Ym1lbnU6IHRlbXBsYXRlV2luZG93IHZpZXdzdGF0ZVxuICAgICAgICB9IGlmIGlzRGFyd2luXG4gICAgXS5maWx0ZXIgKG4pIC0+IG4gIT0gdW5kZWZpbmVkXG5cbm1vZHVsZS5leHBvcnRzID0gKHZpZXdzdGF0ZSkgLT5cbiAgICBNZW51LnNldEFwcGxpY2F0aW9uTWVudSBNZW51LmJ1aWxkRnJvbVRlbXBsYXRlIHRlbXBsYXRlTWVudSh2aWV3c3RhdGUpXG4iXX0=
