(function() {
  var BrowserWindow, Client, Q, app, client, debug, drive, fs, ipc, loadAppWindow, login, logout, mainWindow, path, path_parts, paths, plug, quit, seqreq, session, shouldQuit, tmp, toggleWindowVisible, userData, wait;

  Client = require('hangupsjs');

  Q = require('q');

  login = require('./login');

  ipc = require('electron').ipcMain;

  fs = require('fs');

  path = require('path');

  tmp = require('tmp');

  session = require('electron').session;

  [drive, ...path_parts] = path.normalize(__dirname).split(path.sep);

  global.YAKYAK_ROOT_DIR = [drive, ...path_parts.map(encodeURIComponent)].join('/');

  // test if flag debug is preset (other flags can be used via package args
  //  but requres node v6)
  debug = process.argv.includes('--debug');

  tmp.setGracefulCleanup();

  app = require('electron').app;

  app.disableHardwareAcceleration();

  BrowserWindow = require('electron').BrowserWindow;

  userData = path.normalize(app.getPath('userData'));

  if (!fs.existsSync(userData)) {
    fs.mkdirSync(userData);
  }

  paths = {
    rtokenpath: path.join(userData, 'refreshtoken.txt'),
    cookiespath: path.join(userData, 'cookies.json'),
    chromecookie: path.join(userData, 'Cookies'),
    configpath: path.join(userData, 'config.json')
  };

  client = new Client({
    rtokenpath: paths.rtokenpath,
    cookiespath: paths.cookiespath
  });

  plug = function(rs, rj) {
    return function(err, val) {
      if (err) {
        return rj(err);
      } else {
        return rs(val);
      }
    };
  };

  logout = function() {
    var promise;
    promise = client.logout();
    promise.then(function(res) {
      var argv, ref, ref1, spawn;
      argv = process.argv;
      spawn = require('child_process').spawn;
      // remove electron cookies
      if (typeof mainWindow !== "undefined" && mainWindow !== null) {
        if ((ref = mainWindow.webContents) != null) {
          if ((ref1 = ref.session) != null) {
            ref1.clearStorageData([], function(data) {
              return console.log(data);
            });
          }
        }
      }
      spawn(argv.shift(), argv, {
        cwd: process.cwd,
        env: process.env,
        detached: true,
        stdio: 'inherit'
      });
      return quit();
    });
    return promise; // like it matters
  };

  seqreq = require('./seqreq');

  mainWindow = null;

  // Only allow a single active instance
  shouldQuit = app.makeSingleInstance(function() {
    if (mainWindow) {
      mainWindow.show();
    }
    return true;
  });

  if (shouldQuit) {
    app.quit();
    return;
  }

  global.i18nOpts = {
    opts: null,
    locale: null
  };

  // No more minimizing to tray, just close it
  global.forceClose = false;

  quit = function() {
    global.forceClose = true;
    if (mainWindow != null) {
      // force all windows to close
      mainWindow.destroy();
    }
    app.quit();
  };

  app.on('before-quit', function() {
    global.forceClose = true;
    global.i18nOpts = null;
  });

  // For OSX show window main window if we've hidden it.
  // https://github.com/electron/electron/blob/master/docs/api/app.md#event-activate-os-x
  app.on('activate', function() {
    return mainWindow.show();
  });

  loadAppWindow = function() {
    mainWindow.loadURL('file://' + YAKYAK_ROOT_DIR + '/ui/index.html');
    // Only show window when it has some content
    return mainWindow.once('ready-to-show', function() {
      return mainWindow.webContents.send('ready-to-show');
    });
  };

  toggleWindowVisible = function() {
    if (mainWindow.isVisible()) {
      return mainWindow.hide();
    } else {
      return mainWindow.show();
    }
  };

  // helper wait promise
  wait = function(t) {
    return Q.Promise(function(rs) {
      return setTimeout(rs, t);
    });
  };

  app.on('ready', function() {
    var creds, icon_name, ipcsend, messageQueue, proxycheck, reconnect, reconnectCount, sendInit, syncrecent;
    proxycheck = function() {
      var todo;
      todo = [
        {
          url: 'http://plus.google.com',
          env: 'HTTP_PROXY'
        },
        {
          url: 'https://plus.google.com',
          env: 'HTTPS_PROXY'
        }
      ];
      return Q.all(todo.map(function(t) {
        return Q.Promise(function(rs) {
          console.log(`resolving proxy ${t.url}`);
          return session.defaultSession.resolveProxy(t.url, function(proxyURL) {
            var _, base, name1, purl;
            console.log(`resolved proxy ${proxyURL}`);
            // Format of proxyURL is either "DIRECT" or "PROXY 127.0.0.1:8888"
            [_, purl] = proxyURL.split(' ');
            if ((base = process.env)[name1 = t.env] == null) {
              base[name1] = purl ? `http://${purl}` : "";
            }
            return rs();
          });
        });
      }));
    };
    icon_name = process.platform === 'win32' ? 'icon@2.png' : 'icon@32.png';
    // Create the browser window.
    mainWindow = new BrowserWindow({
      width: 730,
      height: 590,
      "min-width": 620,
      "min-height": 420,
      icon: path.join(__dirname, 'icons', icon_name),
      show: false,
      titleBarStyle: process.platform === 'darwin' ? 'hidden-inset' : void 0,
      frame: process.platform === 'win32' ? false : void 0
    });
    // Launch fullscreen with DevTools open, usage: npm run debug
    // autoHideMenuBar : true unless process.platform is 'darwin'
    if (debug) {
      mainWindow.webContents.openDevTools();
      mainWindow.maximize();
      mainWindow.show();
      try {
        require('devtron').install();
      } catch (error1) {

      }
    }
    //do nothing

    // and load the index.html of the app. this may however be yanked
    // away if we must do auth.
    loadAppWindow();
    
    // Handle uncaught exceptions from the main process
    process.on('uncaughtException', function(msg) {
      ipcsend('expcetioninmain', msg);
      
      return console.log(`Error on main process:\n${msg}\n` + "--- End of error message. More details:\n", msg);
    });
    
    // Handle crashes on the main window and show in console
    mainWindow.webContents.on('crashed', function(msg) {
      console.log('Crash event on main window!', msg);
      return ipc.send('expcetioninmain', {
        msg: 'Detected a crash event on the main window.',
        event: msg
      });
    });
    // short hand
    ipcsend = function(...as) {
      return mainWindow.webContents.send(...as);
    };
    // callback for credentials
    creds = function() {
      var loginWindow, prom;
      console.log("asking for login credentials");
      loginWindow = new BrowserWindow({
        width: 730,
        height: 590,
        "min-width": 620,
        "min-height": 420,
        icon: path.join(__dirname, 'icons', 'icon.png'),
        show: true,
        webPreferences: {
          nodeIntegration: false
        }
      });
      loginWindow.on('closed', quit);
      global.windowHideWhileCred = true;
      mainWindow.hide();
      loginWindow.focus();
      // reinstate app window when login finishes
      prom = login(loginWindow).then(function(rs) {
        global.forceClose = true;
        loginWindow.removeAllListeners('closed');
        loginWindow.close();
        mainWindow.show();
        return rs;
      });
      return {
        auth: function() {
          return prom;
        }
      };
    };
    // sends the init structures to the client
    sendInit = function() {
      var ref;
      if (!(client != null ? (ref = client.init) != null ? ref.self_entity : void 0 : void 0)) {
        // we have no init data before the client has connected first
        // time.
        return false;
      }
      ipcsend('init', {
        init: client.init
      });
      return true;
    };
    // keeps trying to connec the hangupsjs and communicates those
    // attempts to the client.
    reconnect = function() {
      console.log('reconnecting', reconnectCount);
      return proxycheck().then(function() {
        return client.connect(creds).then(function() {
          console.log('connected', reconnectCount);
          // on first connect, send init, after that only resync
          if (reconnectCount === 0) {
            sendInit();
          } else {
            syncrecent();
          }
          return reconnectCount++;
        }).catch(function(e) {
          return console.log('error connecting', e);
        });
      });
    };
    // counter for reconnects
    reconnectCount = 0;
    // whether to connect is dictated by the client.
    ipc.on('hangupsConnect', function() {
      console.log('hconnect');
      return reconnect();
    });
    ipc.on('hangupsDisconnect', function() {
      console.log('hdisconnect');
      reconnectCount = 0;
      return client.disconnect();
    });
    // client deals with window sizing
    mainWindow.on('resize', function(ev) {
      return ipcsend('resize', mainWindow.getSize());
    });
    mainWindow.on('move', function(ev) {
      return ipcsend('move', mainWindow.getPosition());
    });
    // whenever it fails, we try again
    client.on('connect_failed', function(e) {
      console.log('connect_failed', e);
      return wait(3000).then(function() {
        return reconnect();
      });
    });
    // when client requests (re-)init since the first init
    // object is sent as soon as possible on startup
    ipc.on('reqinit', function() {
      if (sendInit()) {
        return syncrecent();
      }
    });
    // sendchatmessage, executed sequentially and
    // retried if not sent successfully
    messageQueue = Q();
    ipc.on('sendchatmessage', function(ev, msg) {
      var client_generated_id, conv_id, delivery_medium, image_id, message_action_type, otr, segs, sendForSure;
      ({conv_id, segs, client_generated_id, image_id, otr, message_action_type, delivery_medium} = msg);
      sendForSure = function() {
        return Q.promise(function(resolve, reject, notify) {
          var attempt;
          attempt = function() {
            // console.log 'sendchatmessage', client_generated_id
            if (delivery_medium == null) {
              delivery_medium = null;
            }
            return client.sendchatmessage(conv_id, segs, image_id, otr, client_generated_id, delivery_medium, message_action_type).then(function(r) {
              // console.log 'sendchatmessage:result', r?.created_event?.self_event_state?.client_generated_id
              ipcsend('sendchatmessage:result', r);
              return resolve();
            });
          };
          return attempt();
        });
      };
      return messageQueue = messageQueue.then(function() {
        return sendForSure();
      });
    });
    // get locale for translations
    ipc.on('seti18n', function(ev, opts, language) {
      if (opts != null) {
        global.i18nOpts.opts = opts;
      }
      if (language != null) {
        return global.i18nOpts.locale = language;
      }
    });
    // sendchatmessage, executed sequentially and
    // retried if not sent successfully
    ipc.on('querypresence', seqreq(function(ev, id) {
      return client.querypresence(id).then(function(r) {
        return ipcsend('querypresence:result', r.presence_result[0]);
      }, false, function() {
        return 1;
      });
    }));
    ipc.on('initpresence', function(ev, l) {
      var i, j, len, p, results;
      results = [];
      for (i = j = 0, len = l.length; j < len; i = ++j) {
        p = l[i];
        if (p !== null) {
          results.push(client.querypresence(p.id).then(function(r) {
            return ipcsend('querypresence:result', r.presence_result[0]);
          }, false, function() {
            return 1;
          }));
        }
      }
      return results;
    });
    // no retry, only one outstanding call
    ipc.on('setpresence', seqreq(function() {
      return client.setpresence(true);
    }, false, function() {
      return 1;
    }));
    // no retry, only one outstanding call
    ipc.on('setactiveclient', seqreq(function(ev, active, secs) {
      return client.setactiveclient(active, secs);
    }, false, function() {
      return 1;
    }));
    // watermarking is only interesting for the last of each conv_id
    // retry send and dedupe for each conv_id
    ipc.on('updatewatermark', seqreq(function(ev, conv_id, time) {
      return client.updatewatermark(conv_id, time);
    }, true, function(ev, conv_id, time) {
      return conv_id;
    }));
    // getentity is not super important, the client will try again when encountering
    // entities without photo_url. so no retry, but do execute all such reqs
    // ipc.on 'getentity', seqreq (ev, ids) ->
    //     client.getentitybyid(ids).then (r) -> ipcsend 'getentity:result', r
    // , false

    // we want to upload. in the order specified, with retry
    ipc.on('uploadimage', seqreq(function(ev, spec) {
      var client_generated_id, conv_id;
      ({path, conv_id, client_generated_id} = spec);
      ipcsend('uploadingimage', {conv_id, client_generated_id, path});
      return client.uploadimage(path).then(function(image_id) {
        var delivery_medium;
        delivery_medium = null;
        return client.sendchatmessage(conv_id, null, image_id, null, client_generated_id, delivery_medium);
      });
    }, true));
    // we want to upload. in the order specified, with retry
    ipc.on('uploadclipboardimage', seqreq(function(ev, spec) {
      var client_generated_id, conv_id, file, pngData;
      ({pngData, conv_id, client_generated_id} = spec);
      file = tmp.fileSync({
        postfix: ".png"
      });
      ipcsend('uploadingimage', {
        conv_id,
        client_generated_id,
        path: file.name
      });
      return Q.Promise(function(rs, rj) {
        return fs.writeFile(file.name, pngData, plug(rs, rj));
      }).then(function() {
        return client.uploadimage(file.name);
      }).then(function(image_id) {
        var delivery_medium;
        delivery_medium = null;
        return client.sendchatmessage(conv_id, null, image_id, null, client_generated_id, delivery_medium);
      }).then(function() {
        return file.removeCallback();
      });
    }, true));
    // retry only last per conv_id
    ipc.on('setconversationnotificationlevel', seqreq(function(ev, conv_id, level) {
      return client.setconversationnotificationlevel(conv_id, level);
    }, true, function(ev, conv_id, level) {
      return conv_id;
    }));
    // retry
    ipc.on('deleteconversation', seqreq(function(ev, conv_id) {
      return client.deleteconversation(conv_id);
    }, true));
    ipc.on('removeuser', seqreq(function(ev, conv_id) {
      return client.removeuser(conv_id);
    }, true));
    // no retries, dedupe on conv_id
    ipc.on('setfocus', seqreq(function(ev, conv_id) {
      client.setfocus(conv_id);
      return client.getconversation(conv_id, new Date(), 1, true).then(function(r) {
        return ipcsend('getconversationmetadata:response', r);
      });
    }, false, function(ev, conv_id) {
      return conv_id;
    }));
    ipc.on('appfocus', function() {
      app.focus();
      if (mainWindow.isVisible()) {
        return mainWindow.focus();
      } else {
        return mainWindow.show();
      }
    });
    // no retries, dedupe on conv_id
    ipc.on('settyping', seqreq(function(ev, conv_id, v) {
      return client.settyping(conv_id, v);
    }, false, function(ev, conv_id) {
      return conv_id;
    }));
    ipc.on('updatebadge', function(ev, value) {
      if (app.dock) {
        return app.dock.setBadge(value);
      }
    });
    ipc.on('searchentities', function(ev, query, max_results) {
      var promise;
      promise = client.searchentities(query, max_results);
      return promise.then(function(res) {
        return ipcsend('searchentities:result', res);
      });
    });
    ipc.on('createconversation', function(ev, ids, name, forcegroup = false) {
      var conv, promise;
      promise = client.createconversation(ids, forcegroup);
      conv = null;
      promise.then(function(res) {
        var conv_id;
        conv = res.conversation;
        conv_id = conv.id.id;
        if (name) {
          return client.renameconversation(conv_id, name);
        }
      });
      return promise = promise.then(function(res) {
        return ipcsend('createconversation:result', conv, name);
      });
    });
    ipc.on('adduser', function(ev, conv_id, toadd) {
      return client.adduser(conv_id, toadd); // will automatically trigger membership_change
    });
    ipc.on('renameconversation', function(ev, conv_id, newname) {
      return client.renameconversation(conv_id, newname); // will trigger conversation_rename
    });
    
    // no retries, just dedupe on the ids
    ipc.on('getentity', seqreq(function(ev, ids, data) {
      return client.getentitybyid(ids).then(function(r) {
        return ipcsend('getentity:result', r, data);
      });
    }, false, function(ev, ids) {
      return ids.sort().join(',');
    }));
    // no retry, just one single request
    ipc.on('syncallnewevents', seqreq(function(ev, time) {
      console.log('syncallnew');
      return client.syncallnewevents(time).then(function(r) {
        return ipcsend('syncallnewevents:response', r);
      });
    }, false, function(ev, time) {
      return 1;
    }));
    // no retry, just one single request
    ipc.on('syncrecentconversations', syncrecent = seqreq(function(ev) {
      console.log('syncrecent');
      return client.syncrecentconversations().then(function(r) {
        ipcsend('syncrecentconversations:response', r);
        // this is because we use syncrecent on reqinit (dev-mode
        // refresh). if we succeeded getting a response, we call it
        // connected.
        return ipcsend('connected');
      });
    }, false, function(ev, time) {
      return 1;
    }));
    // retry, one single per conv_id
    ipc.on('getconversation', seqreq(function(ev, conv_id, timestamp, max) {
      return client.getconversation(conv_id, timestamp, max, true).then(function(r) {
        return ipcsend('getconversation:response', r);
      });
    }, false, function(ev, conv_id, timestamp, max) {
      return conv_id;
    }));
    ipc.on('togglefullscreen', function() {
      return mainWindow.setFullScreen(!mainWindow.isFullScreen());
    });
    // bye bye
    ipc.on('logout', logout);
    ipc.on('quit', quit);
    ipc.on('errorInWindow', function(ev, error, winName = 'YakYak') {
      if (!global.isReadyToShow) {
        mainWindow.show();
      }
      ipcsend('expcetioninmain', error);
      return console.log(`Error on ${winName} window:\n`, error, `\n--- End of error message in ${winName} window.`);
    });
    // propagate these events to the renderer
    return require('./ui/events').forEach(function(n) {
      return client.on(n, function(e) {
        return ipcsend(n, e);
      });
    });
  });

  // Emitted when the window is about to close.
// Hides the window if we're not force closing.
//  IMPORTANT: moved to app.coffee

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXMiOlsibWFpbi5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLGFBQUEsRUFBQSxNQUFBLEVBQUEsQ0FBQSxFQUFBLEdBQUEsRUFBQSxNQUFBLEVBQUEsS0FBQSxFQUFBLEtBQUEsRUFBQSxFQUFBLEVBQUEsR0FBQSxFQUFBLGFBQUEsRUFBQSxLQUFBLEVBQUEsTUFBQSxFQUFBLFVBQUEsRUFBQSxJQUFBLEVBQUEsVUFBQSxFQUFBLEtBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLE1BQUEsRUFBQSxPQUFBLEVBQUEsVUFBQSxFQUFBLEdBQUEsRUFBQSxtQkFBQSxFQUFBLFFBQUEsRUFBQTs7RUFBQSxNQUFBLEdBQVksT0FBQSxDQUFRLFdBQVI7O0VBQ1osQ0FBQSxHQUFZLE9BQUEsQ0FBUSxHQUFSOztFQUNaLEtBQUEsR0FBWSxPQUFBLENBQVEsU0FBUjs7RUFDWixHQUFBLEdBQVksT0FBQSxDQUFRLFVBQVIsQ0FBbUIsQ0FBQzs7RUFDaEMsRUFBQSxHQUFZLE9BQUEsQ0FBUSxJQUFSOztFQUNaLElBQUEsR0FBWSxPQUFBLENBQVEsTUFBUjs7RUFDWixHQUFBLEdBQVksT0FBQSxDQUFRLEtBQVI7O0VBQ1osT0FBQSxHQUFZLE9BQUEsQ0FBUSxVQUFSLENBQW1CLENBQUM7O0VBR2hDLENBQUMsS0FBRCxFQUFRLEdBQUEsVUFBUixDQUFBLEdBQXlCLElBQUksQ0FBQyxTQUFMLENBQWUsU0FBZixDQUF5QixDQUFDLEtBQTFCLENBQWdDLElBQUksQ0FBQyxHQUFyQzs7RUFDekIsTUFBTSxDQUFDLGVBQVAsR0FBeUIsQ0FBQyxLQUFELEVBQVEsR0FBQSxVQUFVLENBQUMsR0FBWCxDQUFlLGtCQUFmLENBQVIsQ0FBOEMsQ0FBQyxJQUEvQyxDQUFvRCxHQUFwRCxFQVh6Qjs7OztFQWVBLEtBQUEsR0FBUSxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQWIsQ0FBc0IsU0FBdEI7O0VBRVIsR0FBRyxDQUFDLGtCQUFKLENBQUE7O0VBRUEsR0FBQSxHQUFNLE9BQUEsQ0FBUSxVQUFSLENBQW1CLENBQUM7O0VBQzFCLEdBQUcsQ0FBQywyQkFBSixDQUFBOztFQUVBLGFBQUEsR0FBZ0IsT0FBQSxDQUFRLFVBQVIsQ0FBbUIsQ0FBQzs7RUFFcEMsUUFBQSxHQUFXLElBQUksQ0FBQyxTQUFMLENBQWUsR0FBRyxDQUFDLE9BQUosQ0FBWSxVQUFaLENBQWY7O0VBQ1gsSUFBMEIsQ0FBSSxFQUFFLENBQUMsVUFBSCxDQUFjLFFBQWQsQ0FBOUI7SUFBQSxFQUFFLENBQUMsU0FBSCxDQUFhLFFBQWIsRUFBQTs7O0VBRUEsS0FBQSxHQUNJO0lBQUEsVUFBQSxFQUFZLElBQUksQ0FBQyxJQUFMLENBQVUsUUFBVixFQUFvQixrQkFBcEIsQ0FBWjtJQUNBLFdBQUEsRUFBYSxJQUFJLENBQUMsSUFBTCxDQUFVLFFBQVYsRUFBb0IsY0FBcEIsQ0FEYjtJQUVBLFlBQUEsRUFBYyxJQUFJLENBQUMsSUFBTCxDQUFVLFFBQVYsRUFBb0IsU0FBcEIsQ0FGZDtJQUdBLFVBQUEsRUFBWSxJQUFJLENBQUMsSUFBTCxDQUFVLFFBQVYsRUFBb0IsYUFBcEI7RUFIWjs7RUFLSixNQUFBLEdBQVMsSUFBSSxNQUFKLENBQ0w7SUFBQSxVQUFBLEVBQVksS0FBSyxDQUFDLFVBQWxCO0lBQ0EsV0FBQSxFQUFhLEtBQUssQ0FBQztFQURuQixDQURLOztFQU1ULElBQUEsR0FBTyxRQUFBLENBQUMsRUFBRCxFQUFLLEVBQUwsQ0FBQTtXQUFZLFFBQUEsQ0FBQyxHQUFELEVBQU0sR0FBTixDQUFBO01BQWMsSUFBRyxHQUFIO2VBQVksRUFBQSxDQUFHLEdBQUgsRUFBWjtPQUFBLE1BQUE7ZUFBeUIsRUFBQSxDQUFHLEdBQUgsRUFBekI7O0lBQWQ7RUFBWjs7RUFFUCxNQUFBLEdBQVMsUUFBQSxDQUFBLENBQUE7QUFDTCxRQUFBO0lBQUEsT0FBQSxHQUFVLE1BQU0sQ0FBQyxNQUFQLENBQUE7SUFDVixPQUFPLENBQUMsSUFBUixDQUFhLFFBQUEsQ0FBQyxHQUFELENBQUE7QUFDVCxVQUFBLElBQUEsRUFBQSxHQUFBLEVBQUEsSUFBQSxFQUFBO01BQUEsSUFBQSxHQUFPLE9BQU8sQ0FBQztNQUNmLEtBQUEsR0FBUSxPQUFBLENBQVEsZUFBUixDQUF3QixDQUFDLE1BRGpDOzs7OztnQkFHZ0MsQ0FBRSxnQkFBbEMsQ0FBbUQsRUFBbkQsRUFBdUQsUUFBQSxDQUFDLElBQUQsQ0FBQTtxQkFBVSxPQUFPLENBQUMsR0FBUixDQUFZLElBQVo7WUFBVixDQUF2RDs7OztNQUNBLEtBQUEsQ0FBTSxJQUFJLENBQUMsS0FBTCxDQUFBLENBQU4sRUFBb0IsSUFBcEIsRUFDSTtRQUFBLEdBQUEsRUFBSyxPQUFPLENBQUMsR0FBYjtRQUNBLEdBQUEsRUFBSyxPQUFPLENBQUMsR0FEYjtRQUVBLFFBQUEsRUFBVSxJQUZWO1FBR0EsS0FBQSxFQUFPO01BSFAsQ0FESjthQUtBLElBQUEsQ0FBQTtJQVZTLENBQWI7QUFXQSxXQUFPLFFBYkY7RUFBQTs7RUFlVCxNQUFBLEdBQVMsT0FBQSxDQUFRLFVBQVI7O0VBRVQsVUFBQSxHQUFhLEtBMURiOzs7RUE2REEsVUFBQSxHQUFhLEdBQUcsQ0FBQyxrQkFBSixDQUF1QixRQUFBLENBQUEsQ0FBQTtJQUNoQyxJQUFxQixVQUFyQjtNQUFBLFVBQVUsQ0FBQyxJQUFYLENBQUEsRUFBQTs7QUFDQSxXQUFPO0VBRnlCLENBQXZCOztFQUliLElBQUcsVUFBSDtJQUNJLEdBQUcsQ0FBQyxJQUFKLENBQUE7QUFDQSxXQUZKOzs7RUFJQSxNQUFNLENBQUMsUUFBUCxHQUFrQjtJQUFFLElBQUEsRUFBTSxJQUFSO0lBQWMsTUFBQSxFQUFRO0VBQXRCLEVBckVsQjs7O0VBd0VBLE1BQU0sQ0FBQyxVQUFQLEdBQW9COztFQUNwQixJQUFBLEdBQU8sUUFBQSxDQUFBLENBQUE7SUFDSCxNQUFNLENBQUMsVUFBUCxHQUFvQjtJQUVwQixJQUF3QixrQkFBeEI7O01BQUEsVUFBVSxDQUFDLE9BQVgsQ0FBQSxFQUFBOztJQUNBLEdBQUcsQ0FBQyxJQUFKLENBQUE7RUFKRzs7RUFPUCxHQUFHLENBQUMsRUFBSixDQUFPLGFBQVAsRUFBc0IsUUFBQSxDQUFBLENBQUE7SUFDbEIsTUFBTSxDQUFDLFVBQVAsR0FBb0I7SUFDcEIsTUFBTSxDQUFDLFFBQVAsR0FBa0I7RUFGQSxDQUF0QixFQWhGQTs7OztFQXVGQSxHQUFHLENBQUMsRUFBSixDQUFPLFVBQVAsRUFBbUIsUUFBQSxDQUFBLENBQUE7V0FDZixVQUFVLENBQUMsSUFBWCxDQUFBO0VBRGUsQ0FBbkI7O0VBR0EsYUFBQSxHQUFnQixRQUFBLENBQUEsQ0FBQTtJQUNaLFVBQVUsQ0FBQyxPQUFYLENBQW1CLFNBQUEsR0FBWSxlQUFaLEdBQThCLGdCQUFqRCxFQUFBOztXQUVBLFVBQVUsQ0FBQyxJQUFYLENBQWdCLGVBQWhCLEVBQWlDLFFBQUEsQ0FBQSxDQUFBO2FBQzdCLFVBQVUsQ0FBQyxXQUFXLENBQUMsSUFBdkIsQ0FBNEIsZUFBNUI7SUFENkIsQ0FBakM7RUFIWTs7RUFNaEIsbUJBQUEsR0FBc0IsUUFBQSxDQUFBLENBQUE7SUFDbEIsSUFBRyxVQUFVLENBQUMsU0FBWCxDQUFBLENBQUg7YUFBK0IsVUFBVSxDQUFDLElBQVgsQ0FBQSxFQUEvQjtLQUFBLE1BQUE7YUFBc0QsVUFBVSxDQUFDLElBQVgsQ0FBQSxFQUF0RDs7RUFEa0IsRUFoR3RCOzs7RUFvR0EsSUFBQSxHQUFPLFFBQUEsQ0FBQyxDQUFELENBQUE7V0FBTyxDQUFDLENBQUMsT0FBRixDQUFVLFFBQUEsQ0FBQyxFQUFELENBQUE7YUFBUSxVQUFBLENBQVcsRUFBWCxFQUFlLENBQWY7SUFBUixDQUFWO0VBQVA7O0VBRVAsR0FBRyxDQUFDLEVBQUosQ0FBTyxPQUFQLEVBQWdCLFFBQUEsQ0FBQSxDQUFBO0FBRVosUUFBQSxLQUFBLEVBQUEsU0FBQSxFQUFBLE9BQUEsRUFBQSxZQUFBLEVBQUEsVUFBQSxFQUFBLFNBQUEsRUFBQSxjQUFBLEVBQUEsUUFBQSxFQUFBO0lBQUEsVUFBQSxHQUFhLFFBQUEsQ0FBQSxDQUFBO0FBQ1QsVUFBQTtNQUFBLElBQUEsR0FBTztRQUNKO1VBQUMsR0FBQSxFQUFJLHdCQUFMO1VBQWdDLEdBQUEsRUFBSTtRQUFwQyxDQURJO1FBRUo7VUFBQyxHQUFBLEVBQUkseUJBQUw7VUFBZ0MsR0FBQSxFQUFJO1FBQXBDLENBRkk7O2FBSVAsQ0FBQyxDQUFDLEdBQUYsQ0FBTSxJQUFJLENBQUMsR0FBTCxDQUFTLFFBQUEsQ0FBQyxDQUFELENBQUE7ZUFBTyxDQUFDLENBQUMsT0FBRixDQUFVLFFBQUEsQ0FBQyxFQUFELENBQUE7VUFDNUIsT0FBTyxDQUFDLEdBQVIsQ0FBWSxDQUFBLGdCQUFBLENBQUEsQ0FBbUIsQ0FBQyxDQUFDLEdBQXJCLENBQUEsQ0FBWjtpQkFDQSxPQUFPLENBQUMsY0FBYyxDQUFDLFlBQXZCLENBQW9DLENBQUMsQ0FBQyxHQUF0QyxFQUEyQyxRQUFBLENBQUMsUUFBRCxDQUFBO0FBQ3ZDLGdCQUFBLENBQUEsRUFBQSxJQUFBLEVBQUEsS0FBQSxFQUFBO1lBQUEsT0FBTyxDQUFDLEdBQVIsQ0FBWSxDQUFBLGVBQUEsQ0FBQSxDQUFrQixRQUFsQixDQUFBLENBQVosRUFBQTs7WUFFQSxDQUFDLENBQUQsRUFBSSxJQUFKLENBQUEsR0FBWSxRQUFRLENBQUMsS0FBVCxDQUFlLEdBQWY7OzRCQUNhLElBQUgsR0FBYSxDQUFBLE9BQUEsQ0FBQSxDQUFVLElBQVYsQ0FBQSxDQUFiLEdBQW1DOzttQkFDekQsRUFBQSxDQUFBO1VBTHVDLENBQTNDO1FBRjRCLENBQVY7TUFBUCxDQUFULENBQU47SUFMUztJQWNiLFNBQUEsR0FBZSxPQUFPLENBQUMsUUFBUixLQUFvQixPQUF2QixHQUNSLFlBRFEsR0FHUixjQWpCSjs7SUFtQkEsVUFBQSxHQUFhLElBQUksYUFBSixDQUFrQjtNQUMzQixLQUFBLEVBQU8sR0FEb0I7TUFFM0IsTUFBQSxFQUFRLEdBRm1CO01BRzNCLFdBQUEsRUFBYSxHQUhjO01BSTNCLFlBQUEsRUFBYyxHQUphO01BSzNCLElBQUEsRUFBTSxJQUFJLENBQUMsSUFBTCxDQUFVLFNBQVYsRUFBcUIsT0FBckIsRUFBOEIsU0FBOUIsQ0FMcUI7TUFNM0IsSUFBQSxFQUFNLEtBTnFCO01BTzNCLGFBQUEsRUFBaUMsT0FBTyxDQUFDLFFBQVIsS0FBb0IsUUFBdEMsR0FBQSxjQUFBLEdBQUEsTUFQWTtNQVEzQixLQUFBLEVBQWdCLE9BQU8sQ0FBQyxRQUFSLEtBQW9CLE9BQTdCLEdBQUEsS0FBQSxHQUFBO0lBUm9CLENBQWxCLEVBbkJiOzs7SUFnQ0EsSUFBRyxLQUFIO01BQ0ksVUFBVSxDQUFDLFdBQVcsQ0FBQyxZQUF2QixDQUFBO01BQ0EsVUFBVSxDQUFDLFFBQVgsQ0FBQTtNQUNBLFVBQVUsQ0FBQyxJQUFYLENBQUE7QUFDQTtRQUNJLE9BQUEsQ0FBUSxTQUFSLENBQWtCLENBQUMsT0FBbkIsQ0FBQSxFQURKO09BQUEsY0FBQTtBQUFBO09BSko7S0FoQ0E7Ozs7O0lBMkNBLGFBQUEsQ0FBQSxFQTNDQTs7O0lBZ0RBLE9BQU8sQ0FBQyxFQUFSLENBQVcsbUJBQVgsRUFBZ0MsUUFBQSxDQUFDLEdBQUQsQ0FBQTtNQUM1QixPQUFBLENBQVEsaUJBQVIsRUFBMkIsR0FBM0I7O2FBRUEsT0FBTyxDQUFDLEdBQVIsQ0FBWSxDQUFBLHdCQUFBLENBQUEsQ0FBMkIsR0FBM0IsQ0FBK0IsRUFBL0IsQ0FBQSxHQUNSLDJDQURKLEVBQ2lELEdBRGpEO0lBSDRCLENBQWhDLEVBaERBOzs7SUF5REEsVUFBVSxDQUFDLFdBQVcsQ0FBQyxFQUF2QixDQUEwQixTQUExQixFQUFxQyxRQUFBLENBQUMsR0FBRCxDQUFBO01BQ2pDLE9BQU8sQ0FBQyxHQUFSLENBQVksNkJBQVosRUFBMkMsR0FBM0M7YUFDQSxHQUFHLENBQUMsSUFBSixDQUFTLGlCQUFULEVBQTRCO1FBQ3hCLEdBQUEsRUFBSyw0Q0FEbUI7UUFFeEIsS0FBQSxFQUFPO01BRmlCLENBQTVCO0lBRmlDLENBQXJDLEVBekRBOztJQWlFQSxPQUFBLEdBQVUsUUFBQSxDQUFBLEdBQUMsRUFBRCxDQUFBO2FBQVksVUFBVSxDQUFDLFdBQVcsQ0FBQyxJQUF2QixDQUE0QixHQUFBLEVBQTVCO0lBQVosRUFqRVY7O0lBb0VBLEtBQUEsR0FBUSxRQUFBLENBQUEsQ0FBQTtBQUNKLFVBQUEsV0FBQSxFQUFBO01BQUEsT0FBTyxDQUFDLEdBQVIsQ0FBWSw4QkFBWjtNQUNBLFdBQUEsR0FBYyxJQUFJLGFBQUosQ0FBa0I7UUFDNUIsS0FBQSxFQUFPLEdBRHFCO1FBRTVCLE1BQUEsRUFBUSxHQUZvQjtRQUc1QixXQUFBLEVBQWEsR0FIZTtRQUk1QixZQUFBLEVBQWMsR0FKYztRQUs1QixJQUFBLEVBQU0sSUFBSSxDQUFDLElBQUwsQ0FBVSxTQUFWLEVBQXFCLE9BQXJCLEVBQThCLFVBQTlCLENBTHNCO1FBTTVCLElBQUEsRUFBTSxJQU5zQjtRQU81QixjQUFBLEVBQWdCO1VBQ1osZUFBQSxFQUFpQjtRQURMO01BUFksQ0FBbEI7TUFZZCxXQUFXLENBQUMsRUFBWixDQUFlLFFBQWYsRUFBeUIsSUFBekI7TUFFQSxNQUFNLENBQUMsbUJBQVAsR0FBNkI7TUFDN0IsVUFBVSxDQUFDLElBQVgsQ0FBQTtNQUNBLFdBQVcsQ0FBQyxLQUFaLENBQUEsRUFqQkE7O01BbUJBLElBQUEsR0FBTyxLQUFBLENBQU0sV0FBTixDQUNQLENBQUMsSUFETSxDQUNELFFBQUEsQ0FBQyxFQUFELENBQUE7UUFDRixNQUFNLENBQUMsVUFBUCxHQUFvQjtRQUNwQixXQUFXLENBQUMsa0JBQVosQ0FBK0IsUUFBL0I7UUFDQSxXQUFXLENBQUMsS0FBWixDQUFBO1FBQ0EsVUFBVSxDQUFDLElBQVgsQ0FBQTtlQUNBO01BTEUsQ0FEQzthQU9QO1FBQUEsSUFBQSxFQUFNLFFBQUEsQ0FBQSxDQUFBO2lCQUFHO1FBQUg7TUFBTjtJQTNCSSxFQXBFUjs7SUFrR0EsUUFBQSxHQUFXLFFBQUEsQ0FBQSxDQUFBO0FBR1AsVUFBQTtNQUFBLElBQUEsb0RBQWdDLENBQUUsOEJBQWxDOzs7QUFBQSxlQUFPLE1BQVA7O01BQ0EsT0FBQSxDQUFRLE1BQVIsRUFBZ0I7UUFBQSxJQUFBLEVBQU0sTUFBTSxDQUFDO01BQWIsQ0FBaEI7QUFDQSxhQUFPO0lBTEEsRUFsR1g7OztJQTJHQSxTQUFBLEdBQVksUUFBQSxDQUFBLENBQUE7TUFDUixPQUFPLENBQUMsR0FBUixDQUFZLGNBQVosRUFBNEIsY0FBNUI7YUFDQSxVQUFBLENBQUEsQ0FBWSxDQUFDLElBQWIsQ0FBa0IsUUFBQSxDQUFBLENBQUE7ZUFDZCxNQUFNLENBQUMsT0FBUCxDQUFlLEtBQWYsQ0FDQSxDQUFDLElBREQsQ0FDTSxRQUFBLENBQUEsQ0FBQTtVQUNGLE9BQU8sQ0FBQyxHQUFSLENBQVksV0FBWixFQUF5QixjQUF6QixFQUFBOztVQUVBLElBQUcsY0FBQSxLQUFrQixDQUFyQjtZQUNJLFFBQUEsQ0FBQSxFQURKO1dBQUEsTUFBQTtZQUdJLFVBQUEsQ0FBQSxFQUhKOztpQkFJQSxjQUFBO1FBUEUsQ0FETixDQVNBLENBQUMsS0FURCxDQVNPLFFBQUEsQ0FBQyxDQUFELENBQUE7aUJBQU8sT0FBTyxDQUFDLEdBQVIsQ0FBWSxrQkFBWixFQUFnQyxDQUFoQztRQUFQLENBVFA7TUFEYyxDQUFsQjtJQUZRLEVBM0daOztJQTBIQSxjQUFBLEdBQWlCLEVBMUhqQjs7SUE2SEEsR0FBRyxDQUFDLEVBQUosQ0FBTyxnQkFBUCxFQUF5QixRQUFBLENBQUEsQ0FBQTtNQUNyQixPQUFPLENBQUMsR0FBUixDQUFZLFVBQVo7YUFDQSxTQUFBLENBQUE7SUFGcUIsQ0FBekI7SUFJQSxHQUFHLENBQUMsRUFBSixDQUFPLG1CQUFQLEVBQTRCLFFBQUEsQ0FBQSxDQUFBO01BQ3hCLE9BQU8sQ0FBQyxHQUFSLENBQVksYUFBWjtNQUNBLGNBQUEsR0FBaUI7YUFDakIsTUFBTSxDQUFDLFVBQVAsQ0FBQTtJQUh3QixDQUE1QixFQWpJQTs7SUF1SUEsVUFBVSxDQUFDLEVBQVgsQ0FBYyxRQUFkLEVBQXdCLFFBQUEsQ0FBQyxFQUFELENBQUE7YUFBUSxPQUFBLENBQVEsUUFBUixFQUFrQixVQUFVLENBQUMsT0FBWCxDQUFBLENBQWxCO0lBQVIsQ0FBeEI7SUFDQSxVQUFVLENBQUMsRUFBWCxDQUFjLE1BQWQsRUFBdUIsUUFBQSxDQUFDLEVBQUQsQ0FBQTthQUFRLE9BQUEsQ0FBUSxNQUFSLEVBQWdCLFVBQVUsQ0FBQyxXQUFYLENBQUEsQ0FBaEI7SUFBUixDQUF2QixFQXhJQTs7SUEySUEsTUFBTSxDQUFDLEVBQVAsQ0FBVSxnQkFBVixFQUE0QixRQUFBLENBQUMsQ0FBRCxDQUFBO01BQ3hCLE9BQU8sQ0FBQyxHQUFSLENBQVksZ0JBQVosRUFBOEIsQ0FBOUI7YUFDQSxJQUFBLENBQUssSUFBTCxDQUFVLENBQUMsSUFBWCxDQUFnQixRQUFBLENBQUEsQ0FBQTtlQUFHLFNBQUEsQ0FBQTtNQUFILENBQWhCO0lBRndCLENBQTVCLEVBM0lBOzs7SUFpSkEsR0FBRyxDQUFDLEVBQUosQ0FBTyxTQUFQLEVBQWtCLFFBQUEsQ0FBQSxDQUFBO01BQUcsSUFBZ0IsUUFBQSxDQUFBLENBQWhCO2VBQUEsVUFBQSxDQUFBLEVBQUE7O0lBQUgsQ0FBbEIsRUFqSkE7OztJQXFKQSxZQUFBLEdBQWUsQ0FBQSxDQUFBO0lBQ2YsR0FBRyxDQUFDLEVBQUosQ0FBTyxpQkFBUCxFQUEwQixRQUFBLENBQUMsRUFBRCxFQUFLLEdBQUwsQ0FBQTtBQUN0QixVQUFBLG1CQUFBLEVBQUEsT0FBQSxFQUFBLGVBQUEsRUFBQSxRQUFBLEVBQUEsbUJBQUEsRUFBQSxHQUFBLEVBQUEsSUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFDLE9BQUQsRUFBVSxJQUFWLEVBQWdCLG1CQUFoQixFQUFxQyxRQUFyQyxFQUErQyxHQUEvQyxFQUFvRCxtQkFBcEQsRUFBeUUsZUFBekUsQ0FBQSxHQUE0RixHQUE1RjtNQUNBLFdBQUEsR0FBYyxRQUFBLENBQUEsQ0FBQTtlQUFHLENBQUMsQ0FBQyxPQUFGLENBQVUsUUFBQSxDQUFDLE9BQUQsRUFBVSxNQUFWLEVBQWtCLE1BQWxCLENBQUE7QUFDdkIsY0FBQTtVQUFBLE9BQUEsR0FBVSxRQUFBLENBQUEsQ0FBQSxFQUFBOztZQUVOLElBQU8sdUJBQVA7Y0FDSSxlQUFBLEdBQWtCLEtBRHRCOzttQkFFQSxNQUFNLENBQUMsZUFBUCxDQUF1QixPQUF2QixFQUFnQyxJQUFoQyxFQUFzQyxRQUF0QyxFQUFnRCxHQUFoRCxFQUFxRCxtQkFBckQsRUFBMEUsZUFBMUUsRUFBMkYsbUJBQTNGLENBQStHLENBQUMsSUFBaEgsQ0FBcUgsUUFBQSxDQUFDLENBQUQsQ0FBQSxFQUFBOztjQUVqSCxPQUFBLENBQVEsd0JBQVIsRUFBa0MsQ0FBbEM7cUJBQ0EsT0FBQSxDQUFBO1lBSGlILENBQXJIO1VBSk07aUJBUVYsT0FBQSxDQUFBO1FBVHVCLENBQVY7TUFBSDthQVVkLFlBQUEsR0FBZSxZQUFZLENBQUMsSUFBYixDQUFrQixRQUFBLENBQUEsQ0FBQTtlQUM3QixXQUFBLENBQUE7TUFENkIsQ0FBbEI7SUFaTyxDQUExQixFQXRKQTs7SUFzS0EsR0FBRyxDQUFDLEVBQUosQ0FBTyxTQUFQLEVBQWtCLFFBQUEsQ0FBQyxFQUFELEVBQUssSUFBTCxFQUFXLFFBQVgsQ0FBQTtNQUNkLElBQUcsWUFBSDtRQUNJLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBaEIsR0FBdUIsS0FEM0I7O01BRUEsSUFBRyxnQkFBSDtlQUNJLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBaEIsR0FBeUIsU0FEN0I7O0lBSGMsQ0FBbEIsRUF0S0E7OztJQThLQSxHQUFHLENBQUMsRUFBSixDQUFPLGVBQVAsRUFBd0IsTUFBQSxDQUFPLFFBQUEsQ0FBQyxFQUFELEVBQUssRUFBTCxDQUFBO2FBQzNCLE1BQU0sQ0FBQyxhQUFQLENBQXFCLEVBQXJCLENBQXdCLENBQUMsSUFBekIsQ0FBOEIsUUFBQSxDQUFDLENBQUQsQ0FBQTtlQUMxQixPQUFBLENBQVEsc0JBQVIsRUFBZ0MsQ0FBQyxDQUFDLGVBQWdCLENBQUEsQ0FBQSxDQUFsRDtNQUQwQixDQUE5QixFQUVFLEtBRkYsRUFFUyxRQUFBLENBQUEsQ0FBQTtlQUFHO01BQUgsQ0FGVDtJQUQyQixDQUFQLENBQXhCO0lBS0EsR0FBRyxDQUFDLEVBQUosQ0FBTyxjQUFQLEVBQXVCLFFBQUEsQ0FBQyxFQUFELEVBQUssQ0FBTCxDQUFBO0FBQ25CLFVBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxHQUFBLEVBQUEsQ0FBQSxFQUFBO0FBQUE7TUFBQSxLQUFBLDJDQUFBOztZQUFtQixDQUFBLEtBQUs7dUJBQ3BCLE1BQU0sQ0FBQyxhQUFQLENBQXFCLENBQUMsQ0FBQyxFQUF2QixDQUEwQixDQUFDLElBQTNCLENBQWdDLFFBQUEsQ0FBQyxDQUFELENBQUE7bUJBQzVCLE9BQUEsQ0FBUSxzQkFBUixFQUFnQyxDQUFDLENBQUMsZUFBZ0IsQ0FBQSxDQUFBLENBQWxEO1VBRDRCLENBQWhDLEVBRUUsS0FGRixFQUVTLFFBQUEsQ0FBQSxDQUFBO21CQUFHO1VBQUgsQ0FGVDs7TUFESixDQUFBOztJQURtQixDQUF2QixFQW5MQTs7SUEwTEEsR0FBRyxDQUFDLEVBQUosQ0FBTyxhQUFQLEVBQXNCLE1BQUEsQ0FBTyxRQUFBLENBQUEsQ0FBQTthQUN6QixNQUFNLENBQUMsV0FBUCxDQUFtQixJQUFuQjtJQUR5QixDQUFQLEVBRXBCLEtBRm9CLEVBRWIsUUFBQSxDQUFBLENBQUE7YUFBRztJQUFILENBRmEsQ0FBdEIsRUExTEE7O0lBK0xBLEdBQUcsQ0FBQyxFQUFKLENBQU8saUJBQVAsRUFBMEIsTUFBQSxDQUFPLFFBQUEsQ0FBQyxFQUFELEVBQUssTUFBTCxFQUFhLElBQWIsQ0FBQTthQUM3QixNQUFNLENBQUMsZUFBUCxDQUF1QixNQUF2QixFQUErQixJQUEvQjtJQUQ2QixDQUFQLEVBRXhCLEtBRndCLEVBRWpCLFFBQUEsQ0FBQSxDQUFBO2FBQUc7SUFBSCxDQUZpQixDQUExQixFQS9MQTs7O0lBcU1BLEdBQUcsQ0FBQyxFQUFKLENBQU8saUJBQVAsRUFBMEIsTUFBQSxDQUFPLFFBQUEsQ0FBQyxFQUFELEVBQUssT0FBTCxFQUFjLElBQWQsQ0FBQTthQUM3QixNQUFNLENBQUMsZUFBUCxDQUF1QixPQUF2QixFQUFnQyxJQUFoQztJQUQ2QixDQUFQLEVBRXhCLElBRndCLEVBRWxCLFFBQUEsQ0FBQyxFQUFELEVBQUssT0FBTCxFQUFjLElBQWQsQ0FBQTthQUF1QjtJQUF2QixDQUZrQixDQUExQixFQXJNQTs7Ozs7Ozs7SUFnTkEsR0FBRyxDQUFDLEVBQUosQ0FBTyxhQUFQLEVBQXNCLE1BQUEsQ0FBTyxRQUFBLENBQUMsRUFBRCxFQUFLLElBQUwsQ0FBQTtBQUN6QixVQUFBLG1CQUFBLEVBQUE7TUFBQSxDQUFBLENBQUMsSUFBRCxFQUFPLE9BQVAsRUFBZ0IsbUJBQWhCLENBQUEsR0FBdUMsSUFBdkM7TUFDQSxPQUFBLENBQVEsZ0JBQVIsRUFBMEIsQ0FBQyxPQUFELEVBQVUsbUJBQVYsRUFBK0IsSUFBL0IsQ0FBMUI7YUFDQSxNQUFNLENBQUMsV0FBUCxDQUFtQixJQUFuQixDQUF3QixDQUFDLElBQXpCLENBQThCLFFBQUEsQ0FBQyxRQUFELENBQUE7QUFFMUIsWUFBQTtRQUFBLGVBQUEsR0FBa0I7ZUFFbEIsTUFBTSxDQUFDLGVBQVAsQ0FBdUIsT0FBdkIsRUFBZ0MsSUFBaEMsRUFBc0MsUUFBdEMsRUFBZ0QsSUFBaEQsRUFBc0QsbUJBQXRELEVBQTJFLGVBQTNFO01BSjBCLENBQTlCO0lBSHlCLENBQVAsRUFRcEIsSUFSb0IsQ0FBdEIsRUFoTkE7O0lBMk5BLEdBQUcsQ0FBQyxFQUFKLENBQU8sc0JBQVAsRUFBK0IsTUFBQSxDQUFPLFFBQUEsQ0FBQyxFQUFELEVBQUssSUFBTCxDQUFBO0FBQ2xDLFVBQUEsbUJBQUEsRUFBQSxPQUFBLEVBQUEsSUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQW1CLG1CQUFuQixDQUFBLEdBQTBDLElBQTFDO01BQ0EsSUFBQSxHQUFPLEdBQUcsQ0FBQyxRQUFKLENBQWE7UUFBQSxPQUFBLEVBQVM7TUFBVCxDQUFiO01BQ1AsT0FBQSxDQUFRLGdCQUFSLEVBQTBCO1FBQUMsT0FBRDtRQUFVLG1CQUFWO1FBQStCLElBQUEsRUFBSyxJQUFJLENBQUM7TUFBekMsQ0FBMUI7YUFDQSxDQUFDLENBQUMsT0FBRixDQUFVLFFBQUEsQ0FBQyxFQUFELEVBQUssRUFBTCxDQUFBO2VBQ04sRUFBRSxDQUFDLFNBQUgsQ0FBYSxJQUFJLENBQUMsSUFBbEIsRUFBd0IsT0FBeEIsRUFBaUMsSUFBQSxDQUFLLEVBQUwsRUFBUyxFQUFULENBQWpDO01BRE0sQ0FBVixDQUVBLENBQUMsSUFGRCxDQUVNLFFBQUEsQ0FBQSxDQUFBO2VBQ0YsTUFBTSxDQUFDLFdBQVAsQ0FBbUIsSUFBSSxDQUFDLElBQXhCO01BREUsQ0FGTixDQUlBLENBQUMsSUFKRCxDQUlNLFFBQUEsQ0FBQyxRQUFELENBQUE7QUFDRixZQUFBO1FBQUEsZUFBQSxHQUFrQjtlQUNsQixNQUFNLENBQUMsZUFBUCxDQUF1QixPQUF2QixFQUFnQyxJQUFoQyxFQUFzQyxRQUF0QyxFQUFnRCxJQUFoRCxFQUFzRCxtQkFBdEQsRUFBMkUsZUFBM0U7TUFGRSxDQUpOLENBT0EsQ0FBQyxJQVBELENBT00sUUFBQSxDQUFBLENBQUE7ZUFDRixJQUFJLENBQUMsY0FBTCxDQUFBO01BREUsQ0FQTjtJQUprQyxDQUFQLEVBYTdCLElBYjZCLENBQS9CLEVBM05BOztJQTJPQSxHQUFHLENBQUMsRUFBSixDQUFPLGtDQUFQLEVBQTJDLE1BQUEsQ0FBTyxRQUFBLENBQUMsRUFBRCxFQUFLLE9BQUwsRUFBYyxLQUFkLENBQUE7YUFDOUMsTUFBTSxDQUFDLGdDQUFQLENBQXdDLE9BQXhDLEVBQWlELEtBQWpEO0lBRDhDLENBQVAsRUFFekMsSUFGeUMsRUFFbkMsUUFBQSxDQUFDLEVBQUQsRUFBSyxPQUFMLEVBQWMsS0FBZCxDQUFBO2FBQXdCO0lBQXhCLENBRm1DLENBQTNDLEVBM09BOztJQWdQQSxHQUFHLENBQUMsRUFBSixDQUFPLG9CQUFQLEVBQTZCLE1BQUEsQ0FBTyxRQUFBLENBQUMsRUFBRCxFQUFLLE9BQUwsQ0FBQTthQUNoQyxNQUFNLENBQUMsa0JBQVAsQ0FBMEIsT0FBMUI7SUFEZ0MsQ0FBUCxFQUUzQixJQUYyQixDQUE3QjtJQUlBLEdBQUcsQ0FBQyxFQUFKLENBQU8sWUFBUCxFQUFxQixNQUFBLENBQU8sUUFBQSxDQUFDLEVBQUQsRUFBSyxPQUFMLENBQUE7YUFDeEIsTUFBTSxDQUFDLFVBQVAsQ0FBa0IsT0FBbEI7SUFEd0IsQ0FBUCxFQUVuQixJQUZtQixDQUFyQixFQXBQQTs7SUF5UEEsR0FBRyxDQUFDLEVBQUosQ0FBTyxVQUFQLEVBQW1CLE1BQUEsQ0FBTyxRQUFBLENBQUMsRUFBRCxFQUFLLE9BQUwsQ0FBQTtNQUN0QixNQUFNLENBQUMsUUFBUCxDQUFnQixPQUFoQjthQUNBLE1BQU0sQ0FBQyxlQUFQLENBQXVCLE9BQXZCLEVBQWdDLElBQUksSUFBSixDQUFBLENBQWhDLEVBQTRDLENBQTVDLEVBQStDLElBQS9DLENBQ0EsQ0FBQyxJQURELENBQ00sUUFBQSxDQUFDLENBQUQsQ0FBQTtlQUNGLE9BQUEsQ0FBUSxrQ0FBUixFQUE0QyxDQUE1QztNQURFLENBRE47SUFGc0IsQ0FBUCxFQU1qQixLQU5pQixFQU1WLFFBQUEsQ0FBQyxFQUFELEVBQUssT0FBTCxDQUFBO2FBQWlCO0lBQWpCLENBTlUsQ0FBbkI7SUFRQSxHQUFHLENBQUMsRUFBSixDQUFPLFVBQVAsRUFBbUIsUUFBQSxDQUFBLENBQUE7TUFDZixHQUFHLENBQUMsS0FBSixDQUFBO01BQ0EsSUFBRyxVQUFVLENBQUMsU0FBWCxDQUFBLENBQUg7ZUFDSSxVQUFVLENBQUMsS0FBWCxDQUFBLEVBREo7T0FBQSxNQUFBO2VBR0ksVUFBVSxDQUFDLElBQVgsQ0FBQSxFQUhKOztJQUZlLENBQW5CLEVBalFBOztJQXlRQSxHQUFHLENBQUMsRUFBSixDQUFPLFdBQVAsRUFBb0IsTUFBQSxDQUFPLFFBQUEsQ0FBQyxFQUFELEVBQUssT0FBTCxFQUFjLENBQWQsQ0FBQTthQUN2QixNQUFNLENBQUMsU0FBUCxDQUFpQixPQUFqQixFQUEwQixDQUExQjtJQUR1QixDQUFQLEVBRWxCLEtBRmtCLEVBRVgsUUFBQSxDQUFDLEVBQUQsRUFBSyxPQUFMLENBQUE7YUFBaUI7SUFBakIsQ0FGVyxDQUFwQjtJQUlBLEdBQUcsQ0FBQyxFQUFKLENBQU8sYUFBUCxFQUFzQixRQUFBLENBQUMsRUFBRCxFQUFLLEtBQUwsQ0FBQTtNQUNsQixJQUE0QixHQUFHLENBQUMsSUFBaEM7ZUFBQSxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVQsQ0FBa0IsS0FBbEIsRUFBQTs7SUFEa0IsQ0FBdEI7SUFHQSxHQUFHLENBQUMsRUFBSixDQUFPLGdCQUFQLEVBQXlCLFFBQUEsQ0FBQyxFQUFELEVBQUssS0FBTCxFQUFZLFdBQVosQ0FBQTtBQUNyQixVQUFBO01BQUEsT0FBQSxHQUFVLE1BQU0sQ0FBQyxjQUFQLENBQXNCLEtBQXRCLEVBQTZCLFdBQTdCO2FBQ1YsT0FBTyxDQUFDLElBQVIsQ0FBYSxRQUFBLENBQUMsR0FBRCxDQUFBO2VBQ1QsT0FBQSxDQUFRLHVCQUFSLEVBQWlDLEdBQWpDO01BRFMsQ0FBYjtJQUZxQixDQUF6QjtJQUlBLEdBQUcsQ0FBQyxFQUFKLENBQU8sb0JBQVAsRUFBNkIsUUFBQSxDQUFDLEVBQUQsRUFBSyxHQUFMLEVBQVUsSUFBVixFQUFnQixhQUFXLEtBQTNCLENBQUE7QUFDekIsVUFBQSxJQUFBLEVBQUE7TUFBQSxPQUFBLEdBQVUsTUFBTSxDQUFDLGtCQUFQLENBQTBCLEdBQTFCLEVBQStCLFVBQS9CO01BQ1YsSUFBQSxHQUFPO01BQ1AsT0FBTyxDQUFDLElBQVIsQ0FBYSxRQUFBLENBQUMsR0FBRCxDQUFBO0FBQ1QsWUFBQTtRQUFBLElBQUEsR0FBTyxHQUFHLENBQUM7UUFDWCxPQUFBLEdBQVUsSUFBSSxDQUFDLEVBQUUsQ0FBQztRQUNsQixJQUEyQyxJQUEzQztpQkFBQSxNQUFNLENBQUMsa0JBQVAsQ0FBMEIsT0FBMUIsRUFBbUMsSUFBbkMsRUFBQTs7TUFIUyxDQUFiO2FBSUEsT0FBQSxHQUFVLE9BQU8sQ0FBQyxJQUFSLENBQWEsUUFBQSxDQUFDLEdBQUQsQ0FBQTtlQUNuQixPQUFBLENBQVEsMkJBQVIsRUFBcUMsSUFBckMsRUFBMkMsSUFBM0M7TUFEbUIsQ0FBYjtJQVBlLENBQTdCO0lBU0EsR0FBRyxDQUFDLEVBQUosQ0FBTyxTQUFQLEVBQWtCLFFBQUEsQ0FBQyxFQUFELEVBQUssT0FBTCxFQUFjLEtBQWQsQ0FBQTthQUNkLE1BQU0sQ0FBQyxPQUFQLENBQWUsT0FBZixFQUF3QixLQUF4QixFQURjO0lBQUEsQ0FBbEI7SUFFQSxHQUFHLENBQUMsRUFBSixDQUFPLG9CQUFQLEVBQTZCLFFBQUEsQ0FBQyxFQUFELEVBQUssT0FBTCxFQUFjLE9BQWQsQ0FBQTthQUN6QixNQUFNLENBQUMsa0JBQVAsQ0FBMEIsT0FBMUIsRUFBbUMsT0FBbkMsRUFEeUI7SUFBQSxDQUE3QixFQS9SQTs7O0lBbVNBLEdBQUcsQ0FBQyxFQUFKLENBQU8sV0FBUCxFQUFvQixNQUFBLENBQU8sUUFBQSxDQUFDLEVBQUQsRUFBSyxHQUFMLEVBQVUsSUFBVixDQUFBO2FBQ3ZCLE1BQU0sQ0FBQyxhQUFQLENBQXFCLEdBQXJCLENBQXlCLENBQUMsSUFBMUIsQ0FBK0IsUUFBQSxDQUFDLENBQUQsQ0FBQTtlQUMzQixPQUFBLENBQVEsa0JBQVIsRUFBNEIsQ0FBNUIsRUFBK0IsSUFBL0I7TUFEMkIsQ0FBL0I7SUFEdUIsQ0FBUCxFQUdsQixLQUhrQixFQUdYLFFBQUEsQ0FBQyxFQUFELEVBQUssR0FBTCxDQUFBO2FBQWEsR0FBRyxDQUFDLElBQUosQ0FBQSxDQUFVLENBQUMsSUFBWCxDQUFnQixHQUFoQjtJQUFiLENBSFcsQ0FBcEIsRUFuU0E7O0lBeVNBLEdBQUcsQ0FBQyxFQUFKLENBQU8sa0JBQVAsRUFBMkIsTUFBQSxDQUFPLFFBQUEsQ0FBQyxFQUFELEVBQUssSUFBTCxDQUFBO01BQzlCLE9BQU8sQ0FBQyxHQUFSLENBQVksWUFBWjthQUNBLE1BQU0sQ0FBQyxnQkFBUCxDQUF3QixJQUF4QixDQUE2QixDQUFDLElBQTlCLENBQW1DLFFBQUEsQ0FBQyxDQUFELENBQUE7ZUFDL0IsT0FBQSxDQUFRLDJCQUFSLEVBQXFDLENBQXJDO01BRCtCLENBQW5DO0lBRjhCLENBQVAsRUFJekIsS0FKeUIsRUFJbEIsUUFBQSxDQUFDLEVBQUQsRUFBSyxJQUFMLENBQUE7YUFBYztJQUFkLENBSmtCLENBQTNCLEVBelNBOztJQWdUQSxHQUFHLENBQUMsRUFBSixDQUFPLHlCQUFQLEVBQWtDLFVBQUEsR0FBYSxNQUFBLENBQU8sUUFBQSxDQUFDLEVBQUQsQ0FBQTtNQUNsRCxPQUFPLENBQUMsR0FBUixDQUFZLFlBQVo7YUFDQSxNQUFNLENBQUMsdUJBQVAsQ0FBQSxDQUFnQyxDQUFDLElBQWpDLENBQXNDLFFBQUEsQ0FBQyxDQUFELENBQUE7UUFDbEMsT0FBQSxDQUFRLGtDQUFSLEVBQTRDLENBQTVDLEVBQUE7Ozs7ZUFJQSxPQUFBLENBQVEsV0FBUjtNQUxrQyxDQUF0QztJQUZrRCxDQUFQLEVBUTdDLEtBUjZDLEVBUXRDLFFBQUEsQ0FBQyxFQUFELEVBQUssSUFBTCxDQUFBO2FBQWM7SUFBZCxDQVJzQyxDQUEvQyxFQWhUQTs7SUEyVEEsR0FBRyxDQUFDLEVBQUosQ0FBTyxpQkFBUCxFQUEwQixNQUFBLENBQU8sUUFBQSxDQUFDLEVBQUQsRUFBSyxPQUFMLEVBQWMsU0FBZCxFQUF5QixHQUF6QixDQUFBO2FBQzdCLE1BQU0sQ0FBQyxlQUFQLENBQXVCLE9BQXZCLEVBQWdDLFNBQWhDLEVBQTJDLEdBQTNDLEVBQWdELElBQWhELENBQXFELENBQUMsSUFBdEQsQ0FBMkQsUUFBQSxDQUFDLENBQUQsQ0FBQTtlQUN2RCxPQUFBLENBQVEsMEJBQVIsRUFBb0MsQ0FBcEM7TUFEdUQsQ0FBM0Q7SUFENkIsQ0FBUCxFQUd4QixLQUh3QixFQUdqQixRQUFBLENBQUMsRUFBRCxFQUFLLE9BQUwsRUFBYyxTQUFkLEVBQXlCLEdBQXpCLENBQUE7YUFBaUM7SUFBakMsQ0FIaUIsQ0FBMUI7SUFLQSxHQUFHLENBQUMsRUFBSixDQUFPLGtCQUFQLEVBQTJCLFFBQUEsQ0FBQSxDQUFBO2FBQ3ZCLFVBQVUsQ0FBQyxhQUFYLENBQXlCLENBQUksVUFBVSxDQUFDLFlBQVgsQ0FBQSxDQUE3QjtJQUR1QixDQUEzQixFQWhVQTs7SUFvVUEsR0FBRyxDQUFDLEVBQUosQ0FBTyxRQUFQLEVBQWlCLE1BQWpCO0lBRUEsR0FBRyxDQUFDLEVBQUosQ0FBTyxNQUFQLEVBQWUsSUFBZjtJQUVBLEdBQUcsQ0FBQyxFQUFKLENBQU8sZUFBUCxFQUF3QixRQUFBLENBQUMsRUFBRCxFQUFLLEtBQUwsRUFBWSxVQUFVLFFBQXRCLENBQUE7TUFDcEIsSUFBQSxDQUF5QixNQUFNLENBQUMsYUFBaEM7UUFBQSxVQUFVLENBQUMsSUFBWCxDQUFBLEVBQUE7O01BQ0EsT0FBQSxDQUFRLGlCQUFSLEVBQTJCLEtBQTNCO2FBQ0EsT0FBTyxDQUFDLEdBQVIsQ0FBWSxDQUFBLFNBQUEsQ0FBQSxDQUFZLE9BQVosQ0FBb0IsVUFBcEIsQ0FBWixFQUE2QyxLQUE3QyxFQUFvRCxDQUFBLDhCQUFBLENBQUEsQ0FBaUMsT0FBakMsQ0FBeUMsUUFBekMsQ0FBcEQ7SUFIb0IsQ0FBeEIsRUF4VUE7O1dBOFVBLE9BQUEsQ0FBUSxhQUFSLENBQXNCLENBQUMsT0FBdkIsQ0FBK0IsUUFBQSxDQUFDLENBQUQsQ0FBQTthQUMzQixNQUFNLENBQUMsRUFBUCxDQUFVLENBQVYsRUFBYSxRQUFBLENBQUMsQ0FBRCxDQUFBO2VBQ1QsT0FBQSxDQUFRLENBQVIsRUFBVyxDQUFYO01BRFMsQ0FBYjtJQUQyQixDQUEvQjtFQWhWWSxDQUFoQjs7RUF0R0E7OztBQUFBIiwic291cmNlc0NvbnRlbnQiOlsiQ2xpZW50ICAgID0gcmVxdWlyZSAnaGFuZ3Vwc2pzJ1xuUSAgICAgICAgID0gcmVxdWlyZSAncSdcbmxvZ2luICAgICA9IHJlcXVpcmUgJy4vbG9naW4nXG5pcGMgICAgICAgPSByZXF1aXJlKCdlbGVjdHJvbicpLmlwY01haW5cbmZzICAgICAgICA9IHJlcXVpcmUgJ2ZzJ1xucGF0aCAgICAgID0gcmVxdWlyZSAncGF0aCdcbnRtcCAgICAgICA9IHJlcXVpcmUgJ3RtcCdcbnNlc3Npb24gICA9IHJlcXVpcmUoJ2VsZWN0cm9uJykuc2Vzc2lvblxuXG5cbltkcml2ZSwgcGF0aF9wYXJ0cy4uLl0gPSBwYXRoLm5vcm1hbGl6ZShfX2Rpcm5hbWUpLnNwbGl0KHBhdGguc2VwKVxuZ2xvYmFsLllBS1lBS19ST09UX0RJUiA9IFtkcml2ZSwgcGF0aF9wYXJ0cy5tYXAoZW5jb2RlVVJJQ29tcG9uZW50KS4uLl0uam9pbignLycpXG5cbiMgdGVzdCBpZiBmbGFnIGRlYnVnIGlzIHByZXNldCAob3RoZXIgZmxhZ3MgY2FuIGJlIHVzZWQgdmlhIHBhY2thZ2UgYXJnc1xuIyAgYnV0IHJlcXVyZXMgbm9kZSB2NilcbmRlYnVnID0gcHJvY2Vzcy5hcmd2LmluY2x1ZGVzICctLWRlYnVnJ1xuXG50bXAuc2V0R3JhY2VmdWxDbGVhbnVwKClcblxuYXBwID0gcmVxdWlyZSgnZWxlY3Ryb24nKS5hcHBcbmFwcC5kaXNhYmxlSGFyZHdhcmVBY2NlbGVyYXRpb24oKVxuXG5Ccm93c2VyV2luZG93ID0gcmVxdWlyZSgnZWxlY3Ryb24nKS5Ccm93c2VyV2luZG93XG5cbnVzZXJEYXRhID0gcGF0aC5ub3JtYWxpemUoYXBwLmdldFBhdGgoJ3VzZXJEYXRhJykpXG5mcy5ta2RpclN5bmModXNlckRhdGEpIGlmIG5vdCBmcy5leGlzdHNTeW5jIHVzZXJEYXRhXG5cbnBhdGhzID1cbiAgICBydG9rZW5wYXRoOiBwYXRoLmpvaW4odXNlckRhdGEsICdyZWZyZXNodG9rZW4udHh0JylcbiAgICBjb29raWVzcGF0aDogcGF0aC5qb2luKHVzZXJEYXRhLCAnY29va2llcy5qc29uJylcbiAgICBjaHJvbWVjb29raWU6IHBhdGguam9pbih1c2VyRGF0YSwgJ0Nvb2tpZXMnKVxuICAgIGNvbmZpZ3BhdGg6IHBhdGguam9pbih1c2VyRGF0YSwgJ2NvbmZpZy5qc29uJylcblxuY2xpZW50ID0gbmV3IENsaWVudChcbiAgICBydG9rZW5wYXRoOiBwYXRocy5ydG9rZW5wYXRoXG4gICAgY29va2llc3BhdGg6IHBhdGhzLmNvb2tpZXNwYXRoXG4pXG5cblxucGx1ZyA9IChycywgcmopIC0+IChlcnIsIHZhbCkgLT4gaWYgZXJyIHRoZW4gcmooZXJyKSBlbHNlIHJzKHZhbClcblxubG9nb3V0ID0gLT5cbiAgICBwcm9taXNlID0gY2xpZW50LmxvZ291dCgpXG4gICAgcHJvbWlzZS50aGVuIChyZXMpIC0+XG4gICAgICAgIGFyZ3YgPSBwcm9jZXNzLmFyZ3ZcbiAgICAgICAgc3Bhd24gPSByZXF1aXJlKCdjaGlsZF9wcm9jZXNzJykuc3Bhd25cbiAgICAgICAgIyByZW1vdmUgZWxlY3Ryb24gY29va2llc1xuICAgICAgICBtYWluV2luZG93Py53ZWJDb250ZW50cz8uc2Vzc2lvbj8uY2xlYXJTdG9yYWdlRGF0YShbXSwgKGRhdGEpIC0+IGNvbnNvbGUubG9nKGRhdGEpKVxuICAgICAgICBzcGF3biBhcmd2LnNoaWZ0KCksIGFyZ3YsXG4gICAgICAgICAgICBjd2Q6IHByb2Nlc3MuY3dkXG4gICAgICAgICAgICBlbnY6IHByb2Nlc3MuZW52XG4gICAgICAgICAgICBkZXRhY2hlZDogdHJ1ZVxuICAgICAgICAgICAgc3RkaW86ICdpbmhlcml0J1xuICAgICAgICBxdWl0KClcbiAgICByZXR1cm4gcHJvbWlzZSAjIGxpa2UgaXQgbWF0dGVyc1xuXG5zZXFyZXEgPSByZXF1aXJlICcuL3NlcXJlcSdcblxubWFpbldpbmRvdyA9IG51bGxcblxuIyBPbmx5IGFsbG93IGEgc2luZ2xlIGFjdGl2ZSBpbnN0YW5jZVxuc2hvdWxkUXVpdCA9IGFwcC5tYWtlU2luZ2xlSW5zdGFuY2UgLT5cbiAgICBtYWluV2luZG93LnNob3coKSBpZiBtYWluV2luZG93XG4gICAgcmV0dXJuIHRydWVcblxuaWYgc2hvdWxkUXVpdFxuICAgIGFwcC5xdWl0KClcbiAgICByZXR1cm5cblxuZ2xvYmFsLmkxOG5PcHRzID0geyBvcHRzOiBudWxsLCBsb2NhbGU6IG51bGwgfVxuXG4jIE5vIG1vcmUgbWluaW1pemluZyB0byB0cmF5LCBqdXN0IGNsb3NlIGl0XG5nbG9iYWwuZm9yY2VDbG9zZSA9IGZhbHNlXG5xdWl0ID0gLT5cbiAgICBnbG9iYWwuZm9yY2VDbG9zZSA9IHRydWVcbiAgICAjIGZvcmNlIGFsbCB3aW5kb3dzIHRvIGNsb3NlXG4gICAgbWFpbldpbmRvdy5kZXN0cm95KCkgaWYgbWFpbldpbmRvdz9cbiAgICBhcHAucXVpdCgpXG4gICAgcmV0dXJuXG5cbmFwcC5vbiAnYmVmb3JlLXF1aXQnLCAtPlxuICAgIGdsb2JhbC5mb3JjZUNsb3NlID0gdHJ1ZVxuICAgIGdsb2JhbC5pMThuT3B0cyA9IG51bGxcbiAgICByZXR1cm5cblxuIyBGb3IgT1NYIHNob3cgd2luZG93IG1haW4gd2luZG93IGlmIHdlJ3ZlIGhpZGRlbiBpdC5cbiMgaHR0cHM6Ly9naXRodWIuY29tL2VsZWN0cm9uL2VsZWN0cm9uL2Jsb2IvbWFzdGVyL2RvY3MvYXBpL2FwcC5tZCNldmVudC1hY3RpdmF0ZS1vcy14XG5hcHAub24gJ2FjdGl2YXRlJywgLT5cbiAgICBtYWluV2luZG93LnNob3coKVxuXG5sb2FkQXBwV2luZG93ID0gLT5cbiAgICBtYWluV2luZG93LmxvYWRVUkwgJ2ZpbGU6Ly8nICsgWUFLWUFLX1JPT1RfRElSICsgJy91aS9pbmRleC5odG1sJ1xuICAgICMgT25seSBzaG93IHdpbmRvdyB3aGVuIGl0IGhhcyBzb21lIGNvbnRlbnRcbiAgICBtYWluV2luZG93Lm9uY2UgJ3JlYWR5LXRvLXNob3cnLCAoKSAtPlxuICAgICAgICBtYWluV2luZG93LndlYkNvbnRlbnRzLnNlbmQgJ3JlYWR5LXRvLXNob3cnXG5cbnRvZ2dsZVdpbmRvd1Zpc2libGUgPSAtPlxuICAgIGlmIG1haW5XaW5kb3cuaXNWaXNpYmxlKCkgdGhlbiBtYWluV2luZG93LmhpZGUoKSBlbHNlIG1haW5XaW5kb3cuc2hvdygpXG5cbiMgaGVscGVyIHdhaXQgcHJvbWlzZVxud2FpdCA9ICh0KSAtPiBRLlByb21pc2UgKHJzKSAtPiBzZXRUaW1lb3V0IHJzLCB0XG5cbmFwcC5vbiAncmVhZHknLCAtPlxuXG4gICAgcHJveHljaGVjayA9IC0+XG4gICAgICAgIHRvZG8gPSBbXG4gICAgICAgICAgIHt1cmw6J2h0dHA6Ly9wbHVzLmdvb2dsZS5jb20nLCAgZW52OidIVFRQX1BST1hZJ31cbiAgICAgICAgICAge3VybDonaHR0cHM6Ly9wbHVzLmdvb2dsZS5jb20nLCBlbnY6J0hUVFBTX1BST1hZJ31cbiAgICAgICAgXVxuICAgICAgICBRLmFsbCB0b2RvLm1hcCAodCkgLT4gUS5Qcm9taXNlIChycykgLT5cbiAgICAgICAgICAgIGNvbnNvbGUubG9nIFwicmVzb2x2aW5nIHByb3h5ICN7dC51cmx9XCJcbiAgICAgICAgICAgIHNlc3Npb24uZGVmYXVsdFNlc3Npb24ucmVzb2x2ZVByb3h5IHQudXJsLCAocHJveHlVUkwpIC0+XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2cgXCJyZXNvbHZlZCBwcm94eSAje3Byb3h5VVJMfVwiXG4gICAgICAgICAgICAgICAgIyBGb3JtYXQgb2YgcHJveHlVUkwgaXMgZWl0aGVyIFwiRElSRUNUXCIgb3IgXCJQUk9YWSAxMjcuMC4wLjE6ODg4OFwiXG4gICAgICAgICAgICAgICAgW18sIHB1cmxdID0gcHJveHlVUkwuc3BsaXQgJyAnXG4gICAgICAgICAgICAgICAgcHJvY2Vzcy5lbnZbdC5lbnZdID89IGlmIHB1cmwgdGhlbiBcImh0dHA6Ly8je3B1cmx9XCIgZWxzZSBcIlwiXG4gICAgICAgICAgICAgICAgcnMoKVxuXG4gICAgaWNvbl9uYW1lID0gaWYgcHJvY2Vzcy5wbGF0Zm9ybSBpcyAnd2luMzInXG4gICAgICAgICdpY29uQDIucG5nJ1xuICAgIGVsc2VcbiAgICAgICAgJ2ljb25AMzIucG5nJ1xuICAgICMgQ3JlYXRlIHRoZSBicm93c2VyIHdpbmRvdy5cbiAgICBtYWluV2luZG93ID0gbmV3IEJyb3dzZXJXaW5kb3cge1xuICAgICAgICB3aWR0aDogNzMwXG4gICAgICAgIGhlaWdodDogNTkwXG4gICAgICAgIFwibWluLXdpZHRoXCI6IDYyMFxuICAgICAgICBcIm1pbi1oZWlnaHRcIjogNDIwXG4gICAgICAgIGljb246IHBhdGguam9pbiBfX2Rpcm5hbWUsICdpY29ucycsIGljb25fbmFtZVxuICAgICAgICBzaG93OiBmYWxzZVxuICAgICAgICB0aXRsZUJhclN0eWxlOiAnaGlkZGVuLWluc2V0JyBpZiBwcm9jZXNzLnBsYXRmb3JtIGlzICdkYXJ3aW4nXG4gICAgICAgIGZyYW1lOiBmYWxzZSBpZiBwcm9jZXNzLnBsYXRmb3JtIGlzICd3aW4zMidcbiAgICAgICAgIyBhdXRvSGlkZU1lbnVCYXIgOiB0cnVlIHVubGVzcyBwcm9jZXNzLnBsYXRmb3JtIGlzICdkYXJ3aW4nXG4gICAgfVxuXG4gICAgIyBMYXVuY2ggZnVsbHNjcmVlbiB3aXRoIERldlRvb2xzIG9wZW4sIHVzYWdlOiBucG0gcnVuIGRlYnVnXG4gICAgaWYgZGVidWdcbiAgICAgICAgbWFpbldpbmRvdy53ZWJDb250ZW50cy5vcGVuRGV2VG9vbHMoKVxuICAgICAgICBtYWluV2luZG93Lm1heGltaXplKClcbiAgICAgICAgbWFpbldpbmRvdy5zaG93KClcbiAgICAgICAgdHJ5XG4gICAgICAgICAgICByZXF1aXJlKCdkZXZ0cm9uJykuaW5zdGFsbCgpXG4gICAgICAgIGNhdGNoXG4gICAgICAgICAgI2RvIG5vdGhpbmdcblxuICAgICMgYW5kIGxvYWQgdGhlIGluZGV4Lmh0bWwgb2YgdGhlIGFwcC4gdGhpcyBtYXkgaG93ZXZlciBiZSB5YW5rZWRcbiAgICAjIGF3YXkgaWYgd2UgbXVzdCBkbyBhdXRoLlxuICAgIGxvYWRBcHBXaW5kb3coKVxuXG4gICAgI1xuICAgICNcbiAgICAjIEhhbmRsZSB1bmNhdWdodCBleGNlcHRpb25zIGZyb20gdGhlIG1haW4gcHJvY2Vzc1xuICAgIHByb2Nlc3Mub24gJ3VuY2F1Z2h0RXhjZXB0aW9uJywgKG1zZykgLT5cbiAgICAgICAgaXBjc2VuZCAnZXhwY2V0aW9uaW5tYWluJywgbXNnXG4gICAgICAgICNcbiAgICAgICAgY29uc29sZS5sb2cgXCJFcnJvciBvbiBtYWluIHByb2Nlc3M6XFxuI3ttc2d9XFxuXCIgK1xuICAgICAgICAgICAgXCItLS0gRW5kIG9mIGVycm9yIG1lc3NhZ2UuIE1vcmUgZGV0YWlsczpcXG5cIiwgbXNnXG5cbiAgICAjXG4gICAgI1xuICAgICMgSGFuZGxlIGNyYXNoZXMgb24gdGhlIG1haW4gd2luZG93IGFuZCBzaG93IGluIGNvbnNvbGVcbiAgICBtYWluV2luZG93LndlYkNvbnRlbnRzLm9uICdjcmFzaGVkJywgKG1zZykgLT5cbiAgICAgICAgY29uc29sZS5sb2cgJ0NyYXNoIGV2ZW50IG9uIG1haW4gd2luZG93IScsIG1zZ1xuICAgICAgICBpcGMuc2VuZCAnZXhwY2V0aW9uaW5tYWluJywge1xuICAgICAgICAgICAgbXNnOiAnRGV0ZWN0ZWQgYSBjcmFzaCBldmVudCBvbiB0aGUgbWFpbiB3aW5kb3cuJ1xuICAgICAgICAgICAgZXZlbnQ6IG1zZ1xuICAgICAgICB9XG5cbiAgICAjIHNob3J0IGhhbmRcbiAgICBpcGNzZW5kID0gKGFzLi4uKSAtPiAgbWFpbldpbmRvdy53ZWJDb250ZW50cy5zZW5kIGFzLi4uXG5cbiAgICAjIGNhbGxiYWNrIGZvciBjcmVkZW50aWFsc1xuICAgIGNyZWRzID0gLT5cbiAgICAgICAgY29uc29sZS5sb2cgXCJhc2tpbmcgZm9yIGxvZ2luIGNyZWRlbnRpYWxzXCJcbiAgICAgICAgbG9naW5XaW5kb3cgPSBuZXcgQnJvd3NlcldpbmRvdyB7XG4gICAgICAgICAgICB3aWR0aDogNzMwXG4gICAgICAgICAgICBoZWlnaHQ6IDU5MFxuICAgICAgICAgICAgXCJtaW4td2lkdGhcIjogNjIwXG4gICAgICAgICAgICBcIm1pbi1oZWlnaHRcIjogNDIwXG4gICAgICAgICAgICBpY29uOiBwYXRoLmpvaW4gX19kaXJuYW1lLCAnaWNvbnMnLCAnaWNvbi5wbmcnXG4gICAgICAgICAgICBzaG93OiB0cnVlXG4gICAgICAgICAgICB3ZWJQcmVmZXJlbmNlczoge1xuICAgICAgICAgICAgICAgIG5vZGVJbnRlZ3JhdGlvbjogZmFsc2VcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGxvZ2luV2luZG93Lm9uICdjbG9zZWQnLCBxdWl0XG5cbiAgICAgICAgZ2xvYmFsLndpbmRvd0hpZGVXaGlsZUNyZWQgPSB0cnVlXG4gICAgICAgIG1haW5XaW5kb3cuaGlkZSgpXG4gICAgICAgIGxvZ2luV2luZG93LmZvY3VzKClcbiAgICAgICAgIyByZWluc3RhdGUgYXBwIHdpbmRvdyB3aGVuIGxvZ2luIGZpbmlzaGVzXG4gICAgICAgIHByb20gPSBsb2dpbihsb2dpbldpbmRvdylcbiAgICAgICAgLnRoZW4gKHJzKSAtPlxuICAgICAgICAgICAgZ2xvYmFsLmZvcmNlQ2xvc2UgPSB0cnVlXG4gICAgICAgICAgICBsb2dpbldpbmRvdy5yZW1vdmVBbGxMaXN0ZW5lcnMgJ2Nsb3NlZCdcbiAgICAgICAgICAgIGxvZ2luV2luZG93LmNsb3NlKClcbiAgICAgICAgICAgIG1haW5XaW5kb3cuc2hvdygpXG4gICAgICAgICAgICByc1xuICAgICAgICBhdXRoOiAtPiBwcm9tXG5cbiAgICAjIHNlbmRzIHRoZSBpbml0IHN0cnVjdHVyZXMgdG8gdGhlIGNsaWVudFxuICAgIHNlbmRJbml0ID0gLT5cbiAgICAgICAgIyB3ZSBoYXZlIG5vIGluaXQgZGF0YSBiZWZvcmUgdGhlIGNsaWVudCBoYXMgY29ubmVjdGVkIGZpcnN0XG4gICAgICAgICMgdGltZS5cbiAgICAgICAgcmV0dXJuIGZhbHNlIHVubGVzcyBjbGllbnQ/LmluaXQ/LnNlbGZfZW50aXR5XG4gICAgICAgIGlwY3NlbmQgJ2luaXQnLCBpbml0OiBjbGllbnQuaW5pdFxuICAgICAgICByZXR1cm4gdHJ1ZVxuXG4gICAgIyBrZWVwcyB0cnlpbmcgdG8gY29ubmVjIHRoZSBoYW5ndXBzanMgYW5kIGNvbW11bmljYXRlcyB0aG9zZVxuICAgICMgYXR0ZW1wdHMgdG8gdGhlIGNsaWVudC5cbiAgICByZWNvbm5lY3QgPSAtPlxuICAgICAgICBjb25zb2xlLmxvZyAncmVjb25uZWN0aW5nJywgcmVjb25uZWN0Q291bnRcbiAgICAgICAgcHJveHljaGVjaygpLnRoZW4gLT5cbiAgICAgICAgICAgIGNsaWVudC5jb25uZWN0KGNyZWRzKVxuICAgICAgICAgICAgLnRoZW4gLT5cbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyAnY29ubmVjdGVkJywgcmVjb25uZWN0Q291bnRcbiAgICAgICAgICAgICAgICAjIG9uIGZpcnN0IGNvbm5lY3QsIHNlbmQgaW5pdCwgYWZ0ZXIgdGhhdCBvbmx5IHJlc3luY1xuICAgICAgICAgICAgICAgIGlmIHJlY29ubmVjdENvdW50ID09IDBcbiAgICAgICAgICAgICAgICAgICAgc2VuZEluaXQoKVxuICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgc3luY3JlY2VudCgpXG4gICAgICAgICAgICAgICAgcmVjb25uZWN0Q291bnQrK1xuICAgICAgICAgICAgLmNhdGNoIChlKSAtPiBjb25zb2xlLmxvZyAnZXJyb3IgY29ubmVjdGluZycsIGVcblxuICAgICMgY291bnRlciBmb3IgcmVjb25uZWN0c1xuICAgIHJlY29ubmVjdENvdW50ID0gMFxuXG4gICAgIyB3aGV0aGVyIHRvIGNvbm5lY3QgaXMgZGljdGF0ZWQgYnkgdGhlIGNsaWVudC5cbiAgICBpcGMub24gJ2hhbmd1cHNDb25uZWN0JywgLT5cbiAgICAgICAgY29uc29sZS5sb2cgJ2hjb25uZWN0J1xuICAgICAgICByZWNvbm5lY3QoKVxuXG4gICAgaXBjLm9uICdoYW5ndXBzRGlzY29ubmVjdCcsIC0+XG4gICAgICAgIGNvbnNvbGUubG9nICdoZGlzY29ubmVjdCdcbiAgICAgICAgcmVjb25uZWN0Q291bnQgPSAwXG4gICAgICAgIGNsaWVudC5kaXNjb25uZWN0KClcblxuICAgICMgY2xpZW50IGRlYWxzIHdpdGggd2luZG93IHNpemluZ1xuICAgIG1haW5XaW5kb3cub24gJ3Jlc2l6ZScsIChldikgLT4gaXBjc2VuZCAncmVzaXplJywgbWFpbldpbmRvdy5nZXRTaXplKClcbiAgICBtYWluV2luZG93Lm9uICdtb3ZlJywgIChldikgLT4gaXBjc2VuZCAnbW92ZScsIG1haW5XaW5kb3cuZ2V0UG9zaXRpb24oKVxuXG4gICAgIyB3aGVuZXZlciBpdCBmYWlscywgd2UgdHJ5IGFnYWluXG4gICAgY2xpZW50Lm9uICdjb25uZWN0X2ZhaWxlZCcsIChlKSAtPlxuICAgICAgICBjb25zb2xlLmxvZyAnY29ubmVjdF9mYWlsZWQnLCBlXG4gICAgICAgIHdhaXQoMzAwMCkudGhlbiAtPiByZWNvbm5lY3QoKVxuXG4gICAgIyB3aGVuIGNsaWVudCByZXF1ZXN0cyAocmUtKWluaXQgc2luY2UgdGhlIGZpcnN0IGluaXRcbiAgICAjIG9iamVjdCBpcyBzZW50IGFzIHNvb24gYXMgcG9zc2libGUgb24gc3RhcnR1cFxuICAgIGlwYy5vbiAncmVxaW5pdCcsIC0+IHN5bmNyZWNlbnQoKSBpZiBzZW5kSW5pdCgpXG5cbiAgICAjIHNlbmRjaGF0bWVzc2FnZSwgZXhlY3V0ZWQgc2VxdWVudGlhbGx5IGFuZFxuICAgICMgcmV0cmllZCBpZiBub3Qgc2VudCBzdWNjZXNzZnVsbHlcbiAgICBtZXNzYWdlUXVldWUgPSBRKClcbiAgICBpcGMub24gJ3NlbmRjaGF0bWVzc2FnZScsIChldiwgbXNnKSAtPlxuICAgICAgICB7Y29udl9pZCwgc2VncywgY2xpZW50X2dlbmVyYXRlZF9pZCwgaW1hZ2VfaWQsIG90ciwgbWVzc2FnZV9hY3Rpb25fdHlwZSwgZGVsaXZlcnlfbWVkaXVtfSA9IG1zZ1xuICAgICAgICBzZW5kRm9yU3VyZSA9IC0+IFEucHJvbWlzZSAocmVzb2x2ZSwgcmVqZWN0LCBub3RpZnkpIC0+XG4gICAgICAgICAgICBhdHRlbXB0ID0gLT5cbiAgICAgICAgICAgICAgICAjIGNvbnNvbGUubG9nICdzZW5kY2hhdG1lc3NhZ2UnLCBjbGllbnRfZ2VuZXJhdGVkX2lkXG4gICAgICAgICAgICAgICAgaWYgbm90IGRlbGl2ZXJ5X21lZGl1bT9cbiAgICAgICAgICAgICAgICAgICAgZGVsaXZlcnlfbWVkaXVtID0gbnVsbFxuICAgICAgICAgICAgICAgIGNsaWVudC5zZW5kY2hhdG1lc3NhZ2UoY29udl9pZCwgc2VncywgaW1hZ2VfaWQsIG90ciwgY2xpZW50X2dlbmVyYXRlZF9pZCwgZGVsaXZlcnlfbWVkaXVtLCBtZXNzYWdlX2FjdGlvbl90eXBlKS50aGVuIChyKSAtPlxuICAgICAgICAgICAgICAgICAgICAgICMgY29uc29sZS5sb2cgJ3NlbmRjaGF0bWVzc2FnZTpyZXN1bHQnLCByPy5jcmVhdGVkX2V2ZW50Py5zZWxmX2V2ZW50X3N0YXRlPy5jbGllbnRfZ2VuZXJhdGVkX2lkXG4gICAgICAgICAgICAgICAgICAgIGlwY3NlbmQgJ3NlbmRjaGF0bWVzc2FnZTpyZXN1bHQnLCByXG4gICAgICAgICAgICAgICAgICAgIHJlc29sdmUoKVxuICAgICAgICAgICAgYXR0ZW1wdCgpXG4gICAgICAgIG1lc3NhZ2VRdWV1ZSA9IG1lc3NhZ2VRdWV1ZS50aGVuIC0+XG4gICAgICAgICAgICBzZW5kRm9yU3VyZSgpXG5cbiAgICAjIGdldCBsb2NhbGUgZm9yIHRyYW5zbGF0aW9uc1xuICAgIGlwYy5vbiAnc2V0aTE4bicsIChldiwgb3B0cywgbGFuZ3VhZ2UpLT5cbiAgICAgICAgaWYgb3B0cz9cbiAgICAgICAgICAgIGdsb2JhbC5pMThuT3B0cy5vcHRzID0gb3B0c1xuICAgICAgICBpZiBsYW5ndWFnZT9cbiAgICAgICAgICAgIGdsb2JhbC5pMThuT3B0cy5sb2NhbGUgPSBsYW5ndWFnZVxuXG4gICAgIyBzZW5kY2hhdG1lc3NhZ2UsIGV4ZWN1dGVkIHNlcXVlbnRpYWxseSBhbmRcbiAgICAjIHJldHJpZWQgaWYgbm90IHNlbnQgc3VjY2Vzc2Z1bGx5XG4gICAgaXBjLm9uICdxdWVyeXByZXNlbmNlJywgc2VxcmVxIChldiwgaWQpIC0+XG4gICAgICAgIGNsaWVudC5xdWVyeXByZXNlbmNlKGlkKS50aGVuIChyKSAtPlxuICAgICAgICAgICAgaXBjc2VuZCAncXVlcnlwcmVzZW5jZTpyZXN1bHQnLCByLnByZXNlbmNlX3Jlc3VsdFswXVxuICAgICAgICAsIGZhbHNlLCAtPiAxXG5cbiAgICBpcGMub24gJ2luaXRwcmVzZW5jZScsIChldiwgbCkgLT5cbiAgICAgICAgZm9yIHAsIGkgaW4gbCB3aGVuIHAgIT0gbnVsbFxuICAgICAgICAgICAgY2xpZW50LnF1ZXJ5cHJlc2VuY2UocC5pZCkudGhlbiAocikgLT5cbiAgICAgICAgICAgICAgICBpcGNzZW5kICdxdWVyeXByZXNlbmNlOnJlc3VsdCcsIHIucHJlc2VuY2VfcmVzdWx0WzBdXG4gICAgICAgICAgICAsIGZhbHNlLCAtPiAxXG5cbiAgICAjIG5vIHJldHJ5LCBvbmx5IG9uZSBvdXRzdGFuZGluZyBjYWxsXG4gICAgaXBjLm9uICdzZXRwcmVzZW5jZScsIHNlcXJlcSAtPlxuICAgICAgICBjbGllbnQuc2V0cHJlc2VuY2UodHJ1ZSlcbiAgICAsIGZhbHNlLCAtPiAxXG5cbiAgICAjIG5vIHJldHJ5LCBvbmx5IG9uZSBvdXRzdGFuZGluZyBjYWxsXG4gICAgaXBjLm9uICdzZXRhY3RpdmVjbGllbnQnLCBzZXFyZXEgKGV2LCBhY3RpdmUsIHNlY3MpIC0+XG4gICAgICAgIGNsaWVudC5zZXRhY3RpdmVjbGllbnQgYWN0aXZlLCBzZWNzXG4gICAgLCBmYWxzZSwgLT4gMVxuXG4gICAgIyB3YXRlcm1hcmtpbmcgaXMgb25seSBpbnRlcmVzdGluZyBmb3IgdGhlIGxhc3Qgb2YgZWFjaCBjb252X2lkXG4gICAgIyByZXRyeSBzZW5kIGFuZCBkZWR1cGUgZm9yIGVhY2ggY29udl9pZFxuICAgIGlwYy5vbiAndXBkYXRld2F0ZXJtYXJrJywgc2VxcmVxIChldiwgY29udl9pZCwgdGltZSkgLT5cbiAgICAgICAgY2xpZW50LnVwZGF0ZXdhdGVybWFyayBjb252X2lkLCB0aW1lXG4gICAgLCB0cnVlLCAoZXYsIGNvbnZfaWQsIHRpbWUpIC0+IGNvbnZfaWRcblxuICAgICMgZ2V0ZW50aXR5IGlzIG5vdCBzdXBlciBpbXBvcnRhbnQsIHRoZSBjbGllbnQgd2lsbCB0cnkgYWdhaW4gd2hlbiBlbmNvdW50ZXJpbmdcbiAgICAjIGVudGl0aWVzIHdpdGhvdXQgcGhvdG9fdXJsLiBzbyBubyByZXRyeSwgYnV0IGRvIGV4ZWN1dGUgYWxsIHN1Y2ggcmVxc1xuICAgICMgaXBjLm9uICdnZXRlbnRpdHknLCBzZXFyZXEgKGV2LCBpZHMpIC0+XG4gICAgIyAgICAgY2xpZW50LmdldGVudGl0eWJ5aWQoaWRzKS50aGVuIChyKSAtPiBpcGNzZW5kICdnZXRlbnRpdHk6cmVzdWx0JywgclxuICAgICMgLCBmYWxzZVxuXG4gICAgIyB3ZSB3YW50IHRvIHVwbG9hZC4gaW4gdGhlIG9yZGVyIHNwZWNpZmllZCwgd2l0aCByZXRyeVxuICAgIGlwYy5vbiAndXBsb2FkaW1hZ2UnLCBzZXFyZXEgKGV2LCBzcGVjKSAtPlxuICAgICAgICB7cGF0aCwgY29udl9pZCwgY2xpZW50X2dlbmVyYXRlZF9pZH0gPSBzcGVjXG4gICAgICAgIGlwY3NlbmQgJ3VwbG9hZGluZ2ltYWdlJywge2NvbnZfaWQsIGNsaWVudF9nZW5lcmF0ZWRfaWQsIHBhdGh9XG4gICAgICAgIGNsaWVudC51cGxvYWRpbWFnZShwYXRoKS50aGVuIChpbWFnZV9pZCkgLT5cblxuICAgICAgICAgICAgZGVsaXZlcnlfbWVkaXVtID0gbnVsbFxuXG4gICAgICAgICAgICBjbGllbnQuc2VuZGNoYXRtZXNzYWdlIGNvbnZfaWQsIG51bGwsIGltYWdlX2lkLCBudWxsLCBjbGllbnRfZ2VuZXJhdGVkX2lkLCBkZWxpdmVyeV9tZWRpdW1cbiAgICAsIHRydWVcblxuICAgICMgd2Ugd2FudCB0byB1cGxvYWQuIGluIHRoZSBvcmRlciBzcGVjaWZpZWQsIHdpdGggcmV0cnlcbiAgICBpcGMub24gJ3VwbG9hZGNsaXBib2FyZGltYWdlJywgc2VxcmVxIChldiwgc3BlYykgLT5cbiAgICAgICAge3BuZ0RhdGEsIGNvbnZfaWQsIGNsaWVudF9nZW5lcmF0ZWRfaWR9ID0gc3BlY1xuICAgICAgICBmaWxlID0gdG1wLmZpbGVTeW5jIHBvc3RmaXg6IFwiLnBuZ1wiXG4gICAgICAgIGlwY3NlbmQgJ3VwbG9hZGluZ2ltYWdlJywge2NvbnZfaWQsIGNsaWVudF9nZW5lcmF0ZWRfaWQsIHBhdGg6ZmlsZS5uYW1lfVxuICAgICAgICBRLlByb21pc2UgKHJzLCByaikgLT5cbiAgICAgICAgICAgIGZzLndyaXRlRmlsZSBmaWxlLm5hbWUsIHBuZ0RhdGEsIHBsdWcocnMsIHJqKVxuICAgICAgICAudGhlbiAtPlxuICAgICAgICAgICAgY2xpZW50LnVwbG9hZGltYWdlKGZpbGUubmFtZSlcbiAgICAgICAgLnRoZW4gKGltYWdlX2lkKSAtPlxuICAgICAgICAgICAgZGVsaXZlcnlfbWVkaXVtID0gbnVsbFxuICAgICAgICAgICAgY2xpZW50LnNlbmRjaGF0bWVzc2FnZSBjb252X2lkLCBudWxsLCBpbWFnZV9pZCwgbnVsbCwgY2xpZW50X2dlbmVyYXRlZF9pZCwgZGVsaXZlcnlfbWVkaXVtXG4gICAgICAgIC50aGVuIC0+XG4gICAgICAgICAgICBmaWxlLnJlbW92ZUNhbGxiYWNrKClcbiAgICAsIHRydWVcblxuICAgICMgcmV0cnkgb25seSBsYXN0IHBlciBjb252X2lkXG4gICAgaXBjLm9uICdzZXRjb252ZXJzYXRpb25ub3RpZmljYXRpb25sZXZlbCcsIHNlcXJlcSAoZXYsIGNvbnZfaWQsIGxldmVsKSAtPlxuICAgICAgICBjbGllbnQuc2V0Y29udmVyc2F0aW9ubm90aWZpY2F0aW9ubGV2ZWwgY29udl9pZCwgbGV2ZWxcbiAgICAsIHRydWUsIChldiwgY29udl9pZCwgbGV2ZWwpIC0+IGNvbnZfaWRcblxuICAgICMgcmV0cnlcbiAgICBpcGMub24gJ2RlbGV0ZWNvbnZlcnNhdGlvbicsIHNlcXJlcSAoZXYsIGNvbnZfaWQpIC0+XG4gICAgICAgIGNsaWVudC5kZWxldGVjb252ZXJzYXRpb24gY29udl9pZFxuICAgICwgdHJ1ZVxuXG4gICAgaXBjLm9uICdyZW1vdmV1c2VyJywgc2VxcmVxIChldiwgY29udl9pZCkgLT5cbiAgICAgICAgY2xpZW50LnJlbW92ZXVzZXIgY29udl9pZFxuICAgICwgdHJ1ZVxuXG4gICAgIyBubyByZXRyaWVzLCBkZWR1cGUgb24gY29udl9pZFxuICAgIGlwYy5vbiAnc2V0Zm9jdXMnLCBzZXFyZXEgKGV2LCBjb252X2lkKSAtPlxuICAgICAgICBjbGllbnQuc2V0Zm9jdXMgY29udl9pZFxuICAgICAgICBjbGllbnQuZ2V0Y29udmVyc2F0aW9uIGNvbnZfaWQsIG5ldyBEYXRlKCksIDEsIHRydWVcbiAgICAgICAgLnRoZW4gKHIpIC0+XG4gICAgICAgICAgICBpcGNzZW5kICdnZXRjb252ZXJzYXRpb25tZXRhZGF0YTpyZXNwb25zZScsIHJcblxuICAgICwgZmFsc2UsIChldiwgY29udl9pZCkgLT4gY29udl9pZFxuXG4gICAgaXBjLm9uICdhcHBmb2N1cycsIC0+XG4gICAgICAgIGFwcC5mb2N1cygpXG4gICAgICAgIGlmIG1haW5XaW5kb3cuaXNWaXNpYmxlKClcbiAgICAgICAgICAgIG1haW5XaW5kb3cuZm9jdXMoKVxuICAgICAgICBlbHNlXG4gICAgICAgICAgICBtYWluV2luZG93LnNob3coKVxuXG4gICAgIyBubyByZXRyaWVzLCBkZWR1cGUgb24gY29udl9pZFxuICAgIGlwYy5vbiAnc2V0dHlwaW5nJywgc2VxcmVxIChldiwgY29udl9pZCwgdikgLT5cbiAgICAgICAgY2xpZW50LnNldHR5cGluZyBjb252X2lkLCB2XG4gICAgLCBmYWxzZSwgKGV2LCBjb252X2lkKSAtPiBjb252X2lkXG5cbiAgICBpcGMub24gJ3VwZGF0ZWJhZGdlJywgKGV2LCB2YWx1ZSkgLT5cbiAgICAgICAgYXBwLmRvY2suc2V0QmFkZ2UodmFsdWUpIGlmIGFwcC5kb2NrXG5cbiAgICBpcGMub24gJ3NlYXJjaGVudGl0aWVzJywgKGV2LCBxdWVyeSwgbWF4X3Jlc3VsdHMpIC0+XG4gICAgICAgIHByb21pc2UgPSBjbGllbnQuc2VhcmNoZW50aXRpZXMgcXVlcnksIG1heF9yZXN1bHRzXG4gICAgICAgIHByb21pc2UudGhlbiAocmVzKSAtPlxuICAgICAgICAgICAgaXBjc2VuZCAnc2VhcmNoZW50aXRpZXM6cmVzdWx0JywgcmVzXG4gICAgaXBjLm9uICdjcmVhdGVjb252ZXJzYXRpb24nLCAoZXYsIGlkcywgbmFtZSwgZm9yY2Vncm91cD1mYWxzZSkgLT5cbiAgICAgICAgcHJvbWlzZSA9IGNsaWVudC5jcmVhdGVjb252ZXJzYXRpb24gaWRzLCBmb3JjZWdyb3VwXG4gICAgICAgIGNvbnYgPSBudWxsXG4gICAgICAgIHByb21pc2UudGhlbiAocmVzKSAtPlxuICAgICAgICAgICAgY29udiA9IHJlcy5jb252ZXJzYXRpb25cbiAgICAgICAgICAgIGNvbnZfaWQgPSBjb252LmlkLmlkXG4gICAgICAgICAgICBjbGllbnQucmVuYW1lY29udmVyc2F0aW9uIGNvbnZfaWQsIG5hbWUgaWYgbmFtZVxuICAgICAgICBwcm9taXNlID0gcHJvbWlzZS50aGVuIChyZXMpIC0+XG4gICAgICAgICAgICBpcGNzZW5kICdjcmVhdGVjb252ZXJzYXRpb246cmVzdWx0JywgY29udiwgbmFtZVxuICAgIGlwYy5vbiAnYWRkdXNlcicsIChldiwgY29udl9pZCwgdG9hZGQpIC0+XG4gICAgICAgIGNsaWVudC5hZGR1c2VyIGNvbnZfaWQsIHRvYWRkICPCoHdpbGwgYXV0b21hdGljYWxseSB0cmlnZ2VyIG1lbWJlcnNoaXBfY2hhbmdlXG4gICAgaXBjLm9uICdyZW5hbWVjb252ZXJzYXRpb24nLCAoZXYsIGNvbnZfaWQsIG5ld25hbWUpIC0+XG4gICAgICAgIGNsaWVudC5yZW5hbWVjb252ZXJzYXRpb24gY29udl9pZCwgbmV3bmFtZSAjIHdpbGwgdHJpZ2dlciBjb252ZXJzYXRpb25fcmVuYW1lXG5cbiAgICAjIG5vIHJldHJpZXMsIGp1c3QgZGVkdXBlIG9uIHRoZSBpZHNcbiAgICBpcGMub24gJ2dldGVudGl0eScsIHNlcXJlcSAoZXYsIGlkcywgZGF0YSkgLT5cbiAgICAgICAgY2xpZW50LmdldGVudGl0eWJ5aWQoaWRzKS50aGVuIChyKSAtPlxuICAgICAgICAgICAgaXBjc2VuZCAnZ2V0ZW50aXR5OnJlc3VsdCcsIHIsIGRhdGFcbiAgICAsIGZhbHNlLCAoZXYsIGlkcykgLT4gaWRzLnNvcnQoKS5qb2luKCcsJylcblxuICAgICMgbm8gcmV0cnksIGp1c3Qgb25lIHNpbmdsZSByZXF1ZXN0XG4gICAgaXBjLm9uICdzeW5jYWxsbmV3ZXZlbnRzJywgc2VxcmVxIChldiwgdGltZSkgLT5cbiAgICAgICAgY29uc29sZS5sb2cgJ3N5bmNhbGxuZXcnXG4gICAgICAgIGNsaWVudC5zeW5jYWxsbmV3ZXZlbnRzKHRpbWUpLnRoZW4gKHIpIC0+XG4gICAgICAgICAgICBpcGNzZW5kICdzeW5jYWxsbmV3ZXZlbnRzOnJlc3BvbnNlJywgclxuICAgICwgZmFsc2UsIChldiwgdGltZSkgLT4gMVxuXG4gICAgIyBubyByZXRyeSwganVzdCBvbmUgc2luZ2xlIHJlcXVlc3RcbiAgICBpcGMub24gJ3N5bmNyZWNlbnRjb252ZXJzYXRpb25zJywgc3luY3JlY2VudCA9IHNlcXJlcSAoZXYpIC0+XG4gICAgICAgIGNvbnNvbGUubG9nICdzeW5jcmVjZW50J1xuICAgICAgICBjbGllbnQuc3luY3JlY2VudGNvbnZlcnNhdGlvbnMoKS50aGVuIChyKSAtPlxuICAgICAgICAgICAgaXBjc2VuZCAnc3luY3JlY2VudGNvbnZlcnNhdGlvbnM6cmVzcG9uc2UnLCByXG4gICAgICAgICAgICAjIHRoaXMgaXMgYmVjYXVzZSB3ZSB1c2Ugc3luY3JlY2VudCBvbiByZXFpbml0IChkZXYtbW9kZVxuICAgICAgICAgICAgIyByZWZyZXNoKS4gaWYgd2Ugc3VjY2VlZGVkIGdldHRpbmcgYSByZXNwb25zZSwgd2UgY2FsbCBpdFxuICAgICAgICAgICAgIyBjb25uZWN0ZWQuXG4gICAgICAgICAgICBpcGNzZW5kICdjb25uZWN0ZWQnXG4gICAgLCBmYWxzZSwgKGV2LCB0aW1lKSAtPiAxXG5cbiAgICAjIHJldHJ5LCBvbmUgc2luZ2xlIHBlciBjb252X2lkXG4gICAgaXBjLm9uICdnZXRjb252ZXJzYXRpb24nLCBzZXFyZXEgKGV2LCBjb252X2lkLCB0aW1lc3RhbXAsIG1heCkgLT5cbiAgICAgICAgY2xpZW50LmdldGNvbnZlcnNhdGlvbihjb252X2lkLCB0aW1lc3RhbXAsIG1heCwgdHJ1ZSkudGhlbiAocikgLT5cbiAgICAgICAgICAgIGlwY3NlbmQgJ2dldGNvbnZlcnNhdGlvbjpyZXNwb25zZScsIHJcbiAgICAsIGZhbHNlLCAoZXYsIGNvbnZfaWQsIHRpbWVzdGFtcCwgbWF4KSAtPiBjb252X2lkXG5cbiAgICBpcGMub24gJ3RvZ2dsZWZ1bGxzY3JlZW4nLCAtPlxuICAgICAgICBtYWluV2luZG93LnNldEZ1bGxTY3JlZW4gbm90IG1haW5XaW5kb3cuaXNGdWxsU2NyZWVuKClcblxuICAgICMgYnllIGJ5ZVxuICAgIGlwYy5vbiAnbG9nb3V0JywgbG9nb3V0XG5cbiAgICBpcGMub24gJ3F1aXQnLCBxdWl0XG5cbiAgICBpcGMub24gJ2Vycm9ySW5XaW5kb3cnLCAoZXYsIGVycm9yLCB3aW5OYW1lID0gJ1lha1lhaycpIC0+XG4gICAgICAgIG1haW5XaW5kb3cuc2hvdygpIHVubGVzcyBnbG9iYWwuaXNSZWFkeVRvU2hvd1xuICAgICAgICBpcGNzZW5kICdleHBjZXRpb25pbm1haW4nLCBlcnJvclxuICAgICAgICBjb25zb2xlLmxvZyBcIkVycm9yIG9uICN7d2luTmFtZX0gd2luZG93OlxcblwiLCBlcnJvciwgXCJcXG4tLS0gRW5kIG9mIGVycm9yIG1lc3NhZ2UgaW4gI3t3aW5OYW1lfSB3aW5kb3cuXCJcblxuICAgICMgcHJvcGFnYXRlIHRoZXNlIGV2ZW50cyB0byB0aGUgcmVuZGVyZXJcbiAgICByZXF1aXJlKCcuL3VpL2V2ZW50cycpLmZvckVhY2ggKG4pIC0+XG4gICAgICAgIGNsaWVudC5vbiBuLCAoZSkgLT5cbiAgICAgICAgICAgIGlwY3NlbmQgbiwgZVxuXG4gICAgIyBFbWl0dGVkIHdoZW4gdGhlIHdpbmRvdyBpcyBhYm91dCB0byBjbG9zZS5cbiAgICAjIEhpZGVzIHRoZSB3aW5kb3cgaWYgd2UncmUgbm90IGZvcmNlIGNsb3NpbmcuXG4gICAgIyAgSU1QT1JUQU5UOiBtb3ZlZCB0byBhcHAuY29mZmVlXG4iXX0=
