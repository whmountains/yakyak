(function() {
  var ClientDeliveryMediumType, MessageActionType, MessageBuilder, OffTheRecordStatus, buildChatMessage, conv, parse, randomid, split_first, urlRegexp, viewstate;

  urlRegexp = require('uber-url-regex');

  ({MessageBuilder, OffTheRecordStatus, MessageActionType, ClientDeliveryMediumType} = require('hangupsjs'));

  viewstate = require('./viewstate');

  conv = require('./conv');

  randomid = function() {
    return Math.round(Math.random() * Math.pow(2, 32));
  };

  split_first = function(str, token) {
    var first, last, start;
    start = str.indexOf(token);
    first = str.substr(0, start);
    last = str.substr(start + token.length);
    return [first, last];
  };

  parse = function(mb, txt) {
    var after, before, i, index, j, last, len, len1, line, lines, url, urls;
    lines = txt.split(/\r?\n/);
    last = lines.length - 1;
    for (index = i = 0, len = lines.length; i < len; index = ++i) {
      line = lines[index];
      urls = line.match(urlRegexp());
      if (urls != null) {
        for (j = 0, len1 = urls.length; j < len1; j++) {
          url = urls[j];
          [before, after] = split_first(line, url);
          if (before) {
            mb.text(before);
          }
          line = after;
          mb.link(url, url);
        }
      }
      if (line) {
        mb.text(line);
      }
      if (index !== last) {
        mb.linebreak();
      }
    }
    return null;
  };

  buildChatMessage = function(sender, txt) {
    var action, client_generated_id, conv_id, conversation_state, delivery_medium, mb, message_action_type, ref, ref1, ref2, ref3, segs, segsj, ts;
    conv_id = viewstate.selectedConv;
    conversation_state = (ref = conv[conv_id]) != null ? ref.self_conversation_state : void 0;
    delivery_medium = ClientDeliveryMediumType[conversation_state != null ? (ref1 = conversation_state.delivery_medium_option) != null ? (ref2 = ref1[0]) != null ? (ref3 = ref2.delivery_medium) != null ? ref3.delivery_medium_type : void 0 : void 0 : void 0 : void 0];
    if (!delivery_medium) {
      delivery_medium = ClientDeliveryMediumType.BABEL;
    }
    action = null;
    if (/^\/me\s/.test(txt)) {
      txt = txt.replace(/^\/me/, sender.first_name);
      action = MessageActionType.ME_ACTION;
    }
    mb = new MessageBuilder(action);
    parse(mb, txt);
    segs = mb.toSegments();
    segsj = mb.toSegsjson();
    message_action_type = mb.toMessageActionType();
    client_generated_id = String(randomid());
    ts = Date.now();
    return {
      segs,
      segsj,
      conv_id,
      client_generated_id,
      ts,
      image_id: void 0,
      otr: OffTheRecordStatus.ON_THE_RECORD,
      message_action_type,
      delivery_medium: [delivery_medium] // requires to be used as an array
    };
  };

  module.exports = {buildChatMessage, parse};

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvbW9kZWxzL3VzZXJpbnB1dC5qcyIsInNvdXJjZXMiOlsidWkvbW9kZWxzL3VzZXJpbnB1dC5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLHdCQUFBLEVBQUEsaUJBQUEsRUFBQSxjQUFBLEVBQUEsa0JBQUEsRUFBQSxnQkFBQSxFQUFBLElBQUEsRUFBQSxLQUFBLEVBQUEsUUFBQSxFQUFBLFdBQUEsRUFBQSxTQUFBLEVBQUE7O0VBQUEsU0FBQSxHQUFZLE9BQUEsQ0FBUSxnQkFBUjs7RUFDWixDQUFBLENBQUMsY0FBRCxFQUFpQixrQkFBakIsRUFBb0MsaUJBQXBDLEVBQXNELHdCQUF0RCxDQUFBLEdBQWtGLE9BQUEsQ0FBUSxXQUFSLENBQWxGOztFQUNBLFNBQUEsR0FBWSxPQUFBLENBQVEsYUFBUjs7RUFDWixJQUFBLEdBQU8sT0FBQSxDQUFRLFFBQVI7O0VBRVAsUUFBQSxHQUFXLFFBQUEsQ0FBQSxDQUFBO1dBQUcsSUFBSSxDQUFDLEtBQUwsQ0FBVyxJQUFJLENBQUMsTUFBTCxDQUFBLENBQUEsR0FBZ0IsSUFBSSxDQUFDLEdBQUwsQ0FBUyxDQUFULEVBQVcsRUFBWCxDQUEzQjtFQUFIOztFQUVYLFdBQUEsR0FBYyxRQUFBLENBQUMsR0FBRCxFQUFNLEtBQU4sQ0FBQTtBQUNaLFFBQUEsS0FBQSxFQUFBLElBQUEsRUFBQTtJQUFBLEtBQUEsR0FBUSxHQUFHLENBQUMsT0FBSixDQUFZLEtBQVo7SUFDUixLQUFBLEdBQVEsR0FBRyxDQUFDLE1BQUosQ0FBVyxDQUFYLEVBQWMsS0FBZDtJQUNSLElBQUEsR0FBTyxHQUFHLENBQUMsTUFBSixDQUFXLEtBQUEsR0FBUSxLQUFLLENBQUMsTUFBekI7V0FDUCxDQUFDLEtBQUQsRUFBUSxJQUFSO0VBSlk7O0VBTWQsS0FBQSxHQUFRLFFBQUEsQ0FBQyxFQUFELEVBQUssR0FBTCxDQUFBO0FBQ0osUUFBQSxLQUFBLEVBQUEsTUFBQSxFQUFBLENBQUEsRUFBQSxLQUFBLEVBQUEsQ0FBQSxFQUFBLElBQUEsRUFBQSxHQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxLQUFBLEVBQUEsR0FBQSxFQUFBO0lBQUEsS0FBQSxHQUFRLEdBQUcsQ0FBQyxLQUFKLENBQVUsT0FBVjtJQUNSLElBQUEsR0FBTyxLQUFLLENBQUMsTUFBTixHQUFlO0lBQ3RCLEtBQUEsdURBQUE7O01BQ0ksSUFBQSxHQUFPLElBQUksQ0FBQyxLQUFMLENBQVcsU0FBQSxDQUFBLENBQVg7TUFDUCxJQUFHLFlBQUg7UUFDSSxLQUFBLHdDQUFBOztVQUNJLENBQUMsTUFBRCxFQUFTLEtBQVQsQ0FBQSxHQUFrQixXQUFBLENBQVksSUFBWixFQUFrQixHQUFsQjtVQUNsQixJQUFHLE1BQUg7WUFBZSxFQUFFLENBQUMsSUFBSCxDQUFRLE1BQVIsRUFBZjs7VUFDQSxJQUFBLEdBQU87VUFDUCxFQUFFLENBQUMsSUFBSCxDQUFRLEdBQVIsRUFBYSxHQUFiO1FBSkosQ0FESjs7TUFNQSxJQUFnQixJQUFoQjtRQUFBLEVBQUUsQ0FBQyxJQUFILENBQVEsSUFBUixFQUFBOztNQUNBLElBQXNCLEtBQUEsS0FBUyxJQUEvQjtRQUFBLEVBQUUsQ0FBQyxTQUFILENBQUEsRUFBQTs7SUFUSjtXQVVBO0VBYkk7O0VBZVIsZ0JBQUEsR0FBbUIsUUFBQSxDQUFDLE1BQUQsRUFBUyxHQUFULENBQUE7QUFDZixRQUFBLE1BQUEsRUFBQSxtQkFBQSxFQUFBLE9BQUEsRUFBQSxrQkFBQSxFQUFBLGVBQUEsRUFBQSxFQUFBLEVBQUEsbUJBQUEsRUFBQSxHQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLEtBQUEsRUFBQTtJQUFBLE9BQUEsR0FBVSxTQUFTLENBQUM7SUFDcEIsa0JBQUEsc0NBQWtDLENBQUU7SUFDcEMsZUFBQSxHQUFrQix3QkFBeUIsa0tBQStELENBQUUsd0RBQWpFO0lBQzNDLElBQUcsQ0FBSSxlQUFQO01BQ0UsZUFBQSxHQUFrQix3QkFBd0IsQ0FBQyxNQUQ3Qzs7SUFFQSxNQUFBLEdBQVM7SUFDVCxJQUFHLFNBQVMsQ0FBQyxJQUFWLENBQWUsR0FBZixDQUFIO01BQ0ksR0FBQSxHQUFNLEdBQUcsQ0FBQyxPQUFKLENBQVksT0FBWixFQUFxQixNQUFNLENBQUMsVUFBNUI7TUFDTixNQUFBLEdBQVMsaUJBQWlCLENBQUMsVUFGL0I7O0lBR0EsRUFBQSxHQUFLLElBQUksY0FBSixDQUFtQixNQUFuQjtJQUNMLEtBQUEsQ0FBTSxFQUFOLEVBQVUsR0FBVjtJQUNBLElBQUEsR0FBUSxFQUFFLENBQUMsVUFBSCxDQUFBO0lBQ1IsS0FBQSxHQUFRLEVBQUUsQ0FBQyxVQUFILENBQUE7SUFDUixtQkFBQSxHQUFzQixFQUFFLENBQUMsbUJBQUgsQ0FBQTtJQUN0QixtQkFBQSxHQUFzQixNQUFBLENBQU8sUUFBQSxDQUFBLENBQVA7SUFDdEIsRUFBQSxHQUFLLElBQUksQ0FBQyxHQUFMLENBQUE7V0FDTDtNQUNJLElBREo7TUFFSSxLQUZKO01BR0ksT0FISjtNQUlJLG1CQUpKO01BS0ksRUFMSjtNQU1JLFFBQUEsRUFBVSxNQU5kO01BT0ksR0FBQSxFQUFLLGtCQUFrQixDQUFDLGFBUDVCO01BUUksbUJBUko7TUFTSSxlQUFBLEVBQWlCLENBQUMsZUFBRCxDQVRyQjtJQUFBO0VBakJlOztFQTZCbkIsTUFBTSxDQUFDLE9BQVAsR0FBaUIsQ0FDYixnQkFEYSxFQUViLEtBRmE7QUF6RGpCIiwic291cmNlc0NvbnRlbnQiOlsidXJsUmVnZXhwID0gcmVxdWlyZSAndWJlci11cmwtcmVnZXgnXG57TWVzc2FnZUJ1aWxkZXIsIE9mZlRoZVJlY29yZFN0YXR1cyxNZXNzYWdlQWN0aW9uVHlwZSxDbGllbnREZWxpdmVyeU1lZGl1bVR5cGV9ID0gcmVxdWlyZSAnaGFuZ3Vwc2pzJ1xudmlld3N0YXRlID0gcmVxdWlyZSAnLi92aWV3c3RhdGUnXG5jb252ID0gcmVxdWlyZSAnLi9jb252J1xuXG5yYW5kb21pZCA9IC0+IE1hdGgucm91bmQgTWF0aC5yYW5kb20oKSAqIE1hdGgucG93KDIsMzIpXG5cbnNwbGl0X2ZpcnN0ID0gKHN0ciwgdG9rZW4pIC0+XG4gIHN0YXJ0ID0gc3RyLmluZGV4T2YgdG9rZW5cbiAgZmlyc3QgPSBzdHIuc3Vic3RyIDAsIHN0YXJ0XG4gIGxhc3QgPSBzdHIuc3Vic3RyIHN0YXJ0ICsgdG9rZW4ubGVuZ3RoXG4gIFtmaXJzdCwgbGFzdF1cblxucGFyc2UgPSAobWIsIHR4dCkgLT5cbiAgICBsaW5lcyA9IHR4dC5zcGxpdCAvXFxyP1xcbi9cbiAgICBsYXN0ID0gbGluZXMubGVuZ3RoIC0gMVxuICAgIGZvciBsaW5lLCBpbmRleCBpbiBsaW5lc1xuICAgICAgICB1cmxzID0gbGluZS5tYXRjaCB1cmxSZWdleHAoKVxuICAgICAgICBpZiB1cmxzP1xuICAgICAgICAgICAgZm9yIHVybCBpbiB1cmxzXG4gICAgICAgICAgICAgICAgW2JlZm9yZSwgYWZ0ZXJdID0gc3BsaXRfZmlyc3QgbGluZSwgdXJsXG4gICAgICAgICAgICAgICAgaWYgYmVmb3JlIHRoZW4gbWIudGV4dChiZWZvcmUpXG4gICAgICAgICAgICAgICAgbGluZSA9IGFmdGVyXG4gICAgICAgICAgICAgICAgbWIubGluayB1cmwsIHVybFxuICAgICAgICBtYi50ZXh0IGxpbmUgaWYgbGluZVxuICAgICAgICBtYi5saW5lYnJlYWsoKSB1bmxlc3MgaW5kZXggaXMgbGFzdFxuICAgIG51bGxcblxuYnVpbGRDaGF0TWVzc2FnZSA9IChzZW5kZXIsIHR4dCkgLT5cbiAgICBjb252X2lkID0gdmlld3N0YXRlLnNlbGVjdGVkQ29udlxuICAgIGNvbnZlcnNhdGlvbl9zdGF0ZSA9IGNvbnZbY29udl9pZF0/LnNlbGZfY29udmVyc2F0aW9uX3N0YXRlXG4gICAgZGVsaXZlcnlfbWVkaXVtID0gQ2xpZW50RGVsaXZlcnlNZWRpdW1UeXBlW2NvbnZlcnNhdGlvbl9zdGF0ZT8uZGVsaXZlcnlfbWVkaXVtX29wdGlvbj9bMF0/LmRlbGl2ZXJ5X21lZGl1bT8uZGVsaXZlcnlfbWVkaXVtX3R5cGVdXG4gICAgaWYgbm90IGRlbGl2ZXJ5X21lZGl1bVxuICAgICAgZGVsaXZlcnlfbWVkaXVtID0gQ2xpZW50RGVsaXZlcnlNZWRpdW1UeXBlLkJBQkVMXG4gICAgYWN0aW9uID0gbnVsbFxuICAgIGlmIC9eXFwvbWVcXHMvLnRlc3QgdHh0XG4gICAgICAgIHR4dCA9IHR4dC5yZXBsYWNlIC9eXFwvbWUvLCBzZW5kZXIuZmlyc3RfbmFtZVxuICAgICAgICBhY3Rpb24gPSBNZXNzYWdlQWN0aW9uVHlwZS5NRV9BQ1RJT05cbiAgICBtYiA9IG5ldyBNZXNzYWdlQnVpbGRlcihhY3Rpb24pXG4gICAgcGFyc2UgbWIsIHR4dFxuICAgIHNlZ3MgID0gbWIudG9TZWdtZW50cygpXG4gICAgc2Vnc2ogPSBtYi50b1NlZ3Nqc29uKClcbiAgICBtZXNzYWdlX2FjdGlvbl90eXBlID0gbWIudG9NZXNzYWdlQWN0aW9uVHlwZSgpXG4gICAgY2xpZW50X2dlbmVyYXRlZF9pZCA9IFN0cmluZyByYW5kb21pZCgpXG4gICAgdHMgPSBEYXRlLm5vdygpXG4gICAge1xuICAgICAgICBzZWdzXG4gICAgICAgIHNlZ3NqXG4gICAgICAgIGNvbnZfaWRcbiAgICAgICAgY2xpZW50X2dlbmVyYXRlZF9pZFxuICAgICAgICB0c1xuICAgICAgICBpbWFnZV9pZDogdW5kZWZpbmVkXG4gICAgICAgIG90cjogT2ZmVGhlUmVjb3JkU3RhdHVzLk9OX1RIRV9SRUNPUkRcbiAgICAgICAgbWVzc2FnZV9hY3Rpb25fdHlwZVxuICAgICAgICBkZWxpdmVyeV9tZWRpdW06IFtkZWxpdmVyeV9tZWRpdW1dICMgcmVxdWlyZXMgdG8gYmUgdXNlZCBhcyBhbiBhcnJheVxuICAgIH1cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgYnVpbGRDaGF0TWVzc2FnZVxuICAgIHBhcnNlXG59XG4iXX0=
