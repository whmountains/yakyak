(function() {
  var Client, clipboard, connection, conv, convsettings, entity, fs, insertTextAtCursor, ipc, isImg, later, mime, nameof, notify, remote, resendfocus, sendsetpresence, throttle, userinput, viewstate,
    indexOf = [].indexOf;

  Client = require('hangupsjs');

  remote = require('electron').remote;

  ipc = require('electron').ipcRenderer;

  fs = require('fs');

  mime = require('mime-types');

  clipboard = require('electron').clipboard;

  ({entity, conv, viewstate, userinput, connection, convsettings, notify} = require('./models'));

  ({insertTextAtCursor, throttle, later, isImg, nameof} = require('./util'));

  'connecting connected connect_failed'.split(' ').forEach(function(n) {
    return handle(n, function() {
      return connection.setState(n);
    });
  });

  handle('alive', function(time) {
    return connection.setLastActive(time);
  });

  handle('reqinit', function() {
    ipc.send('reqinit');
    connection.setState(connection.CONNECTING);
    return viewstate.setState(viewstate.STATE_STARTUP);
  });

  module.exports = {
    init: function({init}) {
      return action('init', init);
    }
  };

  handle('init', function(init) {
    var ref, ref1;
    // set the initial view state
    viewstate.setLoggedin(true);
    viewstate.setColorScheme(viewstate.colorScheme);
    viewstate.setFontSize(viewstate.fontSize);
    // update model from init object
    entity._initFromSelfEntity(init.self_entity);
    if (init.entities) {
      entity._initFromEntities(init.entities);
    }
    conv._initFromConvStates(init.conv_states);
    // ensure there's a selected conv
    if (!conv[viewstate.selectedConv]) {
      viewstate.setSelectedConv((ref = conv.list()) != null ? (ref1 = ref[0]) != null ? ref1.conversation_id : void 0 : void 0);
    }
    ipc.send('initpresence', entity.list());
    require('./version').check();
    // small delay for better experience
    return later(function() {
      return action('set_viewstate_normal');
    });
  });

  handle('set_viewstate_normal', function() {
    viewstate.setContacts(true);
    return viewstate.setState(viewstate.STATE_NORMAL);
  });

  handle('chat_message', function(ev) {
    if (entity[ev.sender_id.chat_id] == null) {
      // TODO entity is not fetched in usable time for first notification
      // if does not have user on cache
      entity.needEntity(ev.sender_id.chat_id);
    }
    // add chat to conversation
    conv.addChatMessage(ev);
    // these messages are to go through notifications
    return notify.addToNotify(ev);
  });

  handle('watermark', function(ev) {
    return conv.addWatermark(ev);
  });

  handle('presence', function(ev) {
    return entity.setPresence(ev[0][0][0][0], ev[0][0][1][1] === 1 ? true : false);
  });

  // handle 'self_presence', (ev) ->
  //     console.log 'self_presence', ev
  handle('querypresence', function(id) {
    return ipc.send('querypresence', id);
  });

  handle('setpresence', function(r) {
    var ref, ref1, ref2;
    if ((r != null ? (ref = r.presence) != null ? ref.available : void 0 : void 0) == null) {
      return console.log(`setpresence: User '${nameof(entity[r != null ? (ref1 = r.user_id) != null ? ref1.chat_id : void 0 : void 0])}' does not show his/hers/it status`, r);
    } else {
      return entity.setPresence(r.user_id.chat_id, r != null ? (ref2 = r.presence) != null ? ref2.available : void 0 : void 0);
    }
  });

  handle('update:unreadcount', function() {
    return console.log('update');
  });

  handle('addconversation', function() {
    viewstate.setState(viewstate.STATE_ADD_CONVERSATION);
    return convsettings.reset();
  });

  handle('convsettings', function() {
    var id;
    id = viewstate.selectedConv;
    if (!conv[id]) {
      return;
    }
    convsettings.reset();
    convsettings.loadConversation(conv[id]);
    return viewstate.setState(viewstate.STATE_ADD_CONVERSATION);
  });

  handle('activity', function(time) {
    return viewstate.updateActivity(time);
  });

  handle('atbottom', function(atbottom) {
    return viewstate.updateAtBottom(atbottom);
  });

  handle('attop', function(attop) {
    viewstate.updateAtTop(attop);
    return conv.updateAtTop(attop);
  });

  handle('history', function(conv_id, timestamp) {
    return ipc.send('getconversation', conv_id, timestamp, 20);
  });

  handle('handleconversationmetadata', function(r) {
    if (!r.conversation_state) {
      return;
    }
    // removing events so they don't get merged
    r.conversation_state.event = null;
    return conv.updateMetadata(r.conversation_state);
  });

  handle('handlehistory', function(r) {
    if (!r.conversation_state) {
      return;
    }
    return conv.updateHistory(r.conversation_state);
  });

  handle('selectConv', function(conv) {
    viewstate.setState(viewstate.STATE_NORMAL);
    viewstate.setSelectedConv(conv);
    return ipc.send('setfocus', viewstate.selectedConv);
  });

  handle('selectNextConv', function(offset = 1) {
    if (viewstate.state !== viewstate.STATE_NORMAL) {
      return;
    }
    viewstate.selectNextConv(offset);
    return ipc.send('setfocus', viewstate.selectedConv);
  });

  handle('selectConvIndex', function(index = 0) {
    if (viewstate.state !== viewstate.STATE_NORMAL) {
      return;
    }
    viewstate.selectConvIndex(index);
    return ipc.send('setfocus', viewstate.selectedConv);
  });

  handle('sendmessage', function(txt = '') {
    var msg;
    if (!txt.trim()) {
      return;
    }
    msg = userinput.buildChatMessage(entity.self, txt);
    ipc.send('sendchatmessage', msg);
    return conv.addChatMessagePlaceholder(entity.self.id, msg);
  });

  handle('toggleshowtray', function() {
    return viewstate.setShowTray(!viewstate.showtray);
  });

  handle('forcecustomsound', function(value) {
    return viewstate.setForceCustomSound(value);
  });

  handle('showiconnotification', function(value) {
    return viewstate.setShowIconNotification(value);
  });

  handle('mutesoundnotification', function() {
    return viewstate.setMuteSoundNotification(!viewstate.muteSoundNotification);
  });

  handle('togglemenu', function() {
    return remote.Menu.getApplicationMenu().popup();
  });

  handle('setescapeclearsinput', function(value) {
    return viewstate.setEscapeClearsInput(value);
  });

  handle('togglehidedockicon', function() {
    return viewstate.setHideDockIcon(!viewstate.hidedockicon);
  });

  handle('show-about', function() {
    viewstate.setState(viewstate.STATE_ABOUT);
    return updated('viewstate');
  });

  handle('hideWindow', function() {
    var mainWindow;
    mainWindow = remote.getCurrentWindow(); // And we hope we don't get another ;)
    return mainWindow.hide();
  });

  handle('togglewindow', function() {
    var mainWindow;
    mainWindow = remote.getCurrentWindow(); // And we hope we don't get another ;)
    if (mainWindow.isVisible()) {
      return mainWindow.hide();
    } else {
      return mainWindow.show();
    }
  });

  handle('togglestartminimizedtotray', function() {
    return viewstate.setStartMinimizedToTray(!viewstate.startminimizedtotray);
  });

  handle('toggleclosetotray', function() {
    return viewstate.setCloseToTray(!viewstate.closetotray);
  });

  handle('showwindow', function() {
    var mainWindow;
    mainWindow = remote.getCurrentWindow(); // And we hope we don't get another ;)
    return mainWindow.show();
  });

  sendsetpresence = throttle(10000, function() {
    ipc.send('setpresence');
    return ipc.send('setactiveclient', true, 15);
  });

  resendfocus = throttle(15000, function() {
    return ipc.send('setfocus', viewstate.selectedConv);
  });

  // on every keep alive signal from hangouts
  //  we inform the server that the user is still
  //  available
  handle('noop', function() {
    return sendsetpresence();
  });

  handle('lastActivity', function() {
    sendsetpresence();
    if (document.hasFocus()) {
      return resendfocus();
    }
  });

  handle('appfocus', function() {
    return ipc.send('appfocus');
  });

  handle('updatewatermark', (function() {
    var throttleWaterByConv;
    throttleWaterByConv = {};
    return function() {
      var c, conv_id, sendWater;
      conv_id = viewstate.selectedConv;
      c = conv[conv_id];
      if (!c) {
        return;
      }
      sendWater = throttleWaterByConv[conv_id];
      if (!sendWater) {
        (function(conv_id) {
          sendWater = throttle(1000, function() {
            return ipc.send('updatewatermark', conv_id, Date.now());
          });
          return throttleWaterByConv[conv_id] = sendWater;
        })(conv_id);
      }
      return sendWater();
    };
  })());

  handle('getentity', function(ids) {
    var fn;
    return (fn = function() {
      ipc.send('getentity', ids.slice(0, 5));
      ids = ids.slice(5);
      if (ids.length > 0) {
        return setTimeout(fn, 500);
      }
    })();
  });

  handle('addentities', function(es, conv_id) {
    var e, i, len, ref;
    ref = es != null ? es : [];
    for (i = 0, len = ref.length; i < len; i++) {
      e = ref[i];
      entity.add(e);
    }
    if (conv_id) { // auto-add these ppl to a conv
      (es != null ? es : []).forEach(function(p) {
        return conv.addParticipant(conv_id, p);
      });
      viewstate.setState(viewstate.STATE_NORMAL);
    }
    // flag to show that contacts are loaded
    return viewstate.setContacts(true);
  });

  handle('uploadimage', function(files) {
    var _, client_generated_id, conv_id, element, ext, file, i, len, msg, ref, ref1;
    // this may change during upload
    conv_id = viewstate.selectedConv;
    // sense check that client is in good state
    if (!(viewstate.state === viewstate.STATE_NORMAL && conv[conv_id])) {
      // clear value for upload image input
      document.getElementById('attachFile').value = '';
      return;
    }
    // if only one file is selected, then it shows as preview before sending
    //  otherwise, it will upload all of them immediatly
    if (files.length === 1) {
      file = files[0];
      element = document.getElementById('preview-img');
      // show error message and return if is not an image
      if (isImg(file.path)) {
        // store image in preview-container and open it
        //  I think it is better to embed than reference path as user should
        //   see exactly what he is sending. (using the path would require
        //   polling)
        fs.readFile(file.path, function(err, original_data) {
          var base64Image, binaryImage, mimeType;
          binaryImage = new Buffer(original_data, 'binary');
          base64Image = binaryImage.toString('base64');
          mimeType = mime.lookup(file.path);
          element.src = 'data:' + mimeType + ';base64,' + base64Image;
          return document.querySelector('#preview-container').classList.add('open');
        });
      } else {
        [_, ext] = (ref = file.path.match(/.*(\.\w+)$/)) != null ? ref : [];
        notr(`Ignoring file of type ${ext}`);
      }
    } else {
      for (i = 0, len = files.length; i < len; i++) {
        file = files[i];
        // only images please
        if (!isImg(file.path)) {
          [_, ext] = (ref1 = file.path.match(/.*(\.\w+)$/)) != null ? ref1 : [];
          notr(`Ignoring file of type ${ext}`);
          continue;
        }
        // message for a placeholder
        msg = userinput.buildChatMessage(entity.self, 'uploading image…');
        msg.uploadimage = true;
        ({client_generated_id} = msg);
        // add a placeholder for the image
        conv.addChatMessagePlaceholder(entity.self.id, msg);
        // and begin upload
        ipc.send('uploadimage', {
          path: file.path,
          conv_id,
          client_generated_id
        });
      }
    }
    // clear value for upload image input
    return document.getElementById('attachFile').value = '';
  });

  handle('onpasteimage', function() {
    var element;
    element = document.getElementById('preview-img');
    element.src = clipboard.readImage().toDataURL();
    element.src = element.src.replace(/image\/png/, 'image/gif');
    return document.querySelector('#preview-container').classList.add('open');
  });

  handle('uploadpreviewimage', function() {
    var client_generated_id, conv_id, element, msg, pngData;
    conv_id = viewstate.selectedConv;
    if (!conv_id) {
      return;
    }
    msg = userinput.buildChatMessage(entity.self, 'uploading image…');
    msg.uploadimage = true;
    ({client_generated_id} = msg);
    conv.addChatMessagePlaceholder(entity.self.id, msg);
    // find preview element
    element = document.getElementById('preview-img');
    // build image from what is on preview
    pngData = element.src.replace(/data:image\/(png|jpe?g|gif|svg);base64,/, '');
    pngData = new Buffer(pngData, 'base64');
    document.querySelector('#preview-container').classList.remove('open');
    document.querySelector('#emoji-container').classList.remove('open');
    element.src = '';
    
    return ipc.send('uploadclipboardimage', {pngData, conv_id, client_generated_id});
  });

  handle('uploadingimage', function(spec) {});

  // XXX this doesn't look very good because the image
  // shows, then flickers away before the real is loaded
  // from the upload.
  //conv.updatePlaceholderImage spec
  handle('leftresize', function(size) {
    return viewstate.setLeftSize(size);
  });

  handle('resize', function(dim) {
    return viewstate.setSize(dim);
  });

  handle('move', function(pos) {
    return viewstate.setPosition(pos);
  });

  handle('conversationname', function(name) {
    return convsettings.setName(name);
  });

  handle('conversationquery', function(query) {
    return convsettings.setSearchQuery(query);
  });

  handle('searchentities', function(query, max_results) {
    return ipc.send('searchentities', query, max_results);
  });

  handle('setsearchedentities', function(r) {
    return convsettings.setSearchedEntities(r);
  });

  handle('selectentity', function(e) {
    return convsettings.addSelectedEntity(e);
  });

  handle('deselectentity', function(e) {
    return convsettings.removeSelectedEntity(e);
  });

  handle('togglegroup', function(e) {
    return convsettings.setGroup(!convsettings.group);
  });

  handle('saveconversation', function() {
    var c, conv_id, current, e, id, name, needsRename, one_to_one, p, recreate, ref, selected, toadd;
    viewstate.setState(viewstate.STATE_NORMAL);
    conv_id = convsettings.id;
    c = conv[conv_id];
    one_to_one = (c != null ? (ref = c.type) != null ? ref.indexOf('ONE_TO_ONE') : void 0 : void 0) >= 0;
    selected = (function() {
      var i, len, ref1, results;
      ref1 = convsettings.selectedEntities;
      results = [];
      for (i = 0, len = ref1.length; i < len; i++) {
        e = ref1[i];
        results.push(e.id.chat_id);
      }
      return results;
    })();
    recreate = conv_id && one_to_one && convsettings.group;
    needsRename = convsettings.group && convsettings.name && convsettings.name !== (c != null ? c.name : void 0);
    // remember: we don't rename one_to_ones, google web client does not do it
    if (!conv_id || recreate) {
      name = (convsettings.group ? convsettings.name : void 0) || "";
      ipc.send('createconversation', selected, name, convsettings.group);
      return;
    }
    p = c.participant_data;
    current = (function() {
      var i, len, results;
      results = [];
      for (i = 0, len = p.length; i < len; i++) {
        c = p[i];
        if (!entity.isSelf(c.id.chat_id)) {
          results.push(c.id.chat_id);
        }
      }
      return results;
    })();
    toadd = (function() {
      var i, len, results;
      results = [];
      for (i = 0, len = selected.length; i < len; i++) {
        id = selected[i];
        if (indexOf.call(current, id) < 0) {
          results.push(id);
        }
      }
      return results;
    })();
    if (toadd.length) {
      ipc.send('adduser', conv_id, toadd);
    }
    if (needsRename) {
      return ipc.send('renameconversation', conv_id, convsettings.name);
    }
  });

  handle('conversation_rename', function(c) {
    conv.rename(c, c.conversation_rename.new_name);
    return conv.addChatMessage(c);
  });

  handle('membership_change', function(e) {
    var conv_id, id, ids, ref;
    conv_id = e.conversation_id.id;
    ids = (function() {
      var i, len, ref, results;
      ref = e.membership_change.participant_ids;
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        id = ref[i];
        results.push(id.chat_id || id.gaia_id);
      }
      return results;
    })();
    if (e.membership_change.type === 'LEAVE') {
      if (ref = entity.self.id, indexOf.call(ids, ref) >= 0) {
        return conv.deleteConv(conv_id);
      }
      return conv.removeParticipants(conv_id, ids);
    }
    conv.addChatMessage(e);
    return ipc.send('getentity', ids, {
      add_to_conv: conv_id
    });
  });

  handle('createconversationdone', function(c) {
    convsettings.reset();
    conv.add(c);
    return viewstate.setSelectedConv(c.id.id);
  });

  handle('notification_level', function(n) {
    var conv_id, level, ref;
    conv_id = n != null ? (ref = n[0]) != null ? ref[0] : void 0 : void 0;
    level = (n != null ? n[1] : void 0) === 10 ? 'QUIET' : 'RING';
    if (conv_id && level) {
      return conv.setNotificationLevel(conv_id, level);
    }
  });

  handle('togglenotif', function() {
    var QUIET, RING, c, conv_id, q;
    ({QUIET, RING} = Client.NotificationLevel);
    conv_id = viewstate.selectedConv;
    if (!(c = conv[conv_id])) {
      return;
    }
    q = conv.isQuiet(c);
    ipc.send('setconversationnotificationlevel', conv_id, (q ? RING : QUIET));
    return conv.setNotificationLevel(conv_id, (q ? 'RING' : 'QUIET'));
  });

  handle('togglestar', function() {
    var c, conv_id;
    conv_id = viewstate.selectedConv;
    if (!(c = conv[conv_id])) {
      return;
    }
    return conv.toggleStar(c);
  });

  handle('delete', function(a) {
    var c, conv_id, ref;
    conv_id = a != null ? (ref = a[0]) != null ? ref[0] : void 0 : void 0;
    if (!(c = conv[conv_id])) {
      return;
    }
    return conv.deleteConv(conv_id);
  });

  
  // Change language in YakYak

  handle('changelanguage', function(language) {
    if (i18n.getLocales().includes(viewstate.language)) {
      ipc.send('seti18n', null, language);
      return viewstate.setLanguage(language);
    }
  });

  handle('deleteconv', function(confirmed) {
    var conv_id;
    conv_id = viewstate.selectedConv;
    if (!confirmed) {
      return later(function() {
        if (confirm(i18n.__('conversation.delete_confirm:Really delete conversation?'))) {
          return action('deleteconv', true);
        }
      });
    } else {
      ipc.send('deleteconversation', conv_id);
      viewstate.selectConvIndex(0);
      return viewstate.setState(viewstate.STATE_NORMAL);
    }
  });

  handle('leaveconv', function(confirmed) {
    var conv_id;
    conv_id = viewstate.selectedConv;
    if (!confirmed) {
      return later(function() {
        if (confirm(i18n.__('conversation.leave_confirm:Really leave conversation?'))) {
          return action('leaveconv', true);
        }
      });
    } else {
      ipc.send('removeuser', conv_id);
      viewstate.selectConvIndex(0);
      return viewstate.setState(viewstate.STATE_NORMAL);
    }
  });

  handle('lastkeydown', function(time) {
    return viewstate.setLastKeyDown(time);
  });

  handle('settyping', function(v) {
    var conv_id;
    conv_id = viewstate.selectedConv;
    if (!(conv_id && viewstate.state === viewstate.STATE_NORMAL)) {
      return;
    }
    ipc.send('settyping', conv_id, v);
    return viewstate.setState(viewstate.STATE_NORMAL);
  });

  handle('typing', function(t) {
    return conv.addTyping(t);
  });

  handle('pruneTyping', function(conv_id) {
    return conv.pruneTyping(conv_id);
  });

  handle('syncallnewevents', throttle(10000, function(time) {
    if (!time) {
      return;
    }
    return ipc.send('syncallnewevents', time);
  }));

  handle('handlesyncedevents', function(r) {
    var e, i, j, len, len1, ref, ref1, st, states;
    states = r != null ? r.conversation_state : void 0;
    if (!(states != null ? states.length : void 0)) {
      return;
    }
    for (i = 0, len = states.length; i < len; i++) {
      st = states[i];
      ref1 = (ref = st != null ? st.event : void 0) != null ? ref : [];
      for (j = 0, len1 = ref1.length; j < len1; j++) {
        e = ref1[j];
        conv.addChatMessage(e);
      }
    }
    return connection.setEventState(connection.IN_SYNC);
  });

  handle('syncrecentconversations', throttle(10000, function() {
    return ipc.send('syncrecentconversations');
  }));

  handle('handlerecentconversations', function(r) {
    var st;
    if (!(st = r.conversation_state)) {
      return;
    }
    conv.replaceFromStates(st);
    return connection.setEventState(connection.IN_SYNC);
  });

  handle('client_conversation', function(c) {
    var ref, ref1;
    if (((ref = conv[c != null ? (ref1 = c.conversation_id) != null ? ref1.id : void 0 : void 0]) != null ? ref.participant_data : void 0) == null) {
      // Conversation must be added, even if already exists
      //  why? because when a new chat message for a new conversation appears
      //  a skeleton is made of a conversation
      return conv.add(c);
    }
  });

  handle('hangout_event', function(e) {
    var ref, ref1;
    if ((ref = e != null ? (ref1 = e.hangout_event) != null ? ref1.event_type : void 0 : void 0) !== 'START_HANGOUT' && ref !== 'END_HANGOUT') {
      return;
    }
    // trigger notifications for this
    return notify.addToNotify(e);
  });

  'reply_to_invite settings conversation_notification invitation_watermark'.split(' ').forEach(function(n) {
    return handle(n, function(...as) {
      return console.log(n, ...as);
    });
  });

  handle('unreadtotal', function(total, orMore) {
    var value;
    value = "";
    if (total > 0) {
      value = total + (orMore ? "+" : "");
    }
    updated('conv_count');
    return ipc.send('updatebadge', value);
  });

  handle('showconvmin', function(doshow) {
    return viewstate.setShowConvMin(doshow);
  });

  handle('setusesystemdateformat', function(val) {
    return viewstate.setUseSystemDateFormat(val);
  });

  handle('showconvthumbs', function(doshow) {
    return viewstate.setShowConvThumbs(doshow);
  });

  handle('showanimatedthumbs', function(doshow) {
    return viewstate.setShowAnimatedThumbs(doshow);
  });

  handle('showconvtime', function(doshow) {
    return viewstate.setShowConvTime(doshow);
  });

  handle('showconvlast', function(doshow) {
    return viewstate.setShowConvLast(doshow);
  });

  handle('showpopupnotifications', function(doshow) {
    return viewstate.setShowPopUpNotifications(doshow);
  });

  handle('showmessageinnotification', function(doshow) {
    return viewstate.setShowMessageInNotification(doshow);
  });

  handle('showusernameinnotification', function(doshow) {
    return viewstate.setShowUsernameInNotification(doshow);
  });

  handle('convertemoji', function(doshow) {
    return viewstate.setConvertEmoji(doshow);
  });

  handle('suggestemoji', function(doshow) {
    return viewstate.setSuggestEmoji(doshow);
  });

  handle('changetheme', function(colorscheme) {
    return viewstate.setColorScheme(colorscheme);
  });

  handle('changefontsize', function(fontsize) {
    return viewstate.setFontSize(fontsize);
  });

  handle('devtools', function() {
    return remote.getCurrentWindow().openDevTools({
      detach: true
    });
  });

  handle('quit', function() {
    return ipc.send('quit');
  });

  handle('togglefullscreen', function() {
    return ipc.send('togglefullscreen');
  });

  handle('zoom', function(step) {
    if (step != null) {
      return viewstate.setZoom((parseFloat(document.body.style.zoom.replace(',', '.')) || 1.0) + step);
    }
    return viewstate.setZoom(1);
  });

  handle('logout', function() {
    return ipc.send('logout');
  });

  handle('wonline', function(wonline) {
    connection.setWindowOnline(wonline);
    if (wonline) {
      return ipc.send('hangupsConnect');
    } else {
      return ipc.send('hangupsDisconnect');
    }
  });

  handle('openonsystemstartup', function(open) {
    return viewstate.setOpenOnSystemStartup(open);
  });

  handle('initopenonsystemstartup', function(isEnabled) {
    return viewstate.initOpenOnSystemStartup(isEnabled);
  });

  handle('minimize', function() {
    var mainWindow;
    mainWindow = remote.getCurrentWindow();
    return mainWindow.minimize();
  });

  handle('resizewindow', function() {
    var mainWindow;
    mainWindow = remote.getCurrentWindow();
    if (mainWindow.isMaximized()) {
      return mainWindow.unmaximize();
    } else {
      return mainWindow.maximize();
    }
  });

  handle('close', function() {
    var mainWindow;
    mainWindow = remote.getCurrentWindow();
    return mainWindow.close();
  });

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvZGlzcGF0Y2hlci5qcyIsInNvdXJjZXMiOlsidWkvZGlzcGF0Y2hlci5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLE1BQUEsRUFBQSxTQUFBLEVBQUEsVUFBQSxFQUFBLElBQUEsRUFBQSxZQUFBLEVBQUEsTUFBQSxFQUFBLEVBQUEsRUFBQSxrQkFBQSxFQUFBLEdBQUEsRUFBQSxLQUFBLEVBQUEsS0FBQSxFQUFBLElBQUEsRUFBQSxNQUFBLEVBQUEsTUFBQSxFQUFBLE1BQUEsRUFBQSxXQUFBLEVBQUEsZUFBQSxFQUFBLFFBQUEsRUFBQSxTQUFBLEVBQUEsU0FBQTtJQUFBOztFQUFBLE1BQUEsR0FBUyxPQUFBLENBQVEsV0FBUjs7RUFDVCxNQUFBLEdBQVMsT0FBQSxDQUFRLFVBQVIsQ0FBbUIsQ0FBQzs7RUFDN0IsR0FBQSxHQUFTLE9BQUEsQ0FBUSxVQUFSLENBQW1CLENBQUM7O0VBRzdCLEVBQUEsR0FBSyxPQUFBLENBQVEsSUFBUjs7RUFDTCxJQUFBLEdBQU8sT0FBQSxDQUFRLFlBQVI7O0VBRVAsU0FBQSxHQUFZLE9BQUEsQ0FBUSxVQUFSLENBQW1CLENBQUM7O0VBRWhDLENBQUEsQ0FBQyxNQUFELEVBQVMsSUFBVCxFQUFlLFNBQWYsRUFBMEIsU0FBMUIsRUFBcUMsVUFBckMsRUFBaUQsWUFBakQsRUFBK0QsTUFBL0QsQ0FBQSxHQUF5RSxPQUFBLENBQVEsVUFBUixDQUF6RTs7RUFDQSxDQUFBLENBQUMsa0JBQUQsRUFBcUIsUUFBckIsRUFBK0IsS0FBL0IsRUFBc0MsS0FBdEMsRUFBNkMsTUFBN0MsQ0FBQSxHQUF1RCxPQUFBLENBQVEsUUFBUixDQUF2RDs7RUFFQSxxQ0FBcUMsQ0FBQyxLQUF0QyxDQUE0QyxHQUE1QyxDQUFnRCxDQUFDLE9BQWpELENBQXlELFFBQUEsQ0FBQyxDQUFELENBQUE7V0FDckQsTUFBQSxDQUFPLENBQVAsRUFBVSxRQUFBLENBQUEsQ0FBQTthQUFHLFVBQVUsQ0FBQyxRQUFYLENBQW9CLENBQXBCO0lBQUgsQ0FBVjtFQURxRCxDQUF6RDs7RUFHQSxNQUFBLENBQU8sT0FBUCxFQUFnQixRQUFBLENBQUMsSUFBRCxDQUFBO1dBQVUsVUFBVSxDQUFDLGFBQVgsQ0FBeUIsSUFBekI7RUFBVixDQUFoQjs7RUFFQSxNQUFBLENBQU8sU0FBUCxFQUFrQixRQUFBLENBQUEsQ0FBQTtJQUNkLEdBQUcsQ0FBQyxJQUFKLENBQVMsU0FBVDtJQUNBLFVBQVUsQ0FBQyxRQUFYLENBQW9CLFVBQVUsQ0FBQyxVQUEvQjtXQUNBLFNBQVMsQ0FBQyxRQUFWLENBQW1CLFNBQVMsQ0FBQyxhQUE3QjtFQUhjLENBQWxCOztFQUtBLE1BQU0sQ0FBQyxPQUFQLEdBQ0k7SUFBQSxJQUFBLEVBQU0sUUFBQSxDQUFDLENBQUMsSUFBRCxDQUFELENBQUE7YUFBWSxNQUFBLENBQU8sTUFBUCxFQUFlLElBQWY7SUFBWjtFQUFOOztFQUVKLE1BQUEsQ0FBTyxNQUFQLEVBQWUsUUFBQSxDQUFDLElBQUQsQ0FBQTtBQUVYLFFBQUEsR0FBQSxFQUFBLElBQUE7O0lBQUEsU0FBUyxDQUFDLFdBQVYsQ0FBc0IsSUFBdEI7SUFFQSxTQUFTLENBQUMsY0FBVixDQUF5QixTQUFTLENBQUMsV0FBbkM7SUFDQSxTQUFTLENBQUMsV0FBVixDQUFzQixTQUFTLENBQUMsUUFBaEMsRUFIQTs7SUFNQSxNQUFNLENBQUMsbUJBQVAsQ0FBMkIsSUFBSSxDQUFDLFdBQWhDO0lBQ0EsSUFBMEMsSUFBSSxDQUFDLFFBQS9DO01BQUEsTUFBTSxDQUFDLGlCQUFQLENBQXlCLElBQUksQ0FBQyxRQUE5QixFQUFBOztJQUNBLElBQUksQ0FBQyxtQkFBTCxDQUF5QixJQUFJLENBQUMsV0FBOUIsRUFSQTs7SUFVQSxJQUFBLENBQU8sSUFBSyxDQUFBLFNBQVMsQ0FBQyxZQUFWLENBQVo7TUFDSSxTQUFTLENBQUMsZUFBViw2REFBeUMsQ0FBRSxpQ0FBM0MsRUFESjs7SUFHQSxHQUFHLENBQUMsSUFBSixDQUFTLGNBQVQsRUFBeUIsTUFBTSxDQUFDLElBQVAsQ0FBQSxDQUF6QjtJQUVBLE9BQUEsQ0FBUSxXQUFSLENBQW9CLENBQUMsS0FBckIsQ0FBQSxFQWZBOztXQWtCQSxLQUFBLENBQU0sUUFBQSxDQUFBLENBQUE7YUFBRyxNQUFBLENBQU8sc0JBQVA7SUFBSCxDQUFOO0VBcEJXLENBQWY7O0VBc0JBLE1BQUEsQ0FBTyxzQkFBUCxFQUErQixRQUFBLENBQUEsQ0FBQTtJQUMzQixTQUFTLENBQUMsV0FBVixDQUFzQixJQUF0QjtXQUNBLFNBQVMsQ0FBQyxRQUFWLENBQW1CLFNBQVMsQ0FBQyxZQUE3QjtFQUYyQixDQUEvQjs7RUFJQSxNQUFBLENBQU8sY0FBUCxFQUF1QixRQUFBLENBQUMsRUFBRCxDQUFBO0lBR25CLElBQThDLG9DQUE5Qzs7O01BQUEsTUFBTSxDQUFDLFVBQVAsQ0FBa0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxPQUEvQixFQUFBO0tBQUE7O0lBRUEsSUFBSSxDQUFDLGNBQUwsQ0FBb0IsRUFBcEIsRUFGQTs7V0FJQSxNQUFNLENBQUMsV0FBUCxDQUFtQixFQUFuQjtFQVBtQixDQUF2Qjs7RUFTQSxNQUFBLENBQU8sV0FBUCxFQUFvQixRQUFBLENBQUMsRUFBRCxDQUFBO1dBQ2hCLElBQUksQ0FBQyxZQUFMLENBQWtCLEVBQWxCO0VBRGdCLENBQXBCOztFQUdBLE1BQUEsQ0FBTyxVQUFQLEVBQW1CLFFBQUEsQ0FBQyxFQUFELENBQUE7V0FDZixNQUFNLENBQUMsV0FBUCxDQUFtQixFQUFHLENBQUEsQ0FBQSxDQUFHLENBQUEsQ0FBQSxDQUFHLENBQUEsQ0FBQSxDQUFHLENBQUEsQ0FBQSxDQUEvQixFQUFzQyxFQUFHLENBQUEsQ0FBQSxDQUFHLENBQUEsQ0FBQSxDQUFHLENBQUEsQ0FBQSxDQUFHLENBQUEsQ0FBQSxDQUFaLEtBQWtCLENBQXJCLEdBQTRCLElBQTVCLEdBQXNDLEtBQXpFO0VBRGUsQ0FBbkIsRUFoRUE7Ozs7RUFzRUEsTUFBQSxDQUFPLGVBQVAsRUFBd0IsUUFBQSxDQUFDLEVBQUQsQ0FBQTtXQUNwQixHQUFHLENBQUMsSUFBSixDQUFTLGVBQVQsRUFBMEIsRUFBMUI7RUFEb0IsQ0FBeEI7O0VBR0EsTUFBQSxDQUFPLGFBQVAsRUFBc0IsUUFBQSxDQUFDLENBQUQsQ0FBQTtBQUNsQixRQUFBLEdBQUEsRUFBQSxJQUFBLEVBQUE7SUFBQSxJQUFPLGtGQUFQO2FBQ0ksT0FBTyxDQUFDLEdBQVIsQ0FBWSxDQUFBLG1CQUFBLENBQUEsQ0FBc0IsTUFBQSxDQUFPLE1BQU8sOENBQVUsQ0FBRSx5QkFBWixDQUFkLENBQXRCLENBQXlELGtDQUF6RCxDQUFaLEVBQTBHLENBQTFHLEVBREo7S0FBQSxNQUFBO2FBR0ksTUFBTSxDQUFDLFdBQVAsQ0FBbUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUE3QixnREFBaUQsQ0FBRSwyQkFBbkQsRUFISjs7RUFEa0IsQ0FBdEI7O0VBTUEsTUFBQSxDQUFPLG9CQUFQLEVBQTZCLFFBQUEsQ0FBQSxDQUFBO1dBQ3pCLE9BQU8sQ0FBQyxHQUFSLENBQVksUUFBWjtFQUR5QixDQUE3Qjs7RUFHQSxNQUFBLENBQU8saUJBQVAsRUFBMEIsUUFBQSxDQUFBLENBQUE7SUFDdEIsU0FBUyxDQUFDLFFBQVYsQ0FBbUIsU0FBUyxDQUFDLHNCQUE3QjtXQUNBLFlBQVksQ0FBQyxLQUFiLENBQUE7RUFGc0IsQ0FBMUI7O0VBSUEsTUFBQSxDQUFPLGNBQVAsRUFBdUIsUUFBQSxDQUFBLENBQUE7QUFDbkIsUUFBQTtJQUFBLEVBQUEsR0FBSyxTQUFTLENBQUM7SUFDZixJQUFBLENBQWMsSUFBSyxDQUFBLEVBQUEsQ0FBbkI7QUFBQSxhQUFBOztJQUNBLFlBQVksQ0FBQyxLQUFiLENBQUE7SUFDQSxZQUFZLENBQUMsZ0JBQWIsQ0FBOEIsSUFBSyxDQUFBLEVBQUEsQ0FBbkM7V0FDQSxTQUFTLENBQUMsUUFBVixDQUFtQixTQUFTLENBQUMsc0JBQTdCO0VBTG1CLENBQXZCOztFQU9BLE1BQUEsQ0FBTyxVQUFQLEVBQW1CLFFBQUEsQ0FBQyxJQUFELENBQUE7V0FDZixTQUFTLENBQUMsY0FBVixDQUF5QixJQUF6QjtFQURlLENBQW5COztFQUdBLE1BQUEsQ0FBTyxVQUFQLEVBQW1CLFFBQUEsQ0FBQyxRQUFELENBQUE7V0FDZixTQUFTLENBQUMsY0FBVixDQUF5QixRQUF6QjtFQURlLENBQW5COztFQUdBLE1BQUEsQ0FBTyxPQUFQLEVBQWdCLFFBQUEsQ0FBQyxLQUFELENBQUE7SUFDWixTQUFTLENBQUMsV0FBVixDQUFzQixLQUF0QjtXQUNBLElBQUksQ0FBQyxXQUFMLENBQWlCLEtBQWpCO0VBRlksQ0FBaEI7O0VBSUEsTUFBQSxDQUFPLFNBQVAsRUFBa0IsUUFBQSxDQUFDLE9BQUQsRUFBVSxTQUFWLENBQUE7V0FDZCxHQUFHLENBQUMsSUFBSixDQUFTLGlCQUFULEVBQTRCLE9BQTVCLEVBQXFDLFNBQXJDLEVBQWdELEVBQWhEO0VBRGMsQ0FBbEI7O0VBR0EsTUFBQSxDQUFPLDRCQUFQLEVBQXFDLFFBQUEsQ0FBQyxDQUFELENBQUE7SUFDakMsSUFBQSxDQUFjLENBQUMsQ0FBQyxrQkFBaEI7QUFBQSxhQUFBO0tBQUE7O0lBRUEsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEtBQXJCLEdBQTZCO1dBQzdCLElBQUksQ0FBQyxjQUFMLENBQW9CLENBQUMsQ0FBQyxrQkFBdEI7RUFKaUMsQ0FBckM7O0VBTUEsTUFBQSxDQUFPLGVBQVAsRUFBd0IsUUFBQSxDQUFDLENBQUQsQ0FBQTtJQUNwQixJQUFBLENBQWMsQ0FBQyxDQUFDLGtCQUFoQjtBQUFBLGFBQUE7O1dBQ0EsSUFBSSxDQUFDLGFBQUwsQ0FBbUIsQ0FBQyxDQUFDLGtCQUFyQjtFQUZvQixDQUF4Qjs7RUFJQSxNQUFBLENBQU8sWUFBUCxFQUFxQixRQUFBLENBQUMsSUFBRCxDQUFBO0lBQ2pCLFNBQVMsQ0FBQyxRQUFWLENBQW1CLFNBQVMsQ0FBQyxZQUE3QjtJQUNBLFNBQVMsQ0FBQyxlQUFWLENBQTBCLElBQTFCO1dBQ0EsR0FBRyxDQUFDLElBQUosQ0FBUyxVQUFULEVBQXFCLFNBQVMsQ0FBQyxZQUEvQjtFQUhpQixDQUFyQjs7RUFLQSxNQUFBLENBQU8sZ0JBQVAsRUFBeUIsUUFBQSxDQUFDLFNBQVMsQ0FBVixDQUFBO0lBQ3JCLElBQUcsU0FBUyxDQUFDLEtBQVYsS0FBbUIsU0FBUyxDQUFDLFlBQWhDO0FBQWtELGFBQWxEOztJQUNBLFNBQVMsQ0FBQyxjQUFWLENBQXlCLE1BQXpCO1dBQ0EsR0FBRyxDQUFDLElBQUosQ0FBUyxVQUFULEVBQXFCLFNBQVMsQ0FBQyxZQUEvQjtFQUhxQixDQUF6Qjs7RUFLQSxNQUFBLENBQU8saUJBQVAsRUFBMEIsUUFBQSxDQUFDLFFBQVEsQ0FBVCxDQUFBO0lBQ3RCLElBQUcsU0FBUyxDQUFDLEtBQVYsS0FBbUIsU0FBUyxDQUFDLFlBQWhDO0FBQWtELGFBQWxEOztJQUNBLFNBQVMsQ0FBQyxlQUFWLENBQTBCLEtBQTFCO1dBQ0EsR0FBRyxDQUFDLElBQUosQ0FBUyxVQUFULEVBQXFCLFNBQVMsQ0FBQyxZQUEvQjtFQUhzQixDQUExQjs7RUFLQSxNQUFBLENBQU8sYUFBUCxFQUFzQixRQUFBLENBQUMsTUFBTSxFQUFQLENBQUE7QUFDbEIsUUFBQTtJQUFBLElBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSixDQUFBLENBQUo7QUFBb0IsYUFBcEI7O0lBQ0EsR0FBQSxHQUFNLFNBQVMsQ0FBQyxnQkFBVixDQUEyQixNQUFNLENBQUMsSUFBbEMsRUFBd0MsR0FBeEM7SUFDTixHQUFHLENBQUMsSUFBSixDQUFTLGlCQUFULEVBQTRCLEdBQTVCO1dBQ0EsSUFBSSxDQUFDLHlCQUFMLENBQStCLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBM0MsRUFBK0MsR0FBL0M7RUFKa0IsQ0FBdEI7O0VBTUEsTUFBQSxDQUFPLGdCQUFQLEVBQXlCLFFBQUEsQ0FBQSxDQUFBO1dBQ3JCLFNBQVMsQ0FBQyxXQUFWLENBQXNCLENBQUksU0FBUyxDQUFDLFFBQXBDO0VBRHFCLENBQXpCOztFQUdBLE1BQUEsQ0FBTyxrQkFBUCxFQUEyQixRQUFBLENBQUMsS0FBRCxDQUFBO1dBQ3ZCLFNBQVMsQ0FBQyxtQkFBVixDQUE4QixLQUE5QjtFQUR1QixDQUEzQjs7RUFHQSxNQUFBLENBQU8sc0JBQVAsRUFBK0IsUUFBQSxDQUFDLEtBQUQsQ0FBQTtXQUMzQixTQUFTLENBQUMsdUJBQVYsQ0FBa0MsS0FBbEM7RUFEMkIsQ0FBL0I7O0VBR0EsTUFBQSxDQUFPLHVCQUFQLEVBQWdDLFFBQUEsQ0FBQSxDQUFBO1dBQzVCLFNBQVMsQ0FBQyx3QkFBVixDQUFtQyxDQUFJLFNBQVMsQ0FBQyxxQkFBakQ7RUFENEIsQ0FBaEM7O0VBR0EsTUFBQSxDQUFPLFlBQVAsRUFBcUIsUUFBQSxDQUFBLENBQUE7V0FDakIsTUFBTSxDQUFDLElBQUksQ0FBQyxrQkFBWixDQUFBLENBQWdDLENBQUMsS0FBakMsQ0FBQTtFQURpQixDQUFyQjs7RUFHQSxNQUFBLENBQU8sc0JBQVAsRUFBK0IsUUFBQSxDQUFDLEtBQUQsQ0FBQTtXQUMzQixTQUFTLENBQUMsb0JBQVYsQ0FBK0IsS0FBL0I7RUFEMkIsQ0FBL0I7O0VBR0EsTUFBQSxDQUFPLG9CQUFQLEVBQTZCLFFBQUEsQ0FBQSxDQUFBO1dBQ3pCLFNBQVMsQ0FBQyxlQUFWLENBQTBCLENBQUksU0FBUyxDQUFDLFlBQXhDO0VBRHlCLENBQTdCOztFQUdBLE1BQUEsQ0FBTyxZQUFQLEVBQXFCLFFBQUEsQ0FBQSxDQUFBO0lBQ2pCLFNBQVMsQ0FBQyxRQUFWLENBQW1CLFNBQVMsQ0FBQyxXQUE3QjtXQUNBLE9BQUEsQ0FBUSxXQUFSO0VBRmlCLENBQXJCOztFQUlBLE1BQUEsQ0FBTyxZQUFQLEVBQXFCLFFBQUEsQ0FBQSxDQUFBO0FBQ2pCLFFBQUE7SUFBQSxVQUFBLEdBQWEsTUFBTSxDQUFDLGdCQUFQLENBQUEsRUFBYjtXQUNBLFVBQVUsQ0FBQyxJQUFYLENBQUE7RUFGaUIsQ0FBckI7O0VBSUEsTUFBQSxDQUFPLGNBQVAsRUFBdUIsUUFBQSxDQUFBLENBQUE7QUFDbkIsUUFBQTtJQUFBLFVBQUEsR0FBYSxNQUFNLENBQUMsZ0JBQVAsQ0FBQSxFQUFiO0lBQ0EsSUFBRyxVQUFVLENBQUMsU0FBWCxDQUFBLENBQUg7YUFBK0IsVUFBVSxDQUFDLElBQVgsQ0FBQSxFQUEvQjtLQUFBLE1BQUE7YUFBc0QsVUFBVSxDQUFDLElBQVgsQ0FBQSxFQUF0RDs7RUFGbUIsQ0FBdkI7O0VBSUEsTUFBQSxDQUFPLDRCQUFQLEVBQXFDLFFBQUEsQ0FBQSxDQUFBO1dBQ2pDLFNBQVMsQ0FBQyx1QkFBVixDQUFrQyxDQUFJLFNBQVMsQ0FBQyxvQkFBaEQ7RUFEaUMsQ0FBckM7O0VBR0EsTUFBQSxDQUFPLG1CQUFQLEVBQTRCLFFBQUEsQ0FBQSxDQUFBO1dBQ3hCLFNBQVMsQ0FBQyxjQUFWLENBQXlCLENBQUksU0FBUyxDQUFDLFdBQXZDO0VBRHdCLENBQTVCOztFQUdBLE1BQUEsQ0FBTyxZQUFQLEVBQXFCLFFBQUEsQ0FBQSxDQUFBO0FBQ2pCLFFBQUE7SUFBQSxVQUFBLEdBQWEsTUFBTSxDQUFDLGdCQUFQLENBQUEsRUFBYjtXQUNBLFVBQVUsQ0FBQyxJQUFYLENBQUE7RUFGaUIsQ0FBckI7O0VBSUEsZUFBQSxHQUFrQixRQUFBLENBQVMsS0FBVCxFQUFnQixRQUFBLENBQUEsQ0FBQTtJQUM5QixHQUFHLENBQUMsSUFBSixDQUFTLGFBQVQ7V0FDQSxHQUFHLENBQUMsSUFBSixDQUFTLGlCQUFULEVBQTRCLElBQTVCLEVBQWtDLEVBQWxDO0VBRjhCLENBQWhCOztFQUdsQixXQUFBLEdBQWMsUUFBQSxDQUFTLEtBQVQsRUFBZ0IsUUFBQSxDQUFBLENBQUE7V0FBRyxHQUFHLENBQUMsSUFBSixDQUFTLFVBQVQsRUFBcUIsU0FBUyxDQUFDLFlBQS9CO0VBQUgsQ0FBaEIsRUF2TGQ7Ozs7O0VBNExBLE1BQUEsQ0FBTyxNQUFQLEVBQWUsUUFBQSxDQUFBLENBQUE7V0FDWCxlQUFBLENBQUE7RUFEVyxDQUFmOztFQUdBLE1BQUEsQ0FBTyxjQUFQLEVBQXVCLFFBQUEsQ0FBQSxDQUFBO0lBQ25CLGVBQUEsQ0FBQTtJQUNBLElBQWlCLFFBQVEsQ0FBQyxRQUFULENBQUEsQ0FBakI7YUFBQSxXQUFBLENBQUEsRUFBQTs7RUFGbUIsQ0FBdkI7O0VBSUEsTUFBQSxDQUFPLFVBQVAsRUFBbUIsUUFBQSxDQUFBLENBQUE7V0FDZixHQUFHLENBQUMsSUFBSixDQUFTLFVBQVQ7RUFEZSxDQUFuQjs7RUFHQSxNQUFBLENBQU8saUJBQVAsRUFBNkIsQ0FBQSxRQUFBLENBQUEsQ0FBQTtBQUN6QixRQUFBO0lBQUEsbUJBQUEsR0FBc0IsQ0FBQTtXQUN0QixRQUFBLENBQUEsQ0FBQTtBQUNJLFVBQUEsQ0FBQSxFQUFBLE9BQUEsRUFBQTtNQUFBLE9BQUEsR0FBVSxTQUFTLENBQUM7TUFDcEIsQ0FBQSxHQUFJLElBQUssQ0FBQSxPQUFBO01BQ1QsSUFBQSxDQUFjLENBQWQ7QUFBQSxlQUFBOztNQUNBLFNBQUEsR0FBWSxtQkFBb0IsQ0FBQSxPQUFBO01BQ2hDLElBQUEsQ0FBTyxTQUFQO1FBQ08sQ0FBQSxRQUFBLENBQUMsT0FBRCxDQUFBO1VBQ0MsU0FBQSxHQUFZLFFBQUEsQ0FBUyxJQUFULEVBQWUsUUFBQSxDQUFBLENBQUE7bUJBQUcsR0FBRyxDQUFDLElBQUosQ0FBUyxpQkFBVCxFQUE0QixPQUE1QixFQUFxQyxJQUFJLENBQUMsR0FBTCxDQUFBLENBQXJDO1VBQUgsQ0FBZjtpQkFDWixtQkFBb0IsQ0FBQSxPQUFBLENBQXBCLEdBQStCO1FBRmhDLENBQUEsQ0FBSCxDQUFJLE9BQUosRUFESjs7YUFJQSxTQUFBLENBQUE7SUFUSjtFQUZ5QixDQUFBLENBQUgsQ0FBQSxDQUExQjs7RUFhQSxNQUFBLENBQU8sV0FBUCxFQUFvQixRQUFBLENBQUMsR0FBRCxDQUFBO0FBQ2hCLFFBQUE7V0FBRyxDQUFBLEVBQUEsR0FBSyxRQUFBLENBQUEsQ0FBQTtNQUNKLEdBQUcsQ0FBQyxJQUFKLENBQVMsV0FBVCxFQUFzQixHQUFJLFlBQTFCO01BQ0EsR0FBQSxHQUFNLEdBQUk7TUFDVixJQUF1QixHQUFHLENBQUMsTUFBSixHQUFhLENBQXBDO2VBQUEsVUFBQSxDQUFXLEVBQVgsRUFBZSxHQUFmLEVBQUE7O0lBSEksQ0FBTCxDQUFILENBQUE7RUFEZ0IsQ0FBcEI7O0VBTUEsTUFBQSxDQUFPLGFBQVAsRUFBc0IsUUFBQSxDQUFDLEVBQUQsRUFBSyxPQUFMLENBQUE7QUFDbEIsUUFBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBLEdBQUEsRUFBQTtBQUFhO0lBQUEsS0FBQSxxQ0FBQTs7TUFBYixNQUFNLENBQUMsR0FBUCxDQUFXLENBQVg7SUFBYTtJQUNiLElBQUcsT0FBSDtNQUNJLGNBQUMsS0FBSyxFQUFOLENBQVMsQ0FBQyxPQUFWLENBQWtCLFFBQUEsQ0FBQyxDQUFELENBQUE7ZUFBTyxJQUFJLENBQUMsY0FBTCxDQUFvQixPQUFwQixFQUE2QixDQUE3QjtNQUFQLENBQWxCO01BQ0EsU0FBUyxDQUFDLFFBQVYsQ0FBbUIsU0FBUyxDQUFDLFlBQTdCLEVBRko7S0FEQTs7V0FNQSxTQUFTLENBQUMsV0FBVixDQUFzQixJQUF0QjtFQVBrQixDQUF0Qjs7RUFTQSxNQUFBLENBQU8sYUFBUCxFQUFzQixRQUFBLENBQUMsS0FBRCxDQUFBO0FBRWxCLFFBQUEsQ0FBQSxFQUFBLG1CQUFBLEVBQUEsT0FBQSxFQUFBLE9BQUEsRUFBQSxHQUFBLEVBQUEsSUFBQSxFQUFBLENBQUEsRUFBQSxHQUFBLEVBQUEsR0FBQSxFQUFBLEdBQUEsRUFBQSxJQUFBOztJQUFBLE9BQUEsR0FBVSxTQUFTLENBQUMsYUFBcEI7O0lBRUEsSUFBQSxDQUFBLENBQU8sU0FBUyxDQUFDLEtBQVYsS0FBbUIsU0FBUyxDQUFDLFlBQTdCLElBQThDLElBQUssQ0FBQSxPQUFBLENBQTFELENBQUE7O01BRUksUUFBUSxDQUFDLGNBQVQsQ0FBd0IsWUFBeEIsQ0FBcUMsQ0FBQyxLQUF0QyxHQUE4QztBQUM5QyxhQUhKO0tBRkE7OztJQVFBLElBQUcsS0FBSyxDQUFDLE1BQU4sS0FBZ0IsQ0FBbkI7TUFDSSxJQUFBLEdBQU8sS0FBTSxDQUFBLENBQUE7TUFDYixPQUFBLEdBQVUsUUFBUSxDQUFDLGNBQVQsQ0FBd0IsYUFBeEIsRUFEVjs7TUFHQSxJQUFHLEtBQUEsQ0FBTSxJQUFJLENBQUMsSUFBWCxDQUFIOzs7OztRQUtJLEVBQUUsQ0FBQyxRQUFILENBQVksSUFBSSxDQUFDLElBQWpCLEVBQXVCLFFBQUEsQ0FBQyxHQUFELEVBQU0sYUFBTixDQUFBO0FBQ25CLGNBQUEsV0FBQSxFQUFBLFdBQUEsRUFBQTtVQUFBLFdBQUEsR0FBYyxJQUFJLE1BQUosQ0FBVyxhQUFYLEVBQTBCLFFBQTFCO1VBQ2QsV0FBQSxHQUFjLFdBQVcsQ0FBQyxRQUFaLENBQXFCLFFBQXJCO1VBQ2QsUUFBQSxHQUFXLElBQUksQ0FBQyxNQUFMLENBQVksSUFBSSxDQUFDLElBQWpCO1VBQ1gsT0FBTyxDQUFDLEdBQVIsR0FBYyxPQUFBLEdBQVUsUUFBVixHQUFxQixVQUFyQixHQUFrQztpQkFDaEQsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsb0JBQXZCLENBQTRDLENBQUMsU0FBUyxDQUFDLEdBQXZELENBQTJELE1BQTNEO1FBTG1CLENBQXZCLEVBTEo7T0FBQSxNQUFBO1FBWUksQ0FBQyxDQUFELEVBQUksR0FBSixDQUFBLHlEQUEyQztRQUMzQyxJQUFBLENBQUssQ0FBQSxzQkFBQSxDQUFBLENBQXlCLEdBQXpCLENBQUEsQ0FBTCxFQWJKO09BSko7S0FBQSxNQUFBO01BbUJJLEtBQUEsdUNBQUE7d0JBQUE7O1FBRUksSUFBQSxDQUFPLEtBQUEsQ0FBTSxJQUFJLENBQUMsSUFBWCxDQUFQO1VBQ0ksQ0FBQyxDQUFELEVBQUksR0FBSixDQUFBLDJEQUEyQztVQUMzQyxJQUFBLENBQUssQ0FBQSxzQkFBQSxDQUFBLENBQXlCLEdBQXpCLENBQUEsQ0FBTDtBQUNBLG1CQUhKO1NBQUE7O1FBS0EsR0FBQSxHQUFNLFNBQVMsQ0FBQyxnQkFBVixDQUEyQixNQUFNLENBQUMsSUFBbEMsRUFBd0Msa0JBQXhDO1FBQ04sR0FBRyxDQUFDLFdBQUosR0FBa0I7UUFDbEIsQ0FBQSxDQUFDLG1CQUFELENBQUEsR0FBd0IsR0FBeEIsRUFQQTs7UUFTQSxJQUFJLENBQUMseUJBQUwsQ0FBK0IsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUEzQyxFQUErQyxHQUEvQyxFQVRBOztRQVdBLEdBQUcsQ0FBQyxJQUFKLENBQVMsYUFBVCxFQUF3QjtVQUFDLElBQUEsRUFBSyxJQUFJLENBQUMsSUFBWDtVQUFpQixPQUFqQjtVQUEwQjtRQUExQixDQUF4QjtNQWJKLENBbkJKO0tBUkE7O1dBMENBLFFBQVEsQ0FBQyxjQUFULENBQXdCLFlBQXhCLENBQXFDLENBQUMsS0FBdEMsR0FBOEM7RUE1QzVCLENBQXRCOztFQThDQSxNQUFBLENBQU8sY0FBUCxFQUF1QixRQUFBLENBQUEsQ0FBQTtBQUNuQixRQUFBO0lBQUEsT0FBQSxHQUFVLFFBQVEsQ0FBQyxjQUFULENBQXdCLGFBQXhCO0lBQ1YsT0FBTyxDQUFDLEdBQVIsR0FBYyxTQUFTLENBQUMsU0FBVixDQUFBLENBQXFCLENBQUMsU0FBdEIsQ0FBQTtJQUNkLE9BQU8sQ0FBQyxHQUFSLEdBQWMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFaLENBQW9CLFlBQXBCLEVBQWtDLFdBQWxDO1dBQ2QsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsb0JBQXZCLENBQTRDLENBQUMsU0FBUyxDQUFDLEdBQXZELENBQTJELE1BQTNEO0VBSm1CLENBQXZCOztFQU1BLE1BQUEsQ0FBTyxvQkFBUCxFQUE2QixRQUFBLENBQUEsQ0FBQTtBQUN6QixRQUFBLG1CQUFBLEVBQUEsT0FBQSxFQUFBLE9BQUEsRUFBQSxHQUFBLEVBQUE7SUFBQSxPQUFBLEdBQVUsU0FBUyxDQUFDO0lBQ3BCLElBQUEsQ0FBYyxPQUFkO0FBQUEsYUFBQTs7SUFDQSxHQUFBLEdBQU0sU0FBUyxDQUFDLGdCQUFWLENBQTJCLE1BQU0sQ0FBQyxJQUFsQyxFQUF3QyxrQkFBeEM7SUFDTixHQUFHLENBQUMsV0FBSixHQUFrQjtJQUNsQixDQUFBLENBQUMsbUJBQUQsQ0FBQSxHQUF3QixHQUF4QjtJQUNBLElBQUksQ0FBQyx5QkFBTCxDQUErQixNQUFNLENBQUMsSUFBSSxDQUFDLEVBQTNDLEVBQStDLEdBQS9DLEVBTEE7O0lBT0EsT0FBQSxHQUFVLFFBQVEsQ0FBQyxjQUFULENBQXdCLGFBQXhCLEVBUFY7O0lBU0EsT0FBQSxHQUFVLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBWixDQUFvQix5Q0FBcEIsRUFBK0QsRUFBL0Q7SUFDVixPQUFBLEdBQVUsSUFBSSxNQUFKLENBQVcsT0FBWCxFQUFvQixRQUFwQjtJQUNWLFFBQVEsQ0FBQyxhQUFULENBQXVCLG9CQUF2QixDQUE0QyxDQUFDLFNBQVMsQ0FBQyxNQUF2RCxDQUE4RCxNQUE5RDtJQUNBLFFBQVEsQ0FBQyxhQUFULENBQXVCLGtCQUF2QixDQUEwQyxDQUFDLFNBQVMsQ0FBQyxNQUFyRCxDQUE0RCxNQUE1RDtJQUNBLE9BQU8sQ0FBQyxHQUFSLEdBQWM7O1dBRWQsR0FBRyxDQUFDLElBQUosQ0FBUyxzQkFBVCxFQUFpQyxDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQW1CLG1CQUFuQixDQUFqQztFQWhCeUIsQ0FBN0I7O0VBa0JBLE1BQUEsQ0FBTyxnQkFBUCxFQUF5QixRQUFBLENBQUMsSUFBRCxDQUFBLEVBQUEsQ0FBekIsRUF4U0E7Ozs7OztFQThTQSxNQUFBLENBQU8sWUFBUCxFQUFxQixRQUFBLENBQUMsSUFBRCxDQUFBO1dBQVUsU0FBUyxDQUFDLFdBQVYsQ0FBc0IsSUFBdEI7RUFBVixDQUFyQjs7RUFDQSxNQUFBLENBQU8sUUFBUCxFQUFpQixRQUFBLENBQUMsR0FBRCxDQUFBO1dBQVMsU0FBUyxDQUFDLE9BQVYsQ0FBa0IsR0FBbEI7RUFBVCxDQUFqQjs7RUFDQSxNQUFBLENBQU8sTUFBUCxFQUFlLFFBQUEsQ0FBQyxHQUFELENBQUE7V0FBUyxTQUFTLENBQUMsV0FBVixDQUFzQixHQUF0QjtFQUFULENBQWY7O0VBRUEsTUFBQSxDQUFPLGtCQUFQLEVBQTJCLFFBQUEsQ0FBQyxJQUFELENBQUE7V0FDdkIsWUFBWSxDQUFDLE9BQWIsQ0FBcUIsSUFBckI7RUFEdUIsQ0FBM0I7O0VBRUEsTUFBQSxDQUFPLG1CQUFQLEVBQTRCLFFBQUEsQ0FBQyxLQUFELENBQUE7V0FDeEIsWUFBWSxDQUFDLGNBQWIsQ0FBNEIsS0FBNUI7RUFEd0IsQ0FBNUI7O0VBRUEsTUFBQSxDQUFPLGdCQUFQLEVBQXlCLFFBQUEsQ0FBQyxLQUFELEVBQVEsV0FBUixDQUFBO1dBQ3JCLEdBQUcsQ0FBQyxJQUFKLENBQVMsZ0JBQVQsRUFBMkIsS0FBM0IsRUFBa0MsV0FBbEM7RUFEcUIsQ0FBekI7O0VBRUEsTUFBQSxDQUFPLHFCQUFQLEVBQThCLFFBQUEsQ0FBQyxDQUFELENBQUE7V0FDMUIsWUFBWSxDQUFDLG1CQUFiLENBQWlDLENBQWpDO0VBRDBCLENBQTlCOztFQUVBLE1BQUEsQ0FBTyxjQUFQLEVBQXVCLFFBQUEsQ0FBQyxDQUFELENBQUE7V0FBTyxZQUFZLENBQUMsaUJBQWIsQ0FBK0IsQ0FBL0I7RUFBUCxDQUF2Qjs7RUFDQSxNQUFBLENBQU8sZ0JBQVAsRUFBeUIsUUFBQSxDQUFDLENBQUQsQ0FBQTtXQUFPLFlBQVksQ0FBQyxvQkFBYixDQUFrQyxDQUFsQztFQUFQLENBQXpCOztFQUNBLE1BQUEsQ0FBTyxhQUFQLEVBQXNCLFFBQUEsQ0FBQyxDQUFELENBQUE7V0FBTyxZQUFZLENBQUMsUUFBYixDQUFzQixDQUFDLFlBQVksQ0FBQyxLQUFwQztFQUFQLENBQXRCOztFQUVBLE1BQUEsQ0FBTyxrQkFBUCxFQUEyQixRQUFBLENBQUEsQ0FBQTtBQUN2QixRQUFBLENBQUEsRUFBQSxPQUFBLEVBQUEsT0FBQSxFQUFBLENBQUEsRUFBQSxFQUFBLEVBQUEsSUFBQSxFQUFBLFdBQUEsRUFBQSxVQUFBLEVBQUEsQ0FBQSxFQUFBLFFBQUEsRUFBQSxHQUFBLEVBQUEsUUFBQSxFQUFBO0lBQUEsU0FBUyxDQUFDLFFBQVYsQ0FBbUIsU0FBUyxDQUFDLFlBQTdCO0lBQ0EsT0FBQSxHQUFVLFlBQVksQ0FBQztJQUN2QixDQUFBLEdBQUksSUFBSyxDQUFBLE9BQUE7SUFDVCxVQUFBLDRDQUFvQixDQUFFLE9BQVQsQ0FBaUIsWUFBakIsb0JBQUEsSUFBa0M7SUFDL0MsUUFBQTs7QUFBeUI7QUFBQTtNQUFBLEtBQUEsc0NBQUE7O3FCQUFiLENBQUMsQ0FBQyxFQUFFLENBQUM7TUFBUSxDQUFBOzs7SUFDekIsUUFBQSxHQUFXLE9BQUEsSUFBWSxVQUFaLElBQTJCLFlBQVksQ0FBQztJQUNuRCxXQUFBLEdBQWMsWUFBWSxDQUFDLEtBQWIsSUFBdUIsWUFBWSxDQUFDLElBQXBDLElBQTZDLFlBQVksQ0FBQyxJQUFiLGtCQUFxQixDQUFDLENBQUUsZUFObkY7O0lBUUEsSUFBRyxDQUFJLE9BQUosSUFBZSxRQUFsQjtNQUNJLElBQUEsR0FBTyxDQUFzQixZQUFZLENBQUMsS0FBbEMsR0FBQSxZQUFZLENBQUMsSUFBYixHQUFBLE1BQUQsQ0FBQSxJQUE2QztNQUNwRCxHQUFHLENBQUMsSUFBSixDQUFTLG9CQUFULEVBQStCLFFBQS9CLEVBQXlDLElBQXpDLEVBQStDLFlBQVksQ0FBQyxLQUE1RDtBQUNBLGFBSEo7O0lBSUEsQ0FBQSxHQUFJLENBQUMsQ0FBQztJQUNOLE9BQUE7O0FBQXdCO01BQUEsS0FBQSxtQ0FBQTs7WUFBZ0IsQ0FBSSxNQUFNLENBQUMsTUFBUCxDQUFjLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBbkI7dUJBQWpDLENBQUMsQ0FBQyxFQUFFLENBQUM7O01BQVEsQ0FBQTs7O0lBQ3hCLEtBQUE7O0FBQVk7TUFBQSxLQUFBLDBDQUFBOztZQUF3QixhQUFVLE9BQVYsRUFBQSxFQUFBO3VCQUEzQjs7TUFBRyxDQUFBOzs7SUFDWixJQUFzQyxLQUFLLENBQUMsTUFBNUM7TUFBQSxHQUFHLENBQUMsSUFBSixDQUFTLFNBQVQsRUFBb0IsT0FBcEIsRUFBNkIsS0FBN0IsRUFBQTs7SUFDQSxJQUE2RCxXQUE3RDthQUFBLEdBQUcsQ0FBQyxJQUFKLENBQVMsb0JBQVQsRUFBK0IsT0FBL0IsRUFBd0MsWUFBWSxDQUFDLElBQXJELEVBQUE7O0VBakJ1QixDQUEzQjs7RUFtQkEsTUFBQSxDQUFPLHFCQUFQLEVBQThCLFFBQUEsQ0FBQyxDQUFELENBQUE7SUFDMUIsSUFBSSxDQUFDLE1BQUwsQ0FBWSxDQUFaLEVBQWUsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLFFBQXJDO1dBQ0EsSUFBSSxDQUFDLGNBQUwsQ0FBb0IsQ0FBcEI7RUFGMEIsQ0FBOUI7O0VBSUEsTUFBQSxDQUFPLG1CQUFQLEVBQTRCLFFBQUEsQ0FBQyxDQUFELENBQUE7QUFDeEIsUUFBQSxPQUFBLEVBQUEsRUFBQSxFQUFBLEdBQUEsRUFBQTtJQUFBLE9BQUEsR0FBVSxDQUFDLENBQUMsZUFBZSxDQUFDO0lBQzVCLEdBQUE7O0FBQWdDO0FBQUE7TUFBQSxLQUFBLHFDQUFBOztxQkFBekIsRUFBRSxDQUFDLE9BQUgsSUFBYyxFQUFFLENBQUM7TUFBUSxDQUFBOzs7SUFDaEMsSUFBRyxDQUFDLENBQUMsaUJBQWlCLENBQUMsSUFBcEIsS0FBNEIsT0FBL0I7TUFDSSxVQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBWixFQUFBLGFBQWtCLEdBQWxCLEVBQUEsR0FBQSxNQUFIO0FBQ0ksZUFBTyxJQUFJLENBQUMsVUFBTCxDQUFnQixPQUFoQixFQURYOztBQUVBLGFBQU8sSUFBSSxDQUFDLGtCQUFMLENBQXdCLE9BQXhCLEVBQWlDLEdBQWpDLEVBSFg7O0lBSUEsSUFBSSxDQUFDLGNBQUwsQ0FBb0IsQ0FBcEI7V0FDQSxHQUFHLENBQUMsSUFBSixDQUFTLFdBQVQsRUFBc0IsR0FBdEIsRUFBMkI7TUFBQyxXQUFBLEVBQWE7SUFBZCxDQUEzQjtFQVJ3QixDQUE1Qjs7RUFVQSxNQUFBLENBQU8sd0JBQVAsRUFBaUMsUUFBQSxDQUFDLENBQUQsQ0FBQTtJQUM3QixZQUFZLENBQUMsS0FBYixDQUFBO0lBQ0EsSUFBSSxDQUFDLEdBQUwsQ0FBUyxDQUFUO1dBQ0EsU0FBUyxDQUFDLGVBQVYsQ0FBMEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUEvQjtFQUg2QixDQUFqQzs7RUFLQSxNQUFBLENBQU8sb0JBQVAsRUFBNkIsUUFBQSxDQUFDLENBQUQsQ0FBQTtBQUN6QixRQUFBLE9BQUEsRUFBQSxLQUFBLEVBQUE7SUFBQSxPQUFBLHlDQUFpQixDQUFBLENBQUE7SUFDakIsS0FBQSxnQkFBVyxDQUFHLENBQUEsQ0FBQSxXQUFILEtBQVMsRUFBWixHQUFvQixPQUFwQixHQUFpQztJQUN6QyxJQUE0QyxPQUFBLElBQVksS0FBeEQ7YUFBQSxJQUFJLENBQUMsb0JBQUwsQ0FBMEIsT0FBMUIsRUFBbUMsS0FBbkMsRUFBQTs7RUFIeUIsQ0FBN0I7O0VBS0EsTUFBQSxDQUFPLGFBQVAsRUFBc0IsUUFBQSxDQUFBLENBQUE7QUFDbEIsUUFBQSxLQUFBLEVBQUEsSUFBQSxFQUFBLENBQUEsRUFBQSxPQUFBLEVBQUE7SUFBQSxDQUFBLENBQUMsS0FBRCxFQUFRLElBQVIsQ0FBQSxHQUFnQixNQUFNLENBQUMsaUJBQXZCO0lBQ0EsT0FBQSxHQUFVLFNBQVMsQ0FBQztJQUNwQixJQUFBLENBQWMsQ0FBQSxDQUFBLEdBQUksSUFBSyxDQUFBLE9BQUEsQ0FBVCxDQUFkO0FBQUEsYUFBQTs7SUFDQSxDQUFBLEdBQUksSUFBSSxDQUFDLE9BQUwsQ0FBYSxDQUFiO0lBQ0osR0FBRyxDQUFDLElBQUosQ0FBUyxrQ0FBVCxFQUE2QyxPQUE3QyxFQUFzRCxDQUFJLENBQUgsR0FBVSxJQUFWLEdBQW9CLEtBQXJCLENBQXREO1dBQ0EsSUFBSSxDQUFDLG9CQUFMLENBQTBCLE9BQTFCLEVBQW1DLENBQUksQ0FBSCxHQUFVLE1BQVYsR0FBc0IsT0FBdkIsQ0FBbkM7RUFOa0IsQ0FBdEI7O0VBUUEsTUFBQSxDQUFPLFlBQVAsRUFBcUIsUUFBQSxDQUFBLENBQUE7QUFDakIsUUFBQSxDQUFBLEVBQUE7SUFBQSxPQUFBLEdBQVUsU0FBUyxDQUFDO0lBQ3BCLElBQUEsQ0FBYyxDQUFBLENBQUEsR0FBSSxJQUFLLENBQUEsT0FBQSxDQUFULENBQWQ7QUFBQSxhQUFBOztXQUNBLElBQUksQ0FBQyxVQUFMLENBQWdCLENBQWhCO0VBSGlCLENBQXJCOztFQUtBLE1BQUEsQ0FBTyxRQUFQLEVBQWlCLFFBQUEsQ0FBQyxDQUFELENBQUE7QUFDYixRQUFBLENBQUEsRUFBQSxPQUFBLEVBQUE7SUFBQSxPQUFBLHlDQUFpQixDQUFBLENBQUE7SUFDakIsSUFBQSxDQUFjLENBQUEsQ0FBQSxHQUFJLElBQUssQ0FBQSxPQUFBLENBQVQsQ0FBZDtBQUFBLGFBQUE7O1dBQ0EsSUFBSSxDQUFDLFVBQUwsQ0FBZ0IsT0FBaEI7RUFIYSxDQUFqQixFQXRYQTs7Ozs7RUErWEEsTUFBQSxDQUFPLGdCQUFQLEVBQXlCLFFBQUEsQ0FBQyxRQUFELENBQUE7SUFDckIsSUFBRyxJQUFJLENBQUMsVUFBTCxDQUFBLENBQWlCLENBQUMsUUFBbEIsQ0FBMkIsU0FBUyxDQUFDLFFBQXJDLENBQUg7TUFDSSxHQUFHLENBQUMsSUFBSixDQUFTLFNBQVQsRUFBb0IsSUFBcEIsRUFBMEIsUUFBMUI7YUFDQSxTQUFTLENBQUMsV0FBVixDQUFzQixRQUF0QixFQUZKOztFQURxQixDQUF6Qjs7RUFLQSxNQUFBLENBQU8sWUFBUCxFQUFxQixRQUFBLENBQUMsU0FBRCxDQUFBO0FBQ2pCLFFBQUE7SUFBQSxPQUFBLEdBQVUsU0FBUyxDQUFDO0lBQ3BCLElBQUEsQ0FBTyxTQUFQO2FBQ0ksS0FBQSxDQUFNLFFBQUEsQ0FBQSxDQUFBO1FBQUcsSUFBRyxPQUFBLENBQVEsSUFBSSxDQUFDLEVBQUwsQ0FBUSx5REFBUixDQUFSLENBQUg7aUJBQ0wsTUFBQSxDQUFPLFlBQVAsRUFBcUIsSUFBckIsRUFESzs7TUFBSCxDQUFOLEVBREo7S0FBQSxNQUFBO01BSUksR0FBRyxDQUFDLElBQUosQ0FBUyxvQkFBVCxFQUErQixPQUEvQjtNQUNBLFNBQVMsQ0FBQyxlQUFWLENBQTBCLENBQTFCO2FBQ0EsU0FBUyxDQUFDLFFBQVYsQ0FBbUIsU0FBUyxDQUFDLFlBQTdCLEVBTko7O0VBRmlCLENBQXJCOztFQVVBLE1BQUEsQ0FBTyxXQUFQLEVBQW9CLFFBQUEsQ0FBQyxTQUFELENBQUE7QUFDaEIsUUFBQTtJQUFBLE9BQUEsR0FBVSxTQUFTLENBQUM7SUFDcEIsSUFBQSxDQUFPLFNBQVA7YUFDSSxLQUFBLENBQU0sUUFBQSxDQUFBLENBQUE7UUFBRyxJQUFHLE9BQUEsQ0FBUSxJQUFJLENBQUMsRUFBTCxDQUFRLHVEQUFSLENBQVIsQ0FBSDtpQkFDTCxNQUFBLENBQU8sV0FBUCxFQUFvQixJQUFwQixFQURLOztNQUFILENBQU4sRUFESjtLQUFBLE1BQUE7TUFJSSxHQUFHLENBQUMsSUFBSixDQUFTLFlBQVQsRUFBdUIsT0FBdkI7TUFDQSxTQUFTLENBQUMsZUFBVixDQUEwQixDQUExQjthQUNBLFNBQVMsQ0FBQyxRQUFWLENBQW1CLFNBQVMsQ0FBQyxZQUE3QixFQU5KOztFQUZnQixDQUFwQjs7RUFVQSxNQUFBLENBQU8sYUFBUCxFQUFzQixRQUFBLENBQUMsSUFBRCxDQUFBO1dBQVUsU0FBUyxDQUFDLGNBQVYsQ0FBeUIsSUFBekI7RUFBVixDQUF0Qjs7RUFDQSxNQUFBLENBQU8sV0FBUCxFQUFvQixRQUFBLENBQUMsQ0FBRCxDQUFBO0FBQ2hCLFFBQUE7SUFBQSxPQUFBLEdBQVUsU0FBUyxDQUFDO0lBQ3BCLElBQUEsQ0FBQSxDQUFjLE9BQUEsSUFBWSxTQUFTLENBQUMsS0FBVixLQUFtQixTQUFTLENBQUMsWUFBdkQsQ0FBQTtBQUFBLGFBQUE7O0lBQ0EsR0FBRyxDQUFDLElBQUosQ0FBUyxXQUFULEVBQXNCLE9BQXRCLEVBQStCLENBQS9CO1dBQ0EsU0FBUyxDQUFDLFFBQVYsQ0FBbUIsU0FBUyxDQUFDLFlBQTdCO0VBSmdCLENBQXBCOztFQU1BLE1BQUEsQ0FBTyxRQUFQLEVBQWlCLFFBQUEsQ0FBQyxDQUFELENBQUE7V0FDYixJQUFJLENBQUMsU0FBTCxDQUFlLENBQWY7RUFEYSxDQUFqQjs7RUFFQSxNQUFBLENBQU8sYUFBUCxFQUFzQixRQUFBLENBQUMsT0FBRCxDQUFBO1dBQ2xCLElBQUksQ0FBQyxXQUFMLENBQWlCLE9BQWpCO0VBRGtCLENBQXRCOztFQUdBLE1BQUEsQ0FBTyxrQkFBUCxFQUEyQixRQUFBLENBQVMsS0FBVCxFQUFnQixRQUFBLENBQUMsSUFBRCxDQUFBO0lBQ3ZDLElBQUEsQ0FBYyxJQUFkO0FBQUEsYUFBQTs7V0FDQSxHQUFHLENBQUMsSUFBSixDQUFTLGtCQUFULEVBQTZCLElBQTdCO0VBRnVDLENBQWhCLENBQTNCOztFQUlBLE1BQUEsQ0FBTyxvQkFBUCxFQUE2QixRQUFBLENBQUMsQ0FBRCxDQUFBO0FBQ3pCLFFBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsR0FBQSxFQUFBLElBQUEsRUFBQSxHQUFBLEVBQUEsSUFBQSxFQUFBLEVBQUEsRUFBQTtJQUFBLE1BQUEsZUFBUyxDQUFDLENBQUU7SUFDWixJQUFBLG1CQUFjLE1BQU0sQ0FBRSxnQkFBdEI7QUFBQSxhQUFBOztJQUNBLEtBQUEsd0NBQUE7O0FBQ0k7TUFBQSxLQUFBLHdDQUFBOztRQUNJLElBQUksQ0FBQyxjQUFMLENBQW9CLENBQXBCO01BREo7SUFESjtXQUdBLFVBQVUsQ0FBQyxhQUFYLENBQXlCLFVBQVUsQ0FBQyxPQUFwQztFQU55QixDQUE3Qjs7RUFRQSxNQUFBLENBQU8seUJBQVAsRUFBa0MsUUFBQSxDQUFTLEtBQVQsRUFBZ0IsUUFBQSxDQUFBLENBQUE7V0FDOUMsR0FBRyxDQUFDLElBQUosQ0FBUyx5QkFBVDtFQUQ4QyxDQUFoQixDQUFsQzs7RUFHQSxNQUFBLENBQU8sMkJBQVAsRUFBb0MsUUFBQSxDQUFDLENBQUQsQ0FBQTtBQUNoQyxRQUFBO0lBQUEsSUFBQSxDQUFjLENBQUEsRUFBQSxHQUFLLENBQUMsQ0FBQyxrQkFBUCxDQUFkO0FBQUEsYUFBQTs7SUFDQSxJQUFJLENBQUMsaUJBQUwsQ0FBdUIsRUFBdkI7V0FDQSxVQUFVLENBQUMsYUFBWCxDQUF5QixVQUFVLENBQUMsT0FBcEM7RUFIZ0MsQ0FBcEM7O0VBS0EsTUFBQSxDQUFPLHFCQUFQLEVBQThCLFFBQUEsQ0FBQyxDQUFELENBQUE7QUFJMUIsUUFBQSxHQUFBLEVBQUE7SUFBQSxJQUFrQiwwSUFBbEI7Ozs7YUFBQSxJQUFJLENBQUMsR0FBTCxDQUFTLENBQVQsRUFBQTs7RUFKMEIsQ0FBOUI7O0VBTUEsTUFBQSxDQUFPLGVBQVAsRUFBd0IsUUFBQSxDQUFDLENBQUQsQ0FBQTtBQUNwQixRQUFBLEdBQUEsRUFBQTtJQUFBLDhEQUE4QixDQUFFLDZCQUFsQixLQUFpQyxlQUFqQyxJQUFBLEdBQUEsS0FBa0QsYUFBaEU7QUFBQSxhQUFBO0tBQUE7O1dBRUEsTUFBTSxDQUFDLFdBQVAsQ0FBbUIsQ0FBbkI7RUFIb0IsQ0FBeEI7O0VBS0EseUVBQXlFLENBQUMsS0FBMUUsQ0FBZ0YsR0FBaEYsQ0FBb0YsQ0FBQyxPQUFyRixDQUE2RixRQUFBLENBQUMsQ0FBRCxDQUFBO1dBQ3pGLE1BQUEsQ0FBTyxDQUFQLEVBQVUsUUFBQSxDQUFBLEdBQUMsRUFBRCxDQUFBO2FBQVcsT0FBTyxDQUFDLEdBQVIsQ0FBWSxDQUFaLEVBQWUsR0FBQSxFQUFmO0lBQVgsQ0FBVjtFQUR5RixDQUE3Rjs7RUFHQSxNQUFBLENBQU8sYUFBUCxFQUFzQixRQUFBLENBQUMsS0FBRCxFQUFRLE1BQVIsQ0FBQTtBQUNsQixRQUFBO0lBQUEsS0FBQSxHQUFRO0lBQ1IsSUFBRyxLQUFBLEdBQVEsQ0FBWDtNQUFrQixLQUFBLEdBQVEsS0FBQSxHQUFRLENBQUksTUFBSCxHQUFlLEdBQWYsR0FBd0IsRUFBekIsRUFBbEM7O0lBQ0EsT0FBQSxDQUFRLFlBQVI7V0FDQSxHQUFHLENBQUMsSUFBSixDQUFTLGFBQVQsRUFBd0IsS0FBeEI7RUFKa0IsQ0FBdEI7O0VBTUEsTUFBQSxDQUFPLGFBQVAsRUFBc0IsUUFBQSxDQUFDLE1BQUQsQ0FBQTtXQUNsQixTQUFTLENBQUMsY0FBVixDQUF5QixNQUF6QjtFQURrQixDQUF0Qjs7RUFHQSxNQUFBLENBQU8sd0JBQVAsRUFBaUMsUUFBQSxDQUFDLEdBQUQsQ0FBQTtXQUU3QixTQUFTLENBQUMsc0JBQVYsQ0FBaUMsR0FBakM7RUFGNkIsQ0FBakM7O0VBSUEsTUFBQSxDQUFPLGdCQUFQLEVBQXlCLFFBQUEsQ0FBQyxNQUFELENBQUE7V0FDckIsU0FBUyxDQUFDLGlCQUFWLENBQTRCLE1BQTVCO0VBRHFCLENBQXpCOztFQUdBLE1BQUEsQ0FBTyxvQkFBUCxFQUE2QixRQUFBLENBQUMsTUFBRCxDQUFBO1dBQ3pCLFNBQVMsQ0FBQyxxQkFBVixDQUFnQyxNQUFoQztFQUR5QixDQUE3Qjs7RUFHQSxNQUFBLENBQU8sY0FBUCxFQUF1QixRQUFBLENBQUMsTUFBRCxDQUFBO1dBQ25CLFNBQVMsQ0FBQyxlQUFWLENBQTBCLE1BQTFCO0VBRG1CLENBQXZCOztFQUdBLE1BQUEsQ0FBTyxjQUFQLEVBQXVCLFFBQUEsQ0FBQyxNQUFELENBQUE7V0FDbkIsU0FBUyxDQUFDLGVBQVYsQ0FBMEIsTUFBMUI7RUFEbUIsQ0FBdkI7O0VBR0EsTUFBQSxDQUFPLHdCQUFQLEVBQWlDLFFBQUEsQ0FBQyxNQUFELENBQUE7V0FDN0IsU0FBUyxDQUFDLHlCQUFWLENBQW9DLE1BQXBDO0VBRDZCLENBQWpDOztFQUdBLE1BQUEsQ0FBTywyQkFBUCxFQUFvQyxRQUFBLENBQUMsTUFBRCxDQUFBO1dBQ2hDLFNBQVMsQ0FBQyw0QkFBVixDQUF1QyxNQUF2QztFQURnQyxDQUFwQzs7RUFHQSxNQUFBLENBQU8sNEJBQVAsRUFBcUMsUUFBQSxDQUFDLE1BQUQsQ0FBQTtXQUNqQyxTQUFTLENBQUMsNkJBQVYsQ0FBd0MsTUFBeEM7RUFEaUMsQ0FBckM7O0VBR0EsTUFBQSxDQUFPLGNBQVAsRUFBdUIsUUFBQSxDQUFDLE1BQUQsQ0FBQTtXQUNuQixTQUFTLENBQUMsZUFBVixDQUEwQixNQUExQjtFQURtQixDQUF2Qjs7RUFHQSxNQUFBLENBQU8sY0FBUCxFQUF1QixRQUFBLENBQUMsTUFBRCxDQUFBO1dBQ25CLFNBQVMsQ0FBQyxlQUFWLENBQTBCLE1BQTFCO0VBRG1CLENBQXZCOztFQUdBLE1BQUEsQ0FBTyxhQUFQLEVBQXNCLFFBQUEsQ0FBQyxXQUFELENBQUE7V0FDbEIsU0FBUyxDQUFDLGNBQVYsQ0FBeUIsV0FBekI7RUFEa0IsQ0FBdEI7O0VBR0EsTUFBQSxDQUFPLGdCQUFQLEVBQXlCLFFBQUEsQ0FBQyxRQUFELENBQUE7V0FDckIsU0FBUyxDQUFDLFdBQVYsQ0FBc0IsUUFBdEI7RUFEcUIsQ0FBekI7O0VBR0EsTUFBQSxDQUFPLFVBQVAsRUFBbUIsUUFBQSxDQUFBLENBQUE7V0FDZixNQUFNLENBQUMsZ0JBQVAsQ0FBQSxDQUF5QixDQUFDLFlBQTFCLENBQXVDO01BQUEsTUFBQSxFQUFPO0lBQVAsQ0FBdkM7RUFEZSxDQUFuQjs7RUFHQSxNQUFBLENBQU8sTUFBUCxFQUFlLFFBQUEsQ0FBQSxDQUFBO1dBQ1gsR0FBRyxDQUFDLElBQUosQ0FBUyxNQUFUO0VBRFcsQ0FBZjs7RUFHQSxNQUFBLENBQU8sa0JBQVAsRUFBMkIsUUFBQSxDQUFBLENBQUE7V0FDdkIsR0FBRyxDQUFDLElBQUosQ0FBUyxrQkFBVDtFQUR1QixDQUEzQjs7RUFHQSxNQUFBLENBQU8sTUFBUCxFQUFlLFFBQUEsQ0FBQyxJQUFELENBQUE7SUFDWCxJQUFHLFlBQUg7QUFDSSxhQUFPLFNBQVMsQ0FBQyxPQUFWLENBQWtCLENBQUMsVUFBQSxDQUFXLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUF6QixDQUFpQyxHQUFqQyxFQUFzQyxHQUF0QyxDQUFYLENBQUEsSUFBMEQsR0FBM0QsQ0FBQSxHQUFrRSxJQUFwRixFQURYOztXQUVBLFNBQVMsQ0FBQyxPQUFWLENBQWtCLENBQWxCO0VBSFcsQ0FBZjs7RUFLQSxNQUFBLENBQU8sUUFBUCxFQUFpQixRQUFBLENBQUEsQ0FBQTtXQUNiLEdBQUcsQ0FBQyxJQUFKLENBQVMsUUFBVDtFQURhLENBQWpCOztFQUdBLE1BQUEsQ0FBTyxTQUFQLEVBQWtCLFFBQUEsQ0FBQyxPQUFELENBQUE7SUFDZCxVQUFVLENBQUMsZUFBWCxDQUEyQixPQUEzQjtJQUNBLElBQUcsT0FBSDthQUNJLEdBQUcsQ0FBQyxJQUFKLENBQVMsZ0JBQVQsRUFESjtLQUFBLE1BQUE7YUFHSSxHQUFHLENBQUMsSUFBSixDQUFTLG1CQUFULEVBSEo7O0VBRmMsQ0FBbEI7O0VBT0EsTUFBQSxDQUFPLHFCQUFQLEVBQThCLFFBQUEsQ0FBQyxJQUFELENBQUE7V0FDMUIsU0FBUyxDQUFDLHNCQUFWLENBQWlDLElBQWpDO0VBRDBCLENBQTlCOztFQUdBLE1BQUEsQ0FBTyx5QkFBUCxFQUFrQyxRQUFBLENBQUMsU0FBRCxDQUFBO1dBQzlCLFNBQVMsQ0FBQyx1QkFBVixDQUFrQyxTQUFsQztFQUQ4QixDQUFsQzs7RUFHQSxNQUFBLENBQU8sVUFBUCxFQUFtQixRQUFBLENBQUEsQ0FBQTtBQUNmLFFBQUE7SUFBQSxVQUFBLEdBQWEsTUFBTSxDQUFDLGdCQUFQLENBQUE7V0FDYixVQUFVLENBQUMsUUFBWCxDQUFBO0VBRmUsQ0FBbkI7O0VBSUEsTUFBQSxDQUFPLGNBQVAsRUFBdUIsUUFBQSxDQUFBLENBQUE7QUFDbkIsUUFBQTtJQUFBLFVBQUEsR0FBYSxNQUFNLENBQUMsZ0JBQVAsQ0FBQTtJQUNiLElBQUcsVUFBVSxDQUFDLFdBQVgsQ0FBQSxDQUFIO2FBQWlDLFVBQVUsQ0FBQyxVQUFYLENBQUEsRUFBakM7S0FBQSxNQUFBO2FBQThELFVBQVUsQ0FBQyxRQUFYLENBQUEsRUFBOUQ7O0VBRm1CLENBQXZCOztFQUlBLE1BQUEsQ0FBTyxPQUFQLEVBQWdCLFFBQUEsQ0FBQSxDQUFBO0FBQ1osUUFBQTtJQUFBLFVBQUEsR0FBYSxNQUFNLENBQUMsZ0JBQVAsQ0FBQTtXQUNiLFVBQVUsQ0FBQyxLQUFYLENBQUE7RUFGWSxDQUFoQjtBQTFoQkEiLCJzb3VyY2VzQ29udGVudCI6WyJDbGllbnQgPSByZXF1aXJlICdoYW5ndXBzanMnXG5yZW1vdGUgPSByZXF1aXJlKCdlbGVjdHJvbicpLnJlbW90ZVxuaXBjICAgID0gcmVxdWlyZSgnZWxlY3Ryb24nKS5pcGNSZW5kZXJlclxuXG5cbmZzID0gcmVxdWlyZSgnZnMnKVxubWltZSA9IHJlcXVpcmUoJ21pbWUtdHlwZXMnKVxuXG5jbGlwYm9hcmQgPSByZXF1aXJlKCdlbGVjdHJvbicpLmNsaXBib2FyZFxuXG57ZW50aXR5LCBjb252LCB2aWV3c3RhdGUsIHVzZXJpbnB1dCwgY29ubmVjdGlvbiwgY29udnNldHRpbmdzLCBub3RpZnl9ID0gcmVxdWlyZSAnLi9tb2RlbHMnXG57aW5zZXJ0VGV4dEF0Q3Vyc29yLCB0aHJvdHRsZSwgbGF0ZXIsIGlzSW1nLCBuYW1lb2Z9ID0gcmVxdWlyZSAnLi91dGlsJ1xuXG4nY29ubmVjdGluZyBjb25uZWN0ZWQgY29ubmVjdF9mYWlsZWQnLnNwbGl0KCcgJykuZm9yRWFjaCAobikgLT5cbiAgICBoYW5kbGUgbiwgLT4gY29ubmVjdGlvbi5zZXRTdGF0ZSBuXG5cbmhhbmRsZSAnYWxpdmUnLCAodGltZSkgLT4gY29ubmVjdGlvbi5zZXRMYXN0QWN0aXZlIHRpbWVcblxuaGFuZGxlICdyZXFpbml0JywgLT5cbiAgICBpcGMuc2VuZCAncmVxaW5pdCdcbiAgICBjb25uZWN0aW9uLnNldFN0YXRlIGNvbm5lY3Rpb24uQ09OTkVDVElOR1xuICAgIHZpZXdzdGF0ZS5zZXRTdGF0ZSB2aWV3c3RhdGUuU1RBVEVfU1RBUlRVUFxuXG5tb2R1bGUuZXhwb3J0cyA9XG4gICAgaW5pdDogKHtpbml0fSkgLT4gYWN0aW9uICdpbml0JywgaW5pdFxuXG5oYW5kbGUgJ2luaXQnLCAoaW5pdCkgLT5cbiAgICAjIHNldCB0aGUgaW5pdGlhbCB2aWV3IHN0YXRlXG4gICAgdmlld3N0YXRlLnNldExvZ2dlZGluIHRydWVcblxuICAgIHZpZXdzdGF0ZS5zZXRDb2xvclNjaGVtZSB2aWV3c3RhdGUuY29sb3JTY2hlbWVcbiAgICB2aWV3c3RhdGUuc2V0Rm9udFNpemUgdmlld3N0YXRlLmZvbnRTaXplXG5cbiAgICAjIHVwZGF0ZSBtb2RlbCBmcm9tIGluaXQgb2JqZWN0XG4gICAgZW50aXR5Ll9pbml0RnJvbVNlbGZFbnRpdHkgaW5pdC5zZWxmX2VudGl0eVxuICAgIGVudGl0eS5faW5pdEZyb21FbnRpdGllcyBpbml0LmVudGl0aWVzIGlmIGluaXQuZW50aXRpZXNcbiAgICBjb252Ll9pbml0RnJvbUNvbnZTdGF0ZXMgaW5pdC5jb252X3N0YXRlc1xuICAgICMgZW5zdXJlIHRoZXJlJ3MgYSBzZWxlY3RlZCBjb252XG4gICAgdW5sZXNzIGNvbnZbdmlld3N0YXRlLnNlbGVjdGVkQ29udl1cbiAgICAgICAgdmlld3N0YXRlLnNldFNlbGVjdGVkQ29udiBjb252Lmxpc3QoKT9bMF0/LmNvbnZlcnNhdGlvbl9pZFxuXG4gICAgaXBjLnNlbmQgJ2luaXRwcmVzZW5jZScsIGVudGl0eS5saXN0KClcblxuICAgIHJlcXVpcmUoJy4vdmVyc2lvbicpLmNoZWNrKClcblxuICAgICMgc21hbGwgZGVsYXkgZm9yIGJldHRlciBleHBlcmllbmNlXG4gICAgbGF0ZXIgLT4gYWN0aW9uICdzZXRfdmlld3N0YXRlX25vcm1hbCdcblxuaGFuZGxlICdzZXRfdmlld3N0YXRlX25vcm1hbCcsIC0+XG4gICAgdmlld3N0YXRlLnNldENvbnRhY3RzIHRydWVcbiAgICB2aWV3c3RhdGUuc2V0U3RhdGUgdmlld3N0YXRlLlNUQVRFX05PUk1BTFxuXG5oYW5kbGUgJ2NoYXRfbWVzc2FnZScsIChldikgLT5cbiAgICAjIFRPRE8gZW50aXR5IGlzIG5vdCBmZXRjaGVkIGluIHVzYWJsZSB0aW1lIGZvciBmaXJzdCBub3RpZmljYXRpb25cbiAgICAjIGlmIGRvZXMgbm90IGhhdmUgdXNlciBvbiBjYWNoZVxuICAgIGVudGl0eS5uZWVkRW50aXR5IGV2LnNlbmRlcl9pZC5jaGF0X2lkIHVubGVzcyBlbnRpdHlbZXYuc2VuZGVyX2lkLmNoYXRfaWRdP1xuICAgICMgYWRkIGNoYXQgdG8gY29udmVyc2F0aW9uXG4gICAgY29udi5hZGRDaGF0TWVzc2FnZSBldlxuICAgICMgdGhlc2UgbWVzc2FnZXMgYXJlIHRvIGdvIHRocm91Z2ggbm90aWZpY2F0aW9uc1xuICAgIG5vdGlmeS5hZGRUb05vdGlmeSBldlxuXG5oYW5kbGUgJ3dhdGVybWFyaycsIChldikgLT5cbiAgICBjb252LmFkZFdhdGVybWFyayBldlxuXG5oYW5kbGUgJ3ByZXNlbmNlJywgKGV2KSAtPlxuICAgIGVudGl0eS5zZXRQcmVzZW5jZSBldlswXVswXVswXVswXSwgaWYgZXZbMF1bMF1bMV1bMV0gPT0gMSB0aGVuIHRydWUgZWxzZSBmYWxzZVxuXG4jIGhhbmRsZSAnc2VsZl9wcmVzZW5jZScsIChldikgLT5cbiMgICAgIGNvbnNvbGUubG9nICdzZWxmX3ByZXNlbmNlJywgZXZcblxuaGFuZGxlICdxdWVyeXByZXNlbmNlJywgKGlkKSAtPlxuICAgIGlwYy5zZW5kICdxdWVyeXByZXNlbmNlJywgaWRcblxuaGFuZGxlICdzZXRwcmVzZW5jZScsIChyKSAtPlxuICAgIGlmIG5vdCByPy5wcmVzZW5jZT8uYXZhaWxhYmxlP1xuICAgICAgICBjb25zb2xlLmxvZyBcInNldHByZXNlbmNlOiBVc2VyICcje25hbWVvZiBlbnRpdHlbcj8udXNlcl9pZD8uY2hhdF9pZF19JyBkb2VzIG5vdCBzaG93IGhpcy9oZXJzL2l0IHN0YXR1c1wiLCByXG4gICAgZWxzZVxuICAgICAgICBlbnRpdHkuc2V0UHJlc2VuY2Ugci51c2VyX2lkLmNoYXRfaWQsIHI/LnByZXNlbmNlPy5hdmFpbGFibGVcblxuaGFuZGxlICd1cGRhdGU6dW5yZWFkY291bnQnLCAtPlxuICAgIGNvbnNvbGUubG9nICd1cGRhdGUnXG5cbmhhbmRsZSAnYWRkY29udmVyc2F0aW9uJywgLT5cbiAgICB2aWV3c3RhdGUuc2V0U3RhdGUgdmlld3N0YXRlLlNUQVRFX0FERF9DT05WRVJTQVRJT05cbiAgICBjb252c2V0dGluZ3MucmVzZXQoKVxuXG5oYW5kbGUgJ2NvbnZzZXR0aW5ncycsIC0+XG4gICAgaWQgPSB2aWV3c3RhdGUuc2VsZWN0ZWRDb252XG4gICAgcmV0dXJuIHVubGVzcyBjb252W2lkXVxuICAgIGNvbnZzZXR0aW5ncy5yZXNldCgpXG4gICAgY29udnNldHRpbmdzLmxvYWRDb252ZXJzYXRpb24gY29udltpZF1cbiAgICB2aWV3c3RhdGUuc2V0U3RhdGUgdmlld3N0YXRlLlNUQVRFX0FERF9DT05WRVJTQVRJT05cblxuaGFuZGxlICdhY3Rpdml0eScsICh0aW1lKSAtPlxuICAgIHZpZXdzdGF0ZS51cGRhdGVBY3Rpdml0eSB0aW1lXG5cbmhhbmRsZSAnYXRib3R0b20nLCAoYXRib3R0b20pIC0+XG4gICAgdmlld3N0YXRlLnVwZGF0ZUF0Qm90dG9tIGF0Ym90dG9tXG5cbmhhbmRsZSAnYXR0b3AnLCAoYXR0b3ApIC0+XG4gICAgdmlld3N0YXRlLnVwZGF0ZUF0VG9wIGF0dG9wXG4gICAgY29udi51cGRhdGVBdFRvcCBhdHRvcFxuXG5oYW5kbGUgJ2hpc3RvcnknLCAoY29udl9pZCwgdGltZXN0YW1wKSAtPlxuICAgIGlwYy5zZW5kICdnZXRjb252ZXJzYXRpb24nLCBjb252X2lkLCB0aW1lc3RhbXAsIDIwXG5cbmhhbmRsZSAnaGFuZGxlY29udmVyc2F0aW9ubWV0YWRhdGEnLCAocikgLT5cbiAgICByZXR1cm4gdW5sZXNzIHIuY29udmVyc2F0aW9uX3N0YXRlXG4gICAgIyByZW1vdmluZyBldmVudHMgc28gdGhleSBkb24ndCBnZXQgbWVyZ2VkXG4gICAgci5jb252ZXJzYXRpb25fc3RhdGUuZXZlbnQgPSBudWxsXG4gICAgY29udi51cGRhdGVNZXRhZGF0YSByLmNvbnZlcnNhdGlvbl9zdGF0ZVxuXG5oYW5kbGUgJ2hhbmRsZWhpc3RvcnknLCAocikgLT5cbiAgICByZXR1cm4gdW5sZXNzIHIuY29udmVyc2F0aW9uX3N0YXRlXG4gICAgY29udi51cGRhdGVIaXN0b3J5IHIuY29udmVyc2F0aW9uX3N0YXRlXG5cbmhhbmRsZSAnc2VsZWN0Q29udicsIChjb252KSAtPlxuICAgIHZpZXdzdGF0ZS5zZXRTdGF0ZSB2aWV3c3RhdGUuU1RBVEVfTk9STUFMXG4gICAgdmlld3N0YXRlLnNldFNlbGVjdGVkQ29udiBjb252XG4gICAgaXBjLnNlbmQgJ3NldGZvY3VzJywgdmlld3N0YXRlLnNlbGVjdGVkQ29udlxuXG5oYW5kbGUgJ3NlbGVjdE5leHRDb252JywgKG9mZnNldCA9IDEpIC0+XG4gICAgaWYgdmlld3N0YXRlLnN0YXRlICE9IHZpZXdzdGF0ZS5TVEFURV9OT1JNQUwgdGhlbiByZXR1cm5cbiAgICB2aWV3c3RhdGUuc2VsZWN0TmV4dENvbnYgb2Zmc2V0XG4gICAgaXBjLnNlbmQgJ3NldGZvY3VzJywgdmlld3N0YXRlLnNlbGVjdGVkQ29udlxuXG5oYW5kbGUgJ3NlbGVjdENvbnZJbmRleCcsIChpbmRleCA9IDApIC0+XG4gICAgaWYgdmlld3N0YXRlLnN0YXRlICE9IHZpZXdzdGF0ZS5TVEFURV9OT1JNQUwgdGhlbiByZXR1cm5cbiAgICB2aWV3c3RhdGUuc2VsZWN0Q29udkluZGV4IGluZGV4XG4gICAgaXBjLnNlbmQgJ3NldGZvY3VzJywgdmlld3N0YXRlLnNlbGVjdGVkQ29udlxuXG5oYW5kbGUgJ3NlbmRtZXNzYWdlJywgKHR4dCA9ICcnKSAtPlxuICAgIGlmICF0eHQudHJpbSgpIHRoZW4gcmV0dXJuXG4gICAgbXNnID0gdXNlcmlucHV0LmJ1aWxkQ2hhdE1lc3NhZ2UgZW50aXR5LnNlbGYsIHR4dFxuICAgIGlwYy5zZW5kICdzZW5kY2hhdG1lc3NhZ2UnLCBtc2dcbiAgICBjb252LmFkZENoYXRNZXNzYWdlUGxhY2Vob2xkZXIgZW50aXR5LnNlbGYuaWQsIG1zZ1xuXG5oYW5kbGUgJ3RvZ2dsZXNob3d0cmF5JywgLT5cbiAgICB2aWV3c3RhdGUuc2V0U2hvd1RyYXkobm90IHZpZXdzdGF0ZS5zaG93dHJheSlcblxuaGFuZGxlICdmb3JjZWN1c3RvbXNvdW5kJywgKHZhbHVlKSAtPlxuICAgIHZpZXdzdGF0ZS5zZXRGb3JjZUN1c3RvbVNvdW5kKHZhbHVlKVxuXG5oYW5kbGUgJ3Nob3dpY29ubm90aWZpY2F0aW9uJywgKHZhbHVlKSAtPlxuICAgIHZpZXdzdGF0ZS5zZXRTaG93SWNvbk5vdGlmaWNhdGlvbih2YWx1ZSlcblxuaGFuZGxlICdtdXRlc291bmRub3RpZmljYXRpb24nLCAtPlxuICAgIHZpZXdzdGF0ZS5zZXRNdXRlU291bmROb3RpZmljYXRpb24obm90IHZpZXdzdGF0ZS5tdXRlU291bmROb3RpZmljYXRpb24pXG5cbmhhbmRsZSAndG9nZ2xlbWVudScsIC0+XG4gICAgcmVtb3RlLk1lbnUuZ2V0QXBwbGljYXRpb25NZW51KCkucG9wdXAoKVxuXG5oYW5kbGUgJ3NldGVzY2FwZWNsZWFyc2lucHV0JywgKHZhbHVlKSAtPlxuICAgIHZpZXdzdGF0ZS5zZXRFc2NhcGVDbGVhcnNJbnB1dCh2YWx1ZSlcblxuaGFuZGxlICd0b2dnbGVoaWRlZG9ja2ljb24nLCAtPlxuICAgIHZpZXdzdGF0ZS5zZXRIaWRlRG9ja0ljb24obm90IHZpZXdzdGF0ZS5oaWRlZG9ja2ljb24pXG5cbmhhbmRsZSAnc2hvdy1hYm91dCcsIC0+XG4gICAgdmlld3N0YXRlLnNldFN0YXRlIHZpZXdzdGF0ZS5TVEFURV9BQk9VVFxuICAgIHVwZGF0ZWQgJ3ZpZXdzdGF0ZSdcblxuaGFuZGxlICdoaWRlV2luZG93JywgLT5cbiAgICBtYWluV2luZG93ID0gcmVtb3RlLmdldEN1cnJlbnRXaW5kb3coKSAjIEFuZCB3ZSBob3BlIHdlIGRvbid0IGdldCBhbm90aGVyIDspXG4gICAgbWFpbldpbmRvdy5oaWRlKClcblxuaGFuZGxlICd0b2dnbGV3aW5kb3cnLCAtPlxuICAgIG1haW5XaW5kb3cgPSByZW1vdGUuZ2V0Q3VycmVudFdpbmRvdygpICMgQW5kIHdlIGhvcGUgd2UgZG9uJ3QgZ2V0IGFub3RoZXIgOylcbiAgICBpZiBtYWluV2luZG93LmlzVmlzaWJsZSgpIHRoZW4gbWFpbldpbmRvdy5oaWRlKCkgZWxzZSBtYWluV2luZG93LnNob3coKVxuXG5oYW5kbGUgJ3RvZ2dsZXN0YXJ0bWluaW1pemVkdG90cmF5JywgLT5cbiAgICB2aWV3c3RhdGUuc2V0U3RhcnRNaW5pbWl6ZWRUb1RyYXkobm90IHZpZXdzdGF0ZS5zdGFydG1pbmltaXplZHRvdHJheSlcblxuaGFuZGxlICd0b2dnbGVjbG9zZXRvdHJheScsIC0+XG4gICAgdmlld3N0YXRlLnNldENsb3NlVG9UcmF5KG5vdCB2aWV3c3RhdGUuY2xvc2V0b3RyYXkpXG5cbmhhbmRsZSAnc2hvd3dpbmRvdycsIC0+XG4gICAgbWFpbldpbmRvdyA9IHJlbW90ZS5nZXRDdXJyZW50V2luZG93KCkgIyBBbmQgd2UgaG9wZSB3ZSBkb24ndCBnZXQgYW5vdGhlciA7KVxuICAgIG1haW5XaW5kb3cuc2hvdygpXG5cbnNlbmRzZXRwcmVzZW5jZSA9IHRocm90dGxlIDEwMDAwLCAtPlxuICAgIGlwYy5zZW5kICdzZXRwcmVzZW5jZSdcbiAgICBpcGMuc2VuZCAnc2V0YWN0aXZlY2xpZW50JywgdHJ1ZSwgMTVcbnJlc2VuZGZvY3VzID0gdGhyb3R0bGUgMTUwMDAsIC0+IGlwYy5zZW5kICdzZXRmb2N1cycsIHZpZXdzdGF0ZS5zZWxlY3RlZENvbnZcblxuIyBvbiBldmVyeSBrZWVwIGFsaXZlIHNpZ25hbCBmcm9tIGhhbmdvdXRzXG4jICB3ZSBpbmZvcm0gdGhlIHNlcnZlciB0aGF0IHRoZSB1c2VyIGlzIHN0aWxsXG4jICBhdmFpbGFibGVcbmhhbmRsZSAnbm9vcCcsIC0+XG4gICAgc2VuZHNldHByZXNlbmNlKClcblxuaGFuZGxlICdsYXN0QWN0aXZpdHknLCAtPlxuICAgIHNlbmRzZXRwcmVzZW5jZSgpXG4gICAgcmVzZW5kZm9jdXMoKSBpZiBkb2N1bWVudC5oYXNGb2N1cygpXG5cbmhhbmRsZSAnYXBwZm9jdXMnLCAtPlxuICAgIGlwYy5zZW5kICdhcHBmb2N1cydcblxuaGFuZGxlICd1cGRhdGV3YXRlcm1hcmsnLCBkbyAtPlxuICAgIHRocm90dGxlV2F0ZXJCeUNvbnYgPSB7fVxuICAgIC0+XG4gICAgICAgIGNvbnZfaWQgPSB2aWV3c3RhdGUuc2VsZWN0ZWRDb252XG4gICAgICAgIGMgPSBjb252W2NvbnZfaWRdXG4gICAgICAgIHJldHVybiB1bmxlc3MgY1xuICAgICAgICBzZW5kV2F0ZXIgPSB0aHJvdHRsZVdhdGVyQnlDb252W2NvbnZfaWRdXG4gICAgICAgIHVubGVzcyBzZW5kV2F0ZXJcbiAgICAgICAgICAgIGRvIChjb252X2lkKSAtPlxuICAgICAgICAgICAgICAgIHNlbmRXYXRlciA9IHRocm90dGxlIDEwMDAsIC0+IGlwYy5zZW5kICd1cGRhdGV3YXRlcm1hcmsnLCBjb252X2lkLCBEYXRlLm5vdygpXG4gICAgICAgICAgICAgICAgdGhyb3R0bGVXYXRlckJ5Q29udltjb252X2lkXSA9IHNlbmRXYXRlclxuICAgICAgICBzZW5kV2F0ZXIoKVxuXG5oYW5kbGUgJ2dldGVudGl0eScsIChpZHMpIC0+XG4gICAgZG8gZm4gPSAtPlxuICAgICAgICBpcGMuc2VuZCAnZ2V0ZW50aXR5JywgaWRzWy4uNF1cbiAgICAgICAgaWRzID0gaWRzWzUuLl1cbiAgICAgICAgc2V0VGltZW91dChmbiwgNTAwKSBpZiBpZHMubGVuZ3RoID4gMFxuXG5oYW5kbGUgJ2FkZGVudGl0aWVzJywgKGVzLCBjb252X2lkKSAtPlxuICAgIGVudGl0eS5hZGQgZSBmb3IgZSBpbiBlcyA/IFtdXG4gICAgaWYgY29udl9pZCAjwqBhdXRvLWFkZCB0aGVzZSBwcGwgdG8gYSBjb252XG4gICAgICAgIChlcyA/IFtdKS5mb3JFYWNoIChwKSAtPiBjb252LmFkZFBhcnRpY2lwYW50IGNvbnZfaWQsIHBcbiAgICAgICAgdmlld3N0YXRlLnNldFN0YXRlIHZpZXdzdGF0ZS5TVEFURV9OT1JNQUxcblxuICAgICMgZmxhZyB0byBzaG93IHRoYXQgY29udGFjdHMgYXJlIGxvYWRlZFxuICAgIHZpZXdzdGF0ZS5zZXRDb250YWN0cyB0cnVlXG5cbmhhbmRsZSAndXBsb2FkaW1hZ2UnLCAoZmlsZXMpIC0+XG4gICAgIyB0aGlzIG1heSBjaGFuZ2UgZHVyaW5nIHVwbG9hZFxuICAgIGNvbnZfaWQgPSB2aWV3c3RhdGUuc2VsZWN0ZWRDb252XG4gICAgIyBzZW5zZSBjaGVjayB0aGF0IGNsaWVudCBpcyBpbiBnb29kIHN0YXRlXG4gICAgdW5sZXNzIHZpZXdzdGF0ZS5zdGF0ZSA9PSB2aWV3c3RhdGUuU1RBVEVfTk9STUFMIGFuZCBjb252W2NvbnZfaWRdXG4gICAgICAgICMgY2xlYXIgdmFsdWUgZm9yIHVwbG9hZCBpbWFnZSBpbnB1dFxuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYXR0YWNoRmlsZScpLnZhbHVlID0gJydcbiAgICAgICAgcmV0dXJuXG4gICAgIyBpZiBvbmx5IG9uZSBmaWxlIGlzIHNlbGVjdGVkLCB0aGVuIGl0IHNob3dzIGFzIHByZXZpZXcgYmVmb3JlIHNlbmRpbmdcbiAgICAjICBvdGhlcndpc2UsIGl0IHdpbGwgdXBsb2FkIGFsbCBvZiB0aGVtIGltbWVkaWF0bHlcbiAgICBpZiBmaWxlcy5sZW5ndGggPT0gMVxuICAgICAgICBmaWxlID0gZmlsZXNbMF0gIyBnZXQgZmlyc3QgYW5kIG9ubHkgZmlsZVxuICAgICAgICBlbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQgJ3ByZXZpZXctaW1nJ1xuICAgICAgICAjIHNob3cgZXJyb3IgbWVzc2FnZSBhbmQgcmV0dXJuIGlmIGlzIG5vdCBhbiBpbWFnZVxuICAgICAgICBpZiBpc0ltZyBmaWxlLnBhdGhcbiAgICAgICAgICAgICMgc3RvcmUgaW1hZ2UgaW4gcHJldmlldy1jb250YWluZXIgYW5kIG9wZW4gaXRcbiAgICAgICAgICAgICMgIEkgdGhpbmsgaXQgaXMgYmV0dGVyIHRvIGVtYmVkIHRoYW4gcmVmZXJlbmNlIHBhdGggYXMgdXNlciBzaG91bGRcbiAgICAgICAgICAgICMgICBzZWUgZXhhY3RseSB3aGF0IGhlIGlzIHNlbmRpbmcuICh1c2luZyB0aGUgcGF0aCB3b3VsZCByZXF1aXJlXG4gICAgICAgICAgICAjICAgcG9sbGluZylcbiAgICAgICAgICAgIGZzLnJlYWRGaWxlIGZpbGUucGF0aCwgKGVyciwgb3JpZ2luYWxfZGF0YSkgLT5cbiAgICAgICAgICAgICAgICBiaW5hcnlJbWFnZSA9IG5ldyBCdWZmZXIob3JpZ2luYWxfZGF0YSwgJ2JpbmFyeScpXG4gICAgICAgICAgICAgICAgYmFzZTY0SW1hZ2UgPSBiaW5hcnlJbWFnZS50b1N0cmluZygnYmFzZTY0JylcbiAgICAgICAgICAgICAgICBtaW1lVHlwZSA9IG1pbWUubG9va3VwIGZpbGUucGF0aFxuICAgICAgICAgICAgICAgIGVsZW1lbnQuc3JjID0gJ2RhdGE6JyArIG1pbWVUeXBlICsgJztiYXNlNjQsJyArIGJhc2U2NEltYWdlXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI3ByZXZpZXctY29udGFpbmVyJykuY2xhc3NMaXN0LmFkZCgnb3BlbicpXG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIFtfLCBleHRdID0gZmlsZS5wYXRoLm1hdGNoKC8uKihcXC5cXHcrKSQvKSA/IFtdXG4gICAgICAgICAgICBub3RyIFwiSWdub3JpbmcgZmlsZSBvZiB0eXBlICN7ZXh0fVwiXG4gICAgZWxzZVxuICAgICAgICBmb3IgZmlsZSBpbiBmaWxlc1xuICAgICAgICAgICAgIyBvbmx5IGltYWdlcyBwbGVhc2VcbiAgICAgICAgICAgIHVubGVzcyBpc0ltZyBmaWxlLnBhdGhcbiAgICAgICAgICAgICAgICBbXywgZXh0XSA9IGZpbGUucGF0aC5tYXRjaCgvLiooXFwuXFx3KykkLykgPyBbXVxuICAgICAgICAgICAgICAgIG5vdHIgXCJJZ25vcmluZyBmaWxlIG9mIHR5cGUgI3tleHR9XCJcbiAgICAgICAgICAgICAgICBjb250aW51ZVxuICAgICAgICAgICAgIyBtZXNzYWdlIGZvciBhIHBsYWNlaG9sZGVyXG4gICAgICAgICAgICBtc2cgPSB1c2VyaW5wdXQuYnVpbGRDaGF0TWVzc2FnZSBlbnRpdHkuc2VsZiwgJ3VwbG9hZGluZyBpbWFnZeKApidcbiAgICAgICAgICAgIG1zZy51cGxvYWRpbWFnZSA9IHRydWVcbiAgICAgICAgICAgIHtjbGllbnRfZ2VuZXJhdGVkX2lkfSA9IG1zZ1xuICAgICAgICAgICAgIyBhZGQgYSBwbGFjZWhvbGRlciBmb3IgdGhlIGltYWdlXG4gICAgICAgICAgICBjb252LmFkZENoYXRNZXNzYWdlUGxhY2Vob2xkZXIgZW50aXR5LnNlbGYuaWQsIG1zZ1xuICAgICAgICAgICAgIyBhbmQgYmVnaW4gdXBsb2FkXG4gICAgICAgICAgICBpcGMuc2VuZCAndXBsb2FkaW1hZ2UnLCB7cGF0aDpmaWxlLnBhdGgsIGNvbnZfaWQsIGNsaWVudF9nZW5lcmF0ZWRfaWR9XG4gICAgIyBjbGVhciB2YWx1ZSBmb3IgdXBsb2FkIGltYWdlIGlucHV0XG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2F0dGFjaEZpbGUnKS52YWx1ZSA9ICcnXG5cbmhhbmRsZSAnb25wYXN0ZWltYWdlJywgLT5cbiAgICBlbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQgJ3ByZXZpZXctaW1nJ1xuICAgIGVsZW1lbnQuc3JjID0gY2xpcGJvYXJkLnJlYWRJbWFnZSgpLnRvRGF0YVVSTCgpXG4gICAgZWxlbWVudC5zcmMgPSBlbGVtZW50LnNyYy5yZXBsYWNlIC9pbWFnZVxcL3BuZy8sICdpbWFnZS9naWYnXG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI3ByZXZpZXctY29udGFpbmVyJykuY2xhc3NMaXN0LmFkZCgnb3BlbicpXG5cbmhhbmRsZSAndXBsb2FkcHJldmlld2ltYWdlJywgLT5cbiAgICBjb252X2lkID0gdmlld3N0YXRlLnNlbGVjdGVkQ29udlxuICAgIHJldHVybiB1bmxlc3MgY29udl9pZFxuICAgIG1zZyA9IHVzZXJpbnB1dC5idWlsZENoYXRNZXNzYWdlIGVudGl0eS5zZWxmLCAndXBsb2FkaW5nIGltYWdl4oCmJ1xuICAgIG1zZy51cGxvYWRpbWFnZSA9IHRydWVcbiAgICB7Y2xpZW50X2dlbmVyYXRlZF9pZH0gPSBtc2dcbiAgICBjb252LmFkZENoYXRNZXNzYWdlUGxhY2Vob2xkZXIgZW50aXR5LnNlbGYuaWQsIG1zZ1xuICAgICMgZmluZCBwcmV2aWV3IGVsZW1lbnRcbiAgICBlbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQgJ3ByZXZpZXctaW1nJ1xuICAgICMgYnVpbGQgaW1hZ2UgZnJvbSB3aGF0IGlzIG9uIHByZXZpZXdcbiAgICBwbmdEYXRhID0gZWxlbWVudC5zcmMucmVwbGFjZSAvZGF0YTppbWFnZVxcLyhwbmd8anBlP2d8Z2lmfHN2Zyk7YmFzZTY0LC8sICcnXG4gICAgcG5nRGF0YSA9IG5ldyBCdWZmZXIocG5nRGF0YSwgJ2Jhc2U2NCcpXG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI3ByZXZpZXctY29udGFpbmVyJykuY2xhc3NMaXN0LnJlbW92ZSgnb3BlbicpXG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2Vtb2ppLWNvbnRhaW5lcicpLmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKVxuICAgIGVsZW1lbnQuc3JjID0gJydcbiAgICAjXG4gICAgaXBjLnNlbmQgJ3VwbG9hZGNsaXBib2FyZGltYWdlJywge3BuZ0RhdGEsIGNvbnZfaWQsIGNsaWVudF9nZW5lcmF0ZWRfaWR9XG5cbmhhbmRsZSAndXBsb2FkaW5naW1hZ2UnLCAoc3BlYykgLT5cbiAgICAjIFhYWCB0aGlzIGRvZXNuJ3QgbG9vayB2ZXJ5IGdvb2QgYmVjYXVzZSB0aGUgaW1hZ2VcbiAgICAjIHNob3dzLCB0aGVuIGZsaWNrZXJzIGF3YXkgYmVmb3JlIHRoZSByZWFsIGlzIGxvYWRlZFxuICAgICMgZnJvbSB0aGUgdXBsb2FkLlxuICAgICNjb252LnVwZGF0ZVBsYWNlaG9sZGVySW1hZ2Ugc3BlY1xuXG5oYW5kbGUgJ2xlZnRyZXNpemUnLCAoc2l6ZSkgLT4gdmlld3N0YXRlLnNldExlZnRTaXplIHNpemVcbmhhbmRsZSAncmVzaXplJywgKGRpbSkgLT4gdmlld3N0YXRlLnNldFNpemUgZGltXG5oYW5kbGUgJ21vdmUnLCAocG9zKSAtPiB2aWV3c3RhdGUuc2V0UG9zaXRpb24gcG9zXG5cbmhhbmRsZSAnY29udmVyc2F0aW9ubmFtZScsIChuYW1lKSAtPlxuICAgIGNvbnZzZXR0aW5ncy5zZXROYW1lIG5hbWVcbmhhbmRsZSAnY29udmVyc2F0aW9ucXVlcnknLCAocXVlcnkpIC0+XG4gICAgY29udnNldHRpbmdzLnNldFNlYXJjaFF1ZXJ5IHF1ZXJ5XG5oYW5kbGUgJ3NlYXJjaGVudGl0aWVzJywgKHF1ZXJ5LCBtYXhfcmVzdWx0cykgLT5cbiAgICBpcGMuc2VuZCAnc2VhcmNoZW50aXRpZXMnLCBxdWVyeSwgbWF4X3Jlc3VsdHNcbmhhbmRsZSAnc2V0c2VhcmNoZWRlbnRpdGllcycsIChyKSAtPlxuICAgIGNvbnZzZXR0aW5ncy5zZXRTZWFyY2hlZEVudGl0aWVzIHJcbmhhbmRsZSAnc2VsZWN0ZW50aXR5JywgKGUpIC0+IGNvbnZzZXR0aW5ncy5hZGRTZWxlY3RlZEVudGl0eSBlXG5oYW5kbGUgJ2Rlc2VsZWN0ZW50aXR5JywgKGUpIC0+IGNvbnZzZXR0aW5ncy5yZW1vdmVTZWxlY3RlZEVudGl0eSBlXG5oYW5kbGUgJ3RvZ2dsZWdyb3VwJywgKGUpIC0+IGNvbnZzZXR0aW5ncy5zZXRHcm91cCghY29udnNldHRpbmdzLmdyb3VwKVxuXG5oYW5kbGUgJ3NhdmVjb252ZXJzYXRpb24nLCAtPlxuICAgIHZpZXdzdGF0ZS5zZXRTdGF0ZSB2aWV3c3RhdGUuU1RBVEVfTk9STUFMXG4gICAgY29udl9pZCA9IGNvbnZzZXR0aW5ncy5pZFxuICAgIGMgPSBjb252W2NvbnZfaWRdXG4gICAgb25lX3RvX29uZSA9IGM/LnR5cGU/LmluZGV4T2YoJ09ORV9UT19PTkUnKSA+PSAwXG4gICAgc2VsZWN0ZWQgPSAoZS5pZC5jaGF0X2lkIGZvciBlIGluIGNvbnZzZXR0aW5ncy5zZWxlY3RlZEVudGl0aWVzKVxuICAgIHJlY3JlYXRlID0gY29udl9pZCBhbmQgb25lX3RvX29uZSBhbmQgY29udnNldHRpbmdzLmdyb3VwXG4gICAgbmVlZHNSZW5hbWUgPSBjb252c2V0dGluZ3MuZ3JvdXAgYW5kIGNvbnZzZXR0aW5ncy5uYW1lIGFuZCBjb252c2V0dGluZ3MubmFtZSAhPSBjPy5uYW1lXG4gICAgIyByZW1lbWJlcjogd2UgZG9uJ3QgcmVuYW1lIG9uZV90b19vbmVzLCBnb29nbGUgd2ViIGNsaWVudCBkb2VzIG5vdCBkbyBpdFxuICAgIGlmIG5vdCBjb252X2lkIG9yIHJlY3JlYXRlXG4gICAgICAgIG5hbWUgPSAoY29udnNldHRpbmdzLm5hbWUgaWYgY29udnNldHRpbmdzLmdyb3VwKSBvciBcIlwiXG4gICAgICAgIGlwYy5zZW5kICdjcmVhdGVjb252ZXJzYXRpb24nLCBzZWxlY3RlZCwgbmFtZSwgY29udnNldHRpbmdzLmdyb3VwXG4gICAgICAgIHJldHVyblxuICAgIHAgPSBjLnBhcnRpY2lwYW50X2RhdGFcbiAgICBjdXJyZW50ID0gKGMuaWQuY2hhdF9pZCBmb3IgYyBpbiBwIHdoZW4gbm90IGVudGl0eS5pc1NlbGYgYy5pZC5jaGF0X2lkKVxuICAgIHRvYWRkID0gKGlkIGZvciBpZCBpbiBzZWxlY3RlZCB3aGVuIGlkIG5vdCBpbiBjdXJyZW50KVxuICAgIGlwYy5zZW5kICdhZGR1c2VyJywgY29udl9pZCwgdG9hZGQgaWYgdG9hZGQubGVuZ3RoXG4gICAgaXBjLnNlbmQgJ3JlbmFtZWNvbnZlcnNhdGlvbicsIGNvbnZfaWQsIGNvbnZzZXR0aW5ncy5uYW1lIGlmIG5lZWRzUmVuYW1lXG5cbmhhbmRsZSAnY29udmVyc2F0aW9uX3JlbmFtZScsIChjKSAtPlxuICAgIGNvbnYucmVuYW1lIGMsIGMuY29udmVyc2F0aW9uX3JlbmFtZS5uZXdfbmFtZVxuICAgIGNvbnYuYWRkQ2hhdE1lc3NhZ2UgY1xuXG5oYW5kbGUgJ21lbWJlcnNoaXBfY2hhbmdlJywgKGUpIC0+XG4gICAgY29udl9pZCA9IGUuY29udmVyc2F0aW9uX2lkLmlkXG4gICAgaWRzID0gKGlkLmNoYXRfaWQgb3IgaWQuZ2FpYV9pZCBmb3IgaWQgaW4gZS5tZW1iZXJzaGlwX2NoYW5nZS5wYXJ0aWNpcGFudF9pZHMpXG4gICAgaWYgZS5tZW1iZXJzaGlwX2NoYW5nZS50eXBlID09ICdMRUFWRSdcbiAgICAgICAgaWYgZW50aXR5LnNlbGYuaWQgaW4gaWRzXG4gICAgICAgICAgICByZXR1cm4gY29udi5kZWxldGVDb252IGNvbnZfaWRcbiAgICAgICAgcmV0dXJuIGNvbnYucmVtb3ZlUGFydGljaXBhbnRzIGNvbnZfaWQsIGlkc1xuICAgIGNvbnYuYWRkQ2hhdE1lc3NhZ2UgZVxuICAgIGlwYy5zZW5kICdnZXRlbnRpdHknLCBpZHMsIHthZGRfdG9fY29udjogY29udl9pZH1cblxuaGFuZGxlICdjcmVhdGVjb252ZXJzYXRpb25kb25lJywgKGMpIC0+XG4gICAgY29udnNldHRpbmdzLnJlc2V0KClcbiAgICBjb252LmFkZCBjXG4gICAgdmlld3N0YXRlLnNldFNlbGVjdGVkQ29udiBjLmlkLmlkXG5cbmhhbmRsZSAnbm90aWZpY2F0aW9uX2xldmVsJywgKG4pIC0+XG4gICAgY29udl9pZCA9IG4/WzBdP1swXVxuICAgIGxldmVsID0gaWYgbj9bMV0gPT0gMTAgdGhlbiAnUVVJRVQnIGVsc2UgJ1JJTkcnXG4gICAgY29udi5zZXROb3RpZmljYXRpb25MZXZlbCBjb252X2lkLCBsZXZlbCBpZiBjb252X2lkIGFuZCBsZXZlbFxuXG5oYW5kbGUgJ3RvZ2dsZW5vdGlmJywgLT5cbiAgICB7UVVJRVQsIFJJTkd9ID0gQ2xpZW50Lk5vdGlmaWNhdGlvbkxldmVsXG4gICAgY29udl9pZCA9IHZpZXdzdGF0ZS5zZWxlY3RlZENvbnZcbiAgICByZXR1cm4gdW5sZXNzIGMgPSBjb252W2NvbnZfaWRdXG4gICAgcSA9IGNvbnYuaXNRdWlldChjKVxuICAgIGlwYy5zZW5kICdzZXRjb252ZXJzYXRpb25ub3RpZmljYXRpb25sZXZlbCcsIGNvbnZfaWQsIChpZiBxIHRoZW4gUklORyBlbHNlIFFVSUVUKVxuICAgIGNvbnYuc2V0Tm90aWZpY2F0aW9uTGV2ZWwgY29udl9pZCwgKGlmIHEgdGhlbiAnUklORycgZWxzZSAnUVVJRVQnKVxuXG5oYW5kbGUgJ3RvZ2dsZXN0YXInLCAtPlxuICAgIGNvbnZfaWQgPSB2aWV3c3RhdGUuc2VsZWN0ZWRDb252XG4gICAgcmV0dXJuIHVubGVzcyBjID0gY29udltjb252X2lkXVxuICAgIGNvbnYudG9nZ2xlU3RhcihjKVxuXG5oYW5kbGUgJ2RlbGV0ZScsIChhKSAtPlxuICAgIGNvbnZfaWQgPSBhP1swXT9bMF1cbiAgICByZXR1cm4gdW5sZXNzIGMgPSBjb252W2NvbnZfaWRdXG4gICAgY29udi5kZWxldGVDb252IGNvbnZfaWRcblxuI1xuI1xuIyBDaGFuZ2UgbGFuZ3VhZ2UgaW4gWWFrWWFrXG4jXG5oYW5kbGUgJ2NoYW5nZWxhbmd1YWdlJywgKGxhbmd1YWdlKSAtPlxuICAgIGlmIGkxOG4uZ2V0TG9jYWxlcygpLmluY2x1ZGVzIHZpZXdzdGF0ZS5sYW5ndWFnZVxuICAgICAgICBpcGMuc2VuZCAnc2V0aTE4bicsIG51bGwsIGxhbmd1YWdlXG4gICAgICAgIHZpZXdzdGF0ZS5zZXRMYW5ndWFnZShsYW5ndWFnZSlcblxuaGFuZGxlICdkZWxldGVjb252JywgKGNvbmZpcm1lZCkgLT5cbiAgICBjb252X2lkID0gdmlld3N0YXRlLnNlbGVjdGVkQ29udlxuICAgIHVubGVzcyBjb25maXJtZWRcbiAgICAgICAgbGF0ZXIgLT4gaWYgY29uZmlybSBpMThuLl9fKCdjb252ZXJzYXRpb24uZGVsZXRlX2NvbmZpcm06UmVhbGx5IGRlbGV0ZSBjb252ZXJzYXRpb24/JylcbiAgICAgICAgICAgIGFjdGlvbiAnZGVsZXRlY29udicsIHRydWVcbiAgICBlbHNlXG4gICAgICAgIGlwYy5zZW5kICdkZWxldGVjb252ZXJzYXRpb24nLCBjb252X2lkXG4gICAgICAgIHZpZXdzdGF0ZS5zZWxlY3RDb252SW5kZXgoMClcbiAgICAgICAgdmlld3N0YXRlLnNldFN0YXRlKHZpZXdzdGF0ZS5TVEFURV9OT1JNQUwpXG5cbmhhbmRsZSAnbGVhdmVjb252JywgKGNvbmZpcm1lZCkgLT5cbiAgICBjb252X2lkID0gdmlld3N0YXRlLnNlbGVjdGVkQ29udlxuICAgIHVubGVzcyBjb25maXJtZWRcbiAgICAgICAgbGF0ZXIgLT4gaWYgY29uZmlybSBpMThuLl9fKCdjb252ZXJzYXRpb24ubGVhdmVfY29uZmlybTpSZWFsbHkgbGVhdmUgY29udmVyc2F0aW9uPycpXG4gICAgICAgICAgICBhY3Rpb24gJ2xlYXZlY29udicsIHRydWVcbiAgICBlbHNlXG4gICAgICAgIGlwYy5zZW5kICdyZW1vdmV1c2VyJywgY29udl9pZFxuICAgICAgICB2aWV3c3RhdGUuc2VsZWN0Q29udkluZGV4KDApXG4gICAgICAgIHZpZXdzdGF0ZS5zZXRTdGF0ZSh2aWV3c3RhdGUuU1RBVEVfTk9STUFMKVxuXG5oYW5kbGUgJ2xhc3RrZXlkb3duJywgKHRpbWUpIC0+IHZpZXdzdGF0ZS5zZXRMYXN0S2V5RG93biB0aW1lXG5oYW5kbGUgJ3NldHR5cGluZycsICh2KSAtPlxuICAgIGNvbnZfaWQgPSB2aWV3c3RhdGUuc2VsZWN0ZWRDb252XG4gICAgcmV0dXJuIHVubGVzcyBjb252X2lkIGFuZCB2aWV3c3RhdGUuc3RhdGUgPT0gdmlld3N0YXRlLlNUQVRFX05PUk1BTFxuICAgIGlwYy5zZW5kICdzZXR0eXBpbmcnLCBjb252X2lkLCB2XG4gICAgdmlld3N0YXRlLnNldFN0YXRlKHZpZXdzdGF0ZS5TVEFURV9OT1JNQUwpXG5cbmhhbmRsZSAndHlwaW5nJywgKHQpIC0+XG4gICAgY29udi5hZGRUeXBpbmcgdFxuaGFuZGxlICdwcnVuZVR5cGluZycsIChjb252X2lkKSAtPlxuICAgIGNvbnYucHJ1bmVUeXBpbmcgY29udl9pZFxuXG5oYW5kbGUgJ3N5bmNhbGxuZXdldmVudHMnLCB0aHJvdHRsZSAxMDAwMCwgKHRpbWUpIC0+XG4gICAgcmV0dXJuIHVubGVzcyB0aW1lXG4gICAgaXBjLnNlbmQgJ3N5bmNhbGxuZXdldmVudHMnLCB0aW1lXG5cbmhhbmRsZSAnaGFuZGxlc3luY2VkZXZlbnRzJywgKHIpIC0+XG4gICAgc3RhdGVzID0gcj8uY29udmVyc2F0aW9uX3N0YXRlXG4gICAgcmV0dXJuIHVubGVzcyBzdGF0ZXM/Lmxlbmd0aFxuICAgIGZvciBzdCBpbiBzdGF0ZXNcbiAgICAgICAgZm9yIGUgaW4gKHN0Py5ldmVudCA/IFtdKVxuICAgICAgICAgICAgY29udi5hZGRDaGF0TWVzc2FnZSBlXG4gICAgY29ubmVjdGlvbi5zZXRFdmVudFN0YXRlIGNvbm5lY3Rpb24uSU5fU1lOQ1xuXG5oYW5kbGUgJ3N5bmNyZWNlbnRjb252ZXJzYXRpb25zJywgdGhyb3R0bGUgMTAwMDAsIC0+XG4gICAgaXBjLnNlbmQgJ3N5bmNyZWNlbnRjb252ZXJzYXRpb25zJ1xuXG5oYW5kbGUgJ2hhbmRsZXJlY2VudGNvbnZlcnNhdGlvbnMnLCAocikgLT5cbiAgICByZXR1cm4gdW5sZXNzIHN0ID0gci5jb252ZXJzYXRpb25fc3RhdGVcbiAgICBjb252LnJlcGxhY2VGcm9tU3RhdGVzIHN0XG4gICAgY29ubmVjdGlvbi5zZXRFdmVudFN0YXRlIGNvbm5lY3Rpb24uSU5fU1lOQ1xuXG5oYW5kbGUgJ2NsaWVudF9jb252ZXJzYXRpb24nLCAoYykgLT5cbiAgICAjIENvbnZlcnNhdGlvbiBtdXN0IGJlIGFkZGVkLCBldmVuIGlmIGFscmVhZHkgZXhpc3RzXG4gICAgIyAgd2h5PyBiZWNhdXNlIHdoZW4gYSBuZXcgY2hhdCBtZXNzYWdlIGZvciBhIG5ldyBjb252ZXJzYXRpb24gYXBwZWFyc1xuICAgICMgIGEgc2tlbGV0b24gaXMgbWFkZSBvZiBhIGNvbnZlcnNhdGlvblxuICAgIGNvbnYuYWRkIGMgdW5sZXNzIGNvbnZbYz8uY29udmVyc2F0aW9uX2lkPy5pZF0/LnBhcnRpY2lwYW50X2RhdGE/XG5cbmhhbmRsZSAnaGFuZ291dF9ldmVudCcsIChlKSAtPlxuICAgIHJldHVybiB1bmxlc3MgZT8uaGFuZ291dF9ldmVudD8uZXZlbnRfdHlwZSBpbiBbJ1NUQVJUX0hBTkdPVVQnLCAnRU5EX0hBTkdPVVQnXVxuICAgICMgdHJpZ2dlciBub3RpZmljYXRpb25zIGZvciB0aGlzXG4gICAgbm90aWZ5LmFkZFRvTm90aWZ5IGVcblxuJ3JlcGx5X3RvX2ludml0ZSBzZXR0aW5ncyBjb252ZXJzYXRpb25fbm90aWZpY2F0aW9uIGludml0YXRpb25fd2F0ZXJtYXJrJy5zcGxpdCgnICcpLmZvckVhY2ggKG4pIC0+XG4gICAgaGFuZGxlIG4sIChhcy4uLikgLT4gY29uc29sZS5sb2cgbiwgYXMuLi5cblxuaGFuZGxlICd1bnJlYWR0b3RhbCcsICh0b3RhbCwgb3JNb3JlKSAtPlxuICAgIHZhbHVlID0gXCJcIlxuICAgIGlmIHRvdGFsID4gMCB0aGVuIHZhbHVlID0gdG90YWwgKyAoaWYgb3JNb3JlIHRoZW4gXCIrXCIgZWxzZSBcIlwiKVxuICAgIHVwZGF0ZWQgJ2NvbnZfY291bnQnXG4gICAgaXBjLnNlbmQgJ3VwZGF0ZWJhZGdlJywgdmFsdWVcblxuaGFuZGxlICdzaG93Y29udm1pbicsIChkb3Nob3cpIC0+XG4gICAgdmlld3N0YXRlLnNldFNob3dDb252TWluIGRvc2hvd1xuXG5oYW5kbGUgJ3NldHVzZXN5c3RlbWRhdGVmb3JtYXQnLCAodmFsKSAtPlxuXG4gICAgdmlld3N0YXRlLnNldFVzZVN5c3RlbURhdGVGb3JtYXQodmFsKVxuXG5oYW5kbGUgJ3Nob3djb252dGh1bWJzJywgKGRvc2hvdykgLT5cbiAgICB2aWV3c3RhdGUuc2V0U2hvd0NvbnZUaHVtYnMgZG9zaG93XG5cbmhhbmRsZSAnc2hvd2FuaW1hdGVkdGh1bWJzJywgKGRvc2hvdykgLT5cbiAgICB2aWV3c3RhdGUuc2V0U2hvd0FuaW1hdGVkVGh1bWJzIGRvc2hvd1xuXG5oYW5kbGUgJ3Nob3djb252dGltZScsIChkb3Nob3cpIC0+XG4gICAgdmlld3N0YXRlLnNldFNob3dDb252VGltZSBkb3Nob3dcblxuaGFuZGxlICdzaG93Y29udmxhc3QnLCAoZG9zaG93KSAtPlxuICAgIHZpZXdzdGF0ZS5zZXRTaG93Q29udkxhc3QgZG9zaG93XG5cbmhhbmRsZSAnc2hvd3BvcHVwbm90aWZpY2F0aW9ucycsIChkb3Nob3cpIC0+XG4gICAgdmlld3N0YXRlLnNldFNob3dQb3BVcE5vdGlmaWNhdGlvbnMgZG9zaG93XG5cbmhhbmRsZSAnc2hvd21lc3NhZ2Vpbm5vdGlmaWNhdGlvbicsIChkb3Nob3cpIC0+XG4gICAgdmlld3N0YXRlLnNldFNob3dNZXNzYWdlSW5Ob3RpZmljYXRpb24gZG9zaG93XG5cbmhhbmRsZSAnc2hvd3VzZXJuYW1laW5ub3RpZmljYXRpb24nLCAoZG9zaG93KSAtPlxuICAgIHZpZXdzdGF0ZS5zZXRTaG93VXNlcm5hbWVJbk5vdGlmaWNhdGlvbiBkb3Nob3dcblxuaGFuZGxlICdjb252ZXJ0ZW1vamknLCAoZG9zaG93KSAtPlxuICAgIHZpZXdzdGF0ZS5zZXRDb252ZXJ0RW1vamkgZG9zaG93XG5cbmhhbmRsZSAnc3VnZ2VzdGVtb2ppJywgKGRvc2hvdykgLT5cbiAgICB2aWV3c3RhdGUuc2V0U3VnZ2VzdEVtb2ppIGRvc2hvd1xuXG5oYW5kbGUgJ2NoYW5nZXRoZW1lJywgKGNvbG9yc2NoZW1lKSAtPlxuICAgIHZpZXdzdGF0ZS5zZXRDb2xvclNjaGVtZSBjb2xvcnNjaGVtZVxuXG5oYW5kbGUgJ2NoYW5nZWZvbnRzaXplJywgKGZvbnRzaXplKSAtPlxuICAgIHZpZXdzdGF0ZS5zZXRGb250U2l6ZSBmb250c2l6ZVxuXG5oYW5kbGUgJ2RldnRvb2xzJywgLT5cbiAgICByZW1vdGUuZ2V0Q3VycmVudFdpbmRvdygpLm9wZW5EZXZUb29scyBkZXRhY2g6dHJ1ZVxuXG5oYW5kbGUgJ3F1aXQnLCAtPlxuICAgIGlwYy5zZW5kICdxdWl0J1xuXG5oYW5kbGUgJ3RvZ2dsZWZ1bGxzY3JlZW4nLCAtPlxuICAgIGlwYy5zZW5kICd0b2dnbGVmdWxsc2NyZWVuJ1xuXG5oYW5kbGUgJ3pvb20nLCAoc3RlcCkgLT5cbiAgICBpZiBzdGVwP1xuICAgICAgICByZXR1cm4gdmlld3N0YXRlLnNldFpvb20gKHBhcnNlRmxvYXQoZG9jdW1lbnQuYm9keS5zdHlsZS56b29tLnJlcGxhY2UoJywnLCAnLicpKSBvciAxLjApICsgc3RlcFxuICAgIHZpZXdzdGF0ZS5zZXRab29tIDFcblxuaGFuZGxlICdsb2dvdXQnLCAtPlxuICAgIGlwYy5zZW5kICdsb2dvdXQnXG5cbmhhbmRsZSAnd29ubGluZScsICh3b25saW5lKSAtPlxuICAgIGNvbm5lY3Rpb24uc2V0V2luZG93T25saW5lIHdvbmxpbmVcbiAgICBpZiB3b25saW5lXG4gICAgICAgIGlwYy5zZW5kICdoYW5ndXBzQ29ubmVjdCdcbiAgICBlbHNlXG4gICAgICAgIGlwYy5zZW5kICdoYW5ndXBzRGlzY29ubmVjdCdcblxuaGFuZGxlICdvcGVub25zeXN0ZW1zdGFydHVwJywgKG9wZW4pIC0+XG4gICAgdmlld3N0YXRlLnNldE9wZW5PblN5c3RlbVN0YXJ0dXAgb3BlblxuXG5oYW5kbGUgJ2luaXRvcGVub25zeXN0ZW1zdGFydHVwJywgKGlzRW5hYmxlZCkgLT5cbiAgICB2aWV3c3RhdGUuaW5pdE9wZW5PblN5c3RlbVN0YXJ0dXAgaXNFbmFibGVkXG5cbmhhbmRsZSAnbWluaW1pemUnLCAtPlxuICAgIG1haW5XaW5kb3cgPSByZW1vdGUuZ2V0Q3VycmVudFdpbmRvdygpXG4gICAgbWFpbldpbmRvdy5taW5pbWl6ZSgpXG5cbmhhbmRsZSAncmVzaXpld2luZG93JywgLT5cbiAgICBtYWluV2luZG93ID0gcmVtb3RlLmdldEN1cnJlbnRXaW5kb3coKVxuICAgIGlmIG1haW5XaW5kb3cuaXNNYXhpbWl6ZWQoKSB0aGVuIG1haW5XaW5kb3cudW5tYXhpbWl6ZSgpIGVsc2UgbWFpbldpbmRvdy5tYXhpbWl6ZSgpXG5cbmhhbmRsZSAnY2xvc2UnLCAtPlxuICAgIG1haW5XaW5kb3cgPSByZW1vdGUuZ2V0Q3VycmVudFdpbmRvdygpXG4gICAgbWFpbldpbmRvdy5jbG9zZSgpXG4iXX0=
