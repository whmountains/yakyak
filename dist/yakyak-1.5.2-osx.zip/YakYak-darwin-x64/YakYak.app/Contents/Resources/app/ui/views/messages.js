(function() {
  var CUTOFF, HANGOUT_ANNOTATION_TYPE, MESSAGE_CLASSES, OBSERVE_OPTS, atTopIfSmall, drawAvatar, drawMeMessage, drawMessage, drawMessageAvatar, drawSeenAvatar, extractObjectStyle, extractProtobufStyle, firstRender, fixProxied, fixlink, forceredraw, format, formatAttachment, formatters, getImageUrl, getProxiedName, groupEvents, groupEventsByMessageType, ifpass, initialsof, isImg, isMeMessage, lastConv, later, linkto, moment, nameof, nameofconv, onMutate, onclick, preload, preloadInstagramPhoto, preloadTweet, preload_cache, scrollToBottom, shell, stripProxiedColon, throttle, url, urlRegexp;

  moment = require('moment');

  shell = require('electron').shell;

  urlRegexp = require('uber-url-regex');

  url = require('url');

  ({nameof, initialsof, nameofconv, linkto, later, forceredraw, throttle, getProxiedName, fixlink, isImg, getImageUrl, drawAvatar} = require('../util'));

  CUTOFF = 5 * 60 * 1000 * 1000; // 5 mins

  
  // chat_message:
  //   {
  //     annotation: [
  //       [4, ""]
  //     ]
  //     message_content: {
  //       attachement: []
  //       segment: [{ ... }]
  //     }
  //   }
  HANGOUT_ANNOTATION_TYPE = {
    me_message: 4
  };

  // this helps fixing houts proxied with things like hangupsbot
  // the format of proxied messages are
  // and here we put entities in the entity db for
  // users found only in proxied messages.
  fixProxied = function(e, proxied, entity) {
    var name, ref, ref1, ref2, ref3;
    if ((e != null ? (ref = e.chat_message) != null ? ref.message_content : void 0 : void 0) == null) {
      return;
    }
    e.chat_message.message_content.proxied = true;
    name = e != null ? (ref1 = e.chat_message) != null ? (ref2 = ref1.message_content) != null ? (ref3 = ref2.segment[0]) != null ? ref3.text : void 0 : void 0 : void 0 : void 0;
    // update fallback_name for entity database
    if (name !== '>>') {
      // synthetic add of fallback_name
      return entity.add({
        id: {
          gaia_id: proxied,
          chat_id: proxied
        },
        fallback_name: name
      }, {
        silent: true
      });
    }
  };

  onclick = function(e) {
    var address, finalUrl, patt, xhr;
    e.preventDefault();
    address = e.currentTarget.getAttribute('href');
    patt = new RegExp("^(https?[:][/][/]www[.]google[.](com|[a-z][a-z])[/]url[?]q[=])([^&]+)(&.+)*");
    if (patt.test(address)) {
      address = address.replace(patt, '$3');
      address = unescape(address);
      // this is a link outside google and can be opened directly
      //  as there is no need for authentication
      shell.openExternal(fixlink(address));
      return;
    }
    if (urlRegexp({
      exact: true
    }).test(address)) {
      if (url.parse(address).host == null) {
        address = `http://${address}`;
      }
    }
    finalUrl = fixlink(address);
    // Google apis give us an url that is only valid for the current logged user.
    // We can't open this url in the external browser because it may not be authenticated
    // or may be authenticated differently (another user or multiple users).
    // In this case we try to open the url ourselves until we get redirected to the final url
    // of the image/video.
    // The finalURL will be cdn-hosted, static and does not require authentication
    // so we can finally open it in the external browser :(
    xhr = new XMLHttpRequest;
    // Showing message with 3 second delay showing the user that something is happening
    notr({
      html: i18n.__('menu.help.about.title:Opening the link in the browser...'),
      stay: 3000
    });
    xhr.onreadystatechange = function(e) {
      var redirected;
      if (e.target.status === 0) {
        return;
      }
      if (xhr.readyState !== 4) {
        return;
      }
      redirected = finalUrl.indexOf(xhr.responseURL) !== 0;
      if (redirected) {
        finalUrl = xhr.responseURL;
      }
      shell.openExternal(finalUrl);
      return xhr.abort();
    };
    xhr.open("get", finalUrl);
    return xhr.send();
  };

  // helper method to group events in time/user bunches
  groupEvents = function(es, entity) {
    var cid, e, group, groups, j, len, proxied, ref, ref1, user;
    groups = [];
    group = null;
    user = null;
    for (j = 0, len = es.length; j < len; j++) {
      e = es[j];
      if (e.timestamp - ((ref = group != null ? group.end : void 0) != null ? ref : 0) > CUTOFF) {
        group = {
          byuser: [],
          start: e.timestamp,
          end: e.timestamp
        };
        user = null;
        groups.push(group);
      }
      proxied = getProxiedName(e);
      if (proxied) {
        fixProxied(e, proxied, entity);
      }
      cid = proxied ? proxied : e != null ? (ref1 = e.sender_id) != null ? ref1.chat_id : void 0 : void 0;
      if (cid !== (user != null ? user.cid : void 0)) {
        group.byuser.push(user = {
          cid: cid,
          event: []
        });
      }
      user.event.push(e);
      group.end = e.timestamp;
    }
    return groups;
  };

  // possible classes of messages
  MESSAGE_CLASSES = ['placeholder', 'chat_message', 'conversation_rename', 'membership_change'];

  OBSERVE_OPTS = {
    childList: true,
    attributes: true,
    attributeOldValue: true,
    subtree: true
  };

  firstRender = true;

  lastConv = null; // to detect conv switching

  module.exports = view(function(models) {
    var all_seen, c, conv, conv_id, entity, j, l, len, len1, participant, ref, ref1, viewstate;
    ({viewstate, conv, entity} = models);
    if (firstRender) {
      // mutation events kicks in after first render
      later(onMutate(viewstate));
    }
    firstRender = false;
    conv_id = viewstate != null ? viewstate.selectedConv : void 0;
    c = conv[conv_id];
    if ((c != null ? c.current_participant : void 0) != null) {
      ref = c.current_participant;
      for (j = 0, len = ref.length; j < len; j++) {
        participant = ref[j];
        entity.needEntity(participant.chat_id);
      }
    }
    div({
      class: 'messages',
      observe: onMutate(viewstate)
    }, function() {
      var clz, events, g, grouped, l, last_seen, last_seen_chat_ids_with_event, len1, results, sender, u;
      if (!(c != null ? c.event : void 0)) {
        return;
      }
      grouped = groupEvents(c.event, entity);
      div({
        class: 'historyinfo'
      }, function() {
        if (c.requestinghistory) {
          return pass('Requesting history…', function() {
            return span({
              class: 'material-icons spin'
            }, 'donut_large');
          });
        }
      });
      if (!viewstate.useSystemDateFormat) {
        moment.locale(i18n.getLocale());
      } else {
        moment.locale(window.navigator.language);
      }
      last_seen = conv.findLastReadEventsByUser(c);
      last_seen_chat_ids_with_event = function(last_seen, event) {
        var chat_id, e, results;
        results = [];
        for (chat_id in last_seen) {
          e = last_seen[chat_id];
          if (event === e) {
            results.push(chat_id);
          }
        }
        return results;
      };
      results = [];
      for (l = 0, len1 = grouped.length; l < len1; l++) {
        g = grouped[l];
        div({
          class: 'timestamp'
        }, moment(g.start / 1000).calendar());
        results.push((function() {
          var len2, m, ref1, results1;
          ref1 = g.byuser;
          results1 = [];
          for (m = 0, len2 = ref1.length; m < len2; m++) {
            u = ref1[m];
            sender = nameof(entity[u.cid]);
            results1.push((function() {
              var len3, n, ref2, results2;
              ref2 = groupEventsByMessageType(u.event);
              results2 = [];
              for (n = 0, len3 = ref2.length; n < len3; n++) {
                events = ref2[n];
                if (isMeMessage(events[0])) {
                  // all items are /me messages if the first one is due to grouping above
                  results2.push(div({
                    class: 'ugroup me'
                  }, function() {
                    var e, len4, o, results3;
                    drawMessageAvatar(u, sender, viewstate, entity);
                    results3 = [];
                    for (o = 0, len4 = events.length; o < len4; o++) {
                      e = events[o];
                      results3.push(drawMeMessage(e));
                    }
                    return results3;
                  }));
                } else {
                  clz = ['ugroup'];
                  if (entity.isSelf(u.cid)) {
                    clz.push('self');
                  }
                  results2.push(div({
                    class: clz.join(' ')
                  }, function() {
                    drawMessageAvatar(u, sender, viewstate, entity);
                    div({
                      class: 'umessages'
                    }, function() {
                      var e, len4, o, results3;
                      results3 = [];
                      for (o = 0, len4 = events.length; o < len4; o++) {
                        e = events[o];
                        results3.push(drawMessage(e, entity));
                      }
                      return results3;
                    });
                    // at the end of the events group we draw who has read any of its events
                    return div({
                      class: 'seen-list'
                    }, function() {
                      var chat_id, e, len4, o, results3, skip;
                      results3 = [];
                      for (o = 0, len4 = events.length; o < len4; o++) {
                        e = events[o];
                        results3.push((function() {
                          var len5, q, ref3, results4;
                          ref3 = last_seen_chat_ids_with_event(last_seen, e);
                          results4 = [];
                          for (q = 0, len5 = ref3.length; q < len5; q++) {
                            chat_id = ref3[q];
                            skip = entity.isSelf(chat_id) || (chat_id === u.cid);
                            if (!skip) {
                              results4.push(drawSeenAvatar(entity[chat_id], e.event_id, viewstate, entity));
                            } else {
                              results4.push(void 0);
                            }
                          }
                          return results4;
                        })());
                      }
                      return results3;
                    });
                  }));
                }
              }
              return results2;
            })());
          }
          return results1;
        })());
      }
      return results;
    });
    // Go through all the participants and only show his last seen status
    if ((c != null ? c.current_participant : void 0) != null) {
      ref1 = c.current_participant;
      for (l = 0, len1 = ref1.length; l < len1; l++) {
        participant = ref1[l];
        // get all avatars
        all_seen = document.querySelectorAll(`.seen[data-id='${participant.chat_id}']`);
      }
    }
    // select last one
    //  NOT WORKING
    //if all_seen.length > 0
    //    all_seen.forEach (el) ->
    //        el.classList.remove 'show'
    //    all_seen[all_seen.length - 1].classList.add 'show'
    if (lastConv !== conv_id) {
      lastConv = conv_id;
      return later(atTopIfSmall);
    }
  });

  drawMessageAvatar = function(u, sender, viewstate, entity) {
    return div({
      class: 'sender-wrapper'
    }, function() {
      a({
        href: linkto(u.cid),
        title: sender
      }, {onclick}, {
        class: 'sender'
      }, function() {
        return drawAvatar(u.cid, viewstate, entity);
      });
      return span(sender);
    });
  };

  groupEventsByMessageType = function(event) {
    var e, index, j, len, prevWasMe, res;
    res = [];
    index = 0;
    prevWasMe = true;
    for (j = 0, len = event.length; j < len; j++) {
      e = event[j];
      if (isMeMessage(e)) {
        index = res.push([e]);
        prevWasMe = true;
      } else {
        if (prevWasMe) {
          index = res.push([e]);
        } else {
          res[index - 1].push(e);
        }
        prevWasMe = false;
      }
    }
    return res;
  };

  isMeMessage = function(e) {
    var ref, ref1, ref2;
    return (e != null ? (ref = e.chat_message) != null ? (ref1 = ref.annotation) != null ? (ref2 = ref1[0]) != null ? ref2[0] : void 0 : void 0 : void 0 : void 0) === HANGOUT_ANNOTATION_TYPE.me_message;
  };

  drawSeenAvatar = function(u, event_id, viewstate, entity) {
    var initials;
    initials = initialsof(u);
    return div({
      class: "seen",
      "data-id": u.id,
      "data-event-id": event_id,
      title: u.display_name
    }, function() {
      return drawAvatar(u.id, viewstate, entity);
    });
  };

  drawMeMessage = function(e) {
    return div({
      class: 'message'
    }, function() {
      var ref;
      return (ref = e.chat_message) != null ? ref.message_content.segment[0].text : void 0;
    });
  };

  drawMessage = function(e, entity) {
    var c, j, len, mclz, title;
    // console.log 'message', e.chat_message
    mclz = ['message'];
    for (j = 0, len = MESSAGE_CLASSES.length; j < len; j++) {
      c = MESSAGE_CLASSES[j];
      if (e[c] != null) {
        mclz.push(c);
      }
    }
    title = e.timestamp ? moment(e.timestamp / 1000).calendar() : null;
    return div({
      id: e.event_id,
      key: e.event_id,
      class: mclz.join(' '),
      title: title
    }, function() {
      var content, ents, hangout_event, names, ref, style, t;
      if (e.chat_message) {
        content = (ref = e.chat_message) != null ? ref.message_content : void 0;
        format(content);
        // loadInlineImages content
        if (e.placeholder && e.uploadimage) {
          return span({
            class: 'material-icons spin'
          }, 'donut_large');
        }
      } else if (e.conversation_rename) {
        return pass(`renamed conversation to ${e.conversation_rename.new_name}`);
      // {new_name: "labbot" old_name: ""}
      } else if (e.membership_change) {
        t = e.membership_change.type;
        ents = e.membership_change.participant_ids.map(function(p) {
          return entity[p.chat_id];
        });
        names = ents.map(nameof).join(', ');
        if (t === 'JOIN') {
          return pass(`invited ${names}`);
        } else if (t === 'LEAVE') {
          return pass(`${names} left the conversation`);
        }
      } else if (e.hangout_event) {
        hangout_event = e.hangout_event;
        style = {
          'vertical-align': 'middle'
        };
        if (hangout_event.event_type === 'START_HANGOUT') {
          span({
            class: 'material-icons',
            style
          }, 'call_made_small');
          return pass(' Call started');
        } else if (hangout_event.event_type === 'END_HANGOUT') {
          span({
            class: 'material-icons small',
            style
          }, 'call_end');
          return pass(' Call ended');
        }
      } else {
        return console.log('unhandled event type', e, entity);
      }
    });
  };

  atTopIfSmall = function() {
    var msgel, screl;
    screl = document.querySelector('.main');
    msgel = document.querySelector('.messages');
    return action('attop', (msgel != null ? msgel.offsetHeight : void 0) < (screl != null ? screl.offsetHeight : void 0));
  };

  // when there's mutation, we scroll to bottom in case we already are at bottom
  onMutate = function(viewstate) {
    return throttle(10, function() {
      if (viewstate.atbottom) {
        // jump to bottom to follow conv
        return scrollToBottom();
      }
    });
  };

  scrollToBottom = module.exports.scrollToBottom = function() {
    var el;
    // ensure we're scrolled to bottom
    el = document.querySelector('.main');
    // to bottom
    return el.scrollTop = Number.MAX_SAFE_INTEGER;
  };

  ifpass = function(t, f) {
    if (t) {
      return f;
    } else {
      return pass;
    }
  };

  format = function(cont) {
    var e, i, j, len, ref, ref1, seg;
    if ((cont != null ? cont.attachment : void 0) != null) {
      try {
        formatAttachment(cont.attachment);
      } catch (error) {
        e = error;
        console.error(e);
      }
    }
    ref1 = (ref = cont != null ? cont.segment : void 0) != null ? ref : [];
    for (i = j = 0, len = ref1.length; j < len; i = ++j) {
      seg = ref1[i];
      if (cont.proxied && i < 1) {
        continue;
      }
      formatters.forEach(function(fn) {
        return fn(seg, cont);
      });
    }
    return null;
  };

  formatters = [
    // text formatter
    function(seg,
    cont) {
      var f,
    href,
    ref,
    ref1;
      f = (ref = seg.formatting) != null ? ref : {};
      href = seg != null ? (ref1 = seg.link_data) != null ? ref1.link_target : void 0 : void 0;
      return ifpass(href,
    (function(f) {
        return a({href,
    onclick},
    f);
      }))(function() {
        return ifpass(f.bold,
    b)(function() {
          return ifpass(f.italic,
    i)(function() {
            return ifpass(f.underline,
    u)(function() {
              return ifpass(f.strikethrough,
    s)(function() {
                return pass(cont.proxied ? stripProxiedColon(seg.text) : seg.type === 'LINE_BREAK' ? '\n' : seg.text);
              });
            });
          });
        });
      });
    },
    // image formatter
    function(seg) {
      var href,
    imageUrl,
    ref;
      href = seg != null ? (ref = seg.link_data) != null ? ref.link_target : void 0 : void 0;
      imageUrl = getImageUrl(href); // false if can't find one
      if (imageUrl && preload(imageUrl)) {
        return div(function() {
          return img({
            src: imageUrl
          });
        });
      }
    },
    // twitter preview
    function(seg) {
      var data,
    href,
    matches;
      href = seg != null ? seg.text : void 0;
      if (!href) {
        return;
      }
      matches = href.match(/^(https?:\/\/)(.+\.)?(twitter.com\/.+\/status\/.+)/);
      if (!matches) {
        return;
      }
      data = preloadTweet(matches[1] + matches[3]);
      if (!data) {
        return;
      }
      return div({
        class: 'tweet'
      },
    function() {
        if (data.text) {
          p(function() {
            return data.text;
          });
        }
        if (data.imageUrl && preload(data.imageUrl)) {
          return img({
            src: data.imageUrl
          });
        }
      });
    },
    // instagram preview
    function(seg) {
      var data,
    href,
    matches;
      href = seg != null ? seg.text : void 0;
      if (!href) {
        return;
      }
      matches = href.match(/^(https?:\/\/)(.+\.)?(instagram.com\/p\/.+)/);
      if (!matches) {
        return;
      }
      data = preloadInstagramPhoto('https://api.instagram.com/oembed/?url=' + href);
      if (!data) {
        return;
      }
      return div({
        class: 'instagram'
      },
    function() {
        if (data.text) {
          p(function() {
            return data.text;
          });
        }
        if (data.imageUrl && preload(data.imageUrl)) {
          return img({
            src: data.imageUrl
          });
        }
      });
    }
  ];

  stripProxiedColon = function(txt) {
    if ((txt != null ? txt.indexOf(": ") : void 0) === 0) {
      return txt.substring(2);
    } else {
      return txt;
    }
  };

  preload_cache = {};

  preload = function(href) {
    var cache, el;
    cache = preload_cache[href];
    if (!cache) {
      el = document.createElement('img');
      el.onload = function() {
        if (typeof el.naturalWidth !== 'number') {
          return;
        }
        el.loaded = true;
        return later(function() {
          return action('loadedimg');
        });
      };
      el.onerror = function() {
        return console.log('error loading image', href);
      };
      el.src = href;
      preload_cache[href] = el;
    }
    return cache != null ? cache.loaded : void 0;
  };

  preloadTweet = function(href) {
    var cache;
    cache = preload_cache[href];
    if (!cache) {
      preload_cache[href] = {};
      fetch(href).then(function(response) {
        return response.text();
      }).then(function(html) {
        var container, frag, image, textNode;
        frag = document.createElement('div');
        frag.innerHTML = html;
        container = frag.querySelector('[data-associated-tweet-id]');
        textNode = container.querySelector('.tweet-text');
        image = container.querySelector('[data-image-url]');
        preload_cache[href].text = textNode.textContent;
        preload_cache[href].imageUrl = image != null ? image.dataset.imageUrl : void 0;
        return later(function() {
          return action('loadedtweet');
        });
      });
    }
    return cache;
  };

  preloadInstagramPhoto = function(href) {
    var cache;
    cache = preload_cache[href];
    if (!cache) {
      preload_cache[href] = {};
      fetch(href).then(function(response) {
        return response.json();
      }).then(function(json) {
        preload_cache[href].text = json.title;
        preload_cache[href].imageUrl = json.thumbnail_url;
        return later(function() {
          return action('loadedinstagramphoto');
        });
      });
    }
    return cache;
  };

  formatAttachment = function(att) {
    var data, href, original_content_url, ref, ref1, ref2, ref3, thumb;
    // console.log 'attachment', att if att.length > 0
    if (att != null ? (ref = att[0]) != null ? (ref1 = ref.embed_item) != null ? ref1.type_ : void 0 : void 0 : void 0) {
      data = extractProtobufStyle(att);
      if (!data) {
        return;
      }
      ({href, thumb, original_content_url} = data);
    } else if (att != null ? (ref2 = att[0]) != null ? (ref3 = ref2.embed_item) != null ? ref3.type : void 0 : void 0 : void 0) {
      console.log('THIS SHOULD NOT HAPPEN WTF !!');
      data = extractProtobufStyle(att);
      if (!data) {
        return;
      }
      ({href, thumb, original_content_url} = data);
    } else {
      if ((att != null ? att.length : void 0) !== 0) {
        console.warn('ignoring attachment', att);
      }
      return;
    }
    if (!href) {
      
      // stickers do not have an href so we link to the original content instead
      href = original_content_url;
    }
    
    // here we assume attachments are only images
    if (preload(thumb)) {
      return div({
        class: 'attach'
      }, function() {
        return a({href, onclick}, function() {
          return img({
            src: thumb
          });
        });
      });
    }
  };

  handle('loadedimg', function() {
    // allow controller to record current position
    updated('beforeImg');
    // will do the redraw inserting the image
    updated('conv');
    // fix the position after redraw
    return updated('afterImg');
  });

  handle('loadedtweet', function() {
    return updated('conv');
  });

  handle('loadedinstagramphoto', function() {
    return updated('conv');
  });

  extractProtobufStyle = function(att) {
    var data, embed_item, href, isVideo, k, original_content_url, plus_photo, ref, ref1, ref10, ref11, ref12, ref2, ref3, ref4, ref5, ref6, ref7, ref8, ref9, t, thumb, type_;
    href = null;
    thumb = null;
    embed_item = att != null ? (ref = att[0]) != null ? ref.embed_item : void 0 : void 0;
    ({plus_photo, data, type_} = embed_item != null ? embed_item : {});
    if (plus_photo != null) {
      href = (ref1 = plus_photo.data) != null ? ref1.url : void 0;
      thumb = (ref2 = plus_photo.data) != null ? (ref3 = ref2.thumbnail) != null ? ref3.image_url : void 0 : void 0;
      href = (ref4 = plus_photo.data) != null ? (ref5 = ref4.thumbnail) != null ? ref5.url : void 0 : void 0;
      original_content_url = (ref6 = plus_photo.data) != null ? ref6.original_content_url : void 0;
      isVideo = ((ref7 = plus_photo.data) != null ? ref7.media_type : void 0) !== 'MEDIA_TYPE_PHOTO';
      return {href, thumb, original_content_url};
    }
    t = type_ != null ? type_[0] : void 0;
    if (t !== 249) {
      return console.warn('ignoring (old) attachment type', att);
    }
    k = (ref8 = Object.keys(data)) != null ? ref8[0] : void 0;
    if (!k) {
      return;
    }
    href = data != null ? (ref9 = data[k]) != null ? ref9[5] : void 0 : void 0;
    thumb = data != null ? (ref10 = data[k]) != null ? ref10[9] : void 0 : void 0;
    if (!thumb) {
      href = data != null ? (ref11 = data[k]) != null ? ref11[4] : void 0 : void 0;
      thumb = data != null ? (ref12 = data[k]) != null ? ref12[5] : void 0 : void 0;
    }
    return {href, thumb, original_content_url};
  };

  extractObjectStyle = function(att) {
    var eitem, href, it, ref, ref1, thumb, type;
    eitem = att != null ? (ref = att[0]) != null ? ref.embed_item : void 0 : void 0;
    ({type} = eitem != null ? eitem : {});
    if ((type != null ? type[0] : void 0) === "PLUS_PHOTO") {
      it = eitem["embeds.PlusPhoto.plus_photo"];
      href = it != null ? it.url : void 0;
      thumb = it != null ? (ref1 = it.thumbnail) != null ? ref1.url : void 0 : void 0;
      return {href, thumb};
    } else {
      return console.warn('ignoring (new) type', type);
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvdmlld3MvbWVzc2FnZXMuanMiLCJzb3VyY2VzIjpbInVpL3ZpZXdzL21lc3NhZ2VzLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUEsTUFBQSxFQUFBLHVCQUFBLEVBQUEsZUFBQSxFQUFBLFlBQUEsRUFBQSxZQUFBLEVBQUEsVUFBQSxFQUFBLGFBQUEsRUFBQSxXQUFBLEVBQUEsaUJBQUEsRUFBQSxjQUFBLEVBQUEsa0JBQUEsRUFBQSxvQkFBQSxFQUFBLFdBQUEsRUFBQSxVQUFBLEVBQUEsT0FBQSxFQUFBLFdBQUEsRUFBQSxNQUFBLEVBQUEsZ0JBQUEsRUFBQSxVQUFBLEVBQUEsV0FBQSxFQUFBLGNBQUEsRUFBQSxXQUFBLEVBQUEsd0JBQUEsRUFBQSxNQUFBLEVBQUEsVUFBQSxFQUFBLEtBQUEsRUFBQSxXQUFBLEVBQUEsUUFBQSxFQUFBLEtBQUEsRUFBQSxNQUFBLEVBQUEsTUFBQSxFQUFBLE1BQUEsRUFBQSxVQUFBLEVBQUEsUUFBQSxFQUFBLE9BQUEsRUFBQSxPQUFBLEVBQUEscUJBQUEsRUFBQSxZQUFBLEVBQUEsYUFBQSxFQUFBLGNBQUEsRUFBQSxLQUFBLEVBQUEsaUJBQUEsRUFBQSxRQUFBLEVBQUEsR0FBQSxFQUFBOztFQUFBLE1BQUEsR0FBWSxPQUFBLENBQVEsUUFBUjs7RUFDWixLQUFBLEdBQVksT0FBQSxDQUFRLFVBQVIsQ0FBbUIsQ0FBQzs7RUFDaEMsU0FBQSxHQUFZLE9BQUEsQ0FBUSxnQkFBUjs7RUFDWixHQUFBLEdBQVksT0FBQSxDQUFRLEtBQVI7O0VBRVosQ0FBQSxDQUFDLE1BQUQsRUFBUyxVQUFULEVBQXFCLFVBQXJCLEVBQWlDLE1BQWpDLEVBQXlDLEtBQXpDLEVBQWdELFdBQWhELEVBQTZELFFBQTdELEVBQ0EsY0FEQSxFQUNnQixPQURoQixFQUN5QixLQUR6QixFQUNnQyxXQURoQyxFQUM2QyxVQUQ3QyxDQUFBLEdBQzRELE9BQUEsQ0FBUSxTQUFSLENBRDVEOztFQUdBLE1BQUEsR0FBUyxDQUFBLEdBQUksRUFBSixHQUFTLElBQVQsR0FBZ0IsS0FSekI7Ozs7Ozs7Ozs7Ozs7RUFvQkEsdUJBQUEsR0FBMEI7SUFDdEIsVUFBQSxFQUFZO0VBRFUsRUFwQjFCOzs7Ozs7RUE0QkEsVUFBQSxHQUFhLFFBQUEsQ0FBQyxDQUFELEVBQUksT0FBSixFQUFhLE1BQWIsQ0FBQTtBQUNULFFBQUEsSUFBQSxFQUFBLEdBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBO0lBQUEsSUFBYyw0RkFBZDtBQUFBLGFBQUE7O0lBQ0EsQ0FBQyxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsT0FBL0IsR0FBeUM7SUFDekMsSUFBQSxnSUFBbUQsQ0FBRSx5Q0FGckQ7O0lBSUEsSUFBRyxJQUFBLEtBQVEsSUFBWDs7YUFFSSxNQUFNLENBQUMsR0FBUCxDQUFXO1FBQ1AsRUFBQSxFQUFJO1VBQ0EsT0FBQSxFQUFTLE9BRFQ7VUFFQSxPQUFBLEVBQVM7UUFGVCxDQURHO1FBS1AsYUFBQSxFQUFlO01BTFIsQ0FBWCxFQU1HO1FBQUEsTUFBQSxFQUFPO01BQVAsQ0FOSCxFQUZKOztFQUxTOztFQWViLE9BQUEsR0FBVSxRQUFBLENBQUMsQ0FBRCxDQUFBO0FBQ04sUUFBQSxPQUFBLEVBQUEsUUFBQSxFQUFBLElBQUEsRUFBQTtJQUFBLENBQUMsQ0FBQyxjQUFGLENBQUE7SUFDQSxPQUFBLEdBQVUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxZQUFoQixDQUE2QixNQUE3QjtJQUVWLElBQUEsR0FBTyxJQUFJLE1BQUosQ0FBVyw2RUFBWDtJQUNQLElBQUcsSUFBSSxDQUFDLElBQUwsQ0FBVSxPQUFWLENBQUg7TUFDSSxPQUFBLEdBQVUsT0FBTyxDQUFDLE9BQVIsQ0FBZ0IsSUFBaEIsRUFBc0IsSUFBdEI7TUFDVixPQUFBLEdBQVUsUUFBQSxDQUFTLE9BQVQsRUFEVjs7O01BSUEsS0FBSyxDQUFDLFlBQU4sQ0FBbUIsT0FBQSxDQUFRLE9BQVIsQ0FBbkI7QUFDQSxhQU5KOztJQVFBLElBQUcsU0FBQSxDQUFVO01BQUMsS0FBQSxFQUFPO0lBQVIsQ0FBVixDQUF3QixDQUFDLElBQXpCLENBQThCLE9BQTlCLENBQUg7TUFDSSxJQUFPLCtCQUFQO1FBQ0ksT0FBQSxHQUFVLENBQUEsT0FBQSxDQUFBLENBQVUsT0FBVixDQUFBLEVBRGQ7T0FESjs7SUFJQSxRQUFBLEdBQVcsT0FBQSxDQUFRLE9BQVIsRUFoQlg7Ozs7Ozs7O0lBMEJBLEdBQUEsR0FBTSxJQUFJLGVBMUJWOztJQTZCQSxJQUFBLENBQUs7TUFDSCxJQUFBLEVBQU0sSUFBSSxDQUFDLEVBQUwsQ0FBUSwwREFBUixDQURIO01BRUgsSUFBQSxFQUFNO0lBRkgsQ0FBTDtJQUtBLEdBQUcsQ0FBQyxrQkFBSixHQUF5QixRQUFBLENBQUMsQ0FBRCxDQUFBO0FBQ3JCLFVBQUE7TUFBQSxJQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBVCxLQUFtQixDQUE3QjtBQUFBLGVBQUE7O01BQ0EsSUFBVSxHQUFHLENBQUMsVUFBSixLQUFvQixDQUE5QjtBQUFBLGVBQUE7O01BQ0EsVUFBQSxHQUFhLFFBQVEsQ0FBQyxPQUFULENBQWlCLEdBQUcsQ0FBQyxXQUFyQixDQUFBLEtBQXFDO01BQ2xELElBQUcsVUFBSDtRQUNJLFFBQUEsR0FBVyxHQUFHLENBQUMsWUFEbkI7O01BRUEsS0FBSyxDQUFDLFlBQU4sQ0FBbUIsUUFBbkI7YUFDQSxHQUFHLENBQUMsS0FBSixDQUFBO0lBUHFCO0lBU3pCLEdBQUcsQ0FBQyxJQUFKLENBQVMsS0FBVCxFQUFnQixRQUFoQjtXQUNBLEdBQUcsQ0FBQyxJQUFKLENBQUE7RUE3Q00sRUEzQ1Y7OztFQTJGQSxXQUFBLEdBQWMsUUFBQSxDQUFDLEVBQUQsRUFBSyxNQUFMLENBQUE7QUFDVixRQUFBLEdBQUEsRUFBQSxDQUFBLEVBQUEsS0FBQSxFQUFBLE1BQUEsRUFBQSxDQUFBLEVBQUEsR0FBQSxFQUFBLE9BQUEsRUFBQSxHQUFBLEVBQUEsSUFBQSxFQUFBO0lBQUEsTUFBQSxHQUFTO0lBQ1QsS0FBQSxHQUFRO0lBQ1IsSUFBQSxHQUFPO0lBQ1AsS0FBQSxvQ0FBQTs7TUFDSSxJQUFHLENBQUMsQ0FBQyxTQUFGLEdBQWMsNERBQWMsQ0FBZCxDQUFkLEdBQWlDLE1BQXBDO1FBQ0ksS0FBQSxHQUFRO1VBQ0osTUFBQSxFQUFRLEVBREo7VUFFSixLQUFBLEVBQU8sQ0FBQyxDQUFDLFNBRkw7VUFHSixHQUFBLEVBQUssQ0FBQyxDQUFDO1FBSEg7UUFLUixJQUFBLEdBQU87UUFDUCxNQUFNLENBQUMsSUFBUCxDQUFZLEtBQVosRUFQSjs7TUFRQSxPQUFBLEdBQVUsY0FBQSxDQUFlLENBQWY7TUFDVixJQUFHLE9BQUg7UUFDSSxVQUFBLENBQVcsQ0FBWCxFQUFjLE9BQWQsRUFBdUIsTUFBdkIsRUFESjs7TUFFQSxHQUFBLEdBQVMsT0FBSCxHQUFnQixPQUFoQixrREFBeUMsQ0FBRTtNQUNqRCxJQUFHLEdBQUEscUJBQU8sSUFBSSxDQUFFLGFBQWhCO1FBQ0ksS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFiLENBQWtCLElBQUEsR0FBTztVQUNyQixHQUFBLEVBQUssR0FEZ0I7VUFFckIsS0FBQSxFQUFPO1FBRmMsQ0FBekIsRUFESjs7TUFLQSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQVgsQ0FBZ0IsQ0FBaEI7TUFDQSxLQUFLLENBQUMsR0FBTixHQUFZLENBQUMsQ0FBQztJQW5CbEI7V0FvQkE7RUF4QlUsRUEzRmQ7OztFQXNIQSxlQUFBLEdBQWtCLENBQUMsYUFBRCxFQUFnQixjQUFoQixFQUNsQixxQkFEa0IsRUFDSyxtQkFETDs7RUFHbEIsWUFBQSxHQUNJO0lBQUEsU0FBQSxFQUFVLElBQVY7SUFDQSxVQUFBLEVBQVcsSUFEWDtJQUVBLGlCQUFBLEVBQWtCLElBRmxCO0lBR0EsT0FBQSxFQUFRO0VBSFI7O0VBS0osV0FBQSxHQUFvQjs7RUFDcEIsUUFBQSxHQUFvQixLQWhJcEI7O0VBa0lBLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLElBQUEsQ0FBSyxRQUFBLENBQUMsTUFBRCxDQUFBO0FBQ2xCLFFBQUEsUUFBQSxFQUFBLENBQUEsRUFBQSxJQUFBLEVBQUEsT0FBQSxFQUFBLE1BQUEsRUFBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBLEdBQUEsRUFBQSxJQUFBLEVBQUEsV0FBQSxFQUFBLEdBQUEsRUFBQSxJQUFBLEVBQUE7SUFBQSxDQUFBLENBQUMsU0FBRCxFQUFZLElBQVosRUFBa0IsTUFBbEIsQ0FBQSxHQUE0QixNQUE1QjtJQUdBLElBQTZCLFdBQTdCOztNQUFBLEtBQUEsQ0FBTSxRQUFBLENBQVMsU0FBVCxDQUFOLEVBQUE7O0lBQ0EsV0FBQSxHQUFjO0lBRWQsT0FBQSx1QkFBVSxTQUFTLENBQUU7SUFDckIsQ0FBQSxHQUFJLElBQUssQ0FBQSxPQUFBO0lBQ1QsSUFBRyxvREFBSDtBQUNJO01BQUEsS0FBQSxxQ0FBQTs7UUFDSSxNQUFNLENBQUMsVUFBUCxDQUFrQixXQUFXLENBQUMsT0FBOUI7TUFESixDQURKOztJQUdBLEdBQUEsQ0FBSTtNQUFBLEtBQUEsRUFBTSxVQUFOO01BQWtCLE9BQUEsRUFBUSxRQUFBLENBQVMsU0FBVDtJQUExQixDQUFKLEVBQW1ELFFBQUEsQ0FBQSxDQUFBO0FBQy9DLFVBQUEsR0FBQSxFQUFBLE1BQUEsRUFBQSxDQUFBLEVBQUEsT0FBQSxFQUFBLENBQUEsRUFBQSxTQUFBLEVBQUEsNkJBQUEsRUFBQSxJQUFBLEVBQUEsT0FBQSxFQUFBLE1BQUEsRUFBQTtNQUFBLElBQUEsY0FBYyxDQUFDLENBQUUsZUFBakI7QUFBQSxlQUFBOztNQUVBLE9BQUEsR0FBVSxXQUFBLENBQVksQ0FBQyxDQUFDLEtBQWQsRUFBcUIsTUFBckI7TUFDVixHQUFBLENBQUk7UUFBQSxLQUFBLEVBQU07TUFBTixDQUFKLEVBQXlCLFFBQUEsQ0FBQSxDQUFBO1FBQ3JCLElBQUcsQ0FBQyxDQUFDLGlCQUFMO2lCQUNJLElBQUEsQ0FBSyxxQkFBTCxFQUE0QixRQUFBLENBQUEsQ0FBQTttQkFBRyxJQUFBLENBQUs7Y0FBQSxLQUFBLEVBQU07WUFBTixDQUFMLEVBQWtDLGFBQWxDO1VBQUgsQ0FBNUIsRUFESjs7TUFEcUIsQ0FBekI7TUFJQSxJQUFHLENBQUMsU0FBUyxDQUFDLG1CQUFkO1FBQ0ksTUFBTSxDQUFDLE1BQVAsQ0FBYyxJQUFJLENBQUMsU0FBTCxDQUFBLENBQWQsRUFESjtPQUFBLE1BQUE7UUFHSSxNQUFNLENBQUMsTUFBUCxDQUFjLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBL0IsRUFISjs7TUFLQSxTQUFBLEdBQVksSUFBSSxDQUFDLHdCQUFMLENBQThCLENBQTlCO01BQ1osNkJBQUEsR0FBZ0MsUUFBQSxDQUFDLFNBQUQsRUFBWSxLQUFaLENBQUE7QUFDNUIsWUFBQSxPQUFBLEVBQUEsQ0FBQSxFQUFBO0FBQVM7UUFBQSxLQUFBLG9CQUFBOztjQUFpQyxLQUFBLEtBQVM7eUJBQWxEOztRQUFRLENBQUE7O01BRG1CO0FBR2hDO01BQUEsS0FBQSwyQ0FBQTs7UUFDSSxHQUFBLENBQUk7VUFBQSxLQUFBLEVBQU07UUFBTixDQUFKLEVBQXVCLE1BQUEsQ0FBTyxDQUFDLENBQUMsS0FBRixHQUFVLElBQWpCLENBQXNCLENBQUMsUUFBdkIsQ0FBQSxDQUF2Qjs7O0FBQ0E7QUFBQTtVQUFBLEtBQUEsd0NBQUE7O1lBQ0ksTUFBQSxHQUFTLE1BQUEsQ0FBTyxNQUFPLENBQUEsQ0FBQyxDQUFDLEdBQUYsQ0FBZDs7O0FBQ1Q7QUFBQTtjQUFBLEtBQUEsd0NBQUE7O2dCQUNJLElBQUcsV0FBQSxDQUFZLE1BQU8sQ0FBQSxDQUFBLENBQW5CLENBQUg7O2dDQUVJLEdBQUEsQ0FBSTtvQkFBQSxLQUFBLEVBQU07a0JBQU4sQ0FBSixFQUF1QixRQUFBLENBQUEsQ0FBQTtBQUNuQix3QkFBQSxDQUFBLEVBQUEsSUFBQSxFQUFBLENBQUEsRUFBQTtvQkFBQSxpQkFBQSxDQUFrQixDQUFsQixFQUFxQixNQUFyQixFQUE2QixTQUE3QixFQUF3QyxNQUF4QztBQUNnQjtvQkFBQSxLQUFBLDBDQUFBOztvQ0FBaEIsYUFBQSxDQUFjLENBQWQ7b0JBQWdCLENBQUE7O2tCQUZHLENBQXZCLEdBRko7aUJBQUEsTUFBQTtrQkFNSSxHQUFBLEdBQU0sQ0FBQyxRQUFEO2tCQUNOLElBQW1CLE1BQU0sQ0FBQyxNQUFQLENBQWMsQ0FBQyxDQUFDLEdBQWhCLENBQW5CO29CQUFBLEdBQUcsQ0FBQyxJQUFKLENBQVMsTUFBVCxFQUFBOztnQ0FDQSxHQUFBLENBQUk7b0JBQUEsS0FBQSxFQUFNLEdBQUcsQ0FBQyxJQUFKLENBQVMsR0FBVDtrQkFBTixDQUFKLEVBQXlCLFFBQUEsQ0FBQSxDQUFBO29CQUNyQixpQkFBQSxDQUFrQixDQUFsQixFQUFxQixNQUFyQixFQUE2QixTQUE3QixFQUF3QyxNQUF4QztvQkFDQSxHQUFBLENBQUk7c0JBQUEsS0FBQSxFQUFNO29CQUFOLENBQUosRUFBdUIsUUFBQSxDQUFBLENBQUE7QUFDbkIsMEJBQUEsQ0FBQSxFQUFBLElBQUEsRUFBQSxDQUFBLEVBQUE7QUFBdUI7c0JBQUEsS0FBQSwwQ0FBQTs7c0NBQXZCLFdBQUEsQ0FBWSxDQUFaLEVBQWUsTUFBZjtzQkFBdUIsQ0FBQTs7b0JBREosQ0FBdkIsRUFEQTs7MkJBS0EsR0FBQSxDQUFJO3NCQUFBLEtBQUEsRUFBTztvQkFBUCxDQUFKLEVBQXdCLFFBQUEsQ0FBQSxDQUFBO0FBQ3BCLDBCQUFBLE9BQUEsRUFBQSxDQUFBLEVBQUEsSUFBQSxFQUFBLENBQUEsRUFBQSxRQUFBLEVBQUE7QUFBQTtzQkFBQSxLQUFBLDBDQUFBOzs7O0FBQ0k7QUFBQTswQkFBQSxLQUFBLHdDQUFBOzs0QkFDSSxJQUFBLEdBQU8sTUFBTSxDQUFDLE1BQVAsQ0FBYyxPQUFkLENBQUEsSUFBMEIsQ0FBQyxPQUFBLEtBQVcsQ0FBQyxDQUFDLEdBQWQ7NEJBQ2pDLElBS0ssQ0FBSSxJQUxUOzRDQUFBLGNBQUEsQ0FDSSxNQUFPLENBQUEsT0FBQSxDQURYLEVBRUksQ0FBQyxDQUFDLFFBRk4sRUFHSSxTQUhKLEVBSUksTUFKSixHQUFBOzZCQUFBLE1BQUE7b0RBQUE7OzBCQUZKLENBQUE7OztzQkFESixDQUFBOztvQkFEb0IsQ0FBeEI7a0JBTnFCLENBQXpCLEdBUko7O2NBREosQ0FBQTs7O1VBRkosQ0FBQTs7O01BRkosQ0FBQTs7SUFqQitDLENBQW5ELEVBWEE7O0lBMkRBLElBQUcsb0RBQUg7QUFDSTtNQUFBLEtBQUEsd0NBQUE7OEJBQUE7O1FBRUksUUFBQSxHQUFXLFFBQ1gsQ0FBQyxnQkFEVSxDQUNPLENBQUEsZUFBQSxDQUFBLENBQWtCLFdBQVcsQ0FBQyxPQUE5QixDQUFzQyxFQUF0QyxDQURQO01BRmYsQ0FESjtLQTNEQTs7Ozs7OztJQXNFQSxJQUFHLFFBQUEsS0FBWSxPQUFmO01BQ0ksUUFBQSxHQUFXO2FBQ1gsS0FBQSxDQUFNLFlBQU4sRUFGSjs7RUF2RWtCLENBQUw7O0VBMkVqQixpQkFBQSxHQUFvQixRQUFBLENBQUMsQ0FBRCxFQUFJLE1BQUosRUFBWSxTQUFaLEVBQXVCLE1BQXZCLENBQUE7V0FDaEIsR0FBQSxDQUFJO01BQUEsS0FBQSxFQUFPO0lBQVAsQ0FBSixFQUE2QixRQUFBLENBQUEsQ0FBQTtNQUN6QixDQUFBLENBQUU7UUFBQSxJQUFBLEVBQUssTUFBQSxDQUFPLENBQUMsQ0FBQyxHQUFULENBQUw7UUFBb0IsS0FBQSxFQUFPO01BQTNCLENBQUYsRUFBcUMsQ0FBQyxPQUFELENBQXJDLEVBQWdEO1FBQUEsS0FBQSxFQUFNO01BQU4sQ0FBaEQsRUFBZ0UsUUFBQSxDQUFBLENBQUE7ZUFDNUQsVUFBQSxDQUFXLENBQUMsQ0FBQyxHQUFiLEVBQWtCLFNBQWxCLEVBQTZCLE1BQTdCO01BRDRELENBQWhFO2FBRUEsSUFBQSxDQUFLLE1BQUw7SUFIeUIsQ0FBN0I7RUFEZ0I7O0VBTXBCLHdCQUFBLEdBQTJCLFFBQUEsQ0FBQyxLQUFELENBQUE7QUFDdkIsUUFBQSxDQUFBLEVBQUEsS0FBQSxFQUFBLENBQUEsRUFBQSxHQUFBLEVBQUEsU0FBQSxFQUFBO0lBQUEsR0FBQSxHQUFNO0lBQ04sS0FBQSxHQUFRO0lBQ1IsU0FBQSxHQUFZO0lBQ1osS0FBQSx1Q0FBQTs7TUFDSSxJQUFHLFdBQUEsQ0FBWSxDQUFaLENBQUg7UUFDSSxLQUFBLEdBQVEsR0FBRyxDQUFDLElBQUosQ0FBUyxDQUFDLENBQUQsQ0FBVDtRQUNSLFNBQUEsR0FBWSxLQUZoQjtPQUFBLE1BQUE7UUFJSSxJQUFHLFNBQUg7VUFDSSxLQUFBLEdBQVEsR0FBRyxDQUFDLElBQUosQ0FBUyxDQUFDLENBQUQsQ0FBVCxFQURaO1NBQUEsTUFBQTtVQUdJLEdBQUksQ0FBQSxLQUFBLEdBQVEsQ0FBUixDQUFVLENBQUMsSUFBZixDQUFvQixDQUFwQixFQUhKOztRQUlBLFNBQUEsR0FBWSxNQVJoQjs7SUFESjtBQVVBLFdBQU87RUFkZ0I7O0VBZ0IzQixXQUFBLEdBQWMsUUFBQSxDQUFDLENBQUQsQ0FBQTtBQUNWLFFBQUEsR0FBQSxFQUFBLElBQUEsRUFBQTswSEFBaUMsQ0FBQSxDQUFBLHNDQUFqQyxLQUF1Qyx1QkFBdUIsQ0FBQztFQURyRDs7RUFHZCxjQUFBLEdBQWlCLFFBQUEsQ0FBQyxDQUFELEVBQUksUUFBSixFQUFjLFNBQWQsRUFBeUIsTUFBekIsQ0FBQTtBQUNiLFFBQUE7SUFBQSxRQUFBLEdBQVcsVUFBQSxDQUFXLENBQVg7V0FDWCxHQUFBLENBQUk7TUFBQSxLQUFBLEVBQU8sTUFBUDtNQUNGLFNBQUEsRUFBVyxDQUFDLENBQUMsRUFEWDtNQUVGLGVBQUEsRUFBaUIsUUFGZjtNQUdGLEtBQUEsRUFBTyxDQUFDLENBQUM7SUFIUCxDQUFKLEVBSUUsUUFBQSxDQUFBLENBQUE7YUFDRSxVQUFBLENBQVcsQ0FBQyxDQUFDLEVBQWIsRUFBaUIsU0FBakIsRUFBNEIsTUFBNUI7SUFERixDQUpGO0VBRmE7O0VBU2pCLGFBQUEsR0FBZ0IsUUFBQSxDQUFDLENBQUQsQ0FBQTtXQUNaLEdBQUEsQ0FBSTtNQUFBLEtBQUEsRUFBTTtJQUFOLENBQUosRUFBcUIsUUFBQSxDQUFBLENBQUE7QUFDakIsVUFBQTtpREFBYyxDQUFFLGVBQWUsQ0FBQyxPQUFRLENBQUEsQ0FBQSxDQUFFLENBQUM7SUFEMUIsQ0FBckI7RUFEWTs7RUFJaEIsV0FBQSxHQUFjLFFBQUEsQ0FBQyxDQUFELEVBQUksTUFBSixDQUFBO0FBRVYsUUFBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBLEdBQUEsRUFBQSxJQUFBLEVBQUEsS0FBQTs7SUFBQSxJQUFBLEdBQU8sQ0FBQyxTQUFEO0lBQ0ssS0FBQSxpREFBQTs7VUFBOEI7UUFBMUMsSUFBSSxDQUFDLElBQUwsQ0FBVSxDQUFWOztJQUFZO0lBQ1osS0FBQSxHQUFXLENBQUMsQ0FBQyxTQUFMLEdBQW9CLE1BQUEsQ0FBTyxDQUFDLENBQUMsU0FBRixHQUFjLElBQXJCLENBQTBCLENBQUMsUUFBM0IsQ0FBQSxDQUFwQixHQUErRDtXQUN2RSxHQUFBLENBQUk7TUFBQSxFQUFBLEVBQUcsQ0FBQyxDQUFDLFFBQUw7TUFBZSxHQUFBLEVBQUksQ0FBQyxDQUFDLFFBQXJCO01BQStCLEtBQUEsRUFBTSxJQUFJLENBQUMsSUFBTCxDQUFVLEdBQVYsQ0FBckM7TUFBcUQsS0FBQSxFQUFNO0lBQTNELENBQUosRUFBc0UsUUFBQSxDQUFBLENBQUE7QUFDbEUsVUFBQSxPQUFBLEVBQUEsSUFBQSxFQUFBLGFBQUEsRUFBQSxLQUFBLEVBQUEsR0FBQSxFQUFBLEtBQUEsRUFBQTtNQUFBLElBQUcsQ0FBQyxDQUFDLFlBQUw7UUFDSSxPQUFBLHVDQUF3QixDQUFFO1FBQzFCLE1BQUEsQ0FBTyxPQUFQLEVBREE7O1FBR0EsSUFBRyxDQUFDLENBQUMsV0FBRixJQUFrQixDQUFDLENBQUMsV0FBdkI7aUJBQ0ksSUFBQSxDQUFLO1lBQUEsS0FBQSxFQUFNO1VBQU4sQ0FBTCxFQUFrQyxhQUFsQyxFQURKO1NBSko7T0FBQSxNQU1LLElBQUcsQ0FBQyxDQUFDLG1CQUFMO2VBQ0QsSUFBQSxDQUFLLENBQUEsd0JBQUEsQ0FBQSxDQUEyQixDQUFDLENBQUMsbUJBQW1CLENBQUMsUUFBakQsQ0FBQSxDQUFMLEVBREM7O09BQUEsTUFHQSxJQUFHLENBQUMsQ0FBQyxpQkFBTDtRQUNELENBQUEsR0FBSSxDQUFDLENBQUMsaUJBQWlCLENBQUM7UUFDeEIsSUFBQSxHQUFPLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLENBQUMsR0FBcEMsQ0FBd0MsUUFBQSxDQUFDLENBQUQsQ0FBQTtpQkFBTyxNQUFPLENBQUEsQ0FBQyxDQUFDLE9BQUY7UUFBZCxDQUF4QztRQUNQLEtBQUEsR0FBUSxJQUFJLENBQUMsR0FBTCxDQUFTLE1BQVQsQ0FBZ0IsQ0FBQyxJQUFqQixDQUFzQixJQUF0QjtRQUNSLElBQUcsQ0FBQSxLQUFLLE1BQVI7aUJBQ0ksSUFBQSxDQUFLLENBQUEsUUFBQSxDQUFBLENBQVcsS0FBWCxDQUFBLENBQUwsRUFESjtTQUFBLE1BRUssSUFBRyxDQUFBLEtBQUssT0FBUjtpQkFDRCxJQUFBLENBQUssQ0FBQSxDQUFBLENBQUcsS0FBSCxDQUFTLHNCQUFULENBQUwsRUFEQztTQU5KO09BQUEsTUFRQSxJQUFHLENBQUMsQ0FBQyxhQUFMO1FBQ0QsYUFBQSxHQUFnQixDQUFDLENBQUM7UUFDbEIsS0FBQSxHQUFRO1VBQUEsZ0JBQUEsRUFBa0I7UUFBbEI7UUFDUixJQUFHLGFBQWEsQ0FBQyxVQUFkLEtBQTRCLGVBQS9CO1VBQ0ksSUFBQSxDQUFLO1lBQUUsS0FBQSxFQUFPLGdCQUFUO1lBQTJCO1VBQTNCLENBQUwsRUFBeUMsaUJBQXpDO2lCQUNBLElBQUEsQ0FBSyxlQUFMLEVBRko7U0FBQSxNQUdLLElBQUcsYUFBYSxDQUFDLFVBQWQsS0FBNEIsYUFBL0I7VUFDRCxJQUFBLENBQUs7WUFBRSxLQUFBLEVBQU0sc0JBQVI7WUFBZ0M7VUFBaEMsQ0FBTCxFQUE4QyxVQUE5QztpQkFDQSxJQUFBLENBQUssYUFBTCxFQUZDO1NBTko7T0FBQSxNQUFBO2VBVUQsT0FBTyxDQUFDLEdBQVIsQ0FBWSxzQkFBWixFQUFvQyxDQUFwQyxFQUF1QyxNQUF2QyxFQVZDOztJQWxCNkQsQ0FBdEU7RUFMVTs7RUFvQ2QsWUFBQSxHQUFlLFFBQUEsQ0FBQSxDQUFBO0FBQ1gsUUFBQSxLQUFBLEVBQUE7SUFBQSxLQUFBLEdBQVEsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsT0FBdkI7SUFDUixLQUFBLEdBQVEsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsV0FBdkI7V0FDUixNQUFBLENBQU8sT0FBUCxtQkFBZ0IsS0FBSyxDQUFFLHNCQUFQLG9CQUFzQixLQUFLLENBQUUsc0JBQTdDO0VBSFcsRUF2UmY7OztFQThSQSxRQUFBLEdBQVcsUUFBQSxDQUFDLFNBQUQsQ0FBQTtXQUFlLFFBQUEsQ0FBUyxFQUFULEVBQWEsUUFBQSxDQUFBLENBQUE7TUFFbkMsSUFBb0IsU0FBUyxDQUFDLFFBQTlCOztlQUFBLGNBQUEsQ0FBQSxFQUFBOztJQUZtQyxDQUFiO0VBQWY7O0VBS1gsY0FBQSxHQUFpQixNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWYsR0FBZ0MsUUFBQSxDQUFBLENBQUE7QUFFN0MsUUFBQSxFQUFBOztJQUFBLEVBQUEsR0FBSyxRQUFRLENBQUMsYUFBVCxDQUF1QixPQUF2QixFQUFMOztXQUVBLEVBQUUsQ0FBQyxTQUFILEdBQWUsTUFBTSxDQUFDO0VBSnVCOztFQU9qRCxNQUFBLEdBQVMsUUFBQSxDQUFDLENBQUQsRUFBSSxDQUFKLENBQUE7SUFBVSxJQUFHLENBQUg7YUFBVSxFQUFWO0tBQUEsTUFBQTthQUFpQixLQUFqQjs7RUFBVjs7RUFFVCxNQUFBLEdBQVMsUUFBQSxDQUFDLElBQUQsQ0FBQTtBQUNMLFFBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsR0FBQSxFQUFBLEdBQUEsRUFBQSxJQUFBLEVBQUE7SUFBQSxJQUFHLGlEQUFIO0FBQ0k7UUFDSSxnQkFBQSxDQUFpQixJQUFJLENBQUMsVUFBdEIsRUFESjtPQUFBLGFBQUE7UUFFTTtRQUNGLE9BQU8sQ0FBQyxLQUFSLENBQWMsQ0FBZCxFQUhKO09BREo7O0FBS0E7SUFBQSxLQUFBLDhDQUFBOztNQUNJLElBQVksSUFBSSxDQUFDLE9BQUwsSUFBaUIsQ0FBQSxHQUFJLENBQWpDO0FBQUEsaUJBQUE7O01BQ0EsVUFBVSxDQUFDLE9BQVgsQ0FBbUIsUUFBQSxDQUFDLEVBQUQsQ0FBQTtlQUNmLEVBQUEsQ0FBRyxHQUFILEVBQVEsSUFBUjtNQURlLENBQW5CO0lBRko7V0FJQTtFQVZLOztFQWFULFVBQUEsR0FBYTs7SUFFVCxRQUFBLENBQUMsR0FBRDtJQUFNLElBQU4sQ0FBQTtBQUNJLFVBQUEsQ0FBQTtJQUFBLElBQUE7SUFBQSxHQUFBO0lBQUE7TUFBQSxDQUFBLDBDQUFxQixDQUFBO01BQ3JCLElBQUEsc0RBQXFCLENBQUU7YUFDdkIsTUFBQSxDQUFPLElBQVA7SUFBYSxDQUFDLFFBQUEsQ0FBQyxDQUFELENBQUE7ZUFBTyxDQUFBLENBQUUsQ0FBQyxJQUFEO0lBQU8sT0FBUCxDQUFGO0lBQW1CLENBQW5CO01BQVAsQ0FBRCxDQUFiLENBQUEsQ0FBNEMsUUFBQSxDQUFBLENBQUE7ZUFDeEMsTUFBQSxDQUFPLENBQUMsQ0FBQyxJQUFUO0lBQWUsQ0FBZixDQUFBLENBQWtCLFFBQUEsQ0FBQSxDQUFBO2lCQUNkLE1BQUEsQ0FBTyxDQUFDLENBQUMsTUFBVDtJQUFpQixDQUFqQixDQUFBLENBQW9CLFFBQUEsQ0FBQSxDQUFBO21CQUNoQixNQUFBLENBQU8sQ0FBQyxDQUFDLFNBQVQ7SUFBb0IsQ0FBcEIsQ0FBQSxDQUF1QixRQUFBLENBQUEsQ0FBQTtxQkFDbkIsTUFBQSxDQUFPLENBQUMsQ0FBQyxhQUFUO0lBQXdCLENBQXhCLENBQUEsQ0FBMkIsUUFBQSxDQUFBLENBQUE7dUJBQ3ZCLElBQUEsQ0FBUSxJQUFJLENBQUMsT0FBUixHQUNELGlCQUFBLENBQWtCLEdBQUcsQ0FBQyxJQUF0QixDQURDLEdBRUcsR0FBRyxDQUFDLElBQUosS0FBWSxZQUFmLEdBQ0QsSUFEQyxHQUdELEdBQUcsQ0FBQyxJQUxSO2NBRHVCLENBQTNCO1lBRG1CLENBQXZCO1VBRGdCLENBQXBCO1FBRGMsQ0FBbEI7TUFEd0MsQ0FBNUM7SUFISixDQUZTOztJQWlCVCxRQUFBLENBQUMsR0FBRCxDQUFBO0FBQ0ksVUFBQSxJQUFBO0lBQUEsUUFBQTtJQUFBO01BQUEsSUFBQSxvREFBcUIsQ0FBRTtNQUN2QixRQUFBLEdBQVcsV0FBQSxDQUFZLElBQVosRUFEWDtNQUVBLElBQUcsUUFBQSxJQUFhLE9BQUEsQ0FBUSxRQUFSLENBQWhCO2VBQ0ksR0FBQSxDQUFJLFFBQUEsQ0FBQSxDQUFBO2lCQUNBLEdBQUEsQ0FBSTtZQUFBLEdBQUEsRUFBSztVQUFMLENBQUo7UUFEQSxDQUFKLEVBREo7O0lBSEosQ0FqQlM7O0lBd0JULFFBQUEsQ0FBQyxHQUFELENBQUE7QUFDSSxVQUFBLElBQUE7SUFBQSxJQUFBO0lBQUE7TUFBQSxJQUFBLGlCQUFPLEdBQUcsQ0FBRTtNQUNaLElBQUcsQ0FBQyxJQUFKO0FBQ0ksZUFESjs7TUFFQSxPQUFBLEdBQVUsSUFBSSxDQUFDLEtBQUwsQ0FBVyxvREFBWDtNQUNWLElBQUcsQ0FBQyxPQUFKO0FBQ0ksZUFESjs7TUFFQSxJQUFBLEdBQU8sWUFBQSxDQUFhLE9BQVEsQ0FBQSxDQUFBLENBQVIsR0FBYSxPQUFRLENBQUEsQ0FBQSxDQUFsQztNQUNQLElBQUcsQ0FBQyxJQUFKO0FBQ0ksZUFESjs7YUFFQSxHQUFBLENBQUk7UUFBQSxLQUFBLEVBQU07TUFBTixDQUFKO0lBQW1CLFFBQUEsQ0FBQSxDQUFBO1FBQ2YsSUFBRyxJQUFJLENBQUMsSUFBUjtVQUNJLENBQUEsQ0FBRSxRQUFBLENBQUEsQ0FBQTttQkFDRSxJQUFJLENBQUM7VUFEUCxDQUFGLEVBREo7O1FBR0EsSUFBRyxJQUFJLENBQUMsUUFBTCxJQUFrQixPQUFBLENBQVEsSUFBSSxDQUFDLFFBQWIsQ0FBckI7aUJBQ0ksR0FBQSxDQUFJO1lBQUEsR0FBQSxFQUFLLElBQUksQ0FBQztVQUFWLENBQUosRUFESjs7TUFKZSxDQUFuQjtJQVZKLENBeEJTOztJQXlDVCxRQUFBLENBQUMsR0FBRCxDQUFBO0FBQ0ksVUFBQSxJQUFBO0lBQUEsSUFBQTtJQUFBO01BQUEsSUFBQSxpQkFBTyxHQUFHLENBQUU7TUFDWixJQUFHLENBQUMsSUFBSjtBQUNJLGVBREo7O01BRUEsT0FBQSxHQUFVLElBQUksQ0FBQyxLQUFMLENBQVcsNkNBQVg7TUFDVixJQUFHLENBQUMsT0FBSjtBQUNJLGVBREo7O01BRUEsSUFBQSxHQUFPLHFCQUFBLENBQXNCLHdDQUFBLEdBQTJDLElBQWpFO01BQ1AsSUFBRyxDQUFDLElBQUo7QUFDSSxlQURKOzthQUVBLEdBQUEsQ0FBSTtRQUFBLEtBQUEsRUFBTTtNQUFOLENBQUo7SUFBdUIsUUFBQSxDQUFBLENBQUE7UUFDbkIsSUFBRyxJQUFJLENBQUMsSUFBUjtVQUNJLENBQUEsQ0FBRSxRQUFBLENBQUEsQ0FBQTttQkFDRSxJQUFJLENBQUM7VUFEUCxDQUFGLEVBREo7O1FBR0EsSUFBRyxJQUFJLENBQUMsUUFBTCxJQUFrQixPQUFBLENBQVEsSUFBSSxDQUFDLFFBQWIsQ0FBckI7aUJBQ0ksR0FBQSxDQUFJO1lBQUEsR0FBQSxFQUFLLElBQUksQ0FBQztVQUFWLENBQUosRUFESjs7TUFKbUIsQ0FBdkI7SUFWSixDQXpDUzs7O0VBMkRiLGlCQUFBLEdBQW9CLFFBQUEsQ0FBQyxHQUFELENBQUE7SUFDaEIsbUJBQUcsR0FBRyxDQUFFLE9BQUwsQ0FBYSxJQUFiLFdBQUEsS0FBc0IsQ0FBekI7YUFDSSxHQUFHLENBQUMsU0FBSixDQUFjLENBQWQsRUFESjtLQUFBLE1BQUE7YUFHSSxJQUhKOztFQURnQjs7RUFNcEIsYUFBQSxHQUFnQixDQUFBOztFQUdoQixPQUFBLEdBQVUsUUFBQSxDQUFDLElBQUQsQ0FBQTtBQUNOLFFBQUEsS0FBQSxFQUFBO0lBQUEsS0FBQSxHQUFRLGFBQWMsQ0FBQSxJQUFBO0lBQ3RCLElBQUcsQ0FBSSxLQUFQO01BQ0ksRUFBQSxHQUFLLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCO01BQ0wsRUFBRSxDQUFDLE1BQUgsR0FBWSxRQUFBLENBQUEsQ0FBQTtRQUNSLElBQWMsT0FBTyxFQUFFLENBQUMsWUFBVixLQUEwQixRQUF4QztBQUFBLGlCQUFBOztRQUNBLEVBQUUsQ0FBQyxNQUFILEdBQVk7ZUFDWixLQUFBLENBQU0sUUFBQSxDQUFBLENBQUE7aUJBQUcsTUFBQSxDQUFPLFdBQVA7UUFBSCxDQUFOO01BSFE7TUFJWixFQUFFLENBQUMsT0FBSCxHQUFhLFFBQUEsQ0FBQSxDQUFBO2VBQUcsT0FBTyxDQUFDLEdBQVIsQ0FBWSxxQkFBWixFQUFtQyxJQUFuQztNQUFIO01BQ2IsRUFBRSxDQUFDLEdBQUgsR0FBUztNQUNULGFBQWMsQ0FBQSxJQUFBLENBQWQsR0FBc0IsR0FSMUI7O0FBU0EsMkJBQU8sS0FBSyxDQUFFO0VBWFI7O0VBYVYsWUFBQSxHQUFlLFFBQUEsQ0FBQyxJQUFELENBQUE7QUFDWCxRQUFBO0lBQUEsS0FBQSxHQUFRLGFBQWMsQ0FBQSxJQUFBO0lBQ3RCLElBQUcsQ0FBSSxLQUFQO01BQ0ksYUFBYyxDQUFBLElBQUEsQ0FBZCxHQUFzQixDQUFBO01BQ3RCLEtBQUEsQ0FBTSxJQUFOLENBQ0EsQ0FBQyxJQURELENBQ00sUUFBQSxDQUFDLFFBQUQsQ0FBQTtlQUNGLFFBQVEsQ0FBQyxJQUFULENBQUE7TUFERSxDQUROLENBR0EsQ0FBQyxJQUhELENBR00sUUFBQSxDQUFDLElBQUQsQ0FBQTtBQUNGLFlBQUEsU0FBQSxFQUFBLElBQUEsRUFBQSxLQUFBLEVBQUE7UUFBQSxJQUFBLEdBQU8sUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkI7UUFDUCxJQUFJLENBQUMsU0FBTCxHQUFpQjtRQUNqQixTQUFBLEdBQVksSUFBSSxDQUFDLGFBQUwsQ0FBbUIsNEJBQW5CO1FBQ1osUUFBQSxHQUFXLFNBQVMsQ0FBQyxhQUFWLENBQXlCLGFBQXpCO1FBQ1gsS0FBQSxHQUFRLFNBQVMsQ0FBQyxhQUFWLENBQXlCLGtCQUF6QjtRQUNSLGFBQWMsQ0FBQSxJQUFBLENBQUssQ0FBQyxJQUFwQixHQUEyQixRQUFRLENBQUM7UUFDcEMsYUFBYyxDQUFBLElBQUEsQ0FBSyxDQUFDLFFBQXBCLG1CQUErQixLQUFLLENBQUUsT0FBTyxDQUFDO2VBQzlDLEtBQUEsQ0FBTSxRQUFBLENBQUEsQ0FBQTtpQkFBRyxNQUFBLENBQU8sYUFBUDtRQUFILENBQU47TUFSRSxDQUhOLEVBRko7O0FBY0EsV0FBTztFQWhCSTs7RUFrQmYscUJBQUEsR0FBd0IsUUFBQSxDQUFDLElBQUQsQ0FBQTtBQUNwQixRQUFBO0lBQUEsS0FBQSxHQUFRLGFBQWMsQ0FBQSxJQUFBO0lBQ3RCLElBQUcsQ0FBSSxLQUFQO01BQ0ksYUFBYyxDQUFBLElBQUEsQ0FBZCxHQUFzQixDQUFBO01BQ3RCLEtBQUEsQ0FBTSxJQUFOLENBQ0EsQ0FBQyxJQURELENBQ00sUUFBQSxDQUFDLFFBQUQsQ0FBQTtlQUNGLFFBQVEsQ0FBQyxJQUFULENBQUE7TUFERSxDQUROLENBR0EsQ0FBQyxJQUhELENBR00sUUFBQSxDQUFDLElBQUQsQ0FBQTtRQUNGLGFBQWMsQ0FBQSxJQUFBLENBQUssQ0FBQyxJQUFwQixHQUEyQixJQUFJLENBQUM7UUFDaEMsYUFBYyxDQUFBLElBQUEsQ0FBSyxDQUFDLFFBQXBCLEdBQStCLElBQUksQ0FBQztlQUNwQyxLQUFBLENBQU0sUUFBQSxDQUFBLENBQUE7aUJBQUcsTUFBQSxDQUFPLHNCQUFQO1FBQUgsQ0FBTjtNQUhFLENBSE4sRUFGSjs7QUFTQSxXQUFPO0VBWGE7O0VBYXhCLGdCQUFBLEdBQW1CLFFBQUEsQ0FBQyxHQUFELENBQUE7QUFFZixRQUFBLElBQUEsRUFBQSxJQUFBLEVBQUEsb0JBQUEsRUFBQSxHQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUEsS0FBQTs7SUFBQSxpRkFBc0IsQ0FBRSxnQ0FBeEI7TUFDSSxJQUFBLEdBQU8sb0JBQUEsQ0FBcUIsR0FBckI7TUFDUCxJQUFVLENBQUksSUFBZDtBQUFBLGVBQUE7O01BQ0EsQ0FBQSxDQUFDLElBQUQsRUFBTyxLQUFQLEVBQWMsb0JBQWQsQ0FBQSxHQUFzQyxJQUF0QyxFQUhKO0tBQUEsTUFJSyxtRkFBc0IsQ0FBRSwrQkFBeEI7TUFDRCxPQUFPLENBQUMsR0FBUixDQUFZLCtCQUFaO01BQ0EsSUFBQSxHQUFPLG9CQUFBLENBQXFCLEdBQXJCO01BQ1AsSUFBVSxDQUFJLElBQWQ7QUFBQSxlQUFBOztNQUNBLENBQUEsQ0FBQyxJQUFELEVBQU8sS0FBUCxFQUFjLG9CQUFkLENBQUEsR0FBc0MsSUFBdEMsRUFKQztLQUFBLE1BQUE7TUFNRCxtQkFBK0MsR0FBRyxDQUFFLGdCQUFMLEtBQWUsQ0FBOUQ7UUFBQSxPQUFPLENBQUMsSUFBUixDQUFhLHFCQUFiLEVBQW9DLEdBQXBDLEVBQUE7O0FBQ0EsYUFQQzs7SUFVTCxJQUFBLENBQW1DLElBQW5DOzs7TUFBQSxJQUFBLEdBQU8scUJBQVA7S0FkQTs7O0lBaUJBLElBQUcsT0FBQSxDQUFRLEtBQVIsQ0FBSDthQUNJLEdBQUEsQ0FBSTtRQUFBLEtBQUEsRUFBTTtNQUFOLENBQUosRUFBb0IsUUFBQSxDQUFBLENBQUE7ZUFDaEIsQ0FBQSxDQUFFLENBQUMsSUFBRCxFQUFPLE9BQVAsQ0FBRixFQUFtQixRQUFBLENBQUEsQ0FBQTtpQkFBRyxHQUFBLENBQUk7WUFBQSxHQUFBLEVBQUk7VUFBSixDQUFKO1FBQUgsQ0FBbkI7TUFEZ0IsQ0FBcEIsRUFESjs7RUFuQmU7O0VBd0JuQixNQUFBLENBQU8sV0FBUCxFQUFvQixRQUFBLENBQUEsQ0FBQSxFQUFBOztJQUVoQixPQUFBLENBQVEsV0FBUixFQUFBOztJQUVBLE9BQUEsQ0FBUSxNQUFSLEVBRkE7O1dBSUEsT0FBQSxDQUFRLFVBQVI7RUFOZ0IsQ0FBcEI7O0VBUUEsTUFBQSxDQUFPLGFBQVAsRUFBc0IsUUFBQSxDQUFBLENBQUE7V0FDbEIsT0FBQSxDQUFRLE1BQVI7RUFEa0IsQ0FBdEI7O0VBR0EsTUFBQSxDQUFPLHNCQUFQLEVBQStCLFFBQUEsQ0FBQSxDQUFBO1dBQzNCLE9BQUEsQ0FBUSxNQUFSO0VBRDJCLENBQS9COztFQUdBLG9CQUFBLEdBQXVCLFFBQUEsQ0FBQyxHQUFELENBQUE7QUFDbkIsUUFBQSxJQUFBLEVBQUEsVUFBQSxFQUFBLElBQUEsRUFBQSxPQUFBLEVBQUEsQ0FBQSxFQUFBLG9CQUFBLEVBQUEsVUFBQSxFQUFBLEdBQUEsRUFBQSxJQUFBLEVBQUEsS0FBQSxFQUFBLEtBQUEsRUFBQSxLQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxDQUFBLEVBQUEsS0FBQSxFQUFBO0lBQUEsSUFBQSxHQUFPO0lBQ1AsS0FBQSxHQUFRO0lBRVIsVUFBQSw2Q0FBb0IsQ0FBRTtJQUN0QixDQUFBLENBQUMsVUFBRCxFQUFhLElBQWIsRUFBbUIsS0FBbkIsQ0FBQSx3QkFBNEIsYUFBYSxDQUFBLENBQXpDO0lBQ0EsSUFBRyxrQkFBSDtNQUNJLElBQUEsMENBQXVCLENBQUU7TUFDekIsS0FBQSw0RUFBa0MsQ0FBRTtNQUNwQyxJQUFBLDRFQUFrQyxDQUFFO01BQ3BDLG9CQUFBLDBDQUFzQyxDQUFFO01BQ3hDLE9BQUEsMkNBQXlCLENBQUUsb0JBQWpCLEtBQWlDO0FBQzNDLGFBQU8sQ0FBQyxJQUFELEVBQU8sS0FBUCxFQUFjLG9CQUFkLEVBTlg7O0lBUUEsQ0FBQSxtQkFBSSxLQUFPLENBQUEsQ0FBQTtJQUNYLElBQWlFLENBQUEsS0FBSyxHQUF0RTtBQUFBLGFBQU8sT0FBTyxDQUFDLElBQVIsQ0FBYSxnQ0FBYixFQUErQyxHQUEvQyxFQUFQOztJQUNBLENBQUEsNENBQXVCLENBQUEsQ0FBQTtJQUN2QixJQUFBLENBQWMsQ0FBZDtBQUFBLGFBQUE7O0lBQ0EsSUFBQSxpREFBaUIsQ0FBQSxDQUFBO0lBQ2pCLEtBQUEsbURBQWtCLENBQUEsQ0FBQTtJQUNsQixJQUFHLENBQUksS0FBUDtNQUNJLElBQUEsbURBQWlCLENBQUEsQ0FBQTtNQUNqQixLQUFBLG1EQUFrQixDQUFBLENBQUEsb0JBRnRCOztXQUlBLENBQUMsSUFBRCxFQUFPLEtBQVAsRUFBYyxvQkFBZDtFQXhCbUI7O0VBMEJ2QixrQkFBQSxHQUFxQixRQUFBLENBQUMsR0FBRCxDQUFBO0FBQ2pCLFFBQUEsS0FBQSxFQUFBLElBQUEsRUFBQSxFQUFBLEVBQUEsR0FBQSxFQUFBLElBQUEsRUFBQSxLQUFBLEVBQUE7SUFBQSxLQUFBLDZDQUFlLENBQUU7SUFDakIsQ0FBQSxDQUFDLElBQUQsQ0FBQSxtQkFBUyxRQUFRLENBQUEsQ0FBakI7SUFDQSxvQkFBRyxJQUFNLENBQUEsQ0FBQSxXQUFOLEtBQVksWUFBZjtNQUNJLEVBQUEsR0FBSyxLQUFNLENBQUEsNkJBQUE7TUFDWCxJQUFBLGdCQUFPLEVBQUUsQ0FBRTtNQUNYLEtBQUEsb0RBQXFCLENBQUU7QUFDdkIsYUFBTyxDQUFDLElBQUQsRUFBTyxLQUFQLEVBSlg7S0FBQSxNQUFBO2FBTUksT0FBTyxDQUFDLElBQVIsQ0FBYSxxQkFBYixFQUFvQyxJQUFwQyxFQU5KOztFQUhpQjtBQXplckIiLCJzb3VyY2VzQ29udGVudCI6WyJtb21lbnQgICAgPSByZXF1aXJlICdtb21lbnQnXG5zaGVsbCAgICAgPSByZXF1aXJlKCdlbGVjdHJvbicpLnNoZWxsXG51cmxSZWdleHAgPSByZXF1aXJlICd1YmVyLXVybC1yZWdleCdcbnVybCAgICAgICA9IHJlcXVpcmUgJ3VybCdcblxue25hbWVvZiwgaW5pdGlhbHNvZiwgbmFtZW9mY29udiwgbGlua3RvLCBsYXRlciwgZm9yY2VyZWRyYXcsIHRocm90dGxlLFxuZ2V0UHJveGllZE5hbWUsIGZpeGxpbmssIGlzSW1nLCBnZXRJbWFnZVVybCwgZHJhd0F2YXRhcn0gID0gcmVxdWlyZSAnLi4vdXRpbCdcblxuQ1VUT0ZGID0gNSAqIDYwICogMTAwMCAqIDEwMDAgIyA1IG1pbnNcblxuIyBjaGF0X21lc3NhZ2U6XG4jICAge1xuIyAgICAgYW5ub3RhdGlvbjogW1xuIyAgICAgICBbNCwgXCJcIl1cbiMgICAgIF1cbiMgICAgIG1lc3NhZ2VfY29udGVudDoge1xuIyAgICAgICBhdHRhY2hlbWVudDogW11cbiMgICAgICAgc2VnbWVudDogW3sgLi4uIH1dXG4jICAgICB9XG4jICAgfVxuSEFOR09VVF9BTk5PVEFUSU9OX1RZUEUgPSB7XG4gICAgbWVfbWVzc2FnZTogNFxufVxuXG4jIHRoaXMgaGVscHMgZml4aW5nIGhvdXRzIHByb3hpZWQgd2l0aCB0aGluZ3MgbGlrZSBoYW5ndXBzYm90XG4jIHRoZSBmb3JtYXQgb2YgcHJveGllZCBtZXNzYWdlcyBhcmVcbiMgYW5kIGhlcmUgd2UgcHV0IGVudGl0aWVzIGluIHRoZSBlbnRpdHkgZGIgZm9yXG4jIHVzZXJzIGZvdW5kIG9ubHkgaW4gcHJveGllZCBtZXNzYWdlcy5cbmZpeFByb3hpZWQgPSAoZSwgcHJveGllZCwgZW50aXR5KSAtPlxuICAgIHJldHVybiB1bmxlc3MgZT8uY2hhdF9tZXNzYWdlPy5tZXNzYWdlX2NvbnRlbnQ/XG4gICAgZS5jaGF0X21lc3NhZ2UubWVzc2FnZV9jb250ZW50LnByb3hpZWQgPSB0cnVlXG4gICAgbmFtZSA9IGU/LmNoYXRfbWVzc2FnZT8ubWVzc2FnZV9jb250ZW50Py5zZWdtZW50WzBdPy50ZXh0XG4gICAgIyB1cGRhdGUgZmFsbGJhY2tfbmFtZSBmb3IgZW50aXR5IGRhdGFiYXNlXG4gICAgaWYgbmFtZSAhPSAnPj4nXG4gICAgICAgICMgc3ludGhldGljIGFkZCBvZiBmYWxsYmFja19uYW1lXG4gICAgICAgIGVudGl0eS5hZGQge1xuICAgICAgICAgICAgaWQ6IHtcbiAgICAgICAgICAgICAgICBnYWlhX2lkOiBwcm94aWVkXG4gICAgICAgICAgICAgICAgY2hhdF9pZDogcHJveGllZFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZmFsbGJhY2tfbmFtZTogbmFtZVxuICAgICAgICB9LCBzaWxlbnQ6dHJ1ZVxuXG5vbmNsaWNrID0gKGUpIC0+XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgYWRkcmVzcyA9IGUuY3VycmVudFRhcmdldC5nZXRBdHRyaWJ1dGUgJ2hyZWYnXG5cbiAgICBwYXR0ID0gbmV3IFJlZ0V4cChcIl4oaHR0cHM/WzpdWy9dWy9dd3d3Wy5dZ29vZ2xlWy5dKGNvbXxbYS16XVthLXpdKVsvXXVybFs/XXFbPV0pKFteJl0rKSgmLispKlwiKVxuICAgIGlmIHBhdHQudGVzdChhZGRyZXNzKVxuICAgICAgICBhZGRyZXNzID0gYWRkcmVzcy5yZXBsYWNlKHBhdHQsICckMycpXG4gICAgICAgIGFkZHJlc3MgPSB1bmVzY2FwZShhZGRyZXNzKVxuICAgICAgICAjIHRoaXMgaXMgYSBsaW5rIG91dHNpZGUgZ29vZ2xlIGFuZCBjYW4gYmUgb3BlbmVkIGRpcmVjdGx5XG4gICAgICAgICMgIGFzIHRoZXJlIGlzIG5vIG5lZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gICAgICAgIHNoZWxsLm9wZW5FeHRlcm5hbChmaXhsaW5rKGFkZHJlc3MpKVxuICAgICAgICByZXR1cm5cblxuICAgIGlmIHVybFJlZ2V4cCh7ZXhhY3Q6IHRydWV9KS50ZXN0KGFkZHJlc3MpXG4gICAgICAgIHVubGVzcyB1cmwucGFyc2UoYWRkcmVzcykuaG9zdD9cbiAgICAgICAgICAgIGFkZHJlc3MgPSBcImh0dHA6Ly8je2FkZHJlc3N9XCJcblxuICAgIGZpbmFsVXJsID0gZml4bGluayhhZGRyZXNzKVxuXG4gICAgIyBHb29nbGUgYXBpcyBnaXZlIHVzIGFuIHVybCB0aGF0IGlzIG9ubHkgdmFsaWQgZm9yIHRoZSBjdXJyZW50IGxvZ2dlZCB1c2VyLlxuICAgICMgV2UgY2FuJ3Qgb3BlbiB0aGlzIHVybCBpbiB0aGUgZXh0ZXJuYWwgYnJvd3NlciBiZWNhdXNlIGl0IG1heSBub3QgYmUgYXV0aGVudGljYXRlZFxuICAgICMgb3IgbWF5IGJlIGF1dGhlbnRpY2F0ZWQgZGlmZmVyZW50bHkgKGFub3RoZXIgdXNlciBvciBtdWx0aXBsZSB1c2VycykuXG4gICAgIyBJbiB0aGlzIGNhc2Ugd2UgdHJ5IHRvIG9wZW4gdGhlIHVybCBvdXJzZWx2ZXMgdW50aWwgd2UgZ2V0IHJlZGlyZWN0ZWQgdG8gdGhlIGZpbmFsIHVybFxuICAgICMgb2YgdGhlIGltYWdlL3ZpZGVvLlxuICAgICMgVGhlIGZpbmFsVVJMIHdpbGwgYmUgY2RuLWhvc3RlZCwgc3RhdGljIGFuZCBkb2VzIG5vdCByZXF1aXJlIGF1dGhlbnRpY2F0aW9uXG4gICAgIyBzbyB3ZSBjYW4gZmluYWxseSBvcGVuIGl0IGluIHRoZSBleHRlcm5hbCBicm93c2VyIDooXG5cbiAgICB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3RcblxuICAgICMgU2hvd2luZyBtZXNzYWdlIHdpdGggMyBzZWNvbmQgZGVsYXkgc2hvd2luZyB0aGUgdXNlciB0aGF0IHNvbWV0aGluZyBpcyBoYXBwZW5pbmdcbiAgICBub3RyIHtcbiAgICAgIGh0bWw6IGkxOG4uX18gJ21lbnUuaGVscC5hYm91dC50aXRsZTpPcGVuaW5nIHRoZSBsaW5rIGluIHRoZSBicm93c2VyLi4uJ1xuICAgICAgc3RheTogMzAwMFxuICAgIH1cblxuICAgIHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSAoZSkgLT5cbiAgICAgICAgcmV0dXJuIGlmIGUudGFyZ2V0LnN0YXR1cyBpcyAwXG4gICAgICAgIHJldHVybiBpZiB4aHIucmVhZHlTdGF0ZSBpc250IDRcbiAgICAgICAgcmVkaXJlY3RlZCA9IGZpbmFsVXJsLmluZGV4T2YoeGhyLnJlc3BvbnNlVVJMKSAhPSAwXG4gICAgICAgIGlmIHJlZGlyZWN0ZWRcbiAgICAgICAgICAgIGZpbmFsVXJsID0geGhyLnJlc3BvbnNlVVJMXG4gICAgICAgIHNoZWxsLm9wZW5FeHRlcm5hbChmaW5hbFVybClcbiAgICAgICAgeGhyLmFib3J0KClcblxuICAgIHhoci5vcGVuKFwiZ2V0XCIsIGZpbmFsVXJsKVxuICAgIHhoci5zZW5kKClcblxuIyBoZWxwZXIgbWV0aG9kIHRvIGdyb3VwIGV2ZW50cyBpbiB0aW1lL3VzZXIgYnVuY2hlc1xuZ3JvdXBFdmVudHMgPSAoZXMsIGVudGl0eSkgLT5cbiAgICBncm91cHMgPSBbXVxuICAgIGdyb3VwID0gbnVsbFxuICAgIHVzZXIgPSBudWxsXG4gICAgZm9yIGUgaW4gZXNcbiAgICAgICAgaWYgZS50aW1lc3RhbXAgLSAoZ3JvdXA/LmVuZCA/IDApID4gQ1VUT0ZGXG4gICAgICAgICAgICBncm91cCA9IHtcbiAgICAgICAgICAgICAgICBieXVzZXI6IFtdXG4gICAgICAgICAgICAgICAgc3RhcnQ6IGUudGltZXN0YW1wXG4gICAgICAgICAgICAgICAgZW5kOiBlLnRpbWVzdGFtcFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdXNlciA9IG51bGxcbiAgICAgICAgICAgIGdyb3Vwcy5wdXNoIGdyb3VwXG4gICAgICAgIHByb3hpZWQgPSBnZXRQcm94aWVkTmFtZShlKVxuICAgICAgICBpZiBwcm94aWVkXG4gICAgICAgICAgICBmaXhQcm94aWVkIGUsIHByb3hpZWQsIGVudGl0eVxuICAgICAgICBjaWQgPSBpZiBwcm94aWVkIHRoZW4gcHJveGllZCBlbHNlIGU/LnNlbmRlcl9pZD8uY2hhdF9pZFxuICAgICAgICBpZiBjaWQgIT0gdXNlcj8uY2lkXG4gICAgICAgICAgICBncm91cC5ieXVzZXIucHVzaCB1c2VyID0ge1xuICAgICAgICAgICAgICAgIGNpZDogY2lkXG4gICAgICAgICAgICAgICAgZXZlbnQ6IFtdXG4gICAgICAgICAgICB9XG4gICAgICAgIHVzZXIuZXZlbnQucHVzaCBlXG4gICAgICAgIGdyb3VwLmVuZCA9IGUudGltZXN0YW1wXG4gICAgZ3JvdXBzXG5cbiMgcG9zc2libGUgY2xhc3NlcyBvZiBtZXNzYWdlc1xuTUVTU0FHRV9DTEFTU0VTID0gWydwbGFjZWhvbGRlcicsICdjaGF0X21lc3NhZ2UnLFxuJ2NvbnZlcnNhdGlvbl9yZW5hbWUnLCAnbWVtYmVyc2hpcF9jaGFuZ2UnXVxuXG5PQlNFUlZFX09QVFMgPVxuICAgIGNoaWxkTGlzdDp0cnVlXG4gICAgYXR0cmlidXRlczp0cnVlXG4gICAgYXR0cmlidXRlT2xkVmFsdWU6dHJ1ZVxuICAgIHN1YnRyZWU6dHJ1ZVxuXG5maXJzdFJlbmRlciAgICAgICA9IHRydWVcbmxhc3RDb252ICAgICAgICAgID0gbnVsbCAjIHRvIGRldGVjdCBjb252IHN3aXRjaGluZ1xuXG5tb2R1bGUuZXhwb3J0cyA9IHZpZXcgKG1vZGVscykgLT5cbiAgICB7dmlld3N0YXRlLCBjb252LCBlbnRpdHl9ID0gbW9kZWxzXG5cbiAgICAjIG11dGF0aW9uIGV2ZW50cyBraWNrcyBpbiBhZnRlciBmaXJzdCByZW5kZXJcbiAgICBsYXRlciBvbk11dGF0ZSh2aWV3c3RhdGUpIGlmIGZpcnN0UmVuZGVyXG4gICAgZmlyc3RSZW5kZXIgPSBmYWxzZVxuXG4gICAgY29udl9pZCA9IHZpZXdzdGF0ZT8uc2VsZWN0ZWRDb252XG4gICAgYyA9IGNvbnZbY29udl9pZF1cbiAgICBpZiBjPy5jdXJyZW50X3BhcnRpY2lwYW50P1xuICAgICAgICBmb3IgcGFydGljaXBhbnQgaW4gYy5jdXJyZW50X3BhcnRpY2lwYW50XG4gICAgICAgICAgICBlbnRpdHkubmVlZEVudGl0eSBwYXJ0aWNpcGFudC5jaGF0X2lkXG4gICAgZGl2IGNsYXNzOidtZXNzYWdlcycsIG9ic2VydmU6b25NdXRhdGUodmlld3N0YXRlKSwgLT5cbiAgICAgICAgcmV0dXJuIHVubGVzcyBjPy5ldmVudFxuXG4gICAgICAgIGdyb3VwZWQgPSBncm91cEV2ZW50cyBjLmV2ZW50LCBlbnRpdHlcbiAgICAgICAgZGl2IGNsYXNzOidoaXN0b3J5aW5mbycsIC0+XG4gICAgICAgICAgICBpZiBjLnJlcXVlc3RpbmdoaXN0b3J5XG4gICAgICAgICAgICAgICAgcGFzcyAnUmVxdWVzdGluZyBoaXN0b3J54oCmJywgLT4gc3BhbiBjbGFzczonbWF0ZXJpYWwtaWNvbnMgc3BpbicsICdkb251dF9sYXJnZSdcblxuICAgICAgICBpZiAhdmlld3N0YXRlLnVzZVN5c3RlbURhdGVGb3JtYXRcbiAgICAgICAgICAgIG1vbWVudC5sb2NhbGUoaTE4bi5nZXRMb2NhbGUoKSlcbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgbW9tZW50LmxvY2FsZSh3aW5kb3cubmF2aWdhdG9yLmxhbmd1YWdlKVxuXG4gICAgICAgIGxhc3Rfc2VlbiA9IGNvbnYuZmluZExhc3RSZWFkRXZlbnRzQnlVc2VyKGMpXG4gICAgICAgIGxhc3Rfc2Vlbl9jaGF0X2lkc193aXRoX2V2ZW50ID0gKGxhc3Rfc2VlbiwgZXZlbnQpIC0+XG4gICAgICAgICAgICAoY2hhdF9pZCBmb3IgY2hhdF9pZCwgZSBvZiBsYXN0X3NlZW4gd2hlbiBldmVudCBpcyBlKVxuXG4gICAgICAgIGZvciBnIGluIGdyb3VwZWRcbiAgICAgICAgICAgIGRpdiBjbGFzczondGltZXN0YW1wJywgbW9tZW50KGcuc3RhcnQgLyAxMDAwKS5jYWxlbmRhcigpXG4gICAgICAgICAgICBmb3IgdSBpbiBnLmJ5dXNlclxuICAgICAgICAgICAgICAgIHNlbmRlciA9IG5hbWVvZiBlbnRpdHlbdS5jaWRdXG4gICAgICAgICAgICAgICAgZm9yIGV2ZW50cyBpbiBncm91cEV2ZW50c0J5TWVzc2FnZVR5cGUgdS5ldmVudFxuICAgICAgICAgICAgICAgICAgICBpZiBpc01lTWVzc2FnZSBldmVudHNbMF1cbiAgICAgICAgICAgICAgICAgICAgICAgICMgYWxsIGl0ZW1zIGFyZSAvbWUgbWVzc2FnZXMgaWYgdGhlIGZpcnN0IG9uZSBpcyBkdWUgdG8gZ3JvdXBpbmcgYWJvdmVcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpdiBjbGFzczondWdyb3VwIG1lJywgLT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkcmF3TWVzc2FnZUF2YXRhciB1LCBzZW5kZXIsIHZpZXdzdGF0ZSwgZW50aXR5XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZHJhd01lTWVzc2FnZSBlIGZvciBlIGluIGV2ZW50c1xuICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICBjbHogPSBbJ3Vncm91cCddXG4gICAgICAgICAgICAgICAgICAgICAgICBjbHoucHVzaCAnc2VsZicgaWYgZW50aXR5LmlzU2VsZih1LmNpZClcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpdiBjbGFzczpjbHouam9pbignICcpLCAtPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRyYXdNZXNzYWdlQXZhdGFyIHUsIHNlbmRlciwgdmlld3N0YXRlLCBlbnRpdHlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXYgY2xhc3M6J3VtZXNzYWdlcycsIC0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRyYXdNZXNzYWdlKGUsIGVudGl0eSkgZm9yIGUgaW4gZXZlbnRzXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAjIGF0IHRoZSBlbmQgb2YgdGhlIGV2ZW50cyBncm91cCB3ZSBkcmF3IHdobyBoYXMgcmVhZCBhbnkgb2YgaXRzIGV2ZW50c1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpdiBjbGFzczogJ3NlZW4tbGlzdCcsICgpIC0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciBlIGluIGV2ZW50c1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIGNoYXRfaWQgaW4gbGFzdF9zZWVuX2NoYXRfaWRzX3dpdGhfZXZlbnQobGFzdF9zZWVuLCBlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNraXAgPSBlbnRpdHkuaXNTZWxmKGNoYXRfaWQpIG9yIChjaGF0X2lkID09IHUuY2lkKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRyYXdTZWVuQXZhdGFyKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRpdHlbY2hhdF9pZF0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUuZXZlbnRfaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdzdGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50aXR5XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSBpZiBub3Qgc2tpcFxuXG4gICAgIyBHbyB0aHJvdWdoIGFsbCB0aGUgcGFydGljaXBhbnRzIGFuZCBvbmx5IHNob3cgaGlzIGxhc3Qgc2VlbiBzdGF0dXNcbiAgICBpZiBjPy5jdXJyZW50X3BhcnRpY2lwYW50P1xuICAgICAgICBmb3IgcGFydGljaXBhbnQgaW4gYy5jdXJyZW50X3BhcnRpY2lwYW50XG4gICAgICAgICAgICAjIGdldCBhbGwgYXZhdGFyc1xuICAgICAgICAgICAgYWxsX3NlZW4gPSBkb2N1bWVudFxuICAgICAgICAgICAgLnF1ZXJ5U2VsZWN0b3JBbGwoXCIuc2VlbltkYXRhLWlkPScje3BhcnRpY2lwYW50LmNoYXRfaWR9J11cIilcbiAgICAgICAgICAgICMgc2VsZWN0IGxhc3Qgb25lXG4gICAgICAgICAgICAjICBOT1QgV09SS0lOR1xuICAgICAgICAgICAgI2lmIGFsbF9zZWVuLmxlbmd0aCA+IDBcbiAgICAgICAgICAgICMgICAgYWxsX3NlZW4uZm9yRWFjaCAoZWwpIC0+XG4gICAgICAgICAgICAjICAgICAgICBlbC5jbGFzc0xpc3QucmVtb3ZlICdzaG93J1xuICAgICAgICAgICAgIyAgICBhbGxfc2VlblthbGxfc2Vlbi5sZW5ndGggLSAxXS5jbGFzc0xpc3QuYWRkICdzaG93J1xuICAgIGlmIGxhc3RDb252ICE9IGNvbnZfaWRcbiAgICAgICAgbGFzdENvbnYgPSBjb252X2lkXG4gICAgICAgIGxhdGVyIGF0VG9wSWZTbWFsbFxuXG5kcmF3TWVzc2FnZUF2YXRhciA9ICh1LCBzZW5kZXIsIHZpZXdzdGF0ZSwgZW50aXR5KSAtPlxuICAgIGRpdiBjbGFzczogJ3NlbmRlci13cmFwcGVyJywgLT5cbiAgICAgICAgYSBocmVmOmxpbmt0byh1LmNpZCksIHRpdGxlOiBzZW5kZXIsIHtvbmNsaWNrfSwgY2xhc3M6J3NlbmRlcicsIC0+XG4gICAgICAgICAgICBkcmF3QXZhdGFyKHUuY2lkLCB2aWV3c3RhdGUsIGVudGl0eSlcbiAgICAgICAgc3BhbiBzZW5kZXJcblxuZ3JvdXBFdmVudHNCeU1lc3NhZ2VUeXBlID0gKGV2ZW50KSAtPlxuICAgIHJlcyA9IFtdXG4gICAgaW5kZXggPSAwXG4gICAgcHJldldhc01lID0gdHJ1ZVxuICAgIGZvciBlIGluIGV2ZW50XG4gICAgICAgIGlmIGlzTWVNZXNzYWdlIGVcbiAgICAgICAgICAgIGluZGV4ID0gcmVzLnB1c2ggW2VdXG4gICAgICAgICAgICBwcmV2V2FzTWUgPSB0cnVlXG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIGlmIHByZXZXYXNNZVxuICAgICAgICAgICAgICAgIGluZGV4ID0gcmVzLnB1c2ggW2VdXG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgcmVzW2luZGV4IC0gMV0ucHVzaCBlXG4gICAgICAgICAgICBwcmV2V2FzTWUgPSBmYWxzZVxuICAgIHJldHVybiByZXNcblxuaXNNZU1lc3NhZ2UgPSAoZSkgLT5cbiAgICBlPy5jaGF0X21lc3NhZ2U/LmFubm90YXRpb24/WzBdP1swXSA9PSBIQU5HT1VUX0FOTk9UQVRJT05fVFlQRS5tZV9tZXNzYWdlXG5cbmRyYXdTZWVuQXZhdGFyID0gKHUsIGV2ZW50X2lkLCB2aWV3c3RhdGUsIGVudGl0eSkgLT5cbiAgICBpbml0aWFscyA9IGluaXRpYWxzb2YgdVxuICAgIGRpdiBjbGFzczogXCJzZWVuXCJcbiAgICAsIFwiZGF0YS1pZFwiOiB1LmlkXG4gICAgLCBcImRhdGEtZXZlbnQtaWRcIjogZXZlbnRfaWRcbiAgICAsIHRpdGxlOiB1LmRpc3BsYXlfbmFtZVxuICAgICwgLT5cbiAgICAgICAgZHJhd0F2YXRhcih1LmlkLCB2aWV3c3RhdGUsIGVudGl0eSlcblxuZHJhd01lTWVzc2FnZSA9IChlKSAtPlxuICAgIGRpdiBjbGFzczonbWVzc2FnZScsIC0+XG4gICAgICAgIGUuY2hhdF9tZXNzYWdlPy5tZXNzYWdlX2NvbnRlbnQuc2VnbWVudFswXS50ZXh0XG5cbmRyYXdNZXNzYWdlID0gKGUsIGVudGl0eSkgLT5cbiAgICAjIGNvbnNvbGUubG9nICdtZXNzYWdlJywgZS5jaGF0X21lc3NhZ2VcbiAgICBtY2x6ID0gWydtZXNzYWdlJ11cbiAgICBtY2x6LnB1c2ggYyBmb3IgYyBpbiBNRVNTQUdFX0NMQVNTRVMgd2hlbiBlW2NdP1xuICAgIHRpdGxlID0gaWYgZS50aW1lc3RhbXAgdGhlbiBtb21lbnQoZS50aW1lc3RhbXAgLyAxMDAwKS5jYWxlbmRhcigpIGVsc2UgbnVsbFxuICAgIGRpdiBpZDplLmV2ZW50X2lkLCBrZXk6ZS5ldmVudF9pZCwgY2xhc3M6bWNsei5qb2luKCcgJyksIHRpdGxlOnRpdGxlLCAtPlxuICAgICAgICBpZiBlLmNoYXRfbWVzc2FnZVxuICAgICAgICAgICAgY29udGVudCA9IGUuY2hhdF9tZXNzYWdlPy5tZXNzYWdlX2NvbnRlbnRcbiAgICAgICAgICAgIGZvcm1hdCBjb250ZW50XG4gICAgICAgICAgICAjIGxvYWRJbmxpbmVJbWFnZXMgY29udGVudFxuICAgICAgICAgICAgaWYgZS5wbGFjZWhvbGRlciBhbmQgZS51cGxvYWRpbWFnZVxuICAgICAgICAgICAgICAgIHNwYW4gY2xhc3M6J21hdGVyaWFsLWljb25zIHNwaW4nLCAnZG9udXRfbGFyZ2UnXG4gICAgICAgIGVsc2UgaWYgZS5jb252ZXJzYXRpb25fcmVuYW1lXG4gICAgICAgICAgICBwYXNzIFwicmVuYW1lZCBjb252ZXJzYXRpb24gdG8gI3tlLmNvbnZlcnNhdGlvbl9yZW5hbWUubmV3X25hbWV9XCJcbiAgICAgICAgICAgICMge25ld19uYW1lOiBcImxhYmJvdFwiIG9sZF9uYW1lOiBcIlwifVxuICAgICAgICBlbHNlIGlmIGUubWVtYmVyc2hpcF9jaGFuZ2VcbiAgICAgICAgICAgIHQgPSBlLm1lbWJlcnNoaXBfY2hhbmdlLnR5cGVcbiAgICAgICAgICAgIGVudHMgPSBlLm1lbWJlcnNoaXBfY2hhbmdlLnBhcnRpY2lwYW50X2lkcy5tYXAgKHApIC0+IGVudGl0eVtwLmNoYXRfaWRdXG4gICAgICAgICAgICBuYW1lcyA9IGVudHMubWFwKG5hbWVvZikuam9pbignLCAnKVxuICAgICAgICAgICAgaWYgdCA9PSAnSk9JTidcbiAgICAgICAgICAgICAgICBwYXNzIFwiaW52aXRlZCAje25hbWVzfVwiXG4gICAgICAgICAgICBlbHNlIGlmIHQgPT0gJ0xFQVZFJ1xuICAgICAgICAgICAgICAgIHBhc3MgXCIje25hbWVzfSBsZWZ0IHRoZSBjb252ZXJzYXRpb25cIlxuICAgICAgICBlbHNlIGlmIGUuaGFuZ291dF9ldmVudFxuICAgICAgICAgICAgaGFuZ291dF9ldmVudCA9IGUuaGFuZ291dF9ldmVudFxuICAgICAgICAgICAgc3R5bGUgPSAndmVydGljYWwtYWxpZ24nOiAnbWlkZGxlJ1xuICAgICAgICAgICAgaWYgaGFuZ291dF9ldmVudC5ldmVudF90eXBlIGlzICdTVEFSVF9IQU5HT1VUJ1xuICAgICAgICAgICAgICAgIHNwYW4geyBjbGFzczogJ21hdGVyaWFsLWljb25zJywgc3R5bGUgfSwgJ2NhbGxfbWFkZV9zbWFsbCdcbiAgICAgICAgICAgICAgICBwYXNzICcgQ2FsbCBzdGFydGVkJ1xuICAgICAgICAgICAgZWxzZSBpZiBoYW5nb3V0X2V2ZW50LmV2ZW50X3R5cGUgaXMgJ0VORF9IQU5HT1VUJ1xuICAgICAgICAgICAgICAgIHNwYW4geyBjbGFzczonbWF0ZXJpYWwtaWNvbnMgc21hbGwnLCBzdHlsZSB9LCAnY2FsbF9lbmQnXG4gICAgICAgICAgICAgICAgcGFzcyAnIENhbGwgZW5kZWQnXG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIGNvbnNvbGUubG9nICd1bmhhbmRsZWQgZXZlbnQgdHlwZScsIGUsIGVudGl0eVxuXG5cbmF0VG9wSWZTbWFsbCA9IC0+XG4gICAgc2NyZWwgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcubWFpbicpXG4gICAgbXNnZWwgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcubWVzc2FnZXMnKVxuICAgIGFjdGlvbiAnYXR0b3AnLCBtc2dlbD8ub2Zmc2V0SGVpZ2h0IDwgc2NyZWw/Lm9mZnNldEhlaWdodFxuXG5cbiMgd2hlbiB0aGVyZSdzIG11dGF0aW9uLCB3ZSBzY3JvbGwgdG8gYm90dG9tIGluIGNhc2Ugd2UgYWxyZWFkeSBhcmUgYXQgYm90dG9tXG5vbk11dGF0ZSA9ICh2aWV3c3RhdGUpIC0+IHRocm90dGxlIDEwLCAtPlxuICAgICMganVtcCB0byBib3R0b20gdG8gZm9sbG93IGNvbnZcbiAgICBzY3JvbGxUb0JvdHRvbSgpIGlmIHZpZXdzdGF0ZS5hdGJvdHRvbVxuXG5cbnNjcm9sbFRvQm90dG9tID0gbW9kdWxlLmV4cG9ydHMuc2Nyb2xsVG9Cb3R0b20gPSAtPlxuICAgICMgZW5zdXJlIHdlJ3JlIHNjcm9sbGVkIHRvIGJvdHRvbVxuICAgIGVsID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLm1haW4nKVxuICAgICMgdG8gYm90dG9tXG4gICAgZWwuc2Nyb2xsVG9wID0gTnVtYmVyLk1BWF9TQUZFX0lOVEVHRVJcblxuXG5pZnBhc3MgPSAodCwgZikgLT4gaWYgdCB0aGVuIGYgZWxzZSBwYXNzXG5cbmZvcm1hdCA9IChjb250KSAtPlxuICAgIGlmIGNvbnQ/LmF0dGFjaG1lbnQ/XG4gICAgICAgIHRyeVxuICAgICAgICAgICAgZm9ybWF0QXR0YWNobWVudCBjb250LmF0dGFjaG1lbnRcbiAgICAgICAgY2F0Y2ggZVxuICAgICAgICAgICAgY29uc29sZS5lcnJvciBlXG4gICAgZm9yIHNlZywgaSBpbiBjb250Py5zZWdtZW50ID8gW11cbiAgICAgICAgY29udGludWUgaWYgY29udC5wcm94aWVkIGFuZCBpIDwgMVxuICAgICAgICBmb3JtYXR0ZXJzLmZvckVhY2ggKGZuKSAtPlxuICAgICAgICAgICAgZm4gc2VnLCBjb250XG4gICAgbnVsbFxuXG5cbmZvcm1hdHRlcnMgPSBbXG4gICAgIyB0ZXh0IGZvcm1hdHRlclxuICAgIChzZWcsIGNvbnQpIC0+XG4gICAgICAgIGYgPSBzZWcuZm9ybWF0dGluZyA/IHt9XG4gICAgICAgIGhyZWYgPSBzZWc/LmxpbmtfZGF0YT8ubGlua190YXJnZXRcbiAgICAgICAgaWZwYXNzKGhyZWYsICgoZikgLT4gYSB7aHJlZiwgb25jbGlja30sIGYpKSAtPlxuICAgICAgICAgICAgaWZwYXNzKGYuYm9sZCwgYikgLT5cbiAgICAgICAgICAgICAgICBpZnBhc3MoZi5pdGFsaWMsIGkpIC0+XG4gICAgICAgICAgICAgICAgICAgIGlmcGFzcyhmLnVuZGVybGluZSwgdSkgLT5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmcGFzcyhmLnN0cmlrZXRocm91Z2gsIHMpIC0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFzcyBpZiBjb250LnByb3hpZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyaXBQcm94aWVkQ29sb24gc2VnLnRleHRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIHNlZy50eXBlID09ICdMSU5FX0JSRUFLJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnXFxuJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VnLnRleHRcbiAgICAjIGltYWdlIGZvcm1hdHRlclxuICAgIChzZWcpIC0+XG4gICAgICAgIGhyZWYgPSBzZWc/LmxpbmtfZGF0YT8ubGlua190YXJnZXRcbiAgICAgICAgaW1hZ2VVcmwgPSBnZXRJbWFnZVVybCBocmVmICMgZmFsc2UgaWYgY2FuJ3QgZmluZCBvbmVcbiAgICAgICAgaWYgaW1hZ2VVcmwgYW5kIHByZWxvYWQgaW1hZ2VVcmxcbiAgICAgICAgICAgIGRpdiAtPlxuICAgICAgICAgICAgICAgIGltZyBzcmM6IGltYWdlVXJsXG4gICAgIyB0d2l0dGVyIHByZXZpZXdcbiAgICAoc2VnKSAtPlxuICAgICAgICBocmVmID0gc2VnPy50ZXh0XG4gICAgICAgIGlmICFocmVmXG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgbWF0Y2hlcyA9IGhyZWYubWF0Y2ggL14oaHR0cHM/OlxcL1xcLykoLitcXC4pPyh0d2l0dGVyLmNvbVxcLy4rXFwvc3RhdHVzXFwvLispL1xuICAgICAgICBpZiAhbWF0Y2hlc1xuICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgIGRhdGEgPSBwcmVsb2FkVHdlZXQgbWF0Y2hlc1sxXSArIG1hdGNoZXNbM11cbiAgICAgICAgaWYgIWRhdGFcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICBkaXYgY2xhc3M6J3R3ZWV0JywgLT5cbiAgICAgICAgICAgIGlmIGRhdGEudGV4dFxuICAgICAgICAgICAgICAgIHAgLT5cbiAgICAgICAgICAgICAgICAgICAgZGF0YS50ZXh0XG4gICAgICAgICAgICBpZiBkYXRhLmltYWdlVXJsIGFuZCBwcmVsb2FkIGRhdGEuaW1hZ2VVcmxcbiAgICAgICAgICAgICAgICBpbWcgc3JjOiBkYXRhLmltYWdlVXJsXG4gICAgIyBpbnN0YWdyYW0gcHJldmlld1xuICAgIChzZWcpIC0+XG4gICAgICAgIGhyZWYgPSBzZWc/LnRleHRcbiAgICAgICAgaWYgIWhyZWZcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICBtYXRjaGVzID0gaHJlZi5tYXRjaCAvXihodHRwcz86XFwvXFwvKSguK1xcLik/KGluc3RhZ3JhbS5jb21cXC9wXFwvLispL1xuICAgICAgICBpZiAhbWF0Y2hlc1xuICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgIGRhdGEgPSBwcmVsb2FkSW5zdGFncmFtUGhvdG8gJ2h0dHBzOi8vYXBpLmluc3RhZ3JhbS5jb20vb2VtYmVkLz91cmw9JyArIGhyZWZcbiAgICAgICAgaWYgIWRhdGFcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICBkaXYgY2xhc3M6J2luc3RhZ3JhbScsIC0+XG4gICAgICAgICAgICBpZiBkYXRhLnRleHRcbiAgICAgICAgICAgICAgICBwIC0+XG4gICAgICAgICAgICAgICAgICAgIGRhdGEudGV4dFxuICAgICAgICAgICAgaWYgZGF0YS5pbWFnZVVybCBhbmQgcHJlbG9hZCBkYXRhLmltYWdlVXJsXG4gICAgICAgICAgICAgICAgaW1nIHNyYzogZGF0YS5pbWFnZVVybFxuXVxuXG5zdHJpcFByb3hpZWRDb2xvbiA9ICh0eHQpIC0+XG4gICAgaWYgdHh0Py5pbmRleE9mKFwiOiBcIikgPT0gMFxuICAgICAgICB0eHQuc3Vic3RyaW5nKDIpXG4gICAgZWxzZVxuICAgICAgICB0eHRcblxucHJlbG9hZF9jYWNoZSA9IHt9XG5cblxucHJlbG9hZCA9IChocmVmKSAtPlxuICAgIGNhY2hlID0gcHJlbG9hZF9jYWNoZVtocmVmXVxuICAgIGlmIG5vdCBjYWNoZVxuICAgICAgICBlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQgJ2ltZydcbiAgICAgICAgZWwub25sb2FkID0gLT5cbiAgICAgICAgICAgIHJldHVybiB1bmxlc3MgdHlwZW9mIGVsLm5hdHVyYWxXaWR0aCA9PSAnbnVtYmVyJ1xuICAgICAgICAgICAgZWwubG9hZGVkID0gdHJ1ZVxuICAgICAgICAgICAgbGF0ZXIgLT4gYWN0aW9uICdsb2FkZWRpbWcnXG4gICAgICAgIGVsLm9uZXJyb3IgPSAtPiBjb25zb2xlLmxvZyAnZXJyb3IgbG9hZGluZyBpbWFnZScsIGhyZWZcbiAgICAgICAgZWwuc3JjID0gaHJlZlxuICAgICAgICBwcmVsb2FkX2NhY2hlW2hyZWZdID0gZWxcbiAgICByZXR1cm4gY2FjaGU/LmxvYWRlZFxuXG5wcmVsb2FkVHdlZXQgPSAoaHJlZikgLT5cbiAgICBjYWNoZSA9IHByZWxvYWRfY2FjaGVbaHJlZl1cbiAgICBpZiBub3QgY2FjaGVcbiAgICAgICAgcHJlbG9hZF9jYWNoZVtocmVmXSA9IHt9XG4gICAgICAgIGZldGNoIGhyZWZcbiAgICAgICAgLnRoZW4gKHJlc3BvbnNlKSAtPlxuICAgICAgICAgICAgcmVzcG9uc2UudGV4dCgpXG4gICAgICAgIC50aGVuIChodG1sKSAtPlxuICAgICAgICAgICAgZnJhZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQgJ2RpdidcbiAgICAgICAgICAgIGZyYWcuaW5uZXJIVE1MID0gaHRtbFxuICAgICAgICAgICAgY29udGFpbmVyID0gZnJhZy5xdWVyeVNlbGVjdG9yICdbZGF0YS1hc3NvY2lhdGVkLXR3ZWV0LWlkXSdcbiAgICAgICAgICAgIHRleHROb2RlID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IgKCcudHdlZXQtdGV4dCcpXG4gICAgICAgICAgICBpbWFnZSA9IGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yICgnW2RhdGEtaW1hZ2UtdXJsXScpXG4gICAgICAgICAgICBwcmVsb2FkX2NhY2hlW2hyZWZdLnRleHQgPSB0ZXh0Tm9kZS50ZXh0Q29udGVudFxuICAgICAgICAgICAgcHJlbG9hZF9jYWNoZVtocmVmXS5pbWFnZVVybCA9IGltYWdlPy5kYXRhc2V0LmltYWdlVXJsXG4gICAgICAgICAgICBsYXRlciAtPiBhY3Rpb24gJ2xvYWRlZHR3ZWV0J1xuICAgIHJldHVybiBjYWNoZVxuXG5wcmVsb2FkSW5zdGFncmFtUGhvdG8gPSAoaHJlZikgLT5cbiAgICBjYWNoZSA9IHByZWxvYWRfY2FjaGVbaHJlZl1cbiAgICBpZiBub3QgY2FjaGVcbiAgICAgICAgcHJlbG9hZF9jYWNoZVtocmVmXSA9IHt9XG4gICAgICAgIGZldGNoIGhyZWZcbiAgICAgICAgLnRoZW4gKHJlc3BvbnNlKSAtPlxuICAgICAgICAgICAgcmVzcG9uc2UuanNvbigpXG4gICAgICAgIC50aGVuIChqc29uKSAtPlxuICAgICAgICAgICAgcHJlbG9hZF9jYWNoZVtocmVmXS50ZXh0ID0ganNvbi50aXRsZVxuICAgICAgICAgICAgcHJlbG9hZF9jYWNoZVtocmVmXS5pbWFnZVVybCA9IGpzb24udGh1bWJuYWlsX3VybFxuICAgICAgICAgICAgbGF0ZXIgLT4gYWN0aW9uICdsb2FkZWRpbnN0YWdyYW1waG90bydcbiAgICByZXR1cm4gY2FjaGVcblxuZm9ybWF0QXR0YWNobWVudCA9IChhdHQpIC0+XG4gICAgIyBjb25zb2xlLmxvZyAnYXR0YWNobWVudCcsIGF0dCBpZiBhdHQubGVuZ3RoID4gMFxuICAgIGlmIGF0dD9bMF0/LmVtYmVkX2l0ZW0/LnR5cGVfXG4gICAgICAgIGRhdGEgPSBleHRyYWN0UHJvdG9idWZTdHlsZShhdHQpXG4gICAgICAgIHJldHVybiBpZiBub3QgZGF0YVxuICAgICAgICB7aHJlZiwgdGh1bWIsIG9yaWdpbmFsX2NvbnRlbnRfdXJsfSA9IGRhdGFcbiAgICBlbHNlIGlmIGF0dD9bMF0/LmVtYmVkX2l0ZW0/LnR5cGVcbiAgICAgICAgY29uc29sZS5sb2coJ1RISVMgU0hPVUxEIE5PVCBIQVBQRU4gV1RGICEhJylcbiAgICAgICAgZGF0YSA9IGV4dHJhY3RQcm90b2J1ZlN0eWxlKGF0dClcbiAgICAgICAgcmV0dXJuIGlmIG5vdCBkYXRhXG4gICAgICAgIHtocmVmLCB0aHVtYiwgb3JpZ2luYWxfY29udGVudF91cmx9ID0gZGF0YVxuICAgIGVsc2VcbiAgICAgICAgY29uc29sZS53YXJuICdpZ25vcmluZyBhdHRhY2htZW50JywgYXR0IHVubGVzcyBhdHQ/Lmxlbmd0aCA9PSAwXG4gICAgICAgIHJldHVyblxuICAgIFxuICAgICMgc3RpY2tlcnMgZG8gbm90IGhhdmUgYW4gaHJlZiBzbyB3ZSBsaW5rIHRvIHRoZSBvcmlnaW5hbCBjb250ZW50IGluc3RlYWRcbiAgICBocmVmID0gb3JpZ2luYWxfY29udGVudF91cmwgdW5sZXNzIGhyZWZcbiAgICBcbiAgICAjIGhlcmUgd2UgYXNzdW1lIGF0dGFjaG1lbnRzIGFyZSBvbmx5IGltYWdlc1xuICAgIGlmIHByZWxvYWQgdGh1bWJcbiAgICAgICAgZGl2IGNsYXNzOidhdHRhY2gnLCAtPlxuICAgICAgICAgICAgYSB7aHJlZiwgb25jbGlja30sIC0+IGltZyBzcmM6dGh1bWJcbiAgICBcblxuaGFuZGxlICdsb2FkZWRpbWcnLCAtPlxuICAgICMgYWxsb3cgY29udHJvbGxlciB0byByZWNvcmQgY3VycmVudCBwb3NpdGlvblxuICAgIHVwZGF0ZWQgJ2JlZm9yZUltZydcbiAgICAjIHdpbGwgZG8gdGhlIHJlZHJhdyBpbnNlcnRpbmcgdGhlIGltYWdlXG4gICAgdXBkYXRlZCAnY29udidcbiAgICAjIGZpeCB0aGUgcG9zaXRpb24gYWZ0ZXIgcmVkcmF3XG4gICAgdXBkYXRlZCAnYWZ0ZXJJbWcnXG5cbmhhbmRsZSAnbG9hZGVkdHdlZXQnLCAtPlxuICAgIHVwZGF0ZWQgJ2NvbnYnXG5cbmhhbmRsZSAnbG9hZGVkaW5zdGFncmFtcGhvdG8nLCAtPlxuICAgIHVwZGF0ZWQgJ2NvbnYnXG5cbmV4dHJhY3RQcm90b2J1ZlN0eWxlID0gKGF0dCkgLT5cbiAgICBocmVmID0gbnVsbFxuICAgIHRodW1iID0gbnVsbFxuXG4gICAgZW1iZWRfaXRlbSA9IGF0dD9bMF0/LmVtYmVkX2l0ZW1cbiAgICB7cGx1c19waG90bywgZGF0YSwgdHlwZV99ID0gZW1iZWRfaXRlbSA/IHt9XG4gICAgaWYgcGx1c19waG90bz9cbiAgICAgICAgaHJlZiAgPSBwbHVzX3Bob3RvLmRhdGE/LnVybFxuICAgICAgICB0aHVtYiA9IHBsdXNfcGhvdG8uZGF0YT8udGh1bWJuYWlsPy5pbWFnZV91cmxcbiAgICAgICAgaHJlZiAgPSBwbHVzX3Bob3RvLmRhdGE/LnRodW1ibmFpbD8udXJsXG4gICAgICAgIG9yaWdpbmFsX2NvbnRlbnRfdXJsID0gcGx1c19waG90by5kYXRhPy5vcmlnaW5hbF9jb250ZW50X3VybFxuICAgICAgICBpc1ZpZGVvID0gcGx1c19waG90by5kYXRhPy5tZWRpYV90eXBlIGlzbnQgJ01FRElBX1RZUEVfUEhPVE8nXG4gICAgICAgIHJldHVybiB7aHJlZiwgdGh1bWIsIG9yaWdpbmFsX2NvbnRlbnRfdXJsfVxuXG4gICAgdCA9IHR5cGVfP1swXVxuICAgIHJldHVybiBjb25zb2xlLndhcm4gJ2lnbm9yaW5nIChvbGQpIGF0dGFjaG1lbnQgdHlwZScsIGF0dCB1bmxlc3MgdCA9PSAyNDlcbiAgICBrID0gT2JqZWN0LmtleXMoZGF0YSk/WzBdXG4gICAgcmV0dXJuIHVubGVzcyBrXG4gICAgaHJlZiA9IGRhdGE/W2tdP1s1XVxuICAgIHRodW1iID0gZGF0YT9ba10/WzldXG4gICAgaWYgbm90IHRodW1iXG4gICAgICAgIGhyZWYgPSBkYXRhP1trXT9bNF1cbiAgICAgICAgdGh1bWIgPSBkYXRhP1trXT9bNV1cblxuICAgIHtocmVmLCB0aHVtYiwgb3JpZ2luYWxfY29udGVudF91cmx9XG5cbmV4dHJhY3RPYmplY3RTdHlsZSA9IChhdHQpIC0+XG4gICAgZWl0ZW0gPSBhdHQ/WzBdPy5lbWJlZF9pdGVtXG4gICAge3R5cGV9ID0gZWl0ZW0gPyB7fVxuICAgIGlmIHR5cGU/WzBdID09IFwiUExVU19QSE9UT1wiXG4gICAgICAgIGl0ID0gZWl0ZW1bXCJlbWJlZHMuUGx1c1Bob3RvLnBsdXNfcGhvdG9cIl1cbiAgICAgICAgaHJlZiA9IGl0Py51cmxcbiAgICAgICAgdGh1bWIgPSBpdD8udGh1bWJuYWlsPy51cmxcbiAgICAgICAgcmV0dXJuIHtocmVmLCB0aHVtYn1cbiAgICBlbHNlXG4gICAgICAgIGNvbnNvbGUud2FybiAnaWdub3JpbmcgKG5ldykgdHlwZScsIHR5cGVcbiJdfQ==
