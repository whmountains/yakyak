(function() {
  var Menu, check, i18n, ipc, path, remote, versionToInt;

  ipc = require('electron').ipcRenderer;

  path = require('path');

  i18n = require('i18n');

  remote = require('electron').remote;

  Menu = remote.Menu;

  ({check, versionToInt} = require('../version'));

  module.exports = view(function(models) {
    var localVersion, releasedVersion, shouldUpdate;
    // simple context menu that can only copy
    remote.getCurrentWindow().webContents.on('context-menu', function(e, params) {
      var menuTemplate;
      e.preventDefault();
      menuTemplate = [
        {
          label: 'Copy',
          role: 'copy',
          enabled: params.editFlags.canCopy
        },
        {
          label: "Copy Link",
          visible: params.linkURL !== '' && params.mediaType === 'none',
          click: function() {
            if (process.platform === 'darwin') {
              return clipboard.writeBookmark(params.linkText,
        params.linkText);
            } else {
              return clipboard.writeText(params.linkText);
            }
          }
        }
      ];
      return Menu.buildFromTemplate(menuTemplate).popup(remote.getCurrentWindow());
    });
    
    // decide if should update
    localVersion = remote.require('electron').app.getVersion();
    releasedVersion = window.localStorage.versionAdvertised;
    shouldUpdate = (releasedVersion != null) && (localVersion != null) && versionToInt(releasedVersion) > versionToInt(localVersion);
    
    return div({
      class: 'about'
    }, function() {
      div(function() {
        return img({
          src: path.join(YAKYAK_ROOT_DIR, '..', 'icons', 'icon@8.png')
        });
      });
      div({
        class: 'name'
      }, function() {
        return h2(function() {
          span('YakYak v' + localVersion);
          if (!shouldUpdate) {
            return span({
              class: 'f-small f-no-bold'
            }, ' (latest)');
          }
        });
      });
      // TODO: if objects are undefined then it should check again on next
      //        time about window is opened
      //        releasedVersion = window.localStorage.versionAdvertised
      if (shouldUpdate) {
        div({
          class: 'update'
        }, function() {
          return span(i18n.__('menu.help.about.newer:A newer version is available, please upgrade from %s to %s', localVersion, releasedVersion));
        });
      }
      div({
        class: 'description'
      }, function() {
        return span(i18n.__('title:YakYak - Hangouts Client'));
      });
      div({
        class: 'license'
      }, function() {
        return span(function() {
          em(`${i18n.__('menu.help.about.license:License')}: `);
          return span('MIT');
        });
      });
      div({
        class: 'devs'
      }, function() {
        div(function() {
          h3(i18n.__('menu.help.about.authors:Main authors'));
          return ul(function() {
            li('Davide Bertola');
            return li('Martin Algesten');
          });
        });
        return div(function() {
          h3(i18n.__('menu.help.about.contributors:Contributors'));
          return ul(function() {
            li('David Banham');
            li('Max Kueng');
            li('Arnaud Riu');
            li('Austin Guevara');
            return li('André Veríssimo');
          });
        });
      });
      return div({
        class: 'home'
      }, function() {
        var href;
        href = "https://github.com/yakyak/yakyak";
        return a({
          href: href,
          onclick: function(ev) {
            var address;
            ev.preventDefault();
            address = ev.currentTarget.getAttribute('href');
            require('electron').shell.openExternal(address);
            return false;
          }
        }, href);
      });
    });
  });

  //$('document').on 'click', '.link-out', (ev)->


}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidWkvdmlld3MvYWJvdXQuanMiLCJzb3VyY2VzIjpbInVpL3ZpZXdzL2Fib3V0LmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUEsSUFBQSxFQUFBLEtBQUEsRUFBQSxJQUFBLEVBQUEsR0FBQSxFQUFBLElBQUEsRUFBQSxNQUFBLEVBQUE7O0VBQUEsR0FBQSxHQUFPLE9BQUEsQ0FBUSxVQUFSLENBQW1CLENBQUM7O0VBQzNCLElBQUEsR0FBTyxPQUFBLENBQVEsTUFBUjs7RUFDUCxJQUFBLEdBQU8sT0FBQSxDQUFRLE1BQVI7O0VBQ1AsTUFBQSxHQUFTLE9BQUEsQ0FBUSxVQUFSLENBQW1CLENBQUM7O0VBQzdCLElBQUEsR0FBUyxNQUFNLENBQUM7O0VBRWhCLENBQUEsQ0FBQyxLQUFELEVBQVEsWUFBUixDQUFBLEdBQXdCLE9BQUEsQ0FBUSxZQUFSLENBQXhCOztFQUVBLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLElBQUEsQ0FBSyxRQUFBLENBQUMsTUFBRCxDQUFBO0FBR2xCLFFBQUEsWUFBQSxFQUFBLGVBQUEsRUFBQSxZQUFBOztJQUFBLE1BQU0sQ0FBQyxnQkFBUCxDQUFBLENBQXlCLENBQUMsV0FBVyxDQUFDLEVBQXRDLENBQXlDLGNBQXpDLEVBQXlELFFBQUEsQ0FBQyxDQUFELEVBQUksTUFBSixDQUFBO0FBQ3JELFVBQUE7TUFBQSxDQUFDLENBQUMsY0FBRixDQUFBO01BQ0EsWUFBQSxHQUFlO1FBQUM7VUFDWixLQUFBLEVBQU8sTUFESztVQUVaLElBQUEsRUFBTSxNQUZNO1VBR1osT0FBQSxFQUFTLE1BQU0sQ0FBQyxTQUFTLENBQUM7UUFIZCxDQUFEO1FBS2Y7VUFDSSxLQUFBLEVBQU8sV0FEWDtVQUVJLE9BQUEsRUFBUyxNQUFNLENBQUMsT0FBUCxLQUFrQixFQUFsQixJQUF5QixNQUFNLENBQUMsU0FBUCxLQUFvQixNQUYxRDtVQUdJLEtBQUEsRUFBTyxRQUFBLENBQUEsQ0FBQTtZQUNILElBQUcsT0FBTyxDQUFDLFFBQVIsS0FBb0IsUUFBdkI7cUJBQ0ksU0FDQSxDQUFDLGFBREQsQ0FDZSxNQUFNLENBQUMsUUFEdEI7UUFDZ0MsTUFBTSxDQUFDLFFBRHZDLEVBREo7YUFBQSxNQUFBO3FCQUlJLFNBQVMsQ0FBQyxTQUFWLENBQW9CLE1BQU0sQ0FBQyxRQUEzQixFQUpKOztVQURHO1FBSFgsQ0FMZTs7YUFlZixJQUFJLENBQUMsaUJBQUwsQ0FBdUIsWUFBdkIsQ0FBb0MsQ0FBQyxLQUFyQyxDQUEyQyxNQUFNLENBQUMsZ0JBQVAsQ0FBQSxDQUEzQztJQWpCcUQsQ0FBekQsRUFBQTs7O0lBcUJBLFlBQUEsR0FBa0IsTUFBTSxDQUFDLE9BQVAsQ0FBZSxVQUFmLENBQTBCLENBQUMsR0FBRyxDQUFDLFVBQS9CLENBQUE7SUFDbEIsZUFBQSxHQUFrQixNQUFNLENBQUMsWUFBWSxDQUFDO0lBQ3RDLFlBQUEsR0FBa0IseUJBQUEsSUFBb0Isc0JBQXBCLElBQ0EsWUFBQSxDQUFhLGVBQWIsQ0FBQSxHQUFnQyxZQUFBLENBQWEsWUFBYjs7V0FFbEQsR0FBQSxDQUFJO01BQUEsS0FBQSxFQUFPO0lBQVAsQ0FBSixFQUFvQixRQUFBLENBQUEsQ0FBQTtNQUNoQixHQUFBLENBQUksUUFBQSxDQUFBLENBQUE7ZUFDQSxHQUFBLENBQUk7VUFBQSxHQUFBLEVBQUssSUFBSSxDQUFDLElBQUwsQ0FBVSxlQUFWLEVBQTJCLElBQTNCLEVBQWlDLE9BQWpDLEVBQTBDLFlBQTFDO1FBQUwsQ0FBSjtNQURBLENBQUo7TUFFQSxHQUFBLENBQUk7UUFBQSxLQUFBLEVBQU87TUFBUCxDQUFKLEVBQW1CLFFBQUEsQ0FBQSxDQUFBO2VBQ2YsRUFBQSxDQUFHLFFBQUEsQ0FBQSxDQUFBO1VBQ0MsSUFBQSxDQUFLLFVBQUEsR0FBYSxZQUFsQjtVQUNBLElBQUEsQ0FBb0QsWUFBcEQ7bUJBQUEsSUFBQSxDQUFLO2NBQUEsS0FBQSxFQUFPO1lBQVAsQ0FBTCxFQUFpQyxXQUFqQyxFQUFBOztRQUZELENBQUg7TUFEZSxDQUFuQixFQUZBOzs7O01BU0EsSUFBRyxZQUFIO1FBQ0ksR0FBQSxDQUFJO1VBQUEsS0FBQSxFQUFPO1FBQVAsQ0FBSixFQUFxQixRQUFBLENBQUEsQ0FBQTtpQkFDakIsSUFBQSxDQUFLLElBQUksQ0FBQyxFQUFMLENBQVEsa0ZBQVIsRUFDVSxZQURWLEVBRVUsZUFGVixDQUFMO1FBRGlCLENBQXJCLEVBREo7O01BS0EsR0FBQSxDQUFJO1FBQUEsS0FBQSxFQUFPO01BQVAsQ0FBSixFQUEwQixRQUFBLENBQUEsQ0FBQTtlQUN0QixJQUFBLENBQUssSUFBSSxDQUFDLEVBQUwsQ0FBUSxnQ0FBUixDQUFMO01BRHNCLENBQTFCO01BRUEsR0FBQSxDQUFJO1FBQUEsS0FBQSxFQUFPO01BQVAsQ0FBSixFQUFzQixRQUFBLENBQUEsQ0FBQTtlQUNsQixJQUFBLENBQUssUUFBQSxDQUFBLENBQUE7VUFDRCxFQUFBLENBQUcsQ0FBQSxDQUFBLENBQUcsSUFBSSxDQUFDLEVBQUwsQ0FBUSxpQ0FBUixDQUFILENBQTZDLEVBQTdDLENBQUg7aUJBQ0EsSUFBQSxDQUFLLEtBQUw7UUFGQyxDQUFMO01BRGtCLENBQXRCO01BSUEsR0FBQSxDQUFJO1FBQUEsS0FBQSxFQUFPO01BQVAsQ0FBSixFQUFtQixRQUFBLENBQUEsQ0FBQTtRQUNmLEdBQUEsQ0FBSSxRQUFBLENBQUEsQ0FBQTtVQUNBLEVBQUEsQ0FBRyxJQUFJLENBQUMsRUFBTCxDQUFRLHNDQUFSLENBQUg7aUJBQ0EsRUFBQSxDQUFHLFFBQUEsQ0FBQSxDQUFBO1lBQ0MsRUFBQSxDQUFHLGdCQUFIO21CQUNBLEVBQUEsQ0FBRyxpQkFBSDtVQUZELENBQUg7UUFGQSxDQUFKO2VBS0EsR0FBQSxDQUFJLFFBQUEsQ0FBQSxDQUFBO1VBQ0EsRUFBQSxDQUFHLElBQUksQ0FBQyxFQUFMLENBQVEsMkNBQVIsQ0FBSDtpQkFDQSxFQUFBLENBQUcsUUFBQSxDQUFBLENBQUE7WUFDQyxFQUFBLENBQUcsY0FBSDtZQUNBLEVBQUEsQ0FBRyxXQUFIO1lBQ0EsRUFBQSxDQUFHLFlBQUg7WUFDQSxFQUFBLENBQUcsZ0JBQUg7bUJBQ0EsRUFBQSxDQUFHLGlCQUFIO1VBTEQsQ0FBSDtRQUZBLENBQUo7TUFOZSxDQUFuQjthQWNBLEdBQUEsQ0FBSTtRQUFBLEtBQUEsRUFBTztNQUFQLENBQUosRUFBbUIsUUFBQSxDQUFBLENBQUE7QUFDZixZQUFBO1FBQUEsSUFBQSxHQUFPO2VBQ1AsQ0FBQSxDQUFFO1VBQUEsSUFBQSxFQUFNLElBQU47VUFDQSxPQUFBLEVBQVMsUUFBQSxDQUFDLEVBQUQsQ0FBQTtBQUNQLGdCQUFBO1lBQUEsRUFBRSxDQUFDLGNBQUgsQ0FBQTtZQUNBLE9BQUEsR0FBVSxFQUFFLENBQUMsYUFBYSxDQUFDLFlBQWpCLENBQThCLE1BQTlCO1lBQ1YsT0FBQSxDQUFRLFVBQVIsQ0FBbUIsQ0FBQyxLQUFLLENBQUMsWUFBMUIsQ0FBdUMsT0FBdkM7bUJBQ0E7VUFKTztRQURULENBQUYsRUFNRSxJQU5GO01BRmUsQ0FBbkI7SUFuQ2dCLENBQXBCO0VBN0JrQixDQUFMOztFQVJqQjs7QUFBQSIsInNvdXJjZXNDb250ZW50IjpbImlwYyAgPSByZXF1aXJlKCdlbGVjdHJvbicpLmlwY1JlbmRlcmVyXG5wYXRoID0gcmVxdWlyZSAncGF0aCdcbmkxOG4gPSByZXF1aXJlICdpMThuJ1xucmVtb3RlID0gcmVxdWlyZSgnZWxlY3Ryb24nKS5yZW1vdGVcbk1lbnUgICA9IHJlbW90ZS5NZW51XG5cbntjaGVjaywgdmVyc2lvblRvSW50fSA9IHJlcXVpcmUgJy4uL3ZlcnNpb24nXG5cbm1vZHVsZS5leHBvcnRzID0gdmlldyAobW9kZWxzKSAtPlxuXG4gICAgIyBzaW1wbGUgY29udGV4dCBtZW51IHRoYXQgY2FuIG9ubHkgY29weVxuICAgIHJlbW90ZS5nZXRDdXJyZW50V2luZG93KCkud2ViQ29udGVudHMub24gJ2NvbnRleHQtbWVudScsIChlLCBwYXJhbXMpIC0+XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICBtZW51VGVtcGxhdGUgPSBbe1xuICAgICAgICAgICAgbGFiZWw6ICdDb3B5J1xuICAgICAgICAgICAgcm9sZTogJ2NvcHknXG4gICAgICAgICAgICBlbmFibGVkOiBwYXJhbXMuZWRpdEZsYWdzLmNhbkNvcHlcbiAgICAgICAgfVxuICAgICAgICB7XG4gICAgICAgICAgICBsYWJlbDogXCJDb3B5IExpbmtcIlxuICAgICAgICAgICAgdmlzaWJsZTogcGFyYW1zLmxpbmtVUkwgIT0gJycgYW5kIHBhcmFtcy5tZWRpYVR5cGUgPT0gJ25vbmUnXG4gICAgICAgICAgICBjbGljazogKCkgLT5cbiAgICAgICAgICAgICAgICBpZiBwcm9jZXNzLnBsYXRmb3JtID09ICdkYXJ3aW4nXG4gICAgICAgICAgICAgICAgICAgIGNsaXBib2FyZFxuICAgICAgICAgICAgICAgICAgICAud3JpdGVCb29rbWFyayBwYXJhbXMubGlua1RleHQsIHBhcmFtcy5saW5rVGV4dFxuICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgY2xpcGJvYXJkLndyaXRlVGV4dCBwYXJhbXMubGlua1RleHRcbiAgICAgICAgfV1cbiAgICAgICAgTWVudS5idWlsZEZyb21UZW1wbGF0ZShtZW51VGVtcGxhdGUpLnBvcHVwIHJlbW90ZS5nZXRDdXJyZW50V2luZG93KClcblxuICAgICNcbiAgICAjIGRlY2lkZSBpZiBzaG91bGQgdXBkYXRlXG4gICAgbG9jYWxWZXJzaW9uICAgID0gcmVtb3RlLnJlcXVpcmUoJ2VsZWN0cm9uJykuYXBwLmdldFZlcnNpb24oKVxuICAgIHJlbGVhc2VkVmVyc2lvbiA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UudmVyc2lvbkFkdmVydGlzZWRcbiAgICBzaG91bGRVcGRhdGUgICAgPSByZWxlYXNlZFZlcnNpb24/ICYmIGxvY2FsVmVyc2lvbj8gJiZcbiAgICAgICAgICAgICAgICAgICAgICB2ZXJzaW9uVG9JbnQocmVsZWFzZWRWZXJzaW9uKSA+IHZlcnNpb25Ub0ludChsb2NhbFZlcnNpb24pXG4gICAgI1xuICAgIGRpdiBjbGFzczogJ2Fib3V0JywgLT5cbiAgICAgICAgZGl2IC0+XG4gICAgICAgICAgICBpbWcgc3JjOiBwYXRoLmpvaW4gWUFLWUFLX1JPT1RfRElSLCAnLi4nLCAnaWNvbnMnLCAnaWNvbkA4LnBuZydcbiAgICAgICAgZGl2IGNsYXNzOiAnbmFtZScsIC0+XG4gICAgICAgICAgICBoMiAtPlxuICAgICAgICAgICAgICAgIHNwYW4gJ1lha1lhayB2JyArIGxvY2FsVmVyc2lvblxuICAgICAgICAgICAgICAgIHNwYW4gY2xhc3M6ICdmLXNtYWxsIGYtbm8tYm9sZCcsICcgKGxhdGVzdCknIHVubGVzcyBzaG91bGRVcGRhdGVcbiAgICAgICAgIyBUT0RPOiBpZiBvYmplY3RzIGFyZSB1bmRlZmluZWQgdGhlbiBpdCBzaG91bGQgY2hlY2sgYWdhaW4gb24gbmV4dFxuICAgICAgICAjICAgICAgICB0aW1lIGFib3V0IHdpbmRvdyBpcyBvcGVuZWRcbiAgICAgICAgIyAgICAgICAgcmVsZWFzZWRWZXJzaW9uID0gd2luZG93LmxvY2FsU3RvcmFnZS52ZXJzaW9uQWR2ZXJ0aXNlZFxuICAgICAgICBpZiBzaG91bGRVcGRhdGVcbiAgICAgICAgICAgIGRpdiBjbGFzczogJ3VwZGF0ZScsIC0+XG4gICAgICAgICAgICAgICAgc3BhbiBpMThuLl9fKCdtZW51LmhlbHAuYWJvdXQubmV3ZXI6QSBuZXdlciB2ZXJzaW9uIGlzIGF2YWlsYWJsZSwgcGxlYXNlIHVwZ3JhZGUgZnJvbSAlcyB0byAlcydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLCBsb2NhbFZlcnNpb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLCByZWxlYXNlZFZlcnNpb24pXG4gICAgICAgIGRpdiBjbGFzczogJ2Rlc2NyaXB0aW9uJywgLT5cbiAgICAgICAgICAgIHNwYW4gaTE4bi5fXygndGl0bGU6WWFrWWFrIC0gSGFuZ291dHMgQ2xpZW50JylcbiAgICAgICAgZGl2IGNsYXNzOiAnbGljZW5zZScsIC0+XG4gICAgICAgICAgICBzcGFuIC0+XG4gICAgICAgICAgICAgICAgZW0gXCIje2kxOG4uX18gJ21lbnUuaGVscC5hYm91dC5saWNlbnNlOkxpY2Vuc2UnfTogXCJcbiAgICAgICAgICAgICAgICBzcGFuICdNSVQnXG4gICAgICAgIGRpdiBjbGFzczogJ2RldnMnLCAtPlxuICAgICAgICAgICAgZGl2IC0+XG4gICAgICAgICAgICAgICAgaDMgaTE4bi5fXygnbWVudS5oZWxwLmFib3V0LmF1dGhvcnM6TWFpbiBhdXRob3JzJylcbiAgICAgICAgICAgICAgICB1bCAtPlxuICAgICAgICAgICAgICAgICAgICBsaSAnRGF2aWRlIEJlcnRvbGEnXG4gICAgICAgICAgICAgICAgICAgIGxpICdNYXJ0aW4gQWxnZXN0ZW4nXG4gICAgICAgICAgICBkaXYgLT5cbiAgICAgICAgICAgICAgICBoMyBpMThuLl9fKCdtZW51LmhlbHAuYWJvdXQuY29udHJpYnV0b3JzOkNvbnRyaWJ1dG9ycycpXG4gICAgICAgICAgICAgICAgdWwgLT5cbiAgICAgICAgICAgICAgICAgICAgbGkgJ0RhdmlkIEJhbmhhbSdcbiAgICAgICAgICAgICAgICAgICAgbGkgJ01heCBLdWVuZydcbiAgICAgICAgICAgICAgICAgICAgbGkgJ0FybmF1ZCBSaXUnXG4gICAgICAgICAgICAgICAgICAgIGxpICdBdXN0aW4gR3VldmFyYSdcbiAgICAgICAgICAgICAgICAgICAgbGkgJ0FuZHLDqSBWZXLDrXNzaW1vJ1xuICAgICAgICBkaXYgY2xhc3M6ICdob21lJywgLT5cbiAgICAgICAgICAgIGhyZWYgPSBcImh0dHBzOi8vZ2l0aHViLmNvbS95YWt5YWsveWFreWFrXCJcbiAgICAgICAgICAgIGEgaHJlZjogaHJlZlxuICAgICAgICAgICAgLCBvbmNsaWNrOiAoZXYpIC0+XG4gICAgICAgICAgICAgICAgZXYucHJldmVudERlZmF1bHQoKVxuICAgICAgICAgICAgICAgIGFkZHJlc3MgPSBldi5jdXJyZW50VGFyZ2V0LmdldEF0dHJpYnV0ZSAnaHJlZidcbiAgICAgICAgICAgICAgICByZXF1aXJlKCdlbGVjdHJvbicpLnNoZWxsLm9wZW5FeHRlcm5hbCBhZGRyZXNzXG4gICAgICAgICAgICAgICAgZmFsc2VcbiAgICAgICAgICAgICwgaHJlZlxuXG4jJCgnZG9jdW1lbnQnKS5vbiAnY2xpY2snLCAnLmxpbmstb3V0JywgKGV2KS0+XG4jXG4iXX0=
