(function() {
  var Client, LOGIN_URL, Q, session;

  Client = require('hangupsjs');

  Q = require('q');

  ({session} = require('electron'));

  // Current programmatic login workflow is described here
  // https://github.com/tdryer/hangups/issues/260#issuecomment-246578670
  LOGIN_URL = "https://accounts.google.com/o/oauth2/programmatic_auth?hl=en&scope=https%3A%2F%2Fwww.google.com%2Faccounts%2FOAuthLogin+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email&client_id=936475272427.apps.googleusercontent.com&access_type=offline&delegated_client_id=183697946088-m3jnlsqshjhh5lbvg05k46q1k4qqtrgn.apps.googleusercontent.com&top_level_cookie=1";

  // promise for one-time oauth token
  module.exports = function(mainWindow) {
    return Q.Promise(function(rs) {
      var onDidFinishLoad;
      mainWindow.webContents.on('did-finish-load', onDidFinishLoad = function() {
        var url;
        // the url that just finished loading
        url = mainWindow.getURL();
        console.log('login: did-finish-load', url);
        if (url.indexOf('/o/oauth2/programmatic_auth') > 0) {
          console.log('login: programmatic auth');
          // get the cookie from browser session, it has to be there
          return session.defaultSession.cookies.get({}, function(err, values = []) {
            var i, len, oauth_code, value;
            oauth_code = false;
            for (i = 0, len = values.length; i < len; i++) {
              value = values[i];
              if (value.name === 'oauth_code') {
                oauth_code = value.value;
              }
            }
            if (oauth_code) {
              return rs(oauth_code);
            }
          });
        }
      });
      // redirect to google oauth
      return mainWindow.loadURL(LOGIN_URL);
    });
  };

}).call(this);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9naW4uanMiLCJzb3VyY2VzIjpbImxvZ2luLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUEsTUFBQSxFQUFBLFNBQUEsRUFBQSxDQUFBLEVBQUE7O0VBQUEsTUFBQSxHQUFTLE9BQUEsQ0FBUSxXQUFSOztFQUNULENBQUEsR0FBSSxPQUFBLENBQVEsR0FBUjs7RUFDSixDQUFBLENBQUMsT0FBRCxDQUFBLEdBQVksT0FBQSxDQUFRLFVBQVIsQ0FBWixFQUZBOzs7O0VBTUEsU0FBQSxHQUFZLHlXQU5aOzs7RUFTQSxNQUFNLENBQUMsT0FBUCxHQUFpQixRQUFBLENBQUMsVUFBRCxDQUFBO1dBQWdCLENBQUMsQ0FBQyxPQUFGLENBQVUsUUFBQSxDQUFDLEVBQUQsQ0FBQTtBQUV2QyxVQUFBO01BQUEsVUFBVSxDQUFDLFdBQVcsQ0FBQyxFQUF2QixDQUEwQixpQkFBMUIsRUFBNkMsZUFBQSxHQUFrQixRQUFBLENBQUEsQ0FBQTtBQUczRCxZQUFBLEdBQUE7O1FBQUEsR0FBQSxHQUFNLFVBQVUsQ0FBQyxNQUFYLENBQUE7UUFDTixPQUFPLENBQUMsR0FBUixDQUFZLHdCQUFaLEVBQXNDLEdBQXRDO1FBRUEsSUFBRyxHQUFHLENBQUMsT0FBSixDQUFZLDZCQUFaLENBQUEsR0FBNkMsQ0FBaEQ7VUFDSSxPQUFPLENBQUMsR0FBUixDQUFZLDBCQUFaLEVBQUE7O2lCQUVBLE9BQU8sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEdBQS9CLENBQW1DLENBQUEsQ0FBbkMsRUFBdUMsUUFBQSxDQUFDLEdBQUQsRUFBTSxTQUFPLEVBQWIsQ0FBQTtBQUNuQyxnQkFBQSxDQUFBLEVBQUEsR0FBQSxFQUFBLFVBQUEsRUFBQTtZQUFBLFVBQUEsR0FBYTtZQUNiLEtBQUEsd0NBQUE7O2NBQ0ksSUFBRyxLQUFLLENBQUMsSUFBTixLQUFjLFlBQWpCO2dCQUNJLFVBQUEsR0FBYSxLQUFLLENBQUMsTUFEdkI7O1lBREo7WUFHQSxJQUFrQixVQUFsQjtxQkFBQSxFQUFBLENBQUcsVUFBSCxFQUFBOztVQUxtQyxDQUF2QyxFQUhKOztNQU4yRCxDQUEvRCxFQUFBOzthQWlCQSxVQUFVLENBQUMsT0FBWCxDQUFtQixTQUFuQjtJQW5CdUMsQ0FBVjtFQUFoQjtBQVRqQiIsInNvdXJjZXNDb250ZW50IjpbIkNsaWVudCA9IHJlcXVpcmUgJ2hhbmd1cHNqcydcblEgPSByZXF1aXJlICdxJ1xue3Nlc3Npb259ID0gcmVxdWlyZSgnZWxlY3Ryb24nKVxuXG4jIEN1cnJlbnQgcHJvZ3JhbW1hdGljIGxvZ2luIHdvcmtmbG93IGlzIGRlc2NyaWJlZCBoZXJlXG4jIGh0dHBzOi8vZ2l0aHViLmNvbS90ZHJ5ZXIvaGFuZ3Vwcy9pc3N1ZXMvMjYwI2lzc3VlY29tbWVudC0yNDY1Nzg2NzBcbkxPR0lOX1VSTCA9IFwiaHR0cHM6Ly9hY2NvdW50cy5nb29nbGUuY29tL28vb2F1dGgyL3Byb2dyYW1tYXRpY19hdXRoP2hsPWVuJnNjb3BlPWh0dHBzJTNBJTJGJTJGd3d3Lmdvb2dsZS5jb20lMkZhY2NvdW50cyUyRk9BdXRoTG9naW4raHR0cHMlM0ElMkYlMkZ3d3cuZ29vZ2xlYXBpcy5jb20lMkZhdXRoJTJGdXNlcmluZm8uZW1haWwmY2xpZW50X2lkPTkzNjQ3NTI3MjQyNy5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSZhY2Nlc3NfdHlwZT1vZmZsaW5lJmRlbGVnYXRlZF9jbGllbnRfaWQ9MTgzNjk3OTQ2MDg4LW0zam5sc3FzaGpoaDVsYnZnMDVrNDZxMWs0cXF0cmduLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tJnRvcF9sZXZlbF9jb29raWU9MVwiXG5cbiMgcHJvbWlzZSBmb3Igb25lLXRpbWUgb2F1dGggdG9rZW5cbm1vZHVsZS5leHBvcnRzID0gKG1haW5XaW5kb3cpIC0+IFEuUHJvbWlzZSAocnMpIC0+XG5cbiAgICBtYWluV2luZG93LndlYkNvbnRlbnRzLm9uICdkaWQtZmluaXNoLWxvYWQnLCBvbkRpZEZpbmlzaExvYWQgPSAtPlxuXG4gICAgICAgICMgdGhlIHVybCB0aGF0IGp1c3QgZmluaXNoZWQgbG9hZGluZ1xuICAgICAgICB1cmwgPSBtYWluV2luZG93LmdldFVSTCgpXG4gICAgICAgIGNvbnNvbGUubG9nICdsb2dpbjogZGlkLWZpbmlzaC1sb2FkJywgdXJsXG5cbiAgICAgICAgaWYgdXJsLmluZGV4T2YoJy9vL29hdXRoMi9wcm9ncmFtbWF0aWNfYXV0aCcpID4gMFxuICAgICAgICAgICAgY29uc29sZS5sb2cgJ2xvZ2luOiBwcm9ncmFtbWF0aWMgYXV0aCdcbiAgICAgICAgICAgICMgZ2V0IHRoZSBjb29raWUgZnJvbSBicm93c2VyIHNlc3Npb24sIGl0IGhhcyB0byBiZSB0aGVyZVxuICAgICAgICAgICAgc2Vzc2lvbi5kZWZhdWx0U2Vzc2lvbi5jb29raWVzLmdldCB7fSwgKGVyciwgdmFsdWVzPVtdKSAtPlxuICAgICAgICAgICAgICAgIG9hdXRoX2NvZGUgPSBmYWxzZVxuICAgICAgICAgICAgICAgIGZvciB2YWx1ZSBpbiB2YWx1ZXNcbiAgICAgICAgICAgICAgICAgICAgaWYgdmFsdWUubmFtZSBpcyAnb2F1dGhfY29kZSdcbiAgICAgICAgICAgICAgICAgICAgICAgIG9hdXRoX2NvZGUgPSB2YWx1ZS52YWx1ZVxuICAgICAgICAgICAgICAgIHJzKG9hdXRoX2NvZGUpIGlmIG9hdXRoX2NvZGVcblxuICAgICMgcmVkaXJlY3QgdG8gZ29vZ2xlIG9hdXRoXG4gICAgbWFpbldpbmRvdy5sb2FkVVJMIExPR0lOX1VSTFxuIl19
